# Independent external player-response review: 26.1.2 → 26.2

## Verdict

This review does **not** endorse full-pair closure. It found no new semantic difference in the client packet receivers, entity push primitives, or the listed block-contact callbacks that I traced. The changed shared `Entity.move` terminal and restitution path are already recorded in the permitted ordinary-closure projection. The external census remains supplemental and bounded: this audit did not establish exhaustive closure of every client callback producer and inherited terminal in roster items 2 and 4.

The main actionable point for integration is to keep the pair open until the remaining client callback and producer inventory is independently closed. The allowed projection explicitly leaves entity/entity pushes and fluids outside its coverage; this review traced the local-player push path and paired the fluid-jump threshold gate, but it is not a replacement full inventory of every callback producer.

## Source identity

Both canonical trees and ready/provenance records match the exact requested versions and `unobfuscated` namespace. The allowed coverage projection records clean source-manifest verification for both trees:

- 26.1.2 source-manifest SHA-256: `54ae320660ca911a6d20514c965c33eb414fbedd1ad6727bbaa95fe906aa23c0`.
- 26.2 source-manifest SHA-256: `a7ad74fc712567eb87136afc1eafcfd602b4088e9869f3596331fd34faefe894`.

Key paired source-file SHA-256 identities used here:

| Relative source file | 26.1.2 | 26.2 |
|---|---|---|
| `net/minecraft/client/multiplayer/ClientPacketListener.java` | `EB70D05E4F8429341FC41823EAE2CC662560EFA1E44C8B729DB5477501718D82` | `9CB0CC8AFEBAE9F4E42F428A52719C645817D03893DC371E6711C7BD16EAC1B6` |
| `net/minecraft/client/player/LocalPlayer.java` | `433FD995AD317AF0F6EF0E50C1E8E3483CB8F00E0E327D4EDF27A4DD99666EBE` | `8D089AA09217E3607B38590F7C1623385562800943AC6DFD3D17804E041DA6D6` |
| `net/minecraft/world/entity/Entity.java` | `8B83B1F036AABBD13D990897C540C993F7120F02955486CFCF229517D4097CCF` | `7AFB9C1294893FFE73E3B1ACFFCAD41C648F15DE8378BFF3DFFAFF869BB811D5` |
| `net/minecraft/world/entity/LivingEntity.java` | `C3B64DE8DBABA8AD8A7CCD4F33255346D8206E66F12CA91260971BF5E5AC93BD` | `7FFD9C70966EDC50C9CB4D9A8FE17A518E2678FF44C8026E763D0B94AC0AE51A` |
| `net/minecraft/world/entity/player/Player.java` | `44CF28E0C64E78D39FD13368E9991381DBEBAB67029070CB9DDC43F09D45D14D` | `8DECC71B9C780664578DDB14591DB2A2F207C72C05B676EDDED6F8E964576531` |

## Ordered roster audit

### 1. Local-player packet receivers

Traced the client receiver and recipient paths in `ClientPacketListener` for motion (`handleSetEntityMotion`, 26.1.2 lines 620–630 / 26.2 lines 619–629), metadata (633–637 / 632–636), position synchronization (640–666 / 639–665), vehicle-teleport fallback and teleport (669–707 / 668–706), entity movement and local-authority gate (732–754 / 731–753), player correction and relative-value application (796–841 / 795–840), passenger vehicle rotation (1156–1171 / 1154–1169), explosion knockback (1361–1378 / 1359–1376), and respawn/replacement (1253–1345 / 1251–1343).

The movement writes and gates are unchanged in the compared method bodies. `handleExplosion` forwards optional `playerKnockback` to the actual local player through `addDeltaMovement` in both releases. `handleRespawn` preserves or resets the same movement, rotation, metadata, and attribute state; differences in this method are screen/renderer API changes. `handleSetPassengersPacket` likewise retains the same mount and boat-rotation writes; its difference is overlay UI routing. The selected packet methods for effects, effect removal, equipment, abilities, and attributes retain the same writes and gates; `handleUpdateMobEffect` and `handleUpdateAttributes` only use equivalent pattern-matching/cast syntax changes.

`handleMoveEntity` updates only the position codec for a locally authoritative entity. `handleMovePlayer` applies the correction only when the player is not a passenger. Teleport and position-sync branches retain their local-authority, interpolation-distance, indirect-passenger, and on-ground gates. No packet-handler difference was found that changes those outcomes.

Paired receiver member starts in `ClientPacketListener.java` (26.1.2 / 26.2): `handleSetEntityMotion` 624 / 623; `handleSetEntityData` 633 / 632; `handleEntityPositionSync` 642 / 641; `handleTeleportEntity` 669 / 668; `handleMoveEntity` 732 / 731; `handleMovePlayer` 796 / 795; `handleRotatePlayer` 832 / 831; `handleSetPassengersPacket` 1146 / 1144; `handleRespawn` 1253 / 1251; `handleExplosion` 1361 / 1359; `handleSetEquipment` 1512 / 1510; `handleUpdateMobEffect` 1795 / 1794; `handleRemoveMobEffect` 1982 / 1980; `handlePlayerAbilities` 2087 / 2089; `handleUpdateAttributes` 2355 / 2357. The paired class hashes above bind these exact members. Except for equivalent cast syntax and unrelated GUI/renderer API changes, the compared movement writes, values, receiver-to-player routing, and gates are the same.

### 2. Client event and callback writers

The `ClientboundSetEntityDataPacket` path reaches `SynchedEntityData.assignValues`, then `Entity.onSyncedDataUpdated` and the `LivingEntity` / `LocalPlayer` overrides. The dimension-refresh callback bodies are unchanged. `ClientboundEntityEventPacket` dispatch reaches `Entity`, `LivingEntity`, `Player`, or `LocalPlayer.handleEntityEvent`; the inspected event override bodies are unchanged, and no movement-state write difference was found there. The respawn replacement path above is the packet-driven replacement writer.

Paired inherited callback member starts (26.1.2 / 26.2): `Entity.onSyncedDataUpdated(EntityDataAccessor)` 3306 / 3379; `LivingEntity.onSyncedDataUpdated` 3459 / 3525; `LocalPlayer.onSyncedDataUpdated` 583 / 583; `Entity.handleEntityEvent` 2587 / 2654; `LivingEntity.handleEntityEvent` 2035 / 2067; `Player.handleEntityEvent` 412 / 413; `LocalPlayer.handleEntityEvent` 505 / 505; `LocalPlayer.resetPos` 748 / 748. These methods are equal by body in the paired files.

`LivingEntity.aiStep` continues to route post-travel block effects to `Entity.applyEffectsFromBlocks`, which dispatches support `stepOn`, block `entityInside`, and fluid-state `entityInside` callbacks. The allowed prior projection covers the listed honey, web, berry, powder-snow, bubble-column, climbable, landing, and piston responses and records their compared formulas/gates. Additional obvious movement-call search hits in `PumpkinBlock` and `BrushableBlockEntity` create or initialize dropped `ItemEntity` motion on `ServerLevel`; they do not write local-player movement.

One adjacent fluid gate was paired as a no-difference check: `LivingEntity.aiStep` uses the 26.1.2 lava test `onGround() && !(fluidHeight > fluidJumpThreshold)` (line 3043) and the 26.2 `onGround() && isInShallowFluid(FluidTags.LAVA)` (line 3110); the new helper at 26.2 line 2545 returns `getFluidHeight(fluidTag) <= getFluidJumpThreshold()`, the same finite-height threshold condition. The old/new `travelInLava` inline threshold is also `<=` in both releases (26.1.2 line 2499; 26.2 line 2552). This check does not close the broader ordinary fluid/travel inventory.

### 3. Entity/entity push with local-player recipient

The actual recipient route is reachable client-side: `LivingEntity.aiStep` invokes `pushEntities`; its `Level.getPushableEntities` list is passed through `doPush`, and `Entity.push(Entity)` can apply the impulse to either pushable, non-vehicle endpoint. `Player` inherits the living pushability predicate, so a local player can receive the shared `Entity.push` write regardless of which colliding entity runs the push loop. The shared `Entity.push(Entity)`, `push(Vec3)`, and `push(double,double,double)` bodies, `LivingEntity.push`, `pushEntities`, `doPush`, `isPushable`, and the `Player` local-authority override are equal between the pair. They retain the finite-vector checks, same-vehicle/no-physics gates, and recipient pushability/vehicle gates.

Paired member starts (26.1.2 / 26.2): `Entity.push(Entity)` 1789 / 1876; `Entity.push(Vec3)` 1820 / 1907; `Entity.push(double,double,double)` 1826 / 1913; `LivingEntity.push(Entity)` 2304 / 2341; `LivingEntity.pushEntities` 3165 / 3232; `LivingEntity.doPush` 3214 / 3281; `LivingEntity.isPushable` 3310 / 3376; `Player.isLocalClientAuthoritative` 1260 / 1281. The base `Entity.isLocalInstanceAuthoritative`, `isLocalClientAuthoritative`, and `canSimulateMovement` method bodies are also equal (old starts 3517, 3520, 3523; new starts 3590, 3593, 3596).

Pushed velocity later reaches the shared `Entity.move` collision terminal. Its old/new changes are part of the allowed ordinary-closure projection (including restitution and the collision/fall-response ordering), not a newly observed push-writer difference.

### 4. Block/entity collision-adjacent direct responses

The direct player callback sources enumerated by the allowed projection remain the paired evidence for their listed operations. The traced path remains `move` / `applyEffectsFromBlocks` → support or inside callback → direct `Entity`/`LivingEntity` response. Piston displacement reaches the same `Entity.move(MoverType.PISTON, ...)` terminal; its local-player recipient is not excluded because it is implemented on `Entity`. No additional external-only block/entity movement writer was accepted from this audit. Full closure of all vanilla callback producers is still open.

Direct callback bodies paired in the canonical trees: `SlimeBlock.stepOn` (old/new line 50 / 30), `HoneyBlock.entityInside` (64 / 64), `PowderSnowBlock.entityInside` (62 / 62), `SweetBerryBushBlock.entityInside` (82 / 82), `WebBlock.entityInside` (27 / 27), `BubbleColumnBlock.entityInside` (53 / 53), and both piston writers `moveCollidedEntities` and `moveEntityByPiston` (120 and 192 in both). Those bodies retain their movement gates/writes; SweetBerry's entity-type symbol changed namespace spelling, while its direct stuck-speed write is unchanged. The historical `Block.updateEntityMovementAfterFallOn` and the `BedBlock`/`SlimeBlock` overrides are present in 26.1.2 (Block line 498; Bed line 138; Slime line 33) and absent in 26.2, as already represented by the ordinary restitution projection.

Paired file hashes for this callback subset (old / new): `Block.java` `1693CFB7B84190A2FE664470A56D59E78ED5BD7D722A2BD16888B036D4D8E977` / `CEC6A05E644E4A7FEB8253CC4CA772A98F0E116FB098A1B7EE7302984AC7ECAB`; `BedBlock.java` `996E4CA63F4BFAEA14B215648F2318D52C49F6C802317381A670D87C0A6D0B03` / `22F515C272D52EEBD75456E4A78EB7F38708D682F8D2CB5FDC170E7C3105AF2B`; `SlimeBlock.java` `84D22CF526D6BF1B4EC4B0B642A76FC2C90380A71F05AB92A7DE9935F0D1C38E` / `E0FC3087B66777A2800676AAEEE47A6E98395EA4C964D5A301F3A73B3577C754`; `HoneyBlock.java` `998AFF733F7BB654FCD837680375BA740574D3371D39BD708DBDAE352D4782EC` / `AD1626F8B2C7AC39BDAE01DE7F8D5DBEC0FB4193057DEA33E39E0C7CC3C1B6AA`; `PowderSnowBlock.java` `5733056253C3F9C7D843E8E7C29DEAEE67D235D830C63C0641F3A7B70604970F` / `2B693BE4A4D3CF2B1895096431C16D7BA3AE51B9CF4320773D384BDD146BA417`; `SweetBerryBushBlock.java` `CA930F1C40D72A03E55E9972A58B4CC3DF645EA918625125B4255343BF893A1D` / `39883C99ABC12E6F6B654F025A2340396F86FEA4E9BEA6D9F5283172EF61699B`; `WebBlock.java` `8AFB61BEA4D6FC8502971D0729C6A2F87F4F55D618AE6ED3251B95141F524AF5` / same; `BubbleColumnBlock.java` `ECE83C008E6F8391B468DAFE445C288630215FDFF490DEFEE50CB7766771E039` / same; `PistonMovingBlockEntity.java` `67BCEB946C172C5C022663FDA32D123A6BBB85CA4171705CA9DC2C54105AB6E6` / `706BAB1A13BA99BBD334AAD853B99F72DF58FCE5B6B67D30D41F902B63DD8E06`.

### 5. Attribute, effect, equipment, ability, and metadata delivery

The paired `ClientPacketListener` receiver paths continue to update a matching `LivingEntity` in the client `Level`; their local-player eligibility is the entity lookup/`instanceof LivingEntity` gate. Attribute values/modifiers, effect add/remove, equipment slot writes, abilities, and metadata handling have no movement-write/gate semantic change in the reviewed receiver methods. Attribute/effect-dependent ordinary travel behavior remains outside this external-receiver conclusion.

### 6. Inherited terminal writers

`Entity.move` is the changed inherited terminal: 26.1.2 performs horizontal collided-component zeroing and the historical support-block `updateEntityMovementAfterFallOn` callback; 26.2 calls `restituteMovementAfterCollisions` under its collision gate. This has a local-player route for self movement, piston displacement, and subsequent movement after an entity push. It is already described in the allowed ordinary-closure projection and is not duplicated as a new external finding here. Other checked terminal methods—entity push overloads, metadata dimension refresh, `Player.makeStuckInBlock`, `LocalPlayer.resetPos`, and synced-data callback chain—are method-body identical across these releases.

## Remaining coverage gate

This is not a full roster freeze. Roster items 2 and 4 still require an exhaustive paired enumeration of all client-reachable callback producers and changed inherited terminal dependencies, with exact per-candidate ordinal/file/member/hash identities. The allowed prior projection itself leaves fluid handling and entity/entity obstacle responses outside its earlier ordinary-closure boundary; this review traced the push core and checked a fluid threshold but did not establish every fluid/contact producer or every eligible block/entity callback. Do not mark the supplemental census or pair closed from this review alone.
