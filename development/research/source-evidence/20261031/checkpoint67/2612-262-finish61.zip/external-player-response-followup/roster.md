# Frozen external player-response census roster: 26.1.2 → 26.2

Frozen before reopening any pair source bodies. Scope is only externally triggered, client-reachable writes that directly affect the local player's movement state or the predicates/routing selecting those writes. Pair source roots and source identity are the exact canonical `26.1.2/unobfuscated` and `26.2/unobfuscated` trees and ready/provenance sidecars already recorded in the parent coverage. Prior source-only movement projection remains permitted only for explicitly covered ordinary collision/restition operations. This supplemental census does not reopen ordinary travel formulas already covered.

## Ordinal source roster

1. **Local player packet receivers:** all client packet receiver methods capable of setting local-player position, delta movement, yaw/pitch, body/head rotations, interpolation targets, pose, abilities, attributes, effects, equipment, metadata, or respawn/replacement state; include correction flags, passenger/local-authority gates, and side effects/callbacks reached by those methods. Candidate file roots: `client/multiplayer/ClientPacketListener`, packet listener dispatch, `client/player/LocalPlayer`, `Player`, and `Entity`.
2. **Client event and callback writers:** exact direct movement-state writes for local-player events not delivered through packet receivers, including local-player tick/contact callbacks, teleport/respawn/portal, entity state sync, block contact, fluid/climb/stuck callbacks, and their vanilla block/entity producers. Exclude changes that only mutate health/food/damage or server-owned state, but retain client-side direct player responses to old-feature valid state.
3. **Entity/entity push with local-player recipient:** both overloads of `Entity.push`, `LivingEntity.push`, push collection/callback dispatch and all gates that decide which recipient executes the write. Keep entity/vehicle physics out of scope, while tracing the actual recipient predicate when the local `Player` itself can be pushed.
4. **Block/entity collision-adjacent direct responses:** old-feature-valid direct player writes from moving pistons, shulker/block entities, powder snow, honey, cobweb, berries, climbable/bubble contacts and collision/inside callbacks; include neighboring-state, entity type and client/server gates. Exclude damage results and server-only block-state production.
5. **Attribute/effect/player state delivery:** client-side installation/removal of attributes, effects, equipment, player abilities, and metadata when these alter a movement writer or gate in rows 1–4; pair the producer/receiver plumbing only as needed to establish client reachability and equal/raw values.
6. **Inherited terminal writers:** every changed method reached from rows 1–5 that writes local `Player`/`LivingEntity` position, delta, rotation, pose, box, collision flags, fall distance, or movement interpolation. Record unchanged inherited terminals as paired evidence and continue until the write or a bounded scope exclusion.

## Candidate identity and deduplication

Deduplicate by `(ordinal roster item, canonical relative source file, member, old file hash, new file hash)`. Record exact member line ranges, paired file SHA-256 values, caller order, preconditions, client/server/local-player/vehicle gates, written field, and whether unchanged. Do not use packet class/name alone to infer receiver behavior. Do not classify a local-player recipient as out of scope merely because the operation is implemented in shared `Entity` physics.

## Review boundary

Source-only fixed old-profile state. Allowed canonical inputs are the exact paired source trees, their per-version ready/provenance records, and the prior ordinary-closure projection. No product code, wiki, backlog, Git history, runtime, builds, or tests. This roster is a supplementary census; it must not modify or replace the earlier historical audit.
