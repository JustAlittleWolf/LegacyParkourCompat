# Entity push and attack-response census — 26.1.2 → 26.2

## Bounded result

Source-only comparison of the frozen external-response roster and the permitted ordinary-collision projection, with the additional push/knockback callback routes requested during the census. This covers entity/entity push to a client local Player, entity-event and attached-firework responses, the ordinary client attack self-damping path, and server-only mob/stab knockback producers. It is not full-pair closure.

Canonical sources: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\26.1.2\unobfuscated` and `...\26.2\unobfuscated`. The parent `coverage.md` records the ready/provenance sidecars, source-manifest hashes, and clean per-source verification for both roots; this report inherits that source identity.

## Findings

### 1. Living-entity collision push reaches the local Player on the client; no movement-body delta found

The tick path already established by the ordinary projection reaches `LivingEntity.pushEntities` from `LocalPlayer.aiStep` → `Player.aiStep` → `LivingEntity.aiStep`. The same `pushEntities` loop is also used by other client-ticked living entities, including mobs: its only `ServerLevel` branch is the cramming damage check; iteration and `doPush` run after that branch on either side.

- `EntitySelector.pushableBy` (`net/minecraft/world/entity/EntitySelector.java:29-56`, both versions) rejects non-pushable candidates and spectators. On a client level it admits only a `Player` for which `isLocalPlayer()` is true, then applies team collision rules. `LocalPlayer.isLocalPlayer()` returns true (`net/minecraft/client/player/LocalPlayer.java:378-380`, both versions). `Level.getPushableEntities` dispatches this predicate (`net/minecraft/world/level/Level.java:852-854` / `857-859`).
- A mob’s `LivingEntity.pushEntities` obtains that list and calls `doPush` without a client-side exclusion (`LivingEntity.java:3165-3188` / `3232-3256`). `doPush` invokes `candidate.push(this)` (`:3214-3216` / `:3281-3283`). For the local Player candidate, `LivingEntity.push(Entity)` adds a sleeping guard and otherwise delegates (`:2303-2308` / `:2340-2345`).
- `Entity.push(Entity)` skips same-vehicle pairs and no-physics pairs; it requires horizontal separation `dd >= 0.01`, and independently writes each participant only when that participant is not a vehicle and is pushable (`Entity.java:1789-1818` / `1876-1905`). A pushable living recipient is alive, not spectator, and not on a climbable (`LivingEntity.java:3310-3312` / `3376-3378`). The local recipient’s `push(double,double,double)` adds the computed impulse to its delta and marks `needsSync` (`Entity.java:1826-1831` / `1913-1918`). There is no logical-side gate on this write.

The paired push arithmetic, recipient gates, sleeping override, candidate selector, and collection callback are behaviorally unchanged in the cited members. File hashes differ for the larger `Entity`, `LivingEntity`, and `Level` files, but the line-local push members above retain the same operations and ordering. `EntitySelector.java` is byte-identical across the pair.

### 2. Client entity callbacks directly write local-Player movement

**Fishing hook pull.** `FishingHook.handleEntityEvent` responds only to event `31`, only on a client level, and only when `hookedIn` is a local `Player`; it calls `pullEntity` (`FishingHook.java:496-502,504-510` / `497-503,505-511`). With a non-null owner, `pullEntity` adds `0.1 * (owner position − hook position)` to that hooked entity’s delta movement. This is a direct local-client movement write. The paired event predicate, vector formula, and write are unchanged.

**Ravager roar.** The server roar requires a `ServerLevel`, selects entities in a four-block inflated box, and broadcasts event `69` (`Ravager.java:222-238` / `223-239`). On receipt, `handleEntityEvent(69)` calls `applyRoarKnockbackClient`; that loop selects living entities in the same box using `ROAR_TARGET_ON_CLIENT`, then calls `strongKnockback` (`:241-267` / `242-268`). The selector excludes Ravagers and dead entities and requires `isLocalInstanceAuthoritative` (`:47-51` / `48-52`). A local Player satisfies this through `Entity.isLocalInstanceAuthoritative` → `Player.isLocalClientAuthoritative` → `Player.isLocalPlayer` (`Entity.java:3516-3528`, `Player.java:1254-1266`, `LocalPlayer.java:378-380` / `Entity.java:3589-3601`, `Player.java:1275-1287`, `LocalPlayer.java:378-380`). `strongKnockback` calls `entity.push(dx/dd*4, 0.2, dz/dd*4)` (`Ravager.java:247-252` / `248-253`). This callback therefore applies client-side knockback to the local Player. The paired predicate, callback order, and impulse formula are unchanged. The server roar’s regular damage/knockback path is a separate server producer; for Players, its server loop does not call `strongKnockback` because that branch excludes `Player`.

**Attached firework boost.** The constructor taking a `LivingEntity stuckTo` stores its entity id and target (`FireworkRocketEntity.java:77-81` / `78-82`). In `tick`, a resolved attached living entity that is fall-flying has its delta movement replaced with `movement + look*0.1 + (look*1.5 − movement)*0.5` (`:113-148` in both versions). There is no side gate around this target write. Thus an attached rocket whose synced target is the local Player can directly update local-player movement each client tick while fall-flying. The paired boost formula and gates are unchanged; surrounding file hashes differ.

### 3. Ordinary local-player attack self-damping is client-reachable, with unchanged local formula

`MultiPlayerGameMode.attack` sends the attack packet and then invokes `player.attack(entity)` locally (`MultiPlayerGameMode.java:425-430` / `426-431`). `Player.attack` reaches its extra-knockback call only when `hurtOrSimulate` returns true (`Player.java:984-988` in both versions). On a client, `RemotePlayer.hurtClient` returns true (`RemotePlayer.java:31-34`, identical source hash across the pair), giving a concrete successful simulated target. If the knockback amount is positive, `Player.causeExtraKnockback` applies target knockback/push, multiplies the attacking Player’s own delta movement by `(0.6, 1.0, 0.6)`, and clears sprinting (`Player.java:1120-1136` / `1122-1150`). This is a client-reachable local-player self-damping write. The self-damping multiplication and sprint gate are unchanged; the 26.2 signature and target-knockback arguments gained damage/effect context. This finding is conditional on a successful client-simulated hit and positive knockback amount; it is not a claim that every ordinary attack damps movement.

### 4. Changed stab-attack damping is server-routed, not a local client write

`Player.stabAttack` changes its knockback call shape: 26.1.2 calls `causeExtraKnockback` once with `0.4 + getKnockback(...)` (`Player.java:1218-1222`); 26.2 calls it once with `0.4` and again with `getKnockback(...)` (`:1238-1243`). Each positive call also performs the Player self-damping described above, so the changed split can produce two server-side damping writes when both amounts are positive.

The local `MultiPlayerGameMode.piercingAttack` sends the `STAB` action and does not call `weapon.attack` locally (`MultiPlayerGameMode.java:515-521` / `520-526`). The paired `ServerGamePacketListenerImpl` is where that action invokes `PiercingWeapon.attack` (`:1276-1288` / `1285-1295`), which calls `attacker.stabAttack` (`PiercingWeapon.java:69-83`, both versions). Kinetic-weapon stab processing is likewise gated server-side: `ItemStack` calls `KineticWeapon.damageEntities` only under `!level.isClientSide()` (`ItemStack.java:1098-1103`, both versions), and that method’s hit loop calls `livingEntity.stabAttack` (`KineticWeapon.java:98-132`, both versions). Therefore the split is a changed server-authoritative producer, not a direct local-client movement writer in these source routes. Any later synchronized response belongs to the separate packet-response census.

### 5. Monster damage knockback remains server-only in these caller paths

`Mob.doHurtTarget` takes `ServerLevel`, calls `target.hurtServer`, and applies extra knockback only when the server hurt succeeds (`Mob.java:1359-1375` / `1389-1410`). In 26.1.2 `LivingEntity.hurtServer(ServerLevel,...)` computes and invokes the default knockback inline (`LivingEntity.java:1155-1238`); 26.2 routes it through `dealDefaultKnockback` from the same server-only method (`:1176-1249,1290-1306`). The knockback terminal body still writes the target delta (`:1612-1630` / `1641-1659`), with a source/damage-extended signature in 26.2. These are server-side movement producers and do not replay historical client movement; a network correction resulting from them is outside this bounded source census.

## Paired source file SHA-256

Paths are relative to the two canonical roots named above. These are whole-file hashes; method-level conclusions above are based on the listed paired line ranges, not on hash equality alone.

| Source file | 26.1.2 SHA-256 | 26.2 SHA-256 |
|---|---|---|
| `net/minecraft/world/entity/Entity.java` | `8b83b1f036aabbd13d990897c540c993f7120f02955486cfcf229517d4097ccf` | `7afb9c1294893ffe73e3b1acffcad41c648f15de8378bff3dffaff869bb811d5` |
| `net/minecraft/world/entity/LivingEntity.java` | `c3b64de8dbaba8ad8a7ccd4f33255346d8206e66f12ca91260971bf5e5ac93bd` | `7ffd9c70966edc50c9cb4d9a8fe17a518e2678ff44c8026e763d0b94ac0ae51a` |
| `net/minecraft/world/entity/EntitySelector.java` | `0735f67b48018b7fc12737e06085cdf194a138edb75f5f95b83c0a9451be589b` | `0735f67b48018b7fc12737e06085cdf194a138edb75f5f95b83c0a9451be589b` |
| `net/minecraft/world/level/Level.java` | `77cc835fc1a79cd970bc3f4897fe5f398958fcbc874400c297f465f0c7819f01` | `1ae4f565ad909f4e90786089b5b4f125e8a7d18e2ef7d8c376172a5787fc5639` |
| `net/minecraft/client/player/LocalPlayer.java` | `433fd995ad317af0f6ef0e50c1e8e3483cb8f00e0e327d4edf27a4dd99666ebe` | `8d089aa09217e3607b38590f7c1623385562800943ac6dfd3d17804e041da6d6` |
| `net/minecraft/client/player/RemotePlayer.java` | `b9154c415720ecf330e1aeeb87b6de6f26b03168bc652fbff5ac1cc08ff6be94` | `b9154c415720ecf330e1aeeb87b6de6f26b03168bc652fbff5ac1cc08ff6be94` |
| `net/minecraft/world/entity/player/Player.java` | `44cf28e0c64e78d39fd13368e9991381dbebab67029070cb9ddc43f09d45d14d` | `8decc71b9c780664578ddb14591db2a2f207c72c05b676edded6f8e964576531` |
| `net/minecraft/client/multiplayer/MultiPlayerGameMode.java` | `674fe62b7debec3fa582735ae1b86247a25211ec03ec19c9f331dd3c44502e37` | `35bbed576b007d610e1892c95dd6fc1ffaa7f216535709cc07bd422c2e039566` |
| `net/minecraft/world/entity/Mob.java` | `b8bd38fd1ab88eb38ebafd8801654daf5fba06400cb8ef7764653e41846e5d94` | `c7e6b640abea491f228f71b58eab04f32caed55cece8eabd9c6d03fca8098164` |
| `net/minecraft/world/item/ItemStack.java` | `26ba4af70893fae5107105ed46ed28cd3d51c7b4aba22bc8810f01b82177e146` | `c9d29d21e59a75fdeccdc68f115585114e2e489eed3b25148e3bbc61ce0bd0dc` |
| `net/minecraft/world/item/component/KineticWeapon.java` | `91f43a4ecd0bbcd2f412dbc67df4221268eefe0dcc5fb88a30f737ff40d92ea0` | `066547ee8d79d75ee20ee4025a511c43954ee07a8c1ea483f5dbd0bbc29e2db5` |
| `net/minecraft/world/item/component/PiercingWeapon.java` | `8c854c02d95a6208fc9306e49101cb26ec3e5747d84e74c26eefa6b1c161e355` | `5c5277fb61b820e4dfffd306a058f8b613594c632ceffce892049140c1779621` |
| `net/minecraft/server/network/ServerGamePacketListenerImpl.java` | `7e643834e2ab54bd1b1aeb79f72146ac4e1f6d30b34e7608091a9ab15494d3e7` | `2015d9e3c8d3e277bc2ef9e709ad4c991894df1deaa2eaca3a5a5dcc29fb51d2` |
| `net/minecraft/world/entity/projectile/FishingHook.java` | `5c36ad0e62c7bacf0da595a72251c1ed2941e6e15bd5c6ef04cb5042965e9a6a` | `82b6d45c5fef7b964ae4800ad9b6fb83ea6648a4f55e296c877bb7cf153cbdd4` |
| `net/minecraft/world/entity/monster/Ravager.java` | `7d50321803fdf1b9a1b455b2c665abf16285e747fde78efb0368a2c597f5b7b0` | `4963ba7f12d3946015f71cc22ddf0bc2d6f215ba64fc6dadd804a7e0ad74fa8e` |
| `net/minecraft/world/entity/projectile/FireworkRocketEntity.java` | `89ff34ad8a9710f1e2049212cff451cf8651f59a480862857ce13164d7bf6833` | `59450230e450df84d9fb8311e4424cac702a58609c248369f58ad1ba1abbda6c` |

## Closure boundary

This bounded pass found four unchanged client-side non-ordinary movement inputs to the local Player (entity push, fishing-hook pull, Ravager event knockback, and attached-firework boost; the latter three are distinct callback/entity sources), plus unchanged ordinary-attack self-damping when the client-simulated target reports a hit. It found a changed stab-attack self-damping sequence only on server-routed calls. Mob damage knockback remains server-side. Other roster rows and entity-originated producers outside these named paths were not audited here.

