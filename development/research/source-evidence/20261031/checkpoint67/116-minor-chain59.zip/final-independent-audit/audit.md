# Independent source audit: 1.16 minor chain, final 11-draft roster

Audit date: 2026-10-31  
Verdict: **Do not freeze.** The current 11-draft 1.16.1→1.16.2 roster is not complete: an additional common-state player-movement candidate is `Entity.isInRain()` and the local Riptide response in `TridentItem`. Both packet candidates are applicable to `LocalPlayer`; the contrary gate interpretation is corrected below. Other screened findings are source-confirmed with listed corrections/dispositions. This is source evidence only; no producer, runtime reachability, or trajectory claim is made.

## Scope, source identity and inventory checks

I read `README.md`, `development/workflows/discovery/WORKFLOW.md`, `development/workflows/discovery/source/WORKFLOW.md`, and `development/workflows/orchestration/WORKFLOW.md` in full. The audit used only exact read-only trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap`, its ready/manifests for 1.16, 1.16.1, 1.16.2 and 1.16.5, and the embedded `.decompile-provenance.json` for 1.16.3 and 1.16.4. No product implementation/history, wiki or backlog was inspected.

The assigned source-author inventory and pair evidence were checked against their requested SHA-256 identities:

- `adjacent-source-coverage.md`: `94710939E45581425EA28A7ACCCE590A52C21D9A5BE860960A25C2F90160AED2`.
- Pair `coverage.md`: `C02197E56B35F96D1371113A4EE972C8F9482FA2C57449A159FAEF135216C526`.
- Pair `closure-appendix.md`: `140DA93C494B4F0CA878FCB42130E26402487591AB748C77DCB59E5317113295`.
- `static-hashes.csv`: `7ABFD6187B86396D00156F5352E1188ACAFBDB0E9C69E0628F0E244D3A95E282`.
- `movement-route-hashes.csv`: `E01DF0C2CE7256973455E7C33E9164E40C00ADB928631B6BE74C8AF66CF91361`.
- Pair `changed-path-inventory.tsv`: `2A4D1371076BEBD5176AD802280EDC32282D94341F53E30B588B2A9F69E2D60C`.
- Pair `movement-method-digests.tsv`: `0EA1AD1128E593F72D9872AA1C6B1E5507107F5B0DB2EB5FCB0A3ED962C8675B`.
- Pair `entity-route-method-changes.tsv`: `CBED07DF165EAD6671AA5428F319A130926336DD3B3B63B8509B3CD521434929`.

All `static-hashes.csv` source-file rows matched current bytes. For parent-manifest versions, each listed source file was rehashed and compared to the ready/source manifests (3,572 / 3,572 / 3,516 / 3,523 files for 1.16 / .1 / .2 / .5; zero discrepancies). For .3 and .4, all provenance-listed source files rehashed with zero discrepancies; the provenance binds the official client mapping inputs and version-manifest identities. Every one of the 40 movement-route matrix source rows matched. The independently recomputed adjacent changed-path totals were 3, 1,147, 5, 72 and 5 respectively. For .1→.2, I independently rehashed both full trees and compared the exact changed path set to the 1,147-row inventory: **1,147 actual, 1,147 listed, zero missing, zero extra**. The inventory includes 121 changed block-package files and 471 method-candidate rows; I screened the block-provider/callback diffs and full entity/receiver route inventories, not only movement-keyword hits.

## Five adjacent-transition dispositions

| Transition | Independent disposition |
|---|---|
| 1.16→1.16.1 | No eligible player-movement source delta found. The three changed files are Realms UI and `DetectedVersion`; movement routes in the hash inventory remain unchanged. |
| 1.16.1→1.16.2 | Ten source drafts are confirmed with the corrections and one excluded modern-only provider state below. The 11th draft, the two packet drafts, is confirmed as applicable after resolving the gate dispatch. **The roster remains incomplete** because of the separate `Entity.isInRain`/Riptide candidate. |
| 1.16.2→1.16.3 | No eligible delta found. Changed Java sources concern mob equipment-drop handling, path-navigation stuck state and `MoveToTargetSink` cooldown/AI behavior. |
| 1.16.3→1.16.4 | No eligible delta found. The 72 changed paths are social-manager/player-list presence, chat/text filtering, options and social UI/service/tutorial. The `handlePlayerInput` and movement/player tick receivers are unchanged. |
| 1.16.4→1.16.5 | No eligible delta found. Four Java-source changes are portal-fire direction/random-axis and POI handling; the axis call is on the fire portal-ignition path, not the player mover. |

## Audit of all 11 pair drafts

The pair source files are at `decompiled_minecraft/1.16.1/mojmap` and `decompiled_minecraft/1.16.2/mojmap`; file hashes in the pair coverage manifest bind the exact sources. Verdicts below concern the described source delta and boundary only.

1. **`bed-exit-position-and-facing.md` — Confirmed, conditional.** `LivingEntity.stopSleeping` and `BedBlock.findStandUpPosition` replace the old directional candidate/search logic with the 1.16.2 `DismountHelper` path. The local wake response sets the selected position and now sets facing. This is a direct position/orientation write, conditional on bed wake and supplied state. Server respawn use of the helper is excluded.
2. **`boat-passenger-eye-water-sprint-gate.md` — Confirmed, conditional.** `Entity.updateFluidOnEyes` changes from full `AABB.contains` after the `eyeY - 0.11111111F` adjustment to vertical interval inclusion. `LocalPlayer.tick` computes `updateIsUnderwater` before `super.tick`, while `LocalPlayer.isUnderWater()` returns the cached `wasUnderwater`; the changed eye result can feed the next tick’s local water-sprint gate. This is a distinct conditional direct player-state dependency.
3. **`chain-collision-axis-shape.md` — Confirmed, conditional.** `ChainBlock` changes from a fixed vertical 3/16 rod to `RotatedPillarBlock` axis-dependent collision shape; `Blocks.CHAIN` retains collision. For common chain state with horizontal axis, the player collision input differs; Y-axis retains the old rod-like shape.
4. **`client-teleport-near-coordinate-fallback.md` — Confirmed and applicable to LocalPlayer.** The old near-coordinate threshold fallback is removed. The entity packet receiver can update the mapped local player, per gate proof below; this is a direct position response, with old/new near-threshold behavior differing.
5. **`dimension-scaled-world-border-collision.md` — Confirmed, conditional.** For custom dimension coordinate scale other than the old handled 1/8 or unscaled cases, 1.16.2 changes the local collision border center scaling. `CollisionSpliterator.worldBorderCheck` is an unchanged player collision consumer. The claim is conditional on the supplied dimension/border state.
6. **`lava-pushing-in-water.md` — Confirmed, conditional.** 1.16.1's `LiquidBlock.entityInside` callback sets lava-contact state and `updateInWaterStateAndDoFluidPushing` returns early on water before scanning lava. 1.16.2 removes that callback/reset route and samples lava in fluid-height processing before the water return; `LivingEntity.travel` consumes the resulting lava flag/height. This is an eligible conditional travel input and the listed operation ordering is supported.
7. **`local-player-suffocation-escape.md` — Confirmed with provider correction.** The local `LocalPlayer.aiStep` operation changes from integer-Y `checkInBlock`/`blocked` scanning to the ordered four `moveTowardsClosestSpace` / `suffocatesAt` probes, including the deflated cell box and existing escape increments. The 1.16.2 registration adds suffocation to FARMLAND, SOUL_SAND and GRASS_PATH. Shulker and piston-head suffocation predicates were already present in 1.16.1; any draft wording implying those were newly added is incorrect. The core operation remains a valid source candidate.
8. **`rejected-block-action-player-rollback.md` — Confirmed, conditional.** The old saved position+rotation is replaced with position-only restoration gated by same client level and `player.isColliding(restoredState)`. The helper and `absMoveTo`/`setPos` routes preserve the relevant arithmetic; where the collision gate fails the old and new responses differ. Direct local-player response.
9. **`relative-move-zero-delta-coordinate-retention.md` — Confirmed and applicable to LocalPlayer.** 1.16.2 preserves raw packet-coordinate components for zero-short axes while nonzero components use the quantized relative update, unlike 1.16.1's fixed-point accumulator conversion across all axes. The mapped local player passes the negated packet gate as detailed below. This is a direct position response.
10. **`sneak-edge-backoff-near-ground.md` — Confirmed, conditional.** `Player.maybeBackOffFromEdge` changes its gate to include `!flying`, self/player identity, shift, `isAboveGround`, and downward collision/fall-distance conditions. The ordered 0.05 backoff loop and pre-clipping `Entity.move` call remain. Candidate applies to local player under these gates.
11. **`soul-speed-support-position.md` — Confirmed, conditional.** `LivingEntity.onSoulSpeedBlock` changes from `getBlockStateOn`/`getOnPos` support lookup to `getBlockPosBelowThatAffectsMyMovement`; the below-box helper is unchanged and probes at `minY - 0.5000001`. `tryAddSoulSpeed` remains conditional on flying/effects/equipment and supplied Soul Speed membership. The changed support block can alter the player travel response.

### Packet gate recheck: direct local-player applicability

The pair draft correctly noted that the negated gate admits the standalone local player; an earlier contrary interpretation was incorrect. Exact source evidence:

- `Entity.getControllingPassenger()` returns `null` in both versions (`Entity.java` 1.16.1 line 2462; 1.16.2 line 2470). Neither `Player` nor `LocalPlayer` overrides it.
- `Entity.isControlledByLocalInstance()` asks that result for a controlling `Player`, otherwise returns `!level.isClientSide` (1.16.1 lines 2549–2552; 1.16.2 lines 2557–2560). Thus on a client-side LocalPlayer with no controlling passenger the value is `false`; the handlers' `if (!entity.isControlledByLocalInstance())` body runs.
- `ClientLevel.addPlayer` delegates to `addEntity`, which puts the player in `entitiesById`; `ClientLevel.getEntity` reads that map (same methods in both versions). `handleLogin`/`handleRespawn` add the local player through this path. `handleTeleportEntity` and `handleMoveEntity` resolve their target through this `ClientLevel.getEntity` lookup.

Consequently both packet drafts are direct local-player response candidates, not merely possible non-player collision inputs. Shulker interpolation/collision is a separate supplied collision-input path and is not needed to support their applicability.

## New eligible roster gap: rain predicate feeding Riptide movement

`net/minecraft/world/entity/Entity.java:isInRain` changed in the 1.16.1→1.16.2 diff. Old code asks `level.isRainingAt(blockPos)` and then `level.isRainingAt(blockPos.offset(0.0, dimensions.height, 0.0))`. New code asks at `new BlockPos(blockPos.getX(), boundingBox.maxY, blockPos.getZ())`. The double-coordinate `BlockPos` constructor floors its inputs. For a common 1.8-high player with fractional base Y at least 0.2, these top probes can land in different block cells; raw weather is an eligible supplied state input, so this is not a modern-only state delta.

`net/minecraft/world/item/TridentItem.java:use` and `releaseUsing` consume `Player.isInWaterOrRain()` (which includes inherited `isInRain`). In `releaseUsing`, the Riptide `k > 0` branch executes the `player.push(...)`, `startAutoSpinAttack(...)`, and, when grounded, `player.move(...)` response; only the damage/projectile portion is guarded by `!level.isClientSide`. This identifies a local player movement terminal depending on the changed predicate. The changed source author roster does not include this terminal. It requires a source-author draft that traces the exact common-state probe difference, inherited predicate call chain, raw-weather gates, and local Riptide movement writes, followed by independent review. Until then this is an **unclosed coverage gap**, not an accepted change and not grounds to assert runtime reachability.

## Provider and route census dispositions

I independently screened the 121 changed block-package sources and the recorded 471 declaration candidates, with emphasis on existing fixed-state collision, fluid and direct player callback consumers. Chain collision, LiquidBlock lava callback and suffocation registrations are covered above. Fire/Vine shape bodies are non-colliding; PistonHead cache/extents preserve the inspected collision geometry; other support/survival/update changes are state placement/update producers. No additional fixed-state collision or callback route was established in the screened providers.

**Lantern:** 1.16.2 adds `WATERLOGGED` and its `getFluidState` override returns source water when true. The 1.16.1 Lantern has no WATERLOGGED property, so `true` has no representation in the old-valid state domain. For the common dry Lantern state, both versions yield the inherited empty fluid state. Under the fixed-state/common-old-state boundary this is **not** an eligible movement delta and is not a blocker.

The ordered route roster covers `Minecraft.runTick`/`tick`, client-level entity tick, `LocalPlayer.tick`/`aiStep`, inherited `Player`/`LivingEntity` tick and travel, `Entity.baseTick`/`move`, collision/dimension helpers, and direct packet sinks. Method-digest coverage confirms unchanged outer tick/travel bodies and lists the changed `LocalPlayer.aiStep`, `Entity.updateFluidOnEyes`, `Entity.updateInWaterStateAndDoFluidPushing`, `Entity.move`, and support/packet terminals. All changed client packet receiver bodies were inventoried; beyond the applicable move/teleport and block-ack drafts, login/respawn ordering remains stable, chunk/tag inputs are conditional data, recipe/UI/cleanup paths do not add a local movement response. This census supports bounded screening but does not prove producer/scheduling reachability.

## Required follow-up before freeze

1. Add and source-author-evidence the `Entity.isInRain` → `Player.isInWaterOrRain` → `TridentItem.use/releaseUsing` local Riptide movement terminal.
2. Re-audit its exact method gates and supplied raw weather/state boundary independently.
3. Retain the two packet findings as applicable to LocalPlayer; correct any record that rejected them due to the packet gate.
4. Keep Lantern waterlogged=true excluded as modern-only and dry common-state output equal.

No code changed. No tests, builds, game launch, decompilation or network use occurred.
