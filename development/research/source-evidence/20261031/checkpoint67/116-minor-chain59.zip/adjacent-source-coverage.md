# Adjacent 1.16 patch-chain source inventory (partial author coverage)

## Scope and exact source identities

This file records my source-author coverage for 1.16 → 1.16.1 → 1.16.2 → 1.16.3 → 1.16.4 → 1.16.5. It is not a pair freeze or independent audit. All sources were read-only Mojmap trees under `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap`; no online mappings, decompilation, product source/history, wiki material, tests, builds, or runtime were used.

The complete SHA-256 inventory for every file under the six source roots is `static-hashes.csv`, SHA-256 `7abfd6187b86396d00156f5352e1188acafbdb0e9c69e0628f0e244d3a95e282`. The inventories contain 3,572 / 3,572 / 3,516 / 3,516 Java / 3,523 Java / 3,523 Java files respectively (1.16.3 and 1.16.4 roots each also contain one provenance JSON in the tree). The 1.16, 1.16.1, 1.16.2 and 1.16.5 parent Mojmap ready/source/artifact manifests identify their exact release and mapping; each ready source-manifest digest matched the actual source manifest. For 1.16.3 and 1.16.4, the hidden `mojmap/.decompile-provenance.json` SHA-256 values are respectively `513271804ead6757345d305717e7e0bfc1641434c35a3b254f287bd8fd281498` and `1e04555c915527a398a2c7150679fb24d056f54bd680261e3c1dd55da821147c`; every Java source entry in each embedded provenance file was rehashed (3,516/3,516 and 3,523/3,523 match).

| Version | Mapping | Java files | SHA-256 of source manifest |
|---|---:|---:|---|
| 1.16 | Mojmap | 3,572 | `e3c23e94ac985c25dec0c768aed17b443ba4823662cf1e152235c99756ae5d4a` |
| 1.16.1 | Mojmap | 3,572 | `76fdd121070c2012f48cbdf5cf0c78490116afc94117c30b0858eedcd6ab9754` |
| 1.16.2 | Mojmap | 3,516 | `10d312ca29ee48e25f4727adafb9fcfbd741dcebe81b343d3dcffa071952a7a7` |
| 1.16.3 | Mojmap | 3,516 | Embedded per-file provenance verified as above |
| 1.16.4 | Mojmap | 3,523 | Embedded per-file provenance verified as above |
| 1.16.5 | Mojmap | 3,523 | `9499f2611d0e6dde37cb635f1a28a591416382d6bc188b37d5f99e2b2a20823b` |

## Static pair inventory and compared movement-facing slices

All files were inventoried and hashed first; identical files were deduplicated by path and content SHA-256 before semantic review. Changed-path counts by adjacent transition are 3, 1,147, 5, 72 and 5. Pair 1.16.1→1.16.2 is assigned to a separate source author whose report remains pending; I will reconcile its exact movement slices after receiving that report.

- **1.16→1.16.1:** changed files are `RealmsUploadScreen.java`, `RealmsMainScreen.java`, and `DetectedVersion.java`. No player tick, travel, response, collision/query/provider, block registration, input, fluid, modifier, or movement packet source changes. The unchanged movement-facing file bodies are identical in the all-tree hash inventory.
- **1.16.1→1.16.2:** full 1,147-path delta is owned by the separate source report. The permitted prior source author inputs contain five candidate operation drafts for this adjacent pair (bed wake position, LocalPlayer suffocation/escape via soul sand/grass path/farmland, zero-delta relative move target retention, and teleport fallback); they are leads only until paired bytes and gates are rechecked. No prior audit verdict is used as evidence.
- **1.16.2→1.16.3:** the only changed Java files are `Mob.java`, `MoveToTargetSink.java`, and `PathNavigation.java` (plus `DetectedVersion.java`; hidden provenance also changes). `PathNavigation` adds navigation-stuck state and `MoveToTargetSink.stop` uses it to reset a cooldown. The changed navigation consumer is `Mob`/AI, not `Player` or `LocalPlayer`; `Mob` separately clears an equipment slot after item drop. Non-player physics/AI is excluded. Player tick/travel/collision/response/provider files are unchanged by the full-tree inventory.
- **1.16.3→1.16.4:** the 72 changed paths include player-list/social/chat filtering and GUI/tutorial/options work. `ClientPacketListener.java` changes only `handlePlayerInfo` to maintain social-manager membership and adds `getOnlinePlayerIds`; no movement response handler changes. `ServerGamePacketListenerImpl.java` changes text-filter lifecycle and chat/book/sign handling; the `handlePlayerInput` hunk is unchanged, and no server-side historical physics is in scope. `Options.java` adds social/UI fields and a social-interactions key; existing movement key declarations and sampled player input routes do not change. `Minecraft.java` additions are social-interactions/service/tutorial/key handling. Player tick, travel, box/position/velocity and fixed-state provider bodies retain their exact bytes. `ClientPacketListener` and `ServerGamePacketListenerImpl` file hashes change for non-movement methods, which were compared at their changed hunks.
- **1.16.4→1.16.5:** changed Java files are `Direction.java`, `DetectedVersion.java`, `PoiSection.java`, and `BaseFireBlock.java` (plus hidden provenance). `Direction.Plane.getRandomAxis(Random)` is new and its only call site is `BaseFireBlock` portal ignition; `BaseFireBlock` uses it only when no portal orientation is preselected. This is portal/state creation, not player movement. `PoiSection` affects POI tracking. All player tick/travel/response/collision/provider and existing-block shape files retain identical hashes.

## Tick and terminal route coverage checked

Compared each adjacent source tree against the full path/hash inventory for the LocalPlayer/client input and response route, including `LocalPlayer`, `AbstractClientPlayer`, `Player`, `LivingEntity`, `Entity`, `EntityDimensions`, client/server player packet listeners, player movement packet receivers, `CollisionGetter`/`BlockGetter` and level access, block state/behavior, shape and AABB/vector helpers, and changed existing-block providers/registrations. For transitions 1.16→1.16.1, 1.16.2→1.16.3, 1.16.3→1.16.4 and 1.16.4→1.16.5, changed movement-looking terminal files were inspected at changed hunks and found to fall within the exclusions above; the movement graph files are byte-identical. The full prior source-author inventory remains reusable only for slices whose per-version bytes and gates match these exact Mojmap trees. A focused route matrix for the player tick, packet, shape, effect, fluid and provider source classes is `movement-route-hashes.csv`, SHA-256 `E01DF0C2CE7256973455E7C33E9164E40C00ADB928631B6BE74C8AF66CF91361`; it records full per-version hashes, not just prefixes.

This source-author report has no new accepted finding. Pair closure and the complete terminal route audit remain pending the independent audit after both pair author inventories are frozen.


The four parent source manifests (1.16, 1.16.1, 1.16.2, 1.16.5) were also matched line-by-line to the freshly computed source-tree hash inventory: 3,572/3,572, 3,572/3,572, 3,516/3,516 and 3,523/3,523 Java files, zero hash mismatches. Embedded 1.16.3 and 1.16.4 provenance source entries were separately verified line-by-line as recorded above.

## Frozen source-author roster before independent audit

The pair-specific 1.16.1→1.16.2 source-author roster is fixed at `.native-source/20261031/116-minor-chain59/1161-1162/coverage.md` (SHA-256 `C02197E56B35F96D1371113A4EE972C8F9482FA2C57449A159FAEF135216C526`) and its eleven adjacent-pair drafts. It covers LocalPlayer suffocation/escape, sneaking edge backoff, Soul Speed support position, bed exit position/facing, lava pushing while in water, ChainBlock collision axis, relative-move coordinate retention, client teleport fallback, rejected block-action rollback, dimension-scaled world-border collision, and boat-passenger eye-water sprint gating. These remain source-author claims only. The paired `closure-appendix.md` (SHA-256 `140DA93C494B4F0CA878FCB42130E26402487591AB748C77DCB59E5317113295`) records the complete 1,147-path census, provider/callback dispositions, 2,792 movement method occurrences and client receiver/direct-sink inventory. No claim is independently accepted and no pair is frozen.

No candidate is independently accepted and no adjacent pair is frozen. The next required step is one fresh blind reviewer over the full five-transition chain and the expanded roster, with every source-author closure claim checked against primary sources and all five adjacent transitions retraced. An earlier review covered the pre-expansion ten-draft roster only; it is not evidence for this expanded set.

