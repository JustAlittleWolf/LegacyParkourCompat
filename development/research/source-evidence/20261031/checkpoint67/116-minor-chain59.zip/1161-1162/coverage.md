# 1.16.1 to 1.16.2 source comparison

Status: source-only worker draft; this is not pair freeze or a source-acceptance verdict. A separate fresh reviewer must independently audit the coverage inventory after it is frozen by the coordinator.

## Exact inputs and integrity

Both readonly canonical trees are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap`, Mojmap namespace, emitted in one run with Vineflower 1.12.0 / Java 25.0.3+9-LTS; staging ID `mojmap-1.16.1-to-1.16.2-e70b9be363894d4898ba9ec4c224103a`.

- 1.16.1: 3,572 files / 19,220,344 bytes; source manifest SHA-256 `76fdd121070c2012f48cbdf5cf0c78490116afc94117c30b0858eedcd6ab9754`; artifact manifest SHA-256 `a113f9d59fa4582effb2ebf548c4388a54c9c5654fbf57fae7974dce896d1f98`.
- 1.16.2: 3,516 files / 19,198,358 bytes; source manifest SHA-256 `10d312ca29ee48e25f4727adafb9fcfbd741dcebe81b343d3dcffa071952a7a7`; artifact manifest SHA-256 `7b8551bdc108a1584039ac22e35b6b75c3584ed85aba24561c7d340f5cbeb108`.
- Recomputed manifests, counts, total bytes and every listed file hash against the ready markers: both match; bad/missing/malformed files: zero. The source manifest comparison reports 1,147 differing path hashes.

### Key paired source file hashes

The pair manifest above binds the full tree; these hashes identify high-impact files for this draft.

| Source path | 1.16.1 SHA-256 | 1.16.2 SHA-256 |
|---|---|---|
| `net/minecraft/client/multiplayer/ClientPacketListener.java` | `466d11a2b628c80e17885a0e85f25fee2ee6a05de33d9e71f309b8bc233a549d` | `4d043b866c970910ef079334b0d506f7bc0f78f679e5225f11a0418bab7a72f9` |
| `net/minecraft/client/multiplayer/MultiPlayerGameMode.java` | `6be55796cb04dc2a1c33ddd1aca2c0004070a80555ea2115b73306b83990fec7` | `80d1b28891b33de967cbc26e13acec097fb94091bbc226f92ad5ba2750015b66` |
| `net/minecraft/world/entity/Entity.java` | `27e3bb01b5d03c09161891e717c16477899768333082e81ebfaac4e525616576` | `f9a9a073fe3105a0aa53d0f21ec72e59084e8d21a14c1cd3be75703865ee2666` |
| `net/minecraft/world/entity/LivingEntity.java` | `b6ea2b9b037b79fc3ea6e1f6bcd2c4c1d89d4a96315968a8f247641f6c335f26` | `b5d8a1a3c80f85d5d545b5a777e9e2a915dc002a7e31b5f5ad12bf7e285d7a88` |
| `net/minecraft/world/entity/player/Player.java` | `a849960d47bf00a2cddfb6636c78c518532a11967ba08829f19c5ebced08681e` | `d2e26589bdb6a20dc914266db06aa48f50811efc792d6e63b3008c9199914960` |
| `net/minecraft/world/level/block/ChainBlock.java` | `3f05483f3f4053910f658fb951b93b1dc85022594520bff77aa36ae7d5edfdcb` | `6a7fed55ffa892a3781b64849d9f42fb85a125eeb023a23171bc8880bf67fb6e` |
| `net/minecraft/world/level/block/LiquidBlock.java` | `e7b138668f426eaf7c2f89b34dd0448f6ba0eb133963929ebf12d64840f22fb3` | `24f1cfbd036cca77ec99d855a028194ed39f583699ce91bc2a4c61957ff22fb7` |
| `net/minecraft/network/protocol/game/ClientboundMoveEntityPacket.java` | `7bf671557d36296789f53e8b0b1d576bf946543b0d3388926bebffa2174099ec` | `c787f142b1621edfa211b7293f851171562ca79d32299e76718593052a354db7` |
| `net/minecraft/network/protocol/game/ClientboundSetDefaultSpawnPositionPacket.java` | `061e787ab4038fe7fee869399e42e6c27c1ab65b1ed5d3c8427b4a1e50334528` | `7136991bf9d04440624568dac3dfc45a89a0570ec6d04d4ee2d25a9c4b31ba7a` |
| `net/minecraft/world/level/EntityGetter.java` | `bb07fe2a90a7d898ef940837d3324ac974ebc9260549549f4d108bc83fa83256` | `12b4ad28f0a92414ec1478dd42b6a41ff6cd0a0a00650ae37490ea8cd0a1bba5` |
| `net/minecraft/world/entity/monster/Shulker.java` | `f27e103e6821816fa40912f668d2a60aae22c90074c022a50e9cd68b1097aa61` | `148223a61c38992efdb88f1537886efcbff4697ab4b46a18f335995a40739570` |
| `net/minecraft/world/entity/vehicle/Boat.java` | `10fd69faa90c651cf08fd3d0b7573fbf9a36ae9eff1f17c99d4ca26eeb0e34aa` | `9f3c92c0516ab31dc42918fcedbb5894fb695a1fcc32f05e73db25784d30c056` |
| `net/minecraft/world/entity/ai/attributes/DefaultAttributes.java` | `378f46c27ba14b42eba9fc5682323fbdf6710f97d11183abcb493b71d102cf3` | `b90d7255a57198785454036b70216c013a6ab86f68b263aec7d1578283f27f6e` |
| `net/minecraft/data/tags/BlockTagsProvider.java` | `bba0bac845a3fe3f76b3b78990421aa0ebf2d6a77982df395875763c9a34df7b` | `9f084139857f7fd2c78928d89596d8b224c5959fc374191d755e17dadca4c239` |
| `net/minecraft/world/level/Level.java` | `5f6be38c6b3e11e1ca00a9067f676151d1288f19d8cd817a3bbd1cc91b8eaa19` | `e9a23488863fd43a7d8975efc23f4c7cf4af874554bab5b76eaa2c79f028db80` |
| `net/minecraft/world/level/CollisionGetter.java` | `fc7f175b10c2c6683913a903a366bd775facecf3c58f04cc6e9cfc95ddceed98` | `b507d6be11e5985a62cfeb249a99dcb5f8edaf346f12cb2487797d9e01763eac` |
| `net/minecraft/world/level/dimension/DimensionType.java` | `afcefce1879cf139294bfd5db3a192049617b176170486635b30964249dc0954` | `e2f87508c846871ce9a302509e5057e925ab242fa0a5c1bb953fb2b8bfb20dac` |

## Ordered player-movement route slices examined

1. **Local client input and pre-travel state:** `LocalPlayer.aiStep` input/jump handling and its four post-input suffocation probes; compared the old `checkInBlock` / `blocked` path and call order against `moveTowardsClosestSpace` / `suffocatesAt`. The player tick implementation around this operation is otherwise unchanged in the inspected diff. Four calls use the new same `moveTowardsClosestSpace` operation. Its `noPhysics` gate, `.35 * bbWidth` X/Z probes, four ordered probes, cell-wide suffocation query with the `1.0E-7` deflation and candidate direction comparisons were traced. Provider differences on FarmBlock, SoulSandBlock and GrassPathBlock are included in this finding.
2. **Sneak edge movement:** `Player.maybeBackOffFromEdge`, `isAboveGround`, `isStayingOnGroundSurface`, and the caller in `Entity.move` were compared. Draft covers the changed gate (`!flying`, SELF/PLAYER, shift and `isAboveGround`) and unchanged `.05` decrement loop. `Entity.move` collision clipping/call order showed no adjacent change in the inspected body.
3. **Travel and support/material inputs:** compared `LivingEntity.travel`, its lava/water branches, Soul Speed (`onSoulSpeedBlock`, `getBlockSpeedFactor`, `tryAddSoulSpeed`), support-position helper and Player flying override. Draft covers the Soul Speed lookup change from `getBlockStateOn()` / `getOnPos()` to `getBlockPosBelowThatAffectsMyMovement()`. The helper's `minY - 0.5000001` probe and Soul Speed attribute math were traced. Travel branch order/coefficients outside the lava-state dependency showed no other diff in these inspected bodies.
4. **Tick fluid state and callback path:** compared `Entity.tick`, `checkBlockCollisions`, `LiquidBlock.entityInside`, `isInLava`, `updateInWaterStateAndDoFluidPushing`, `updateFluidHeightAndDoFluidPushing`, and `LivingEntity.travel` lava consumers. Draft includes old callback-set lava flag removal and new fluid-height sampling before the in-water return; helper deflation, scan/height accumulation, flow averaging/scaling, Player vector normalization exception and small-horizontal-flow clamp were traced.
5. **Wake placement and facing:** `LivingEntity.stopSleeping`, `BedBlock.findStandUpPosition`, its old directional-grid search / stand-up predicate and new `DismountHelper` path were compared. Draft records current-yaw candidate ordering, bunk-bed route, entity floor/collision/danger gates, position set and new facing write. Prior bed-wake candidate is the same endpoint operation, independently rechecked against the current pair.
6. **Server/direct client position responses:** compared `ClientPacketListener.handleTeleportEntity`, `handleMoveEntity`, their position packet helpers, `Entity.setPacketCoordinates`, `Entity.isControlledByLocalInstance`, and inherited `LivingEntity.lerpTo`/interpolation tick. Drafts cover teleport fallback removal and relative packet coordinate quantization/zero-axis retention. The client gate includes local player because `Entity.isControlledByLocalInstance` returns false for a standalone client entity; its negation admits the direct position update.
7. **Rejected block-action rollback:** compared `MultiPlayerGameMode.sendBlockAction` and `handleBlockBreakAck`, `Entity.isColliding`, and the relevant `absMoveTo` overloads. Draft records new same-level/collision gate, position-only snapshot and response; old code unconditionally restored saved position and rotation when a snapshot existed.
8. **Block-shape/provider census:** used the coordinator's broad changed-block declaration inventory (`.native-source/20261031/116-minor-chain59/changed-block-method-candidates.tsv`, 471 method rows across changed block paths) as a lead list, then compared paired source bodies for `getShape`, `getCollisionShape`, `entityInside`, `stepOn`, `fallOn`, and `updateShape` candidates. The worker helper `compare-block-bodies.ps1` records the changed body candidates. ChainBlock is movement-relevant: 1.16.1 has a fixed vertical 3/16 rod; 1.16.2's registered colliding chain extends `RotatedPillarBlock` and shape follows AXIS (Y preserves old shape; X/Z are horizontal bars). LiquidBlock's removed lava callback is in the fluid draft. Farm/SoulSand/GrassPath suffocation providers are in the suffocation draft. BedBlock is in the wake draft. Other body changes from this census: FireBlock caches a shape but its registration disables collision; VineBlock outline-shape cache remains non-colliding by registration; PistonHeadBlock caches the pre-existing extents; GrowingPlantHeadBlock, Lantern and NetherPortalBlock `updateShape` changes produce/update state and are outside fixed-state movement. No changed body was seen for the other screened shape/collision/callback candidates. This is source screening, not reviewer closure.
9. **Pose/dimensions and block collision dependencies:** compared `EntityDimensions.makeBoundingBox` to its former inline expression (same width/height arithmetic and types), `BlockBehaviour` default shape-to-collision delegation, `CollisionGetter.noBlockCollision`, bed dismount shape paths, and checked player bounding-box consumers implicated by the drafts. `Entity.move` remains the collision clipping caller. ChainBlock's `Blocks.CHAIN` registration retains collision (it does not set `noCollission()`), and default `BlockBehaviour.getCollisionShape` delegates to state shape when `hasCollision`.
10. **World-border collision input:** paired `Level` constructor and `DimensionType` codec/accessor changes. The border collision consumer in `CollisionSpliterator.worldBorderCheck` is byte-identical, but 1.16.2 maps a custom non-1/non-8 coordinate scale onto local border centers by dividing by that value; 1.16.1 had only `shrunk` and `/8` or unscaled centers. The conditional candidate is drafted in `dimension-scaled-world-border-collision.md`.

### Direct player packet receiver inventory

Compared the changed receiver methods in both `ClientPacketListener.java` bodies and the block-ack delegate in `MultiPlayerGameMode.java`. The method-body digests below are SHA-256 over trimmed method lines in the exact paired sources; equal digests are unchanged methods, while changed methods are classified below. File-level digests above bind each containing file.

| Receiver method | 1.16.1 method SHA-256 | 1.16.2 method SHA-256 | Pair disposition |
|---|---|---|---|
| `handleTeleportEntity` | `ef6df2c98d18fb5258062a3886d4d2ee65d001db477f8571325b98413287368d` | `c11d2b6239992ef6ffd991be971988eabba4c9deb2cc05ab178dcb68e8d28ccf` | Draft finding: removes near-coordinate fallback. |
| `handleMoveEntity` | `fa63bc70e59b05c4967d33a6d2d4d96031e8913aab7b61b7b6fb811698fc151f` | `c9fe3948fb86210d1eedb8fb780de0dd501a53667af5d0eec8f6fbad89f2d899` | Draft finding: relative coordinate helper/zero-axis behavior. |
| `handleMovePlayer` | `d0af1cad69c00f9e07f1006b43fa32ef0f45a0a5be0cce953a3608978b9b2f31` | same | No delta: correction and non-mounted write order identical. |
| `handlePlayerAbilities` | `12212376b0af2e2ceb6b08aa9be21aa0c64f179e0c80a22b33939b885103125f` | same | No delta: same decoded ability fields applied. |
| `handleSetEntityMotion` | `150d0f5164bfe6a0ae6528374683ef5c9b1bb8339a763533766ecce86a8f9a70` | same | No delta: same decoded velocity sink. |
| `handleUpdateMobEffect` | `50bd1a5d529f22c18333fc6c23162695687213881e699b173761d99c023eaebc` | same | No delta for this adjacent pair. |
| `handleUpdateAttributes` | `a198922e3e373e3a4f729ee3dd1e92885cc72b1b85b114052831c9a80906ab9d` | same | No delta: direct modifier receiver body identical. |
| `handleBlockBreakAck` (listener delegate) | `66af71786895f549f0fcc548588e8334b07c6a2aff428b527a16c5052f41899a` | same | Same packet-to-game-mode dispatch; delegated response differs below. |
| `handleSetSpawn` | `1d93c540826fed8a6b1ba59d512c0891ff68a21f85407e1fccc291abcc76f024` | `9b7b2725dea86de8ede251c8e8889b426f3033501828f9de8a6f370ce2e8dffe` | New angle value is not read/written by packet codec; decoded angle defaults to 0, no client orientation delta. |
| `handleRespawn` | `88df630f6ea1933e4850ef410917bb9ba781183eb3e39206626c3706c9e2e0e6` | `4a964772268432850d01921df24a6da4bce93cfffd84846e3d2a540ffbd07616` | Changed registry/dimension API only; recreation, `resetPos`, `-180.0F` yaw reset and attribute-copy gate remain. |
| `handleLogin` | `8f5bca6653c7d76bed7d1d8485c41a5739a67861ab372dab2a4695fe4d65db93` | `c6a008843b40a0cb93c21b93c1ea1e5a5adf15a18ada8292b1666e32a2603e2c` | Changed registry/tag/recipe setup; local player creation, reset, `-180.0F` yaw, input installation and current game-mode application remain. |
| `handleChunkBlocksUpdate` | `d6700d15671b146ef31788620decd043b5827c883452d6115389599f675c37c4` | `750baa68adf76668c501a5a0c5af78c72212e9ecbdb57da6e9eea480bc75b976` | Packet renamed and client block-state update API/flags changed; this supplies world state and is not a player-specific movement response. |
| `handleUpdateTags` | `ef84a76b104baed97be6c0bbec605d49bd9103da7c562c7b701d1ed0abcfa858` | `5525d5c28670191c67e2b9d109009df63718165674fcb1cf3077b86917d43fc3` | Tag container/state input path; no movement solver change. Effective input membership remains a supplied-state gate. |

`handleChangeDifficulty` is byte-for-byte equal as a method and does not change player movement. Other receiver methods changed in the `ClientPacketListener` diff are presentation, recipe-book, biome registry, or block/tag state-input paths, as classified above. Changed packet constructor-only `ClientboundTeleportEntityPacket` uses `isOnGround()` instead of the field; equal decoded packet fields yield the same on-ground write.

### Entity collision collection and callbacks

`EntityGetter.getEntityCollisions` changed from collecting non-null `getCollideBox()` shapes and an optional mover-specific `getCollideAgainstBox()` to filtering candidates by bounding-box intersection and `entity.canCollideWith(entity2)` / `entity2.canBeCollidedWith()`, then using each candidate bounding box. This is reached by `Entity.move` collision clipping. For a local player as the mover, paired default target behavior was checked: old `Entity.getCollideBox()` returns null and new default `canBeCollidedWith()` is false; old `Shulker.getCollideBox()` returns its box iff alive and new `Shulker.canBeCollidedWith()` is the same alive predicate; old `Boat.getCollideBox()` returns its box and new `Boat.canBeCollidedWith()` returns true. Thus the ordinary player-mover candidate set and shape are the same for those concrete collidable entity classes. The changed old mover-specific `getCollideAgainstBox` overrides and new `Boat` / `AbstractMinecart.canCollideWith` govern vehicle-origin collision behavior and are excluded with vehicle physics. `LivingEntity.isPushable` gains a spectator check, but its changed use is through vehicle collision eligibility; the local spectator has `noPhysics`.

`Entity.moveTowardsClosestSpace(double,double,double)` is a rename of base `checkInBlock` for generic entities. Its callsites are `ItemEntity` and `ExperienceOrb`; LocalPlayer no longer overrides either name and instead owns its distinct two-argument method called four times in `aiStep`. No LocalPlayer fallthrough into the generic utility exists.

### Tag and modifier source inputs

Compared `DefaultAttributes`: the 1.16.2 addition registers attributes for new `PIGLIN_BRUTE`; the `PLAYER` entry remains `Player.createAttributes()` on both sides. No `world/effect` or `EnchantmentHelper` source path changed in the pair manifests; `ThornsEnchantment` changes damage only. `BlockTagsProvider` differs by adding mushroom-growth and base-stone tags; the generated `SOUL_SPEED_BLOCKS` and `CLIMBABLE` memberships are unchanged in the paired provider source. Server/resource tag overlays can still supply different effective membership; the movement findings remain conditional on equal supplied tags. `LivingEntity` adds Fire Resistance on the death/totem-related path, and changes absorption/loot handling; those health/damage/loot routes do not alter the movement modifiers or movement readers in scope.
## Draft findings in this lane

- `findings/1.16.1--1.16.2/local-player-suffocation-escape.md`
- `findings/1.16.1--1.16.2/sneak-edge-backoff-near-ground.md`
- `findings/1.16.1--1.16.2/soul-speed-support-position.md`
- `findings/1.16.1--1.16.2/bed-exit-position-and-facing.md`
- `findings/1.16.1--1.16.2/lava-pushing-in-water.md`
- `findings/1.16.1--1.16.2/chain-collision-axis-shape.md`
- `findings/1.16.1--1.16.2/relative-move-zero-delta-coordinate-retention.md`
- `findings/1.16.1--1.16.2/client-teleport-near-coordinate-fallback.md`
- `findings/1.16.1--1.16.2/rejected-block-action-player-rollback.md`
- `findings/1.16.1--1.16.2/dimension-scaled-world-border-collision.md`
- `findings/1.16.1--1.16.2/boat-passenger-eye-water-sprint-gate.md`
- `findings/1.16.1--1.16.2/in-rain-riptide-client-movement-gate.md`

## Reconciled earlier SOURCE-author leads

The prior drafts in `.native-source/20261030/1152-1165-finish43/canonical-findings/1.16.1--1.16.2/` were treated only as leads. Paired current sources confirm `bed-wake-stand-up-position` (same wake endpoint; our bed draft is the lane-owned operation), `soul-sand-grass-path-localplayer-escape` and `farmland-suffocation-localplayer-escape` (same consumer call-order/probe operation plus matching `isSuffocating(Blocks::always)` provider additions for soul sand, grass path and farmland), `relative-move-zero-delta-coordinate-retention`, and `client-teleport-near-coordinate-fallback`. The two block-provider drafts converge on one independent suffocation consumer operation; do not present them as separate LocalPlayer operations. Prior candidate witnesses and any interval claims still require fresh audit; only paired endpoint source facts were reused. No prior audit verdict is evidence here.

## Dispositions and exclusions

- `ClientboundSetDefaultSpawnPositionPacket` in 1.16.2 adds an `angle` field/constructor and downstream setters accept it, but packet `read`/`write` still serialize only the BlockPos. Server-created packets are decoded through the no-argument constructor, so the new angle stays default zero on this network path; no client player movement orientation change is established. Player constructor yaw change is server-side and excluded.
- `PistonMovingBlockEntity.moveCollidedEntities` changes the slime velocity override for `ServerPlayer`; both versions still call `moveEntityByPiston`. Server-only behavior is excluded.
- `Player.isPushable` adds a spectator exclusion. The local spectator route sets `noPhysics`; no independent ordinary local-player movement operation was established from this predicate change.
- New `Entity.isColliding` is also used for block-target interaction; only its conditional rollback use is included above.
- `VineBlock.getShape` is outline-only because the registration has no collision; FireBlock has no collision; PistonHeadBlock's cached short/long shapes preserve the inspected extents. Ladder/scaffolding collision method bodies did not change (their block source diffs were imports); no shape delta claimed there.
- Changed `Blocks` properties also include block support/survival and mob-spawn rules, new-block registration and material metadata. World-state production/placement, spawn eligibility, render geometry, vehicle/non-player physics, health/food and damage are excluded unless they expose a fixed-state player collision or direct player response covered above.

## Coverage closure and remaining audit

The four residual coverage gates are now recorded in [`closure-appendix.md`](closure-appendix.md): changed block providers/callbacks, ordered inherited player route and dependencies, changed packet receiver methods/direct state sinks, and the complete 1,147-path inventory. The paired source artifacts and their hashes are identified in that appendix and in the TSV evidence files. Newly added candidates: `Entity.updateFluidOnEyes` boat-passenger eye-water predicate affecting the conditional next-tick local sprint gate; and `Entity.isInRain` top-cell sampling affecting the inherited Player rain gate and local Riptide release response. Exact source lines, hashes and conditional raw-state witness are in `findings/1.16.1--1.16.2/boat-passenger-eye-water-sprint-gate.md` and `findings/1.16.1--1.16.2/in-rain-riptide-client-movement-gate.md`.

No pair-specific terminal slice remains open from the four assigned source-coverage gates. Supplied tags/effects/attributes/equipment/fluid and packet state remain conditional raw inputs; no generated resource membership, packet scheduling, producer reachability or trajectory claim is made. This is still source-author coverage, not pair freeze or acceptance. The next action is coordinator freeze of the expanded roster, then an independent fresh reviewer audit.