$root='D:/Javastuff/LegacyParkourCompat/decompiled_minecraft'; $inv='.native-source/20261031/116-minor-chain59/changed-block-method-candidates.tsv'
$rows=Import-Csv $inv -Delimiter "`t" -Header version,path,line,decl
$rows=$rows | Where-Object { $_.decl -match 'getCollisionShape|getShape\(|entityInside\(|stepOn\(|fallOn\(|updateShape\(' }
function Get-Body($file,$line) {
  $lines=[System.IO.File]::ReadAllLines($file); $i=[int]$line-1
  while($i -lt $lines.Length -and $lines[$i] -notmatch '\{'){$i++}
  if($i -ge $lines.Length){return @()}
  $depth=0; $started=$false; $out=[System.Collections.Generic.List[string]]::new()
  for(;$i -lt $lines.Length;$i++) { $s=$lines[$i]; $out.Add($s.Trim()); foreach($ch in $s.ToCharArray()){ if($ch -eq '{'){$depth++;$started=$true}; if($ch -eq '}'){$depth--} }; if($started -and $depth -eq 0){break} }
  return $out.ToArray()
}
$groups=$rows | Group-Object path
foreach($g in $groups){
 $path=$g.Name; $pair=@{}
 foreach($v in @('1.16.1','1.16.2')) {
  $pair[$v]=@($g.Group | Where-Object version -eq $v | Sort-Object {[int]$_.line} | ForEach-Object { [pscustomobject]@{ line=$_.line; decl=$_.decl; body=(Get-Body "$root/$v/mojmap/$path" $_.line) } })
 }
 $max=[Math]::Max($pair['1.16.1'].Count,$pair['1.16.2'].Count)
 for($j=0;$j -lt $max;$j++) { $a=$pair['1.16.1'][$j]; $b=$pair['1.16.2'][$j]; if(!$a -or !$b -or (($a.body -join "`n") -ne ($b.body -join "`n"))) { "${path}`t$($a.line):$($a.decl)`t$($b.line):$($b.decl)" } }
}
