# Independent five-provider source audit

Audit date: 2026-10-31. Read-only source basis: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{1.12.2,1.13,1.13.1,1.13.2}\ornithe-feather`. This audit is bound to the five candidate revisions by their SHA-256 hashes below. I did not inspect other findings, drafts, candidate implementations, wiki material, product code/history, or the moving-piston draft.

## Verdicts

| Finding | Verdict | Audit result |
| --- | --- | --- |
| `anvil-collision-geometry.md` | **Accept** | Provider geometry, common shape dispatch, 1.12.2 damage-state property, 1.13+ registrations/datafix mapping, and the stated witness all check out. The stated box can be made fully explicit by setting its X interval to any subinterval of `[0,1]`, e.g. `[0.1,0.7]`. |
| `brewing-stand-collision-geometry.md` | **Accept** | The old full-footprint plate and modern inset plate/stem union are the actual collision shapes. A valid box is X `[0.95,1.55]`, Z `[0.2,0.8]`, Y `[0.05,0.65]` against a stand at the origin: it intersects only the old plate strip and misses the modern plate and stem. Bottle flags do not enter `getShape`. |
| `cauldron-collision-geometry.md` | **Accept** | The old base top is `5/16`; the modern solid shell starts at `4/16`, with the same `2/16` side walls. A player box with X/Z `[0.2,0.8]` fits the opening `[0.125,0.875]`; once settled, the old bottom supports it `1/16` higher. `LEVEL` is not read by either shape provider. |
| `hopper-collision-geometry.md` | **Accept** | Shape dimensions, `FACING` selection, independent `ENABLED` state, and the coordinate witness check out. At block `(0,3,0)`, the supplied box intersects the old east full-height wall at Y `[3,3.1]`; that Z interval misses the modern east spout (`6/16..10/16`), and the modern rim starts at Y `3.625`. |
| `wall-tnt-neighbor-connection.md` | **Incomplete** | The predicate/shape difference and vanilla-state correspondence are correct, but the immutable finding supplies no concrete player box. See the concrete reachable witness below; adding it changes the finding revision and needs a renewed review. |

All five source differences are real. “Incomplete” for the wall draft is a finding-claim completeness verdict, not a dispute about its provider or predicate comparison.

## Source readiness and integrity

Every version has a `ready` marker with exact `versionId`, `ornithe-feather` mapping namespace, and a source manifest whose actual SHA-256 matches the marker. Each directly hashed source file below also matches its row in that version's `ornithe-feather.sources.sha256` manifest.

| Version | Ready marker SHA-256 | Provenance SHA-256 | Source manifest SHA-256 (matches ready marker) |
| --- | --- | --- | --- |
| 1.12.2 | `b0aeec721e5c0af02b33d9e217cb8272889fa139ded1ecc2a31e42b930138f7a` | `747425a26da363d1abc8a2cecd83a74504aeb1f58be93aa53f48c690e35318ce` | `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da` |
| 1.13 | `82a4a8f6a03fbd99a7b8577b1ae5980d95af07c7ded0da284106d16eb1e01a99` | `34652aeef6914b5cbff6619ae60a855aa676b2ae1f607eccdaa623ad09dc5e8d` | `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a` |
| 1.13.1 | `f098b3a08b37276cc1a465a8a122df8de76d68786c854b92bac1ca51a79670de` | `c28ed59f2c507b6133f7677742d316d38e9993eaf1fbb6c2054bd68d1085e904` | `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba` |
| 1.13.2 | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |

The readiness records identify Feather build.2 mappings for each exact release, Vineflower and Java 25. The four source trees and their method bodies are intact for this audit. No source regeneration or network lookup was used.

## Direct source hashes

Hashes are the actual file SHA-256 values; all matched their version's source-manifest row. Rows with “modern shared” are byte-identical in 1.13, 1.13.1 and 1.13.2.

| File | 1.12.2 | 1.13 | 1.13.1 | 1.13.2 |
| --- | --- | --- | --- | --- |
| `block/AnvilBlock.java` | `80729f34a74ff8b1b4b2d59e55c5d8dd9d61fff94c47f862c61c12d9947eb8bb` | `156505373606a0cf2c0df329e170465c207b72b2ab59798272cbec389373092e` | same as 1.13 | same as 1.13 |
| `block/BrewingStandBlock.java` | `e875022b9a47ca6336878bcec205459462687bb35d567ee183f7ec2f1924a4fd` | `0ff465b18dc0377c1a1a123ad083f04d07f77cea8a0bc88a218a67d750f886d3` | same as 1.13 | same as 1.13 |
| `block/CauldronBlock.java` | `0aff4a0de147e0c677f4b931cd9a881154666bb288f128c9d8041b70c38d63f9` | `81cf1275a962c024bcfdf569286e967088f2f8d06a6ab5e8eb88b8bad7ab33c8` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` | same as 1.13.1 |
| `block/HopperBlock.java` | `3510f351f1a6b913dd834d1c8696d49e888d3a7cd9dd307388d3551c9cabfb6c` | `c43588fd0bdf0c17ec7356090e67af8101335b5ee2a565088837d6d75a3a73ae` | same as 1.13 | same as 1.13 |
| `block/WallBlock.java` | `7e4378c46e367c32deca14475e5161b6e4223947d83153ce3e7ba5c8a0d18e50` | `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf` | same as 1.13 | same as 1.13 |
| `block/Block.java` | `e4a90eca411e7b0e14f5018f7385ec29891f6cdf1a1e917fa648b5712f9b33a1` | `e5be72b77a28e89595009289964bb031bbb187d15d5698570615e6fc9a21a476` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | same as 1.13.1 |
| `block/Blocks.java` | `8d34c5e531407689108668a84bb8fe705bf987b1481ae8b6d3a6e39424243e2e` | `8e66b1ad391d61f4f42fecb313f99299810493cb87525493f9ace8a1eb7cd000` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | same as 1.13.1 |
| `block/state/BlockState.java` | `3fb6f06df86c3b89716b5efaed5d97eee670d007d3c4535e47eb0fdd993e92eb` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | same as 1.13 | same as 1.13 |
| `entity/Entity.java` | `80f091bf32166c88cf8bbd31caf72d84fa16224410733c7d2a0f00563f294a0a` | `09514488d9055449c47e2e4bcd23b5773203ca634b7ecba2323a99d0ae016642` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | same as 1.13.1 |
| `world/World.java` | `e9fa9b8d6d31ad57a5b876f5f63a5e3c554a23437decf1845a493daf48233594` | `6e3d94e6cdcfbb15472c4ee981a1c12500eaf7cd5d5dc20d75bcde91174c2eb5` | `119ac6f61b93cf352b2026934e9f95877f55dc2f582b45d75c2bdae3652532b6` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| `world/WorldView.java` | `628ce75d2c76ed025b62e905da8030024e1b89b145445fd6971bfef798bba7cc` | `b0d1406fb04eacbc644a78548f858d5ff6c14ad781927832cb374e985f32a543` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | same as 1.13.1 |
| `block/TntBlock.java` | `28fbb89aca1f7aed4587bc612cd9356f760f8784f138358afb7e27108405df9d` | `43e398acc9d401a2ba8b20b0bc2cfd979a0662a41e3c29b2ef3d9aa75d513713` | `2acf48c3575f434324af23053816855e8e34e21119653c304b438af0ae03a305` | same as 1.13.1 |
| `unmapped/C_37931705.java` (1.13+) | — | `2717df7465597f98634ff1569968ff247a4ccda472209e2628ae4ab21c7364de` | same as 1.13 | same as 1.13 |

`Blocks.java` exposes the registry references; `Block.java` contains the actual registrations and class constructions. The above `Block.java` hashes cover those registration rows. `C_37931705.java` is the 1.13+ data-fixer class for old block IDs and maps `anvil.0`, `.1`, `.2` to `anvil`, `chipped_anvil`, `damaged_anvil` (lines 63–65); 1.13+ `Block.java` registers all three as `new AnvilBlock(...)` (1.13.2 lines 1284–1286). In 1.12.2, `AnvilBlock.DAMAGE` is `0..2`, and shape selection only reads `FACING`. Thus the damage-state correspondence claimed by the draft is closed.

For the wall, 1.12.2 `WallBlock.VARIANT` has `NORMAL` and `MOSSY` variants while shape indexing reads the four direction properties. In 1.13+, `Block.java` registers both `cobblestone_wall` and `mossy_cobblestone_wall` as `WallBlock`; the separate registry names replace the old variant encoding while retaining the same shape provider. These are both source-supported vanilla state representations.

## Caller and provider trace

- In 1.12.2, `Entity.move` (Entity.java around lines 462–620) asks `World.getCollisions` for the candidate moved player box. World.java lines 964–1005 enumerates block states and calls `BlockState.addCollisions`; `Block.addCollisions` uses `state.getCollisionShape`, and the five changed blocks override `addCollisions`/shape accessors as appropriate.
- In 1.13.2, `Entity.move` (Entity.java around lines 473–620) asks `World.hasNoCollisions`/`World.getCollisions`. `WorldView.getCollisions` reaches `getBlockCollisions` (WorldView.java lines 112–177), `BlockState.getCollisionShape` dispatches to the block, and `Block.getCollisionShape` defaults to the state's shape when `hasCollision` is true (Block.java lines 388–395). Anvil, brewing stand, cauldron, hopper and wall provide the cited shapes through this path. The same relevant caller/provider methods are present in 1.13 and 1.13.1; file hash comparison confirms byte identity for the five providers where the drafts claim it (and confirms cauldron's distinct 1.13 body while its cited shape declarations/provider are equivalent).

## Per-finding source check and exact corrections

### Anvil

1.12.2 `AnvilBlock.java` lines 30–32 defines full-height `SHAPE_X` and transposed `SHAPE_Z`; `getShape` lines 92–95 selects by `FACING` axis. 1.13.2 lines 29–37 builds the 2/16 base, narrow legs and 6/16 top, and lines 71–74 selects the corresponding orientation. The modern top slab's narrow-axis maximum is `13/16`; the old box reaches `14/16`. Draft witness Z `[0.85,1.45]`, feet Y `0.9` overlaps the old sliver at Z `[0.85,0.875]`, Y `[0.9,1]`, but no modern component. To make the witness fully bounded, add X `[0.1,0.7]` and specify a normal player-height box. The proof applies to the matching old `DAMAGE` 0/1/2 and modern separate registered anvil blocks; no state rewrite is required.

### Brewing stand

1.12.2 lines 36–37 and `addCollisions` lines 70–73 emit a full `[0,1] × [0,1]` plate through Y `1/8` plus the centered 2/16 stem through Y `14/16`. 1.13.2 lines 33, 56–58 combine a `[1/16,15/16]` plate with the same stem. The 1/16 outer-strip witness given in the Verdicts has vertical overlap and misses the stem. The default collision path consumes the union shape; bottle state is not read.

### Cauldron

1.12.2 lines 35–39 and 47–53 define the `5/16` base and four `2/16` walls. 1.13.2 lines 33–45 subtract the inside box starting at `4/16` from a unit cube. The shell therefore supports a player in the opening at the stated differing heights. The 1.13.2 `getShape` does not branch on `LEVEL`; neither did the old collision union.

### Hopper

1.12.2 lines 38–42 and 56–62 always emit a `10/16` floor and full-height perimeter walls, without reading `FACING`. 1.13.2 lines 33–41 form a 10/16 rim with inner subtraction, a 4/16-to-10/16 funnel, and directional 4/16 spouts; lines 54–69 select by `FACING`. The draft's EAST box has a positive old wall intersection and no modern shape intersection at its Y/Z coordinates. The modern `ENABLED` property does not enter this provider. `Hopper.INSIDE` is a shape ingredient for the subtraction, not an extra collision response.

### Wall beside TNT

1.12.2 `WallBlock.java` lines 146–160 obtains the neighbor face shape and excludes the attachment/barrier/pumpkin family; it does not exclude TNT. Its `getShape`, `addCollisions`, and `getCollisionShape` resolve the virtual directions from neighboring vanilla block state (lines 84–102, 190–196). Base `Block.getFaceShape` is `SOLID` (Block.java lines 306 onward). In 1.13.2 `WallBlock.java` lines 51–66 excludes `Blocks.TNT`, and placement/update paths lines 69–118 compute the direction property used by `getCollisionShape`. TNT inherits the same default solid face shape. Wall collision volume depends on the direction bits: the old east arm is present; the modern east arm is absent.

Correction for the immutable claim's missing concrete player-box witness: put a wall at `(0,0,0)` with TNT at `(1,0,0)`, air elsewhere, and the wall's east side as the only horizontal connection candidate. Use a player collision box X `[0.78,1.38]`, Z `[0.2,0.8]`, Y `[1.01,2.81]` (ordinary width/height, standing or moving above the TNT top). The old east arm reaches X `1`, spans the center Z band, and has collision height `1.5`; it intersects this box over X `[0.78,1]`, Z `[0.25,0.75]`, Y `[1.01,1.5]`. The modern disconnected wall's post ends at X `0.75`, while TNT's own cube ends at Y `1`, so neither blocks the box. This makes the wall-arm collision difference reachable without attributing the collision to TNT. Add this witness and bind renewed acceptance to the amended revision.

## Immutable finding revisions

| File | SHA-256 |
| --- | --- |
| `anvil-collision-geometry.md` | `32b7aa3969d729468c758d4d8b8dff3e2c738a6f0a4e8f348d6c6a55231e75a6` |
| `brewing-stand-collision-geometry.md` | `4c43818b954bc6f240e95cee4738d22ec16cac618e6c1f5608426ea25352ea7e` |
| `cauldron-collision-geometry.md` | `3c086c7d61ce0b9d22b1bff0e4a707e841ddb2276586a60c8017727c9ea59c1c` |
| `hopper-collision-geometry.md` | `8da3c9f75358eac3646e9fa9b30ce35b2cb0c530ccfd193da2035ac46ead7f2d` |
| `wall-tnt-neighbor-connection.md` | `2e3cc708fae17c9bcb0b942b9ae2532cce02262ae9965a363756845370c8cd4b` |

No files outside this assigned audit directory were changed.

## Renewed review: amended wall-TNT revision

Review date: 2026-10-31. Immutable candidate revision reviewed: `wall-tnt-neighbor-connection.md`, SHA-256 `55acca1ebf4c50cb883e26d8739b8077a84114075c8820728b3e16b1678eb3b4`. This binding supersedes the previous **incomplete due to missing witness** verdict only for evaluating whether a witness is now present; it does not alter the earlier audit record.

**Verdict: Incomplete.** The north-side old arm/core bounds and modern disconnected provider state are correct, but the new witness intersects the adjacent TNT collision cube. It therefore does not establish an old-only player collision.

Evidence checked against canonical source and direct source-manifest rows:

- 1.12.2 `WallBlock.java` SHA-256 `7e4378c46e367c32deca14475e5161b6e4223947d83153ce3e7ba5c8a0d18e50`; `Block.java` `e4a90eca411e7b0e14f5018f7385ec29891f6cdf1a1e917fa648b5712f9b33a1`; `TntBlock.java` `28fbb89aca1f7aed4587bc612cd9356f760f8784f138358afb7e27108405df9d`.
- 1.13, 1.13.1 and 1.13.2 `WallBlock.java` are byte-identical, SHA-256 `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf`; `PaneBlock.java` is byte-identical across these versions, SHA-256 `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c`. Each matches its respective source-manifest row.
- 1.12.2 `WallBlock` maps the NORTH property to horizontal bit 2 (Direction.java lines 17, 47–49; `getShapeIndex` lines 105–123), selecting shape index 4 when north alone connects. Shape index 4 is X `[0.25,0.75]`, Z `[0,0.75]`; its collision counterpart has maxY `1.5` (`WallBlock.java` lines 33, 46–62). This decomposes into the core Z `[0.25,0.75]` and the north arm Z `[0,0.25]`, so the draft's old-only wall geometry bounds are accurate.
- In 1.13.2 TNT is in `isExceptionForConnection` (`WallBlock.java` lines 57–65), while base `Block.getFaceShape` is SOLID and default `getCollisionShape` uses the state shape when collidable (`Block.java` lines 383–395). With TNT north and other neighbors empty, the modern state has NORTH=false and UP=true. The wall provider indexes the disconnected center core only (`WallBlock.java` lines 24–39). `PaneBlock.makeShapes` makes that core X/Z `[0.25,0.75]` and collision Y `[0,1.5]` (PaneBlock.java lines 38–64). These facts validate the draft's modern provider claim.

The candidate box X `[0.2,0.8]`, Z `[-0.36,0.24]`, Y `[0,1.8]` overlaps the TNT block at north position `(0,0,-1)`: the TNT cube has X `[0,1]`, Z `[-1,0]`, Y `[0,1]`, giving positive overlap in all three dimensions. Its “no modern collision candidate” conclusion is false; the TNT itself supplies a modern collision candidate (and a native collision in the old version).

Exact witness correction: keep the wall at `(0,0,0)`, TNT at `(0,0,-1)`, other horizontal sides empty, and set the player box to X `[0.2,0.8]`, Z `[-0.36,0.24]`, Y `[1.01,2.81]`. It remains width/height `0.6 × 1.8`. This clears TNT vertically because the player bottom is above its top at Y=1. The old north arm then intersects X `[0.25,0.75]`, Z `[0,0.24]`, Y `[1.01,1.5]`; the modern wall core starts at Z=0.25 and does not intersect. A horizontal move above the TNT top can distinguish the providers. Amend the immutable candidate with this corrected box and request another hash-bound review before acceptance.

## Second renewed review: elevated wall witness and fence-TNT finding

Review date: 2026-10-31. Exact candidate revisions rechecked:

| Finding | SHA-256 | Verdict |
| --- | --- | --- |
| `wall-tnt-neighbor-connection.md` | `ecf8453d373106fe332439ef243be86166b8e2681799132c519d0f94fe2e833a` | **Accept** |
| `fence-tnt-neighbor-connection.md` | `6d11641319feed525a87fd631bbd6ece331047d8fd53587a9f5397639b4c6440` | **Accept** |

### Wall witness verification

The new wall revision's north-only player box has X `[0.2,0.8]`, Z `[-0.36,0.24]`, Y `[1.01,2.81]`, with TNT north at `(0,0,-1)`. The north TNT unit cube ends at Y=1; the player box begins at Y=1.01, so there is no TNT collision. The old wall's north arm has X `[0.25,0.75]`, Z `[0,0.25]`, and collision height through Y=1.5; the player box overlaps it with positive volume X `[0.25,0.75]`, Z `[0,0.24]`, Y `[1.01,1.5]`. The old core also reaches Z `[0.25,0.75]`, so it has no overlap because the player box ends at Z=0.24. The modern disconnected core starts at Z=0.25, likewise with no overlap. The corrected witness therefore establishes old-only wall collision.

### Fence source and state correspondence

All directly hashed source files below match the row in the corresponding exact-release `ornithe-feather.sources.sha256` manifest.

| Evidence file | 1.12.2 SHA-256 | 1.13–1.13.2 SHA-256 |
| --- | --- | --- |
| `block/FenceBlock.java` | `633ad3b20250bd010a28d0b1362b24c81a5508be8a81a9d826953a3c9c4a703e` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` |
| `block/Block.java` | `e4a90eca411e7b0e14f5018f7385ec29891f6cdf1a1e917fa648b5712f9b33a1` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` (1.13 has its own `e5be72b77a28e89595009289964bb031bbb187d15d5698570615e6fc9a21a476`) |
| `block/Blocks.java` | `8d34c5e531407689108668a84bb8fe705bf987b1481ae8b6d3a6e39424243e2e` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` (1.13 has its own `8e66b1ad391d61f4f42fecb313f99299810493cb87525493f9ace8a1eb7cd000`) |
| `block/PaneBlock.java` | not used by the 1.12.2 fence provider | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` |
| `block/TntBlock.java` | `28fbb89aca1f7aed4587bc612cd9356f760f8784f138358afb7e27108405df9d` | `2acf48c3575f434324af23053816855e8e34e21119653c304b438af0ae03a305` (1.13 has its own `43e398acc9d401a2ba8b20b0bc2cfd979a0662a41e3c29b2ef3d9aa75d513713`) |
| `unmapped/C_37931705.java` | — | `2717df7465597f98634ff1569968ff247a4ccda472209e2628ae4ab21c7364de` |

1.12.2 `Block.java` registers `fence` as a `FenceBlock` with oak material (lines 946–954); modern `C_37931705.java` maps `minecraft:fence.0` to `minecraft:oak_fence` (line 274), and modern `Block.java` registers `oak_fence` as `FenceBlock` (line 1075). `nether_brick_fence` also uses `FenceBlock` on both sides. The source-confirmed oak state correspondence is therefore explicit; compatibility need not rewrite state. TNT is `TntBlock` in both bootstraps and inherits base `Block.getFaceShape`, which returns SOLID; its ordinary full-block collision is also present in both versions.

### Fence witness verification

1.12.2 `FenceBlock.addCollisions` (lines 59–80) always emits the center collision box X/Z `[0.375,0.625]`, Y `[0,1.5]`, then emits the north arm when the resolved NORTH property is true. `NORTH_COLLISION_SHAPE` is X `[0.375,0.625]`, Z `[0,0.375]`, Y `[0,1.5]` (lines 46–50). Its resolver computes NORTH from the neighboring face and the old exception list does not contain TNT (lines 124–138, 163–167).

In 1.13.2 the fence predicate excludes TNT (FenceBlock.java lines 46–61), and placement/update write the directional booleans from that predicate (lines 75–108). With TNT north and other sides empty, NORTH is false. `FenceBlock` inherits `PaneBlock.getCollisionShape`, which indexes the collision shapes by those booleans (PaneBlock.java lines 32–35, 38–73, 82–84); with no connections the provider is the center core X/Z `[0.375,0.625]`, Y `[0,1.5]`, with no north arm. The separate `FenceBlock.shapes` field is used by `getOcclusionShape`, not this movement-collision provider.

The draft's X `[0.2,0.8]`, Z `[-0.36,0.24]`, Y `[1.01,2.81]` witness clears TNT because the player bottom is above its top at Y=1. It intersects only the old north arm over X `[0.375,0.625]`, Z `[0,0.24]`, Y `[1.01,1.5]`; it misses both old and modern center cores because its maximum Z is below 0.375, and misses the modern disconnected arm because NORTH=false. Thus the witness demonstrates old-only collision. The old predicate, modern exclusion, selected vanilla fence/TNT classes, endpoint-boundary caveat, and movement interpretation in the immutable draft are supported.

### Geometry note correcting the preceding wall review text

On rechecking the exact constructor arguments, the modern **WallBlock** center core's Z interval is `[5/16,11/16]` (`[0.3125,0.6875]`), not `[0.25,0.75]`; its X interval is `[4/16,12/16]` (`[0.25,0.75]`). `WallBlock` builds its own arrays with `makeShapes(4.0F, 3.0F, ...)` (WallBlock.java lines 22–28), where `PaneBlock.makeShapes` derives the center bounds from `8-f` and `8-g` (PaneBlock.java lines 38–47). Earlier modern-wall descriptions in this audit that gave Z `[0.25,0.75]` are corrected here. This does not change the wall verdict: both reviewed boxes end at Z=0.24, below the actual modern core minimum Z=0.3125, and the old north arm intersection remains positive. The fence geometry and verdict are unaffected.

## Moving-piston amendment re-review

Review date 2026-10-31. Immutable draft `findings/moving-piston-short-head-collision.md`, SHA-256 `93121adeba200935b23c14df1d4c97a7adf0b06eaae94fe62e982df3b22b76e5`.

**Verdict: Accept.** The amendment removes the false factory claim. The chunk NBT path does accept a `MOVING_BLOCK` plus serialized `piston` block entity at `(0,0,0)` without an adjacent piston base; this is a conditional file-input premise and does not claim ordinary piston mechanics generate it. The earlier predicate, geometry, player movement broadphase and witness review remains applicable to this unchanged draft content.

Direct canonical source-file SHA-256 hashes match their exact-release `ornithe-feather.sources.sha256` rows: 1.12.2 `MovingBlock.java` `2bcea815334849934eaa3283eead3a7a27f7b77503a8789aae1479af725df5c4`, `MovingBlockEntity.java` `a55ee14227fe6ac0932283cba0414e946ba8e2637f543b3a3fe13d4e45b7b16e`, `BlockEntity.java` `8679832a35bf046517522bc7c05f30256eb674c70781748bae9fcbd8060eb3f8`, `WorldChunk.java` `b80c4962661b31c9015faa9bb3d42e390528b59473956ba20e424c76625b844f`, `AnvilChunkStorage.java` `057c620b6156a3c860065122c1cef42e44917422662599cc18000efdfea98c60`; 1.13.2 `MovingBlock.java` `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61`, `MovingBlockEntity.java` `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46`, `BlockEntity.java` `14cdcff8076ba8d32e0e36c32e1a7d645e1a63b4e02f4a74d086fae7f232a0d2`, `WorldChunk.java` `d800fac11aa2672a4dd69cb5a599e5f84bb6e2c71cfc8080fa972acdabfb4914`, `AnvilChunkStorage.java` `9037625793eb4b046d4c80ebf352d73a0b750f969dfaa1fc2a53b35467dc5031`.

The old loader reads the chunk `TileEntities` list, calls `BlockEntity.fromNbt(world, nbtCompound3)`, then `worldChunk.addBlockEntity` (`AnvilChunkStorage.java` lines 338–345). Old `BlockEntity.fromNbt` resolves id `piston` to `MovingBlockEntity`, then calls `load(world)` and `readNbt`; `WorldChunk.setBlockEntity` accepts the instance because the target block is a `BlockEntityProvider`, without checking a base neighbor. In modern 1.13.2, `AnvilChunkStorage` lines 538–550 reads each serialized block entity through `BlockEntity.fromNbt` and adds it to the chunk (including the pending/packed handling path); `BlockEntityType.PISTON` constructs `MovingBlockEntity`, `readNbt` assigns the moved state/facing/progress/extending/source, and `WorldChunk.setBlockEntity` accepts it for a provider state without neighbor validation. `MovingBlock` extends `BlockWithBlockEntity` in both releases but `createBlockEntity` returns null, so the serialized entity is loaded by id/type rather than by that factory. Both providers query the BE at the moving block's own position for collision and perform no base lookup. No source gap remains for the amended conditional premise.
