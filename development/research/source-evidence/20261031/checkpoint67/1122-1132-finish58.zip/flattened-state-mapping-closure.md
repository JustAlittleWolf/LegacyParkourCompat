# Flattened block-state mapping closure for reviewed geometry claims

This source-only note prevents interpreting newly named registry IDs as automatically modern-only movement features. It establishes selected common-state correspondences in the exact 1.12.2→1.13 endpoint interval; it does not claim exhaustive block-state migration coverage.

- **Walls:** 1.12.2 `WallBlock.Variant` defines `NORMAL(0, "cobblestone", "normal")` and `MOSSY(1, "mossy_cobblestone", "mossy")`; `getMetadataFromState` emits those IDs. Exact 1.13.2 `C_37931705.java` lines 183–184 maps `cobblestone_wall.0` to `cobblestone_wall` and `.1` to `mossy_cobblestone_wall`. 1.13.2 `Block.java` registers both IDs as `WallBlock` (lines 1240–1241). The reviewed TNT-neighbor connection difference therefore applies to both historical wall variants; `mossy_cobblestone_wall` is not treated as a newly introduced wall mechanic just because it gained a separate registry ID.
- **Pumpkins:** the 1.13.2 data fixer lines 278–279 map old `lit_pumpkin.0` to `jack_o_lantern` and old `pumpkin.0` to `carved_pumpkin`. New 1.13.2 `pumpkin` is a separate `PumpkinBlock`/growable registration, while `carved_pumpkin` and `jack_o_lantern` are registered as `CarvedPumpkinBlock`. Fence/wall exception comparisons must preserve the two old inputs through their mapped carved/lit states; they must not mistake the new uncarved `pumpkin` registration for the old pumpkin block.
- **Slabs:** 1.13.2 `C_37931705.java` lines 224–238 maps the old stone slab metadata variants and wooden slab metadata 0–5 to named flattened slab IDs (including `stone_slab.2`→`petrified_oak_slab`, `stone_slab2.0`→`red_sandstone_slab`, and `wooden_slab.0..5`→oak/spruce/birch/jungle/acacia/dark-oak slabs). Its `C_80754635.java` block-state migration rules additionally distinguish old double slabs from bottom/top single slabs and carry material variants into the modern state representation; examples are lines 832–897 and 4765–4793. Therefore slab geometry comparisons must pair matching material plus half/double state rather than compare registry IDs as features. This note does not establish per-material shape equivalence.
- **Stairs:** common stair block IDs such as oak, cobblestone, sandstone and red-sandstone stairs are retained as their names in the modern registry and constructed as `StairsBlock`. The separately recorded `stair-state-index-proof.md` pairs every shared `FACING`, `HALF`, `SHAPE` selection and proves provider index/geometry equivalence for all 40 old states. The newer `WATERLOGGED` property is not read by that collision provider. New stair registry variants must be separated from that old-state proof.
- **Anvils:** the already audited data fixer maps `anvil.0/.1/.2` to `anvil/chipped_anvil/damaged_anvil`, all of which are registered as `AnvilBlock`; the accepted anvil draft explicitly covers these damage values.

These mappings support the accepted wall and anvil pairings and constrain future slab/stair provider work. They do not close the broader provider-state inventory.

## Source identities

All hashes are exact current file SHA-256 values and match their corresponding source-manifest rows.

| Source | SHA-256 |
|---|---|
| 1.12.2 `block/WallBlock.java` | `7e4378c46e367c32deca14475e5161b6e4223947d83153ce3e7ba5c8a0d18e50` |
| 1.13.2 `unmapped/C_37931705.java` | `2717df7465597f98634ff1569968ff247a4ccda472209e2628ae4ab21c7364de` |
| 1.13.2 `unmapped/C_80754635.java` | `2aff1baacd621e5719ee221181cac4593e382a6fd1c3f0215f1a7bddbbb7330e` |
| 1.12.2 `block/SingleStoneSlabBlock.java` | `3b3808a68671d1f559f20ac6cc71a367223d50e9c646dbf470f2da3a503cca98` |
| 1.12.2 `block/DoubleStoneSlabBlock.java` | `1a3734ac32471179ba9b4637e857f0131968077abbe1f82535acc3fe73300729` |
| 1.13.2 `block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` |
| 1.13.2 `block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
