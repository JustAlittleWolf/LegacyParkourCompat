# Farmland conversion push-up epsilon

## Source binding

Exact `ornithe-feather` sources, SHA-256:

| Release | `net/minecraft/block/FarmlandBlock.java` | `net/minecraft/block/Block.java` |
|---|---|---|
| 1.12.2 | `d84c75dae139181b5d58cfa34f3cb77c5b2d4bda63d6ad9c3b52a47350bd0b98` | `e4a90eca411e7b0e14f5018f7385ec29891f6cdf1a1e917fa648b5712f9b33a1` |
| 1.13 | `18d061d467420844b6a610e62fd1cff402f657afd7f8b115669e51d3e6bee219` | `e5be72b77a28e89595009289964bb031bbb187d15d5698570615e6fc9a21a476` |
| 1.13.1 | `581dae15cc29abe90f9cf20232a3cd1b7ab6c868808bc5e4f05816952b61eef9` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `581dae15cc29abe90f9cf20232a3cd1b7ab6c868808bc5e4f05816952b61eef9` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |

## Paired operation and reachable trigger

1.12.2 `FarmlandBlock.onFallenOn` (`:60-69`) calls `setDirt` after the following gates: server world (`!world.isClient`), `world.random.nextFloat() < fallDistance - 0.5F`, `entity instanceof LivingEntity`, PlayerEntity or mob-griefing, and `entity.width * entity.width * entity.height > 0.512F`. The 1.13 / 1.13.1 / 1.13.2 method (`:85-95`) has the same gate/order; it passes the old state to the new helper. A normal-sized player satisfies the final gate (`0.6 * 0.6 * 1.8 = 0.648`) and is admitted regardless of the mob-griefing rule. A landing with fall distance over 0.5 has a reachable random outcome.

On conversion, 1.12.2 `setDirt(World,BlockPos)` (`:72-80`) first writes dirt, then queries entities intersecting the top farmland slice and computes `d = min(slice height, slice.maxY - entity.shape.minY)`. It calls `entity.teleport(x, y + d + 0.001, z)`. In 1.13+ `setDirt` (`1.13 :97-99`, `.1/.2 :97-99`) passes old/new states to `Block.pushEntitiesUp`; that helper obtains the new-shape-only slice, enumerates intersecting entities and teleports by `1.0 + calculateMaxOffset(Y, entity shape moved up by 1, slice, -1.0)` with no epsilon (`Block.java` 1.13 `:138-150`, .1/.2 `:122-134`).

## Movement result

For a player horizontally overlapping the top 1/16 and landing with feet at `Y + 0.9375`, the old overlap query includes the player and yields a `0.0625` push plus `0.001`, while the new shape offset yields `0.0625` only. The player's resulting direct server-side position differs by `0.001` block. The helper itself calls the player entity's `teleport`; this is therefore an eligible direct player-position response propagated to the local client through the previously source-bound authoritative correction path. It is not excluded just because farmland-to-dirt conversion initiates it.

The trigger and helper-call behavior match across 1.13, 1.13.1 and 1.13.2; those later releases are not distinguished here. Applicability is conditional on horizontal overlap with that slice and the source fall gate. This is an independently source-bound candidate for review, not an accepted finding or pair-freeze claim.
