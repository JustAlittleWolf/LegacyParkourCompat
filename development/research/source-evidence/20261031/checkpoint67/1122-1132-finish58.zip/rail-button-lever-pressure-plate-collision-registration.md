# Collision-registration closure: rails, buttons, levers, pressure plates

## Pair and state scope

Canonical exact local `ornithe-feather` sources are 1.12.2, 1.13, 1.13.1, 1.13.2. This closes the movement collision-registration branch for the historically shared rail family (rail, powered/golden rail, detector rail, activator rail), buttons (stone and wood), lever, and pressure plates (stone, wood, light weighted, heavy weighted). It does not assess their outline/ray-trace/render shape changes or redstone activation behavior.

## Old collision path

In 1.12.2, `Block.EMPTY_BLOCK_SHAPE` is null (`Block.java:54`), and `Block.addCollision` skips null shapes (`Block.java:375-380`). `AbstractRailBlock.getCollisionShape` returns this empty shape (`AbstractRailBlock.java:39-43`); `AbstractPressurePlateBlock.getCollisionShape` does so (`AbstractPressurePlateBlock.java:43-47`); `ButtonBlock.getCollisionShape` does so (`ButtonBlock.java:46-50`); and `LeverBlock.getCollisionShape` does so (`LeverBlock.java:38-42`). Each concrete old registered rail, button, lever and pressure plate extends the matching base class. Thus the world movement collector receives no collision box from these registered block states even though their separate outline shapes are non-empty and can differ.

Old registration rows in `net/minecraft/block/Block.java`: rails IDs 27, 28, 66, 157; lever 69; stone button 77; wooden button 143; stone/wood/weighted plates are the respective `register(...)` arrays at lines 897-911 and 1089-1098. This maps all registered common states to the empty-collision base class above.

## Modern registration and default provider

In 1.13 / 1.13.1 / 1.13.2, each corresponding concrete registration passes `Block.Properties.noCollision()` to the shared base: powered/detector rails (Block.java 1.13 lines 936-937; 1.13.1/.2 lines 917-918), rail (1025/1006), activator rail (1325/1306), lever (1028-1029/1009-1010), stone and every wood pressure plate in the adjacent registration arrays (1030-1077/1011-1058), weighted plates (1308-1315/1289-1296), stone button (1085/1066), and every wood button (1285-1290/1266-1271). Those registration expressions are unchanged between exact 1.13, 1.13.1 and 1.13.2 for these classes.

`Block.Properties.noCollision()` sets `hasCollision=false` (`Block.java:1943-1945`), copied into the registered `Block` (`:231`). The default `Block.getCollisionShape` then returns `VoxelShapes.empty()` when `hasCollision` is false (`:393-395`). None of the four modern base classes overrides `getCollisionShape`; they only provide their nonempty outline shapes. Thus all corresponding states again yield empty movement collision shapes.

## Conclusion and bounds

There is no movement collision difference to accept for these registrations: old explicit empty shapes and modern `noCollision` defaults both contribute no block candidate to local-player movement. This closes the registration/state dependency for these four families only. The general VoxelShape-query versus AABB provider/aggregator and remaining custom providers are separate dependencies; no pair freeze or full provider census is claimed.

## Direct source hashes

All values were recomputed from the exact canonical Java files and matched each version's `ornithe-feather.sources.sha256` row.

| File | 1.12.2 | 1.13 | 1.13.1 | 1.13.2 |
|---|---|---|---|---|
| `net/minecraft/block/AbstractRailBlock.java` | `c68e554d052bb9e6d9ed11a9c21a89601e03d032a8b8b3d09fa5681de9f83de1` | `ef89230726ce9bd5ebb009d9332da90969d074762fc7eca8d477640d020a0a8d` | same as 1.13 | same as 1.13 |
| `net/minecraft/block/AbstractPressurePlateBlock.java` | `b9df850102e619002d9ce6aa6a69a133465b709602ebdaffbcbc5bc67015dd5d` | `c920500d5b908f6f516e04b6c312ba7c848c3cfa97b24d3427ccf10d2b0de701` | same as 1.13 | same as 1.13 |
| `net/minecraft/block/ButtonBlock.java` | `d1d17ec936c10a4f82a0746c75c80e9b9b75c23a73ca73bf193065ba77786894` | `0cdd88bf4f0ee6b2d935a59867c1ba6df68c098d97701e800f499f83dc7a9578` | same as 1.13 | same as 1.13 |
| `net/minecraft/block/LeverBlock.java` | `13b4dd69759f7de12e6ecf9a67464dc5704b249b0e6306eb6279ff5f85a9bf2c` | `0e9d5a08921c8b0f96c060742a24666f3a8eb2e4b9f7d408a5d242a0edc1daed` | same as 1.13 | same as 1.13 |
| `net/minecraft/block/Block.java` | `e4a90eca411e7b0e14f5018f7385ec29891f6cdf1a1e917fa648b5712f9b33a1` | `e5be72b77a28e89595009289964bb031bbb187d15d5698570615e6fc9a21a476` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | same as 1.13.1 |
