# Independent effect/equipment/movement-attribute source roster

Roster frozen before opening finish58 author reports or findings. Four exact local Ornithe Feather trees were scanned for movement attribute/effect/equipment/tick consumer terms. Exact included Java paths and SHA-256 values are in `independent-source-roster.tsv`; exact source manifest identities:
1.12.2 b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da
1.13 0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a
1.13.1 21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba
1.13.2 2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211

Selected Java files: 815
No product source, product reconciliation, backlog, wiki, Git history, tests, runtime, network or online mappings were inspected.
