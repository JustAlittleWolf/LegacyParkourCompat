# Stair collision shape index proof

## Exact sources

The canonical roots are exact `ornithe-feather` Feather Gen2 build 2 trees at `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{1.12.2,1.13,1.13.1,1.13.2}\ornithe-feather`. The checked `StairsBlock.java` hashes match each exact `ornithe-feather.sources.sha256` manifest:

| Version | `StairsBlock.java` SHA-256 |
|---|---|
| 1.12.2 | `c52a011a759b6f3ef6d45162d3b61f464ceceee5d2d8735de6f6e25a56e55611` |
| 1.13 | `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` |
| 1.13.1 | `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` |
| 1.13.2 | `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` |

`Direction.java` hashes also match the 1.12.2 and 1.13.2 manifests. Both source enums assign horizontal IDs identically: SOUTH=0, WEST=1, NORTH=2, EAST=3. Old `StairsBlock.Shape` and modern `StairShape` have the same ordinal/string order: STRAIGHT=0, INNER_LEFT=1, INNER_RIGHT=2, OUTER_LEFT=3, OUTER_RIGHT=4.

## Old provider and modern index

1.12.2 `StairsBlock.addCollisions` emits a base half-box, then a facing-oriented half-box for STRAIGHT/INNER_LEFT/INNER_RIGHT, then a directional quarter-box for every non-STRAIGHT state. The top-half boxes mirror the lower-half coordinates vertically. 1.13.2 `getShape` selects the same top/bottom base and an OR-shape assembled from quarter masks. Its index is `shape.ordinal()*4 + Direction.getIdHorizontal()`, and `SHAPE_INDICES` is `[12,5,3,10,14,13,7,11,13,7,11,14,8,4,1,2,4,1,2,8]`. Mask bits are NW=1, NE=2, SW=4, SE=8.

The following table independently evaluates the 20 modern indices against the old procedural box-selection rules. Each mask includes all old top-step boxes in addition to the always-present base half.

| Shape | Facing | Old half-box(es) | Index | Modern mask | Old mask |
|---|---|---|---:|---:|---:|
| straight | south | south | 0 | 12 | 12 |
| straight | west | west | 1 | 5 | 5 |
| straight | north | north | 2 | 3 | 3 |
| straight | east | east | 3 | 10 | 10 |
| inner_left | south | south + east-derived quarter | 4 | 14 | 14 |
| inner_left | west | west + south-derived quarter | 5 | 13 | 13 |
| inner_left | north | north + west-derived quarter | 6 | 7 | 7 |
| inner_left | east | east + north-derived quarter | 7 | 11 | 11 |
| inner_right | south | south + north-derived quarter | 8 | 13 | 13 |
| inner_right | west | west + east-derived quarter | 9 | 7 | 7 |
| inner_right | north | north + south-derived quarter | 10 | 11 | 11 |
| inner_right | east | east + west-derived quarter | 11 | 14 | 14 |
| outer_left | south | south-derived quarter | 12 | 8 | 8 |
| outer_left | west | west-derived quarter | 13 | 4 | 4 |
| outer_left | north | north-derived quarter | 14 | 1 | 1 |
| outer_left | east | east-derived quarter | 15 | 2 | 2 |
| outer_right | south | west-derived quarter | 16 | 4 | 4 |
| outer_right | west | north-derived quarter | 17 | 1 | 1 |
| outer_right | north | east-derived quarter | 18 | 2 | 2 |
| outer_right | east | south-derived quarter | 19 | 8 | 8 |

The shared `FACING`, `HALF`, and `SHAPE` values therefore select the same collision volume for all 40 non-waterlogged stair states. Modern `WATERLOGGED` is extra state but is not read by `getShape` or its index calculation. There is no stair collision geometry finding from this provider/index slice. This closes only common stair-state selector equivalence; it does not close every stair registration, shape-provider dependency, or the 1.12.2→1.13.2 pair audit.
