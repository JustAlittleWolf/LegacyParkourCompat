# Intermediate source comparison and body checks

All exact trees were read from the canonical `ornithe-feather` roots. The source-file identities and manifest matches are in `source-hashes.md`. Normalized method-body hashes below were computed from the exact source lines with line endings joined as LF; they supplement the whole-file SHA-256 values and are not a substitute for those source-file identities.

## Bodies identical across exact 1.13, 1.13.1, and 1.13.2 sources

| Source member | 1.13 body SHA-256 | Lines inspected in 1.13.2 | Result |
|---|---|---:|---|
| `Entity.checkWaterState()` | `e31d25551c436b509c5b147c193441b76380f0330cafa1e6c1114f411a0c2931` | 961-977 | identical in all three |
| `Entity.m_69693160(Tag<Fluid>)` | `c354fc9dfd269c48bf3aedc76773d4a756608f639b2753f762b2613d9703c3ef` | 2509-2571 | identical in all three |
| `Entity.isSubmergedIn(Tag<Fluid>)` | `a20602ba90ad4b8f99992bd3161ccdee1e4320de3f2e54021852aaf077b6c8df` | 1042-1051 | identical in all three |
| `LivingEntity.moveRelative()` | `78de2dc443a97a6d6d08a3e430b0a5dbcb967ad73a5dddd14d9f7169cec56e82` | 1478-1656 | identical in all three |
| `LivingEntity.mobTick()` | `456e54a0cb1f45dae34ef3f9aa4e208539a92e688a0f9cc85c20e5686d5c1a68` | jump slice 1903-1917 | identical in all three |
| `LivingEntity.m_74407200(Tag<Fluid>)` | not separately hashed; body at 1470-1472 is `velocityY += 0.04F` | 1470-1472 | reopened in all three |
| `LocalClientPlayerEntity.mobTick()` | `17fe27977ef9dea1ac2f5e6641d9a5c06ce6ab942c9834c550bc46e99db756a6` | sprint slice 723-758 | identical in all three |
| `PlayerEntity.updateWaterSubmersion()` | `1204172ae5b95c11c2d6314c19f2dc7077e87cc0158de9278085253f989ce285` | 257-260 | identical in all three |
| `PlayerEntity.hasLiquidCollision()` | `674a7567d6bb0afdd9f36555cdbfcc57f42055fc5c397aaff170c00672312de5` | 1826-1828 | identical in all three |
| `FlowingFluid.getFlow()` | `001bfabf4aba133605305741c8ab88d1a35e57975cbc56974d92b4a34d3d4b6f` | 54-99 | identical in all three |
| `FlowingFluid.canFlowInto()` | `e37a57afd1e25fc79e9819dee7726b37dcd25f1afb80be2198982265c0efacab` | 101-103 | identical in all three |
| `FlowingFluid.isSolidFace()` | `c7cc2bc44e87196728aa54346811ce4057ad0a9169620b4c84b503d021617005` | 105-123 | identical in all three |
| `FlowingFluid.getHeight()` | `987e3445d0b5f6f9356ec18de6b7f669218df959db826d1f500215d0a21300a8` | 448-450 | identical in all three |
| `FluidTagsProvider.addTags()` | `be44e2cf2ed026ab63eb645537f024524dcb76927529bd0e5232ba230873d120` | 18-21 | identical in all three |
| `World.getFluidState()` | `b9ee8e95cca00f4d3d62a7cd83b68c7afc5733af3da10fbd6c9f477b21d65fd4` | 529-536 | identical in all three |
| `WorldChunk.getFluidState(int,int,int)` | `aa9c00aa846aaf8b4b138881fb10ff45c202fdd19f9bdd6f8696a86cd7944485` | 384-400 | identical in all three |
| `WorldChunkSection.getFluidState(int,int,int)` | `d9b81c3ab54f01d6789888387d7d23d7941ed294d426fe1e43055e9fc1882ad2` | 34-36 | identical in all three |
| `BlockState.getFluidState()` | `43ba504666351922720a54cdffb48bfedf078ad32ce6b15bfb65893a5d28e755` | 313-315 | identical in all three |
| `Block.getFluidState(BlockState)` | `e46dbdc9da83fb1d1dcbed3d63f8177dedb39def8bfc4d5c987f8954543375c1` | 678-681 | identical in all three |
| `FluidState.getHeight()` | `d63f4092eba682ec4a622e294b631be576ad6868f93c66249ab15704d9efe7ce` | 29-31 | identical in all three |
| `FluidState.getFlow()` | `a9951a32637a663e36b9c351e93c95ecb8bc079150d70e8e534009ffe9f70148` | 67-69 | identical in all three |

The whole `FlowingFluid.java` file differs between 1.13 and 1.13.1, but the movement-relevant flow, neighboring-fluid eligibility, solid-face, and height bodies listed above are text-identical. The whole `FluidTagsProvider.java` and `LiquidBlock.java` files also differ, so their following relevant changes were opened rather than inferred from file hashes.

## 1.13 → 1.13.1 fluid-state mapping change

1.13 `LiquidBlock.getFluidState()` lines 57-64 maps block `LEVEL >= 8` to `liquid.asFlowing(8, true)`, level 0 to `asSource(false)`, and other levels to `asFlowing(8 - level, false)`. 1.13.1/1.13.2 lines 38-50 build a list containing the source at index 0, flowing levels 7 through 1 at indexes 1 through 7, and falling level 8 at index 8; `getFluidState()` indexes that list by `min(LEVEL, 8)` at lines 67-71. The two encodings therefore yield the same `FluidState` for block levels 0 through 8. The 1.13.1 and 1.13.2 `getHeight()` body remains `state.getLevel() / 9.0F`, so legacy falling level 8 remains height `8/9` at both releases.

The fluid tag declaration itself is `FluidTags.WATER = register("water")`; the three inspected default `FluidTagsProvider.addTags()` bodies include `Fluids.WATER` and `Fluids.FLOWING_WATER` in that tag. `WaterFluid.is(Fluid)` treats those two water variants as the same family for flow adjacency. This confirms the vanilla default membership and provider behavior only; a reloadable datapack or mod-added tag member is not established by the Java default provider.

## Read-only provider chain reopened

In 1.13.2 `World.getFluidState()` returns empty outside world height and delegates to the chunk (529-536); `WorldChunk` returns empty for absent/out-of-height sections and otherwise delegates (384-400); `WorldChunkSection` reads the stored block state's fluid state (34-36); `BlockState.getFluidState()` delegates to the block (313-315); the base `Block` returns empty (678-681); `LiquidBlock` maps legacy liquid `LEVEL` to the prebuilt fluid states (67-71). This chain's methods have identical normalized bodies at 1.13, 1.13.1 and 1.13.2 except the LiquidBlock mapping representation already described.

The 1.13.2 block-specific `getFluidState()` override census and per-body dispositions are recorded in the following section; the legacy-water claims are bounded to vanilla liquid block states that existed in 1.12.2.

## Source-cell provider inventory for non-legacy 1.13 states

The 1.13.2 source census found block-level `getFluidState()` overrides in the following classes. For legacy blocks with a new `WATERLOGGED` property, those overrides return source water only when that 1.13 state property is true, otherwise delegating to the base `Block` implementation that returns `Fluids.EMPTY`: `BaseCoralPlantTypeBlock.java:109-111`, `ChestBlock.java:153-155`, `ConduitBlock.java:57-59`, `EnderChestBlock.java:155-157`, `LadderBlock.java:141-143`, `PaneBlock.java:122-124`, `SeaPickleBlock.java:113-115`, `SignBlock.java:89-91`, `SlabBlock.java:132-134`, `StairsBlock.java:345-347`, and `TrapdoorBlock.java:174-176`. The exact 1.12.2 source tree contains no `WATERLOGGED`/`waterlogged` reference, so these true states did not exist at the older endpoint. New blocks `BubbleColumnBlock.java:86-88`, `KelpBlock.java:63-65`, `KelpPlantBlock.java:41-43`, `SeaGrassBlock.java:86-88`, and `TallSeaGrassBlock.java:77-79` directly return source water; those classes are absent from the 1.12.2 source tree. The new states/blocks are retained as modern behavior under the project invariant and do not make the legacy-water current witness depend on an omitted provider.

The queried vanilla legacy water source/flowing blocks are supplied by `LiquidBlock.getFluidState()` and its enumerated fluid-state list. There is therefore no uninspected vanilla old-state block provider in this assigned query slice. Modded block providers and reloadable custom tag membership remain outside this exact vanilla-source claim.
