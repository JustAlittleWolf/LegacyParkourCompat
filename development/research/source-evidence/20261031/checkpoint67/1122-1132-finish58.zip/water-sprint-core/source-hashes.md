# Exact source identities and file hashes

Read-only canonical roots: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\<release>\ornithe-feather\`. Markers and source manifests are siblings in `<release>\`. Mapping namespace is Ornithe Feather; mapping option is Feather. No source tree was generated or changed.

| Release | Ready marker source manifest SHA-256 | Mapping artifact identity |
|---|---|---|
| 1.12.2 | `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da` | `feather-gen2-1.12.2+build.2-mergedv2.jar,feather-gen2-1.12.2+build.2.tiny` |
| 1.13 | `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a` | `feather-gen2-1.13+build.2-mergedv2.jar,feather-gen2-1.13+build.2.tiny` |
| 1.13.1 | `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba` | `feather-gen2-1.13.1+build.2-mergedv2.jar,feather-gen2-1.13.1+build.2.tiny` |
| 1.13.2 | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `feather-gen2-1.13.2+build.2-mergedv2.jar,feather-gen2-1.13.2+build.2.tiny` |

Relevant source file SHA-256 values below were computed from the read-only tree and each matched the corresponding row in that release source manifest.

| Release | Relative Java path | SHA-256 | Manifest row |
|---|---|---|---|
| 1.12.2 | `net/minecraft/entity/Entity.java` | `80f091bf32166c88cf8bbd31caf72d84fa16224410733c7d2a0f00563f294a0a` | matched |
| 1.12.2 | `net/minecraft/entity/living/LivingEntity.java` | `190e9ac551538e015d9e4d6c42856e5ba32b593131cf6d93895e7b29533f1ee6` | matched |
| 1.12.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `e4e0fdbe07a7d0a0ae4a70cbb6739a287c9d045a4a12b409895c220b5d91fe1e` | matched |
| 1.12.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `01a58e94d8c6ff98a8e3794227cdc76a5fcbdbad795c70c9cf28854aff9823cc` | matched |
| 1.12.2 | `net/minecraft/world/World.java` | `e9fa9b8d6d31ad57a5b876f5f63a5e3c554a23437decf1845a493daf48233594` | matched |
| 1.12.2 | `net/minecraft/block/LiquidBlock.java` | `00f7995dd49a48bf97316e30b3d6e41d8ee1e65dd212f3dc64891883621c4260` | matched |
| 1.12.2 | `net/minecraft/util/math/Box.java` | `f788b8146b14f299ccb58ea0854609f845c298a963295d503de2e30e15d66f3a` | matched |
| 1.13 | `net/minecraft/entity/Entity.java` | `09514488d9055449c47e2e4bcd23b5773203ca634b7ecba2323a99d0ae016642` | matched |
| 1.13 | `net/minecraft/entity/living/LivingEntity.java` | `c38e95c2c13e088b03d77fc2c6b98d4edd7e6ca5aef12b187c8e3f3ea782e864` | matched |
| 1.13 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4a57ce65405436aeb211d7a04a9a9f6ae1a661d033fd3ba2424909bfb42b8acd` | matched |
| 1.13 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `a188e1bc87831dd9da1ec1366a49acc4104c18e6979129097d02d5d3617e6a08` | matched |
| 1.13 | `net/minecraft/world/World.java` | `6e3d94e6cdcfbb15472c4ee981a1c12500eaf7cd5d5dc20d75bcde91174c2eb5` | matched |
| 1.13 | `net/minecraft/block/LiquidBlock.java` | `a2033da6ef3d2e1adc3b67c58b524949d458aa9992d8fad6c1c2596a01830626` | matched |
| 1.13 | `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | matched |
| 1.13 | `net/minecraft/tag/FluidTags.java` | `b9d4c2d93f4594f27e235e2d5973cd0c81d269597cbdc400a11333cc617247aa` | matched |
| 1.13 | `net/minecraft/data/tag/FluidTagsProvider.java` | `c6a5d61c8ac606fcc6c28e6705043eefada4ec32d9ae02688b4524a0e3b88e16` | matched |
| 1.13 | `net/minecraft/fluid/Fluids.java` | `1df360e05d0220a84c37fa48a93deea72eeb92908902781170ec0001821d5d74` | matched |
| 1.13 | `net/minecraft/fluid/WaterFluid.java` | `183894d0a4f7a85becd97eb2c0f6cedc1d5adc4648dc6d3d2b5624df173df28b` | matched |
| 1.13 | `net/minecraft/fluid/FlowingFluid.java` | `da81f379a77ef5da26e87503a1f605df4efbf5d5c02e6b6f68a916dc327df5dd` | matched |
| 1.13 | `net/minecraft/fluid/state/FluidState.java` | `05e2df9377a3bc1e91645ce4282bcaa4edebe93d7ef1907407961baaecff23a6` | matched |
| 1.13 | `net/minecraft/fluid/state/FluidStateImpl.java` | `cffddf7de4779c0d6e7508b827db506ea3b0cfe1a010fe24c2a8e042c2398b71` | matched |
| 1.13 | `net/minecraft/world/chunk/WorldChunk.java` | `85d6203e3c3b1ebbb134b23b79fde4fd8f7a1950e9c065e3fd5ade030344029c` | matched |
| 1.13 | `net/minecraft/world/chunk/WorldChunkSection.java` | `df960f6239f7413dea7882775b9693a37c5f3650eabd0e5bf70f1504a0094e7e` | matched |
| 1.13 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | matched |
| 1.13 | `net/minecraft/block/Block.java` | `e5be72b77a28e89595009289964bb031bbb187d15d5698570615e6fc9a21a476` | matched |
| 1.13.1 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | matched |
| 1.13.1 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | matched |
| 1.13.1 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4c1b14b4727116071b1ba9e3eeae84b8077f3d767e10e49b6a68a2556da32272` | matched |
| 1.13.1 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | matched |
| 1.13.1 | `net/minecraft/world/World.java` | `119ac6f61b93cf352b2026934e9f95877f55dc2f582b45d75c2bdae3652532b6` | matched |
| 1.13.1 | `net/minecraft/block/LiquidBlock.java` | `feedc9a5f1843604e6755a447e89d8d5599613799e25cf8c93a0562e52e97856` | matched |
| 1.13.1 | `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | matched |
| 1.13.1 | `net/minecraft/tag/FluidTags.java` | `b9d4c2d93f4594f27e235e2d5973cd0c81d269597cbdc400a11333cc617247aa` | matched |
| 1.13.1 | `net/minecraft/data/tag/FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` | matched |
| 1.13.1 | `net/minecraft/fluid/Fluids.java` | `89ac9422f5e0f1893a9f500736d44ffff555c90571258db22addfcb5961911dc` | matched |
| 1.13.1 | `net/minecraft/fluid/WaterFluid.java` | `183894d0a4f7a85becd97eb2c0f6cedc1d5adc4648dc6d3d2b5624df173df28b` | matched |
| 1.13.1 | `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | matched |
| 1.13.1 | `net/minecraft/fluid/state/FluidState.java` | `05e2df9377a3bc1e91645ce4282bcaa4edebe93d7ef1907407961baaecff23a6` | matched |
| 1.13.1 | `net/minecraft/fluid/state/FluidStateImpl.java` | `cffddf7de4779c0d6e7508b827db506ea3b0cfe1a010fe24c2a8e042c2398b71` | matched |
| 1.13.1 | `net/minecraft/world/chunk/WorldChunk.java` | `b1ee0253097c441ee75f05c187c086c3b37453dd74b276762ee58274c304d97b` | matched |
| 1.13.1 | `net/minecraft/world/chunk/WorldChunkSection.java` | `df960f6239f7413dea7882775b9693a37c5f3650eabd0e5bf70f1504a0094e7e` | matched |
| 1.13.1 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | matched |
| 1.13.1 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | matched |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | matched |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | matched |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | matched |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | matched |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` | matched |
| 1.13.2 | `net/minecraft/block/LiquidBlock.java` | `feedc9a5f1843604e6755a447e89d8d5599613799e25cf8c93a0562e52e97856` | matched |
| 1.13.2 | `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | matched |
| 1.13.2 | `net/minecraft/tag/FluidTags.java` | `b9d4c2d93f4594f27e235e2d5973cd0c81d269597cbdc400a11333cc617247aa` | matched |
| 1.13.2 | `net/minecraft/data/tag/FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` | matched |
| 1.13.2 | `net/minecraft/fluid/Fluids.java` | `89ac9422f5e0f1893a9f500736d44ffff555c90571258db22addfcb5961911dc` | matched |
| 1.13.2 | `net/minecraft/fluid/WaterFluid.java` | `183894d0a4f7a85becd97eb2c0f6cedc1d5adc4648dc6d3d2b5624df173df28b` | matched |
| 1.13.2 | `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | matched |
| 1.13.2 | `net/minecraft/fluid/state/FluidState.java` | `05e2df9377a3bc1e91645ce4282bcaa4edebe93d7ef1907407961baaecff23a6` | matched |
| 1.13.2 | `net/minecraft/fluid/state/FluidStateImpl.java` | `cffddf7de4779c0d6e7508b827db506ea3b0cfe1a010fe24c2a8e042c2398b71` | matched |
| 1.13.2 | `net/minecraft/world/chunk/WorldChunk.java` | `d800fac11aa2672a4dd69cb5a599e5f84bb6e2c71cfc8080fa972acdabfb4914` | matched |
| 1.13.2 | `net/minecraft/world/chunk/WorldChunkSection.java` | `df960f6239f7413dea7882775b9693a37c5f3650eabd0e5bf70f1504a0094e7e` | matched |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | matched |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | matched |

## Provider class file hashes (1.13.2)

These exact Java file hashes match their 1.13.2 `ornithe-feather.sources.sha256` rows. The cited line bodies are provider inventory only; no product implementation is involved.

| Relative source file | SHA-256 |
|---|---|
| `net/minecraft/block/BaseCoralPlantTypeBlock.java` | `661b6d0f87c8a872acd945c0716aa396ac53932d773b17e31be95b224e531fc6` |
| `net/minecraft/block/BubbleColumnBlock.java` | `0320e1b70b215dfff209f8e5003b97cac3a247fd3d642597f2db8ab46d251b2e` |
| `net/minecraft/block/ChestBlock.java` | `483ed7dc673f8acb33fbac6d5d883c652db05de2314931c522e0bee482792541` |
| `net/minecraft/block/ConduitBlock.java` | `66b110a324d9c3fe60eaa6595e59eab1b720a92a234307a8a77796b8b26a8eee` |
| `net/minecraft/block/EnderChestBlock.java` | `12642f9af345dd70a0a1787af22c48f7ce9ae0f0c2ded1ae0fe6ba009bbff431` |
| `net/minecraft/block/KelpBlock.java` | `57330c0ac1cd00000f2e0c0f78ec98d2ec48024045b65d24f506408ea3cb8952` |
| `net/minecraft/block/KelpPlantBlock.java` | `dba4dffada2a7baae6a0f06e973b5af7dd175b71b9387581497087f76378751f` |
| `net/minecraft/block/LadderBlock.java` | `c89dea1d7648bf5908e9d925b31b1ad6ead25bea3784838ae3d0fb505cfb9ab5` |
| `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` |
| `net/minecraft/block/SeaGrassBlock.java` | `a3019943a0a5a61055f4731566446e662b532b75e950d8f8676ada28ff4f5b10` |
| `net/minecraft/block/SeaPickleBlock.java` | `1b232549de646d46b2f986d78802b0f7208978e103f00bd98fe64e4fe47d76a4` |
| `net/minecraft/block/SignBlock.java` | `64d61e8c4758d6f1d13d92e56a25f7599736e625fcfaa980fcb1f8bebfe5ad39` |
| `net/minecraft/block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` |
| `net/minecraft/block/StairsBlock.java` | `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` |
| `net/minecraft/block/TallSeaGrassBlock.java` | `0876535db8acade7e4295c6044355452b936d8af99845dea71145553af35fe52` |
| `net/minecraft/block/TrapdoorBlock.java` | `26dd6911517029daef779cef046e943953356644a76372f1d47b1323054629da` |
