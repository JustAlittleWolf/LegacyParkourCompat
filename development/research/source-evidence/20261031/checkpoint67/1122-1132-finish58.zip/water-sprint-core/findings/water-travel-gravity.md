# Existing-water travel gravity

1.12.2, Ornithe Feather: `net/minecraft/entity/living/LivingEntity.java`, water branch of `moveRelative()` lines 1555-1585.
1.13, Ornithe Feather: `net/minecraft/entity/living/LivingEntity.java`, water branch of `moveRelative()` lines 1598-1636.
1.13.1 and 1.13.2, Ornithe Feather: same water-branch body; 1.13.2 lines 1617-1655.

Difference: after movement and vertical drag `velocityY *= 0.8F`, 1.12.2 subtracts `0.02` whenever gravity is enabled. 1.13.2 selects gravity magnitude `d` (normally `0.08`; `0.01` under Slow Falling while descending), then, only when gravity is enabled and the entity is not sprinting, snaps a qualifying near-zero downward value to `-0.003` or subtracts `d / 16.0`. In the default non-sprinting case this is normally `0.005` rather than `0.02`; the snap predicate can instead produce `-0.003`. Sprinting suppresses this water gravity sub-branch. Slow Falling is an additional post-1.12 effect and is not itself an old-profile behavior.

Movement meaning: for an on-foot, non-boat player in the water branch with the same entering vertical velocity and ordinary gravity, the post-move vertical velocity receives a smaller downward increment in 1.13.2, subject to the exact snap gate; a sprinting player receives no gravity subtraction in this branch. Player sprint eligibility in water is separately covered by `local-sprint-water-gates.md`.
