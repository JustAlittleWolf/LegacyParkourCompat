# Water jump decision uses immersion depth

1.12.2, Ornithe Feather: `net/minecraft/entity/living/LivingEntity.java`, `mobTick()` lines 1827-1839 and `jumpInWater()` lines 1413-1415.
1.13, Ornithe Feather: `net/minecraft/entity/living/LivingEntity.java`, jump branch in `mobTick()` lines 1884-1898 and `m_74407200(Tag<Fluid>)` lines 1451-1453.
1.13.1 and 1.13.2, Ornithe Feather: same `mobTick()` and helper bodies; 1.13.2 lines 1903-1917 and 1470-1472.

Difference: with jump held, 1.12.2 calls `jumpInWater()` whenever `isInWater()` and adds `0.04F` to vertical velocity. 1.13.2 instead reads the immersion value `f_85121000` populated by the preceding entity water query. If immersion is positive and the player is grounded with depth at most `0.4`, jump executes through `jump()` when the cooldown is zero; positive deeper immersion uses the fluid-jump helper, which adds `0.04F`. The cooldown is set to 10 after an ordinary jump and reset when jump is released. For a non-grounded player with positive depth, the fluid-jump branch is used.

Movement meaning: for an on-foot, non-boat player whose water query ran for the tick, a held jump in shallow water while grounded can take the ordinary ground-jump impulse in 1.13.2 instead of the 1.12.2 fixed `+0.04F` water impulse; deeper immersion keeps the fixed fluid impulse. The condition depends on the new cached height/query timing, not merely the old water-contact boolean. Boats skip the new contact query and are outside this finding. The change is present in exact 1.13 sources and the inspected 1.13.1/1.13.2 bodies match; the pair evidence does not inspect any unlisted versions before 1.13.
