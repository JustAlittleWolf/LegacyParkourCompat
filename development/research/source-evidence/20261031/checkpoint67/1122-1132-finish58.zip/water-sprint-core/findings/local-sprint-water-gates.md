# Existing local sprint gates in water

1.12.2, Ornithe Feather: `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java`, `mobTick()` lines 694-745.
1.13, Ornithe Feather: same member's sprint start/stop region, lines 719-753.
1.13.1 and 1.13.2, Ornithe Feather: same region; 1.13.2 lines 723-758.

Difference: the pre-existing sprint-key start path in 1.12.2 has no water gate. In 1.13.2 it requires `!isInWater() || isSubmergedInWater()`. Its ordinary stop condition adds shallow non-submerged water to the existing low-forward-input, horizontal-collision, and food/fly eligibility checks when the player is not in the new swimming branch. The new off-ground double-tap allowance while submerged and swimming-specific keep-sprint rules are 1.13 swimming additions, so they are not asserted as changed 1.12.2 behavior. `isSubmergedInWater()` is refreshed by `PlayerEntity.updateWaterSubmersion()` and also requires the entity's current `inWater` state; eye-height fluid-height membership supplies the submersion predicate.

Movement meaning: for an on-foot local player with otherwise eligible forward input, a direct sprint-key press can start sprinting in 1.12.2 when the player is in shallow water, whereas 1.13.2 rejects that start; an already sprinting, non-swimming player is also stopped by that shallow-water state. The precise shallow classification follows the new eye-height/tag predicate and the contact query, including the falling-water height case described in the contact finding. Vehicle sprinting is outside this slice.
