# Independent operation roster — 1.12.2→1.13.2 water and sprint slice

Input pair: exact 1.12.2, 1.13, 1.13.1, and 1.13.2 `ornithe-feather` source trees. This roster was recorded before reopening candidate method bodies. It is an operation inventory for the assigned slice, not pair-complete movement coverage.

1. **Water contact state:** entity water-contact detection, its query bounds/cell scan, per-cell predicates, contact result/state writes, and the call/update timing reachable by a local player.
2. **Water height and jump response:** water-surface/immersion-height production and refresh; jump gating and vertical response that consumes that height for an existing water-jump path.
3. **Water travel vertical force:** existing-water branch gravity/drag/snap ordering and gates during living-entity travel, including sprint and slow-fall interactions where already in scope.
4. **Local sprint start and stop:** client-local sprint initiation and cancellation predicates relevant to ordinary sprinting in/near water; keep swimming-only additions identifiable and disposition them separately from changed behavior of pre-existing sprinting.
5. **Water current force:** player-eligible liquid-flow aggregation, normalization/scaling, gates, and velocity write; include exact queried fluid state/flow dependencies needed to support the movement claim.

Planned bounded method families to trace: `Entity` fluid/contact update and entity tick call; `World`/fluid-state query and flow computation; `LivingEntity` jump/travel; `LocalClientPlayerEntity` sprint controls; `PlayerEntity` liquid-collision eligibility and water-height refresh. Neighbour fluid/block/tag rules are dependencies only where the reopened source methods actually read them.

Out of this roster: new swimming pose/propulsion and submerged double-tap sprint as modern-only additions for the old profile; unrelated movement inventory, product source, wiki inventories, product history, implementation, tests, runtime, and source generation.
