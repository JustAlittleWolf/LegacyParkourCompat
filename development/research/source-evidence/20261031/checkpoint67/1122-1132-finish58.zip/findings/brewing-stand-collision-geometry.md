# Brewing stand collision geometry

1.12.2, `ornithe-feather`: `net/minecraft/block/BrewingStandBlock.java`, `SHAPE`/`COLLISION_SHAPE`, lines 36-37 and `addCollisions`, lines 70-73.
1.13.2, `ornithe-feather`: `net/minecraft/block/BrewingStandBlock.java`, `SHAPE`, line 33 and `getShape`, lines 56-58. These complete source files are byte-identical in exact 1.13 and 1.13.1.

Difference: the 1.12.2 collision provider emits a full-footprint plate from y=0 to 2/16 plus a centered 2/16-wide stem from y=0 to 14/16. In 1.13.2 the union shape keeps the stem dimensions but narrows the plate to x,z=1/16..15/16. The modern inherited collision provider uses that union as the block collision shape. A player box overlapping only the outer 1/16 strip of the old plate (with vertical overlap) therefore collides in 1.12.2 but not in 1.13.2. Bottle-presence properties do not affect this shape. This comparison is for the shared brewing-stand block state and does not change vanilla state.

The pair endpoints establish only an unknown insertion boundary within 1.12.2 to 1.13.2. The narrowed plate is present by 1.13 and remains through 1.13.1 and 1.13.2.
