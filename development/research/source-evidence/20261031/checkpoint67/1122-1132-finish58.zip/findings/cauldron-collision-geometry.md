# Cauldron bottom collision thickness

1.12.2, `ornithe-feather`: `net/minecraft/block/CauldronBlock.java`, `BASE_SHAPE` and `addCollisions`, lines 35-53.
1.13.2, `ornithe-feather`: `net/minecraft/block/CauldronBlock.java`, `INSIDE_SHAPE`/`SHAPE`, lines 34-35 and `getShape`, lines 43-45. The 1.13.1 and 1.13.2 source files match; the 1.13 file has unrelated body changes, while the cited shape constants and provider method retain the same values and operations.

Difference: the old collision union's solid base reaches y=5/16 (`BASE_SHAPE` maxY 0.3125). The modern shape is a full unit cube minus the inner box beginning at y=4/16; its solid bottom therefore reaches y=4/16. The surrounding walls retain 2/16 thickness. A player who drops through the open top far enough for its body box to fit inside the 12/16 opening stands one sixteenth of a block higher under the old collision provider. The `LEVEL` state does not alter either provider shape. The same vanilla cauldron block state is used; no state is rewritten.

The pair endpoints establish only an unknown insertion boundary within 1.12.2 to 1.13.2. The 1/16 bottom-thickness difference is present by 1.13 and remains through 1.13.1 and 1.13.2.
