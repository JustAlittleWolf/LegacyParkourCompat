# Independent review: bounded on-ground shallow-water jump supplement

Pair: exact 1.12.2 → 1.13.2, independently checked at 1.13 and 1.13.1. This review covers only the sibling-owned water-jump candidate's hash-bound reachability supplement. It is not a complete tick graph audit, acceptance freeze, or pair freeze.

## Frozen author inputs

| Input | SHA-256 | Disposition |
|---|---|---|
| `local-tick-writer-residual/findings/water-jump-depth-witness-supplement.md` | `43F6CA555FC83B0C6E93E28A13F0CEFE70FB512DE723E131A8FE2DF8C8C4DEDE` | Pass; geometry, contact state, depth and jump outputs independently source-checked |
| `local-tick-writer-residual/findings/manifest-r6.md` | `621FAC57B48FAA85F5D18CDB35D7846A2109B7FA4D6C2834B3E7030E428615DB` | Current candidate bindings match recalculated hashes |
| `local-tick-writer-residual/coverage.md` | `639FD479461D6C214B401A9481DA3FCC1406216AFB483C4EE95F25280C3C900E` | Context only; it still declares broader coverage open |

The canonical source manifest hashes independently checked are: 1.12.2 `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da`; 1.13 `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a`; 1.13.1 `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba`; 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`. The exact primary file hashes listed below match their source-manifest rows.

## Slab identity, remap and collision shape: pass

Old `net/minecraft/block/StoneSlabBlock.java:getStateFromMetadata` applies `metadata & 7` to the slab variant and uses metadata bit 8 to select the half when the block is not double (`1.12.2:72-80`). The `Variant` enum assigns `STONE(0)`, so metadata 0 is stone/bottom. Old `SlabBlock.getShape` returns `BOTTOM_SHAPE` for the bottom half; that box is `(0,0,0)-(1,0.5,1)` (`SlabBlock.java:20-43`).

The flattening direction is verified from `C_80754635.m_11856336`: its first serialized state is stored as the canonical state, and each later state is indexed as an alias that maps to that canonical state (`1.13.2:C_80754635.java:22-30,898`). The line-898 entry therefore maps old `{Name:'minecraft:stone_slab',Properties:{half:'bottom',variant:'stone'}}` to modern `{Name:'minecraft:stone_slab',Properties:{type:'bottom'}}`; the same entry appears at line 898 in 1.13 and 1.13.1. This is the exact `BlockState` remap for metadata 0, not a reversed interpretation.

Modern `SlabBlock` uses `Properties.SLAB_TYPE`, initializes its default to `BOTTOM` and `WATERLOGGED=false`, and returns `BOTTOM_SHAPE` for `SlabType.BOTTOM` (`SlabBlock.java:25-59`); `Block.block` scales the 16-unit shape coordinates by 1/16 (`Block.java:136-138`). Thus the mapped modern state has the same lower-half support bounds as the old state. Player width/height are `0.6F/1.8F` in all releases, and position-to-box logic centers x/z on the player (`Entity.java:177-179` old; `190-191` modern). For center `(0.8,0.5)` and feet `p+0.5`, the box x/z intervals `[0.5,1.1] × [0.2,0.8]` overlap the slab at `(0,p,0)` and adjacent water cell `(1,p,0)` with positive area, while feet rest on the lower slab's top. This is a geometrically valid on-ground state.

## Water contact, immersion and submersion: pass

The old level-0 water block at `(1,p,0)` has surface `p+8/9`: `LiquidBlock.getHeightLoss` returns `1/9` for level 0, and old `World.applyLiquidDrag` uses `ceil(bounds.maxY) >= p+1-heightLoss` while scanning cells from `floor(bounds.minY)` to `<ceil(bounds.maxY)` (`1.12.2:World.java:1579-1621`, `LiquidBlock.java:50-56`). The player's box bottom is `p+0.5`. Old contact bounds apply `.grown(0,-0.4F,0).contract(0.001)`, producing minimum y `p+0.901`, whose floor is still p; the adjacent water cell is included and the old height predicate succeeds. `Entity.checkWaterCollisions()` assigns the contact result to `inWater` before local `mobTick` (`Entity.java:382,948-963`).

Modern liquid block level 0 resolves to `liquid.asSource(false)` (`LiquidBlock.java:38-50`), and its fluid state has level 8 when it is a source (`WaterFluid.java:136-145`); `FlowingFluid.getHeight` returns `level/9.0F`, so the surface is `p+8/9` (`1.13:FlowingFluid.java:374-376`; 1.13.1/.2: `448-450`). Modern `Entity.m_69693160` contracts the full box by `.001`, scans cell `(1,p,0)`, and computes depth as `surface-box.minY`; for this witness the minimum is `p+0.501`, so depth is approximately `0.3878889`, positive and below `0.4` (`1.13:Entity.java:2507-2569`; 1.13.1/.2: `2509-2571`). `checkWaterState()` sets modern `inWater` from this contact result before local `mobTick` (`1.13:Entity.java:394,960-975`; 1.13.1/.2: `394,961-976`).

Modern `PlayerEntity.tick()` calls `updateWaterSubmersion()` before `super.tick()`, and that helper evaluates `isSubmergedIn(FluidTags.WATER)` (`PlayerEntity.java:207,257-259` in 1.13.2; corresponding lines 206/256 in 1.13 and 207/257 in 1.13.1). `Entity.isSubmergedIn` samples fluid at `y+getEyeHeight()`; with a non-sneaking, non-swimming, non-fall-flying player, `getEyeHeight()` is `1.62F` in all releases. Eyes are at `p+2.12`, above `p+8/9`, so `submergedInWater=false`. The modern current-tick immersion depth and eye submersion are separate inputs, as the draft claims.

## Jump branch, direct velocity and cooldown: pass

Use `jumping=true`, `velocityY=0`, no Jump Boost, no lava, `jumpingCooldown=0`, not sprinting/flying/riding, and the on-ground water-contact state above. In 1.12.2 `LivingEntity.mobTick()` tests `isInWater()` before the ground branch and calls `jumpInWater()` (`LivingEntity.java:1827-1839`); `jumpInWater()` adds `0.04F` to `velocityY` (`1413-1415`) and does not assign the cooldown. The direct result is `velocityY=0.04F`, cooldown remains 0.

In 1.13, .1 and .2, the freshly computed depth is approximately `0.3878889`, so the jump branch condition `!(depth>0) || onGround && !(depth>0.4)` is true; `isInLava()` is false, then the grounded/shallow condition and zero cooldown call `this.jump()` and set cooldown 10 (`1.13:1885-1897`, `.1/.2:1904-1916`). `PlayerEntity.jump()` delegates to `LivingEntity.jump()`; absent Jump Boost, the latter writes `getJumpStrength()=0.42F`. With no sprint, it does not add horizontal sprint-jump velocity. The direct result is `velocityY=0.42F`, cooldown 10. The helper and normal jump bodies are otherwise retained through the modern releases, so this candidate's first cutover is the 1.13 branch choice, not a changed jump strength.

The jump input is supplied by the local player route: `LocalClientPlayerEntity.serverTickAi()` copies keyboard `input.jumping` for the camera player, then inherited `LivingEntity.mobTick()` processes the jump before travel. `Entity.tick()` refreshes old contact or modern contact/depth before dispatching that local tick. This supports the supplement's direct pre-travel output and makes no position or trajectory claim.

## Primary source identities checked

Hashes are full-file SHA-256, verified against the exact release manifests.

| Primary source | 1.12.2 | 1.13 | 1.13.1 | 1.13.2 |
|---|---|---|---|---|
| `net/minecraft/block/StoneSlabBlock.java` | `00562D8697BF21950356A54B01D5CC13310623A672330DF4105261E539D362C4` | — | — | — |
| `net/minecraft/block/SlabBlock.java` | `DC510F95B373BC2ECCD128FBC82E2F07BABC658D8446AB1DBC4E5DD4F27293E0` | `2E7FF3FCFA5FAA83AA4AF7EA9B68F07AF8D8FE7047E08EE3A9D7D37B78C7128F` | same as 1.13 | same as 1.13 |
| `net/minecraft/block/Block.java` | `E4A90ECA411E7B0E14F5018F7385EC29891F6CDF1A1E917FA648B5712F9B33A1` | `E5BE72B77A28E89595009289964BB031BBB187D15D5698570615E6FC9A21A476` | `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` | same as 1.13.1 |
| `net/minecraft/unmapped/C_80754635.java` | — | `F9965BDE736684FE1B5B679D4F7FE80D28721D1FBEFFB037567C88B5766242EC` | `2AFF1BAACD621E5719EE221181CAC4593E382A6FD1C3F0215F1A7BDDBBB7330E` | same as 1.13.1 |
| `net/minecraft/entity/Entity.java` | `80F091BF32166C88CF8BBD31CAF72D84FA16224410733C7D2A0F00563F294A0A` | `09514488D9055449C47E2E4BCD23B5773203CA634B7ECBA2323A99D0AE016642` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` | same as 1.13.1 |
| `net/minecraft/entity/living/LivingEntity.java` | `190E9AC551538E015D9E4D6C42856E5BA32B593131CF6D93895E7B29533F1EE6` | `C38E95C2C13E088B03D77FC2C6B98D4EDD7E6CA5AEF12B187C8E3F3EA782E864` | `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C` | same as 1.13.1 |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `E4E0FDBE07A7D0A0AE4A70CBB6739A287C9D045A4A12B409895C220B5D91FE1E` | `4A57CE65405436AEB211D7A04A9A9F6AE1A661D033FD3BA2424909BFB42B8ACD` | `4C1B14B4727116071B1BA9E3EEAE84B8077F3D767E10E49B6A68A2556DA32272` | `4ED22F6C5A3C55D67EED782070AC722201DF4D624ADBC90779F1FD29C2876633` |

Water support sources: old `World.java` `E9FA9B8D6D31AD57A5B876F5F63A5E3C554A23437DECF1845A493DAF48233594`; old `LiquidBlock.java` `00F7995DD49A48BF97316E30B3D6E41D8EE1E65DD212F3DC64891883621C4260`; modern `LiquidBlock.java` 1.13 `A2033DA6EF3D2E1ADC3B67C58B524949D458AA9992D8FAD6C1C2596A01830626`, .1/.2 `FEEDC9A5F1843604E6755A447E89D8D5599613799E25CF8C93A0562E52E97856`; modern `FluidState.java` SHA `05E2DF9377A3BC1E91645CE4282BCAA4EDBE93D7EF1907407961BAAECFF23A6` and `WaterFluid.java` SHA `183894D0A4F7A85BECD97EB2C0F6CEDC1D5ADC4648DC6D3D2B5624DF173DF28B` in all three modern releases; modern `FlowingFluid.java` 1.13 `DA81F379A77EF5DA26E87503A1F605DF4EFBF5D5C02E6B6F68A916DC327DF5DD`, .1/.2 `2398D109DDC5785CB1BC8872B8C157319137DF8957FA8A03581A8F68AFB1253`. Modern water source state mapping and dimensions were inspected in all three releases. No source generation, game, build, test, network or product implementation was used.

This bounded witness passes; general water-contact/provider equivalence, complete jump/travel pairing, collision/shape and remaining local tick/writer/direct-response terminals remain open. No pair-freeze conclusion follows.
