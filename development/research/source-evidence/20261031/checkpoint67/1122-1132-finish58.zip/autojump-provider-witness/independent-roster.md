# Independent auto-jump / provider roster — exact 1.12.2 → 1.13.2
#
Roster frozen before opening any finish58 author report. Scope: `LocalClientPlayerEntity.autoJump` caller/gates and exact intersection/headroom behavior; world collision query enumeration and box/shape decomposition; all block-package Java declarations of `getShape`, `getOutlineShape`, `getCollisionShape`, or `addCollisions` in each exact source tree; relevant block state/ID migration tables and chunk/world query methods. File hashes and metadata hashes are in `independent-source-roster.tsv`.

Canonical read-only roots: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{1.12.2,1.13,1.13.1,1.13.2}\ornithe-feather`. All four `ornithe-feather.sources.sha256`, provenance and ready manifest hashes are recorded. No previous lane conclusions or author drafts were used to derive this roster.
