# Slab state migration and collision-provider closure

## Semantic mapping

The 1.12.2 slab state domain encodes material/variant in the block ID plus `Variant`; stone-family single slabs additionally carry `HALF`, double slabs carry `SEAMLESS`, and wooden single/double slab IDs carry species plus half/double semantics. The 1.13 flattened registry splits old material variants into material-specific slab IDs, and the `SlabBlock` state uses `HALF` = bottom/top/double plus `WATERLOGGED`.

Exact 1.13.2 `C_37931705.java` maps old variant IDs, including `stone_slab.0..7` to stone/sandstone/petrified-oak/cobblestone/brick/stone-brick/nether-brick/quartz slab IDs, `stone_slab2.0` to `red_sandstone_slab`, and `wooden_slab.0..5` to oak/spruce/birch/jungle/acacia/dark-oak slab IDs. `C_80754635.java` block-state conversion tables pair material-specific flattened states with legacy variant/seamless and bottom/top representations; examples for stone states are lines 832–943 and for wood states lines 4765–4794. The migration table also distinguishes modern double slab `type=double` from single `type=top|bottom`. Old `purpur_slab` was already a separate registered block; modern `purpur_slab` is likewise a `SlabBlock`.

This pairing does not treat a newly separate material ID as a new movement feature. For geometry, compare same material and semantic half/double state; ignore old stone `SEAMLESS` and modern `WATERLOGGED`, neither of which the provider reads.

## Collision output comparison

1.12.2 `SlabBlock.getShape` returns `FULL_BLOCK_SHAPE` when `isDouble()`; otherwise it chooses `TOP_SHAPE` or `BOTTOM_SHAPE` from `HALF` (old `SlabBlock.java:34–41`). Those are `[0,1]×[0.5,1]×[0,1]` and `[0,1]×[0,0.5]×[0,1]`. The default old `Block.getCollisionShape` returns that state's shape and `Block.addCollisions` appends it if non-null; material variants and `SEAMLESS` are not consulted by the collision provider.

1.13.2 `SlabBlock.getShape` returns `VoxelShapes.block()` for `SlabType.DOUBLE`, `TOP_SHAPE` for `TOP`, and `BOTTOM_SHAPE` otherwise (`SlabBlock.java:47–59`). The exact top/bottom constants use the same half-height bounds. The default modern `Block.getCollisionShape` returns `state.getShape()` because all corresponding slab registrations retain collision-enabled defaults (Block.java:393–395). `WATERLOGGED` is not read by `getShape` or the collision provider.

The shared semantic slab states therefore select equal collision volumes in the endpoint sources: all top/bottom single slabs match and all double slabs match. No 1.12.2→1.13.2 slab collision geometry finding is supported by this provider slice. This closes only slab state/material selection and its default collision provider; it does not audit placement, neighbor updates, fluid contact, or the global collision aggregation migration.

## Exact source hashes

Every listed file hash was recomputed from canonical source and matched its source manifest row; the modern `SlabBlock.java` hash is identical for 1.13, 1.13.1, and 1.13.2.

| File | Version | SHA-256 |
|---|---|---|
| `block/SlabBlock.java` | 1.12.2 | `dc510f95b373bc2eccd128fbc82e2f07babc658d8446ab1dbc4e5dd4f27293e0` |
| `block/SlabBlock.java` | 1.13.2 | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` |
| `block/Block.java` | 1.12.2 | `e4a90eca411e7b0e14f5018f7385ec29891f6cdf1a1e917fa648b5712f9b33a1` |
| `block/Block.java` | 1.13.2 | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| `unmapped/C_37931705.java` | 1.13.2 | `2717df7465597f98634ff1569968ff247a4ccda472209e2628ae4ab21c7364de` |
| `unmapped/C_80754635.java` | 1.13.2 | `2aff1baacd621e5719ee221181cac4593e382a6fd1c3f0215f1a7bddbbb7330e` |
