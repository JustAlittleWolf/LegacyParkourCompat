# Immutable author draft manifest

Pair: exact 1.12.2 → 1.13.2, checked across exact 1.13 and 1.13.1 intermediates. Each draft below is hash-locked; if its content needs correction, author a new versioned draft and retain the original.

| Candidate | Draft SHA-256 |
|---|---|
| `grounded-friction-constant.md` | `F4DD7F37C588CF2E7A86C9CB119B6D568EA8A36AF6AA2CA564680248AB06E041` |
| `wet-sprint-predicate.md` | `1C30E9D1C51DFA29CEC0E0313557B70ACACF310398338763B225DED7DB5C466B` |
| `wet-sneak-knock-down.md` | `725C060CAF67D19D600E57EFCE151C5630EE68713A939F6A0AC7FE596F4BC1D2` |

The sibling Anvil AutoJump candidate has its own separately owned primary-source draft and is referenced from `coverage.md`; it is not re-authored here.
