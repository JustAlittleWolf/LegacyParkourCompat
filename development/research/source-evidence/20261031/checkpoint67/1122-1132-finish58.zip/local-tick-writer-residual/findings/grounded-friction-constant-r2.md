# Source finding draft: grounded friction constant

Status: eligible old-feature local movement candidate; awaiting independent acceptance. This is a velocity arithmetic witness, not a trajectory or position claim.

## Claim and exact pair

`LivingEntity.moveRelative` changes the grounded non-fall-flying acceleration constant from `0.16277136F` in 1.12.2 to `0.16277137F` beginning in 1.13; the 1.13.1 and 1.13.2 methods retain the modern literal. The branch computes `s = supportSlipperiness * 0.91F`, `t = constant / (s*s*s)`, then uses `getSpeed() * t` only when `onGround`. Airborne movement selects `speedInAir`; water/lava and separate flying/fall-flying branches do not consume this formula.

Exact primary `LivingEntity.java` full-file SHA-256: 1.12.2 `190E9AC551538E015D9E4D6C42856E5BA32B593131CF6D93895E7B29533F1EE6`; 1.13 `C38E95C2C13E088B03D77FC2C6B98D4EDD7E6CA5AEF12B187C8E3F3EA782E864`; 1.13.1 and 1.13.2 each `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C`. Literal lines: 1.12.2 `1485`, 1.13 `1526`, 1.13.1 and 1.13.2 `1545`.

## Eligible local caller and state/input

`LivingEntity.mobTick` calls `moveRelative` after multiplying the movement speed fields by `0.98F`. `LocalClientPlayerEntity.serverTickAi` copies keyboard input movement fields into those speed fields. Both are executed for the local player on the logical client. `PlayerEntity` uses base `MOVEMENT_SPEED = 0.1F` in each release, with no sprint/status modifiers in this witness. Source hashes: `LocalClientPlayerEntity.java` 1.12.2 `01A58E94D8C6FF98A8E3794227CDC76A5FCBDBAD795C70C9CF28854AFF9823CC`, 1.13 `A188E1BC87831DD9DA1EC1366A49ACC4104C18E6979129097D02D5D3617E6A08`, 1.13.1/.2 `2583495F3A02B4791AA036E6A8D354D7596C4984761969A0F29B29D8D9BF42BF`; `PlayerEntity.java` 1.12.2 `E4E0FDBE07A7D0A0AE4A70CBB6739A287C9D045A4A12B409895C220B5D91FE1E`, 1.13 `4A57CE65405436AEB211D7A04A9A9F6AE1A661D033FD3BA2424909BFB42B8ACD`, 1.13.1 `4C1B14B4727116071B1BA9E3EEAE84B8077F3D767E10E49B6A68A2556DA32272`, 1.13.2 `4ED22F6C5A3C55D67EED782070AC722201DF4D624ADBC90779F1FD29C2876633`.

Use a grounded player with zero horizontal velocity, yaw zero, forward key only, no collision affecting the requested movement, and Ice Block support. Old `IceBlock.java` sets slipperiness to `0.98F` (SHA `C92BB850B67F5B3857D150EB6CC1C1D17D351EF0A553613A09FFFE543C1D7952`); modern flattened registration retains `0.98F` in `Block.java` (1.13 SHA `E5BE72B77A28E89595009289964BB031BBB187D15D5698570615E6FC9A21A476`; 1.13.1/.2 SHA `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4`). This uses an existing full block and does not rely on a changed shape.

## Source arithmetic output

Binary32 source-order arithmetic gives `s = f32(0.98F*0.91F) = 0.891800045967102`, `s³ = 0.7092550992965698`. Old `t = f32(0.16277136F/s³) = 0.22949621081352234F`; modern `t = f32(0.16277137F/s³) = 0.22949624061584473F`. Multiplying by player speed gives old scale `0.022949621081352234F`, modern `0.022949624806642532F`. The call chain is `LivingEntity.mobTick → moveRelative(sidewaysSpeed, verticalSpeed, forwardSpeed)`, so forward key input is `moveRelative` `upwards=0.98F`; its `updateVelocity` input is `(sideways=0, forwards=0, upwards=0.98F)`, whose magnitude clamps to one. At yaw zero, its Z increment `upwards*cos(0) + sideways*sin(0)` is old `0.02249062992632389F` (`0x3CB83E45`) and modern `0.02249063365161419F` (`0x3CB83E47`). This is a two-ULP difference in the immediate velocity result, before friction/collision processing. These numbers were derived from Java float operations only; no game, test, or runtime was used.

## Gates and exclusions

Required gates are local/control-side movement, grounded, not fall-flying, not in the water/lava branch, old-era support with the paired slipperiness, and paired input/attribute state. The `.162…` literal is not a flying constant. The first cutover is 1.13, and 1.13/.1/.2 all agree on the modern value. The source algebra establishes no later position or trajectory result; collision/provider behavior remains a separate dependency.
