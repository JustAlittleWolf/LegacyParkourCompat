# Immutable author draft manifest r4

Pair: exact 1.12.2 → 1.13.2, checked across exact 1.13 and 1.13.1 intermediates. Use these current drafts; earlier revisions/manifests remain preserved as audit history.

| Candidate | Current draft SHA-256 |
|---|---|
| Grounded friction constant (`0.16277136F` → `0.16277137F`) | `46B6FE5E966EE537116F7F84E9B7680392F466FE05D90D3F6B8318A6C141AE53` |
| Wet/not-submerged sprint start and retention | `D4B29057D619C6F24B83BF611608B91ED3FDAAF96A04790AF1F205FACC718798` |
| Wet+sneak `knockDownwards` | `725C060CAF67D19D600E57EFCE151C5630EE68713A939F6A0AC7FE596F4BC1D2` |

`grounded-friction-constant-r3.md` carries the corrected `moveRelative`/`updateVelocity` channel mapping and exact player speed/updateVelocity source references. `wet-sprint-predicate-r2.md` carries the corrected synchronous attribute read and same-tick Depth Strider witness. Sibling-owned Anvil AutoJump remains separately authored and is referenced from `coverage.md`.
