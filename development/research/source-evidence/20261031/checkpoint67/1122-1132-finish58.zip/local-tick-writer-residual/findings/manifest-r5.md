# Immutable author draft manifest r5

Pair: exact 1.12.2 → 1.13.2, checked across exact 1.13 and 1.13.1 intermediates. Use these current drafts; earlier revisions/manifests remain preserved as audit history.

| Candidate | Current draft SHA-256 |
|---|---|
| Grounded friction constant (`0.16277136F` → `0.16277137F`) | `46B6FE5E966EE537116F7F84E9B7680392F466FE05D90D3F6B8318A6C141AE53` |
| Wet/not-submerged sprint start and retention | `DB5652A3C85ACFBEE8EB8D32D183503CB6213E69D0F0CDCD077B9B9FFD5D1F16` |
| Wet+sneak `knockDownwards` | `725C060CAF67D19D600E57EFCE151C5630EE68713A939F6A0AC7FE596F4BC1D2` |

`wet-sprint-predicate-r3.md` corrects the r2 Depth Strider III arithmetic with every binary32 intermediate. The preceding r1/r2 sprint drafts remain preserved and superseded. The friction r1/r2 drafts and prior indexes remain preserved. Sibling-owned Anvil AutoJump remains separately authored and is referenced from `coverage.md`.
