# Immutable author index r6

Pair: exact 1.12.2 → 1.13.2 with 1.13 and 1.13.1 cutovers. This index preserves current independent author drafts plus the bounded water-jump reachability supplement. The supplement belongs to the sibling-owned canonical water-jump candidate and is not a separate claim.

| Item | SHA-256 |
|---|---|
| Grounded friction constant r3 | `46B6FE5E966EE537116F7F84E9B7680392F466FE05D90D3F6B8318A6C141AE53` |
| Wet/not-submerged sprint predicate r3 | `DB5652A3C85ACFBEE8EB8D32D183503CB6213E69D0F0CDCD077B9B9FFD5D1F16` |
| Wet+sneak knock-down | `725C060CAF67D19D600E57EFCE151C5630EE68713A939F6A0AC7FE596F4BC1D2` |
| Water-jump depth witness supplement | `43F6CA555FC83B0C6E93E28A13F0CEFE70FB512DE723E131A8FE2DF8C8C4DEDE` |

Earlier immutable drafts and indexes are preserved as audit history. The sibling-owned Anvil AutoJump and water-jump depth claims remain referenced in `coverage.md`.
