# Source finding draft: wet sneak knock-down write

Status: eligible old-era local movement writer delta; awaiting independent acceptance. This is a direct velocity source output, not a trajectory claim.

## Exact pair and cutover

Beginning in 1.13, `LocalClientPlayerEntity.mobTick()` adds `if (isInWater() && input.sneaking) knockDownwards()`; 1.12.2 has no such call or method. The call appears at 1.13 lines 785–787 and the corresponding 1.13.1/.2 lines 785–787; `LivingEntity.knockDownwards()` is the direct `velocityY -= 0.04F` writer (1.13 line 1447–1449; 1.13.1/.2 lines 1466–1468). Full-file source hashes: local player 1.12.2 `01A58E94D8C6FF98A8E3794227CDC76A5FCBDBAD795C70C9CF28854AFF9823CC`, 1.13 `A188E1BC87831DD9DA1EC1366A49ACC4104C18E6979129097D02D5D3617E6A08`, 1.13.1/.2 `2583495F3A02B4791AA036E6A8D354D7596C4984761969A0F29B29D8D9BF42BF`; `LivingEntity.java` 1.12.2 `190E9AC551538E015D9E4D6C42856E5BA32B593131CF6D93895E7B29533F1EE6`, 1.13 `C38E95C2C13E088B03D77FC2C6B98D4EDD7E6CA5AEF12B187C8E3F3EA782E864`, 1.13.1/.2 `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C`.

## Caller state, order and exact output

This call precedes `super.mobTick()`, so it runs before that tick's `LivingEntity.travel()` and directly changes the local player's vertical velocity. `Entity.baseTick()` refreshes water contact before virtual local player `mobTick()` in both eras. The old contact producer can therefore yield the shared old-era state `inWater=true`, even when the player's eyes remain above the fluid surface (`submergedInWater=false`). With equal `velocityY=0.0`, `inWater=true`, and sneak input true, the old path performs no knock-down write; 1.13+ writes `velocityY=-0.04F` before travel. This does not rely on modern swimming or submersion.

The exact local-player gate is only `isInWater() && input.sneaking`; it does not require `isSwimming`, `isSubmergedInWater`, on-ground, or a sprint state. The candidate depends on the paired old/new water contact source and same tick ordering; the permitted water-current slice owns the fluid-query equivalence proof. It is separate from the modern underwater-visibility counter immediately following it, which does not write movement state. No post-travel position or velocity trajectory is claimed.
