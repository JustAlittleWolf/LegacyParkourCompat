# Immutable author draft manifest r2

Pair: exact 1.12.2 → 1.13.2, checked across exact 1.13 and 1.13.1 intermediates.

| Candidate | Draft SHA-256 | Status |
|---|---|---|
| `grounded-friction-constant.md` | `F4DD7F37C588CF2E7A86C9CB119B6D568EA8A36AF6AA2CA564680248AB06E041` | current |
| `wet-sprint-predicate.md` | `1C30E9D1C51DFA29CEC0E0313557B70ACACF310398338763B225DED7DB5C466B` | superseded; retains erroneous speed-cache conclusion |
| `wet-sprint-predicate-r2.md` | `PENDING` | current correction; use this draft |
| `wet-sneak-knock-down.md` | `725C060CAF67D19D600E57EFCE151C5630EE68713A939F6A0AC7FE596F4BC1D2` | current |

Sibling-owned Anvil AutoJump remains separately authored and is referenced from `coverage.md`.
