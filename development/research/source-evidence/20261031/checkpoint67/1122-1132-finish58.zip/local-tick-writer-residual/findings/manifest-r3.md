# Immutable author draft manifest r3

Pair: exact 1.12.2 → 1.13.2, checked across exact 1.13 and 1.13.1 intermediates. Use only current revisions; earlier drafts and interim manifests remain preserved for audit history.

| Candidate | Current draft SHA-256 |
|---|---|
| Grounded friction constant (`0.16277136F` → `0.16277137F`) | `290425B576BA4821868955AF980B5612FA129E394D3F2FBCC000D0FD89715344` |
| Wet/not-submerged sprint start and retention | `D4B29057D619C6F24B83BF611608B91ED3FDAAF96A04790AF1F205FACC718798` |
| Wet+sneak `knockDownwards` | `725C060CAF67D19D600E57EFCE151C5630EE68713A939F6A0AC7FE596F4BC1D2` |

The initial wet sprint draft contained an incorrect same-tick cache claim; use `wet-sprint-predicate-r2.md`. The initial friction draft described the forward axis in the wrong `updateVelocity` parameter; use `grounded-friction-constant-r2.md`. The interim manifests r1/r2 are preserved. Sibling-owned Anvil AutoJump remains separately authored and is referenced from `coverage.md`.
