# Independent terminal roster: local tick and player writer residuals

Roster frozen before opening other finish58 author reports.

## Pair and canonical source identity

- Pair: exact 1.12.2 → 1.13.2, with exact 1.13 and 1.13.1 intermediates.
- Mapping/source roots: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\<version>\ornithe-feather`; read-only.
- Publisher: Ornithe Feather / Feather Gen2, Vineflower-decompiled source as identified by each exact ready record.
- 1.12.2 source manifest SHA-256 `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da`; source count 2050.
- 1.13 source manifest SHA-256 `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a`.
- 1.13.1 source manifest SHA-256 `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba`.
- 1.13.2 source manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; source count 2711.
- Ready metadata reports mapping jars `feather-gen2-1.12.2+build.2-mergedv2.jar`/`.tiny` and `feather-gen2-1.13.2+build.2-mergedv2.jar`/`.tiny`; intermediate release readiness manifests are also bound above.

## Frozen coverage terminals

1. Local input: `Input`, `KeyboardInput`, local input tick/read, axis/sneak scaling, living-control copy; validate exact methods/intermediates.
2. Local-player tick graph: `LocalClientPlayerEntity` tick/mobTick/ai/serverTickAi, sprint and auto-jump gates, push-out, riding input, item-use slowdown; follow into `PlayerEntity`, `LivingEntity`, `Entity` and exact `super` dispatch/order.
3. Ordinary inherited movement: `LivingEntity` jump, travel/moveRelative, post-move velocity/gravity/friction/sprint/effects; `Entity.move` and collision/step/support/chunk/world-border gates; full player-specific and inherited caller chain.
4. Position/velocity/box writers: enumerate and pair direct writes in `Entity`, `LivingEntity`, `PlayerEntity`, `LocalClientPlayerEntity`, client/controller/interaction methods, block and entity callbacks, status effects/items; record each caller and logical-side gate.
5. Player state geometry: dimensions, pose, eye height, swimming/sneaking/sleeping/riding, `setPosition`/box writers and resets; check local client producer/packet routes and state dependencies.
6. Modifier/equipment/effect inputs: registered effects and modifiers, add/remove timing, player attribute base/packet replacement, item/equipment slot producers and movement attribute reads; distinguish newer-only additions and excluded production.
7. Direct external/client response operations: correction/teleport, velocity/explosion, login/respawn/dimension/spectate, entity events, collision and fluid queries; trace packet producer vs client consumer separately and compare same effective inputs.
8. Block/entity/environmental player callbacks: old-era block transitions (including farmland), moving entities and callbacks, chorus teleport, dismount, push/knockback, collision and fluid/neighbor predicates; close state/registration/query dependencies or classify server-only/out-of-scope.
9. Exact intermediate cutovers for every candidate or terminal whose operation body differs across 1.13, 1.13.1, 1.13.2.
10. Water contact/current provider is an explicit dependency owned by the existing same-pair water-current source slice; independently check its source report only after this roster is frozen and pair the relevant cross-calls without duplicating provider discovery.

## Frozen exclusions/dispositions to test

- Do not emulate movement on logical server/integrated server; trace server producers and client receipt separately.
- Exclude vehicle/non-player physics, health/food production, damage calculation, rendering, bed-entry eligibility, modern-only mechanics, and profile-switch behavior.
- Equal native effective packets remain equal-input consumer evidence; server-side source behavior is not local historical movement absent a separately eligible client response.

## Required evidence shape

For each terminal: exact 1.12.2/.13/.1/.2 source file and member hashes, method/caller and side gates, state/property/tag/resource/provider dependencies, checked absence/replacement for additions/removals, and disposition as equal, concrete old-feature candidate, modern-only, or excluded. This roster is an independent inventory plan, not a completion verdict.
