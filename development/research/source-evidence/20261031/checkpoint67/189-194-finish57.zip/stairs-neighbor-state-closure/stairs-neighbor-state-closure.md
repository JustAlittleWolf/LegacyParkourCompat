# Stair neighbor-state collision closure: 1.8.9 through 1.9.4

## Bounded result

For the registered `StairsBlock` collision route, every legal local `FACING` (`NORTH`, `SOUTH`, `EAST`, `WEST`) and `HALF` (`BOTTOM`, `TOP`) can resolve to each of the five collision shapes (`STRAIGHT`, `INNER_LEFT`, `INNER_RIGHT`, `OUTER_LEFT`, `OUTER_RIGHT`) under an appropriate neighboring-stair arrangement. The A-era live predicates select the same shape as each of 1.9.1, 1.9.2, 1.9.3, and 1.9.4. For each of those 40 local tuples, the cell-local collision-box sequence and append order are equal: base first; a full half-step for straight/inner; then a quarter box for any corner. Outer shapes emit base plus quarter only. A corner-producing front neighbor takes priority over a back/inner neighbor.

This closes only `StairsBlock.addCollisions()`'s neighbor-derived local box route. It does not close the rest of the collision inventory, player clipping/trajectory, or pair coverage.

## Source and provenance bindings

Exact read-only source files under `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\<version>\ornithe-feather\net\minecraft\block\StairsBlock.java` were rehashed. Source mapping is Feather/Ornithe Feather per the assignment. Per-release source and route rows in the permitted state-domain artifacts are also bound below.

| Release | `StairsBlock.java` SHA-256 | `addCollisions` body (line range; body SHA-256) | `oak_stairs` registered route row |
|---|---|---|---:|
| 1.8.9 | `fadc964480227f6ffd5756471212b18d0172bffbcd0866ee0c278454ab079409` | 384–394; `a557925799d64c904a6324b0f44e402ce257b470e81daeb701e1edd3c4bfe03d` | `registered-route-matrix.tsv:55` |
| 1.9.1 | `19e43095405bb61eec8c9529922384c97eb6645b28f5007d3652fee9f19faa98` | 66–72; `855a5730a96b41bde86685ec88d352bb2952f828447a065a335f4b06763e8c08` | `registered-route-matrix.tsv:253` |
| 1.9.2 | `19e43095405bb61eec8c9529922384c97eb6645b28f5007d3652fee9f19faa98` | 66–72; `855a5730a96b41bde86685ec88d352bb2952f828447a065a335f4b06763e8c08` | `registered-route-matrix.tsv:467` |
| 1.9.3 | `ee143aced2a6902563cddbae77e78d1d1a512244f278987684ebe5bcacba37cb` | 67–73; `855a5730a96b41bde86685ec88d352bb2952f828447a065a335f4b06763e8c08` | `registered-route-matrix.tsv:681` |
| 1.9.4 | `ee143aced2a6902563cddbae77e78d1d1a512244f278987684ebe5bcacba37cb` | 67–73; `855a5730a96b41bde86685ec88d352bb2952f828447a065a335f4b06763e8c08` | `registered-route-matrix.tsv:895` |

The bound lane inputs are `inputs/historical-source-run.md` SHA-256 `d327b5d673c455f4f2d390c52e1e4f9bbbfc9c0c1202490f725a8f207c099d29` (read through its permitted line 989), `collision-list-inventory/report.md` SHA-256 `68901c16aac946daa65ca1647e4eebd3031b56a102fa824f585a790efee64a30`, `provider-state-census/registered-route-matrix.tsv` SHA-256 `86568a5337d92c4b3abdfd08051ec5bc9a4eaf6169a17e29b5b69df5d8f0a1b3`, `provider-state-domains/provider-method-readsets.tsv` SHA-256 `97a76e2db1b84b96b774fe3d68d98e0908bfc56d137c2a982f5de1534a0147c0`, `provider-state-domains/provider-method-transitive-hooks.tsv` SHA-256 `4fc1e0dcc43c8e87e05a94f67f445ff189563675cc064b3a04d42912a3409e2a`, `property-value-domains/helper-route-evidence.tsv` SHA-256 `f58cb00727431ff692d6eb6f0f72e7c3d0ddbbad7785b5a9e979d2373b919db4`, and `property-value-domains/property-domains-by-release.tsv` SHA-256 `a5c18db383428397ff39ebb840a748d317de9fba277c86928524b7e84ec8cc25`.

The relevant state/property provenance rows are `property-domains-by-release.tsv` 46–49, 98–101, 150–153, 202–205, and 254–257; exact helper and provider route rows are `helper-route-evidence.tsv` 8, 20, 32, 44, and 56; provider body/readset rows are `provider-method-transitive-hooks.tsv` 41, 82, 122, 162, and 202 and `provider-method-readsets.tsv` 41, 82, 122, 162, and 202. Registered `oak_stairs` reaches the direct `StairsBlock.addCollisions` provider in every release at the matrix rows above.

The permitted historical source-run projection records the Feather Gen2 build 2 source identity for the 1.8.9 and 1.9.4 endpoints and its limitation that the original derived mapped JARs are unavailable. This result binds the exact hashed source files in the assigned trees and the per-release lane rows; it does not claim byte identity to those unavailable original derived JARs. The permitted projection does not establish a separate original mapped-JAR identity for 1.9.1–1.9.3.

## Neighbor predicate and SHAPE route

In 1.8.9, `StairsBlock.addCollisions` (384–394) starts from the local `FACING`/`HALF`, probes the front neighbor in `isInnerStair` (216–295), and only probes the back neighbor in `setStepShapeForCollisions` (297–381) after no front outer corner was selected. A neighbor qualifies as a corner candidate only if it is a `StairsBlock`, has the current `HALF`, and has a perpendicular horizontal `FACING`. For an outer candidate, its opposite-facing side probe suppresses the corner only when that probe is itself a stair with the current half and facing (A helper `isStairSameHalfSameFacing`, 86–90). For an inner candidate, the corresponding neighbor-facing side probe has the same suppression rule. Thus A's positive same-family/half/facing helper under a negated call is the same gate as B's negative helper. Here A's “shape” labels these live collision outcomes; its separate virtual-outline `SHAPE` resolution is not used as evidence for collision selection.

In each B release, `FACING`, `HALF`, and `SHAPE` are declared at lines 29–31 (1.9.1/.2) or 30–32 (1.9.3/.4). The `Shape` enum contains exactly the five values listed above (1.9.1/.2 lines 422–427; 1.9.3/.4 lines 424–429). The default and placement state use `SHAPE=STRAIGHT` (default at line 55 or 56; placement at 262–263 or 263–264). There is no `StairsBlock.updateShape` neighbor-state writer in these B files. Instead `resolveVirtualProperties` (1.9.1/.2 lines 309–310; 1.9.3/.4 lines 311–312) returns `state.set(SHAPE, getStairShape(...))`. `addCollisions` calls that resolver immediately before `getCollisionShapes` (1.9.1/.2 lines 66–72; 1.9.3/.4 lines 67–73). The returned state is local to that provider call; the resolution does not write it back to the world. The same shape resolver and provider body hashes are identical within the 1.9.1/.2 group and within the 1.9.3/.4 group. `Direction.java` confirms clockwise/counterclockwise/opposite cardinal mappings: A SHA-256 `ede4dc29795263853c048e569f24e74407255767c5e02349a90895ac5b08e544` (lines 52–54, 81–89, 129–137), 1.9.1/.2 `03ef526e1f5c0a4d4a2a47263bb849665780e69ffb3d59b42368faa60ea61a1f` (same lines), and 1.9.3/.4 `10bd074fa46e27658e7109836fe5456fa1f2017a15401f28fc12900d942f02ef` (lines 53–55, 82–90, 130–138).

For current facing `d`, B checks `pos.offset(d)` first. If it is a stair of the same half, perpendicular to `d`, and the probe at `pos.offset(neighborFacing.opposite())` is not a stair of the current half/facing, the result is `OUTER_LEFT` when `neighborFacing == d.counterClockwiseY()`, otherwise `OUTER_RIGHT`. If that fails, B checks `pos.offset(d.opposite())` with the same stair/half/perpendicular gates, and suppresses the inner corner when `pos.offset(neighborFacing)` is a stair of the current half/facing. It returns `INNER_LEFT` for `neighborFacing == d.counterClockwiseY()`, otherwise `INNER_RIGHT`; if neither candidate qualifies it returns `STRAIGHT` (1.9.1/.2 lines 313–345; 1.9.3/.4 lines 315–347). A's front-first and conditional back check implements the same selection and side suppression for collision geometry.

All 40 local `(FACING, HALF, resolved SHAPE)` tuples are reachable: each of the eight `FACING × HALF` states can be straight with no qualifying front/back neighbor, outer-left/right with one qualifying front neighbor and a non-suppressing side probe, or inner-left/right with one qualifying back neighbor and a non-suppressing side probe. A qualifying neighbor must match the local `HALF`; therefore choose bottom neighbors for a bottom stair and top neighbors for a top stair. No facing/half/shape combination is ruled out. In B, `getStateFromMetadata`/`getMetadataFromState` encode `FACING` and `HALF`, not `SHAPE`; the placement/default `STRAIGHT` value is re-resolved at collision time.

## Cell-local boxes and append order

The A base box is `BOTTOM_BASE=(0,0,0)-(1,0.5,1)` or `TOP_BASE=(0,0.5,0)-(1,1,1)` (`setBaseShapeForCollisions`, 74–80). B constants match (`BOTTOM_BASE_SHAPE` and `TOP_BASE_SHAPE`, 41–42). The full half-step uses the current facing's half-plane and shares the same y range: bottom `[0.5,1]`, top `[0,0.5]`.

| Facing | Full step XZ range | Outer-left quarter | Outer-right quarter | Inner-left quarter | Inner-right quarter |
|---|---|---|---|---|---|
| NORTH | x 0–1, z 0–0.5 | NW | NE | SW | SE |
| SOUTH | x 0–1, z 0.5–1 | SE | SW | NE | NW |
| EAST | x 0.5–1, z 0–1 | NE | SE | NW | SW |
| WEST | x 0–0.5, z 0–1 | SW | NW | SE | NE |

Quarter labels are their XZ quadrants: `NW=(0,0)-(0.5,0.5)`, `NE=(0.5,0)-(1,0.5)`, `SW=(0,0.5)-(0.5,1)`, and `SE=(0.5,0.5)-(1,1)`. Their y range is the same half-step range above. The sequence is:

| Resolved shape | Ordered local boxes |
|---|---|
| `STRAIGHT` | base; full step for facing |
| `OUTER_LEFT` | base; outer-left quarter |
| `OUTER_RIGHT` | base; outer-right quarter |
| `INNER_LEFT` | base; full step for facing; inner-left quarter |
| `INNER_RIGHT` | base; full step for facing; inner-right quarter |

Taking the Cartesian product of the four facing rows, both half y-ranges, and the five shape rows explicitly enumerates the 40 tuples above. A emits base first, then the front-selected full/outer step, then the optional back-selected inner quarter (`addCollisions`, 384–394). B constructs base first, adds full step for `STRAIGHT` and `INNER_*`, and adds the selected quarter for every non-straight shape (`getCollisionShapes`, 74–88). B's inner/quarter selector formulas and constants are at 90–134 (1.9.1/.2) or 91–135 (1.9.3/.4); the orientation table above matches A's `isInnerStair` and `setStepShapeForCollisions` bounds for every direction.

The provider appends each candidate only when the supplied query box strictly overlaps it on all three axes after cell translation. A's `Block.addCollisions` gate is `box != null && query.intersects(box)` and `getCollisionShape` adds the cell position to each bound (A `Block.java`, 339–350; SHA-256 `ea10f05106a3cf7189aec85236a7ecf9c7106a717f37bed583b5ea4adeffa528`); B's helper translates the local box with `move(pos)` then uses `query.intersects(box)` (1.9.1/.2 `Block.java`, 341–346; SHA-256 `91c053e11d6bedaac292b6be2f5670e5a5c4522f175c1e227163eeb5499780b2`; 1.9.3/.4 `Block.java`, 341–346; SHA-256 `e62ece80c6a7e7121346f65f8fdfd9b148c29441a27de9f568bba9afe1d84fe6`). In exact inequalities, for query `Q` and translated candidate `C`, append iff `Q.minX < C.maxX && Q.maxX > C.minX && Q.minY < C.maxY && Q.maxY > C.minY && Q.minZ < C.maxZ && Q.maxZ > C.minZ`; face-only contact is excluded. The `Box.intersects` code is strictly positive overlap in X/Y/Z: A `Box.java` SHA-256 `8fc7bb57b1132afc7ae9539c30ff9c2585f0e36c2b0e59c60946cb1e3cee9eea`, lines 153–159; 1.9.1/.2 `Box.java` SHA-256 `cb0f30c72b7925fa0c0b133dffd051cf8260f4321f7c4a093c64ef5a5f500e62`, lines 197–203; 1.9.3/.4 `Box.java` SHA-256 `055d57e1e555cc378fd1d7ea14d57036190ae335238175d284b969f439abe198`, lines 199–205. Therefore the equal candidate sequence yields equal emitted ordered sub-sequences for any fixed query box and cell position, including queries that intersect only some of the candidates.

## Residual

The next stair-specific residual is outside this bound: verify the broader player collision-list/call-site inventory and its query-box reachability as assigned by the coordinator. Do not infer full collision coverage, overall 1.8.9→1.9.4 pair freeze, or runtime movement parity from this provider closure.
