# Lily Pad vertical collision terminal: 1.8.9 → 1.9.4

## Conditional source-level witness

The paired provider result in `fixed-inherited-provider-lists/outputs.tsv` (SHA-256 `17c3958c0bdfc30f89e2a141be9b27eae658f241f82ac188bf034a426b54c797`) is sufficient to derive a concrete local-player clipping difference through the paired `Entity.move`/`Box.intersectY` source. The exact inputs are:

- One vanilla Lily Pad at block position `(0, 64, 0)`, with air in the cells around it and water at `(0,63,0)`; no other collision boxes in the swept query.
- Same awake normal player box centered at `(0.5, 65.0, 0.5)` in both releases: `x/z=[0.2,0.8]`, `minY=65.0`, height `1.8`, from paired `PlayerEntity.setSize(0.6F,1.8F)`. It is non-sneaking, non-riding, non-noClip, and its horizontal footprint overlaps both pad shapes. No horizontal movement; `dy=-1.0`.
- The player is not a boat. This satisfies both providers' entity filter; in A the pad is included for null or any non-boat, and B skips only a `BoatEntity`.

The swept query includes the pad cell and intersects its collision shape on both sides. The A pad box is `[0,0,0]–[1,1/64,1]`; each B pad box from 1.9.0 through 1.9.4 is `[1/16,0,1/16]–[15/16,3/32,15/16]`. There are no other boxes to affect the Y loop. In both `Entity.move` bodies, the same list is collected before clipping; each list box calls `intersectY` against the current player box and requested `dy`, then the player shape is moved by the clipped `dy`.

For a negative Y limit with the player's bottom at `1.0`, `Box.intersectY` clamps to `obstacle.maxY - player.minY`. Therefore:

| Version | Pad top | Clipped `dy` | Resulting player bottom |
|---|---:|---:|---:|
| 1.8.9 | `64 + 1/64` | `-63/64` (`-0.984375`) | `64 + 1/64` (`64.015625`) |
| 1.9.0–1.9.4 | `64 + 3/32` | `-29/32` (`-0.90625`) | `64 + 3/32` (`64.09375`) |

Thus the local player's terminal Y position differs by `5/64` for this exact equal-input call. The changed provider geometry is movement-relevant, not merely a list-order observation. This remains a conditional source witness: it does not assert a vanilla server producer, ordinary player trajectory, or runtime result. The provider/list comparison is hash-bound to all five sources in the fixed-provider report; the 1.9.0 applicability addendum is established by `release-190-cutover-audit/report.md` (SHA-256 `5af7410843c41b9a125964350795d92c8671e9e50bd30b156940cd4e50c4db66`), which verifies the 1.9.0 Lily Pad, `Entity.move`, `Box.intersectY`, and world collision route against the exact .0 source map. B Lily Pad `addCollisions` bodies remain stable across 1.9.0–1.9.4. The `Entity.move` candidate-call and Y-clip order is identical in A and B; exact source file hashes and relevant method anchors follow.

## Primary source anchors

| Source | Member / anchor | SHA-256 |
|---|---|---|
| A `net/minecraft/block/LilyPadBlock.java` | constructor lines 15–19; `addCollisions` 23–27; `getCollisionShape` 30–34 | `c5d5c92a927e5d86feb5fbf22102e7200037314cdba6c1207abbe52445580f35` |
| B 1.9.0 `net/minecraft/block/LilyPadBlock.java` | `SHAPE` line 15; `addCollisions` 22–26; `getShape` 37–39 | `4e266ccc4f6f1530abc4f3fdb04acff50e171288b0735e5171d8ce34857af429` |
| B `net/minecraft/block/LilyPadBlock.java` | `SHAPE` line 15; `addCollisions` 23–27; `getShape` 31–33 | `91004173b4287d244c671ffe565ca0935d0c04983d598027f37f26d9c111136d` |
| A `net/minecraft/entity/living/player/PlayerEntity.java` | normal dimensions `setSize(0.6F,1.8F)` line 417 | `e66cb294fc93118148a444bbafdf4dd57cbf66a23d69b1e8892cefccc690ab88` |
| B `net/minecraft/entity/living/player/PlayerEntity.java` | normal dimensions `setSize(0.6F,1.8F)` line 388 | `d658a0d95452d12bb7e347bfd802240eeecaf7f938e10dcd43e2640434387f85` |
| B 1.9.0 `net/minecraft/entity/living/player/PlayerEntity.java` | normal dimensions `setSize(0.6F,1.8F)` line 387 | `edbb46236d1e42630e600e4afcb434eb6e9adecbfc4ac7e15710a5dea50010b1` |
| A `net/minecraft/entity/Entity.java` | `move(DDD)V` lines 371 onward; collision-list call at 439, Y clip loop, then `setPositionFromShape()` at 544 | `d4c10932cb5bb1067a5a58be4e1bb1b42bdde3b6fc893d88178cc07435a1696b` |
| B 1.9.0 `net/minecraft/entity/Entity.java` | `move(DDD)V` lines 438 onward; collision-list call at 506, Y clip loop, then `setPositionFromShape()` at 622 | `74d3ac34d7e6355c8fdcdd777dcd95ba9ef4626718c8772c1b58d0e28419e42a` |
| B `net/minecraft/entity/Entity.java` | `move(DDD)V` lines 441 onward; collision-list call at 509, Y clip loop, then `setPositionFromShape()` at 625 | `bcd7fa2206bf8d7271102f6da7fe2771f96dbe22ec79dab9f2101a3e29c17ef0` |
| A `net/minecraft/util/math/Box.java` | `intersectY(Box,double)` lines 113–132 | `8fc7bb57b1132afc7ae9539c30ff9c2585f0e36c2b0e59c60946cb1e3cee9eea` |
| B `net/minecraft/util/math/Box.java` | `intersectY(Box,double)` lines 159–178 | `055d57e1e555cc378fd1d7ea14d57036190ae335238175d284b969f439abe198` |
| A `net/minecraft/world/World.java` | `getCollisions(Entity,Box)` lines 891–945 | `3c04f5b874fbb6692039164c882a3c47fe28c7eca864e91c9ac57798153888ee` |
| B `net/minecraft/world/World.java` | `getCollisions(@Nullable Entity,Box)` lines 899–961 | `2fe063e0ec224eed9fc7d01b8f788c32035eed5fee5a9d98ea5e82296236e05a` |

The 1.9.0 `net/minecraft/entity/Entity.java` SHA-256 is `74d3ac34d7e6355c8fdcdd777dcd95ba9ef4626718c8772c1b58d0e28419e42a`; `move(DDD)V` begins at line 438 and its collision-list call is at line 506. The 1.9.0 `Box.java` SHA-256 is `cb0f30c72b7925fa0c0b133dffd051cf8260f4321f7c4a093c64ef5a5f500e62`; `intersectY` is the same body as 1.9.1/.2. Its `World.java` SHA-256 is `d1e23db2e20c86eb37b964a0df6838f1422ade7b0c2fff9c869ff8345979aa98`; `getCollisions(Entity,Box)` begins at line 893 and its body matches the 1.9.1 collision scan. These 1.9.0 file rows matched `.decompile-provenance.json`; the full source-map audit is in the crosswalk above.

For B intermediate releases, source-local provenance confirms current class files and the same-lane direct-method matrix records a stable Lily Pad collision-provider body hash across 1.9.1/.2/.3/.4. The `Entity.move` and collision-query scan bodies are bound in the same-lane `collision-list-inventory/source-census.json` and report. The claim is limited to the stated one-cell local-player collision witness and does not close provider-wide list, step, callback, or tick inventories.
