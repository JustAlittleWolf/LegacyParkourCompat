# Blind source audit: 1.8.9 → 1.9.4 player collision border fallback and candidate scan

Scope: exact local decompiled source comparison of 1.8.9, 1.9.1, 1.9.2, 1.9.3 and 1.9.4 only. No product source, history, wiki, tests, build or runtime was used. Source lines below are one-based line numbers.

## Result

The candidate-scan change is introduced by 1.9.1 and is source-stable in 1.9.2; it remains stable through 1.9.3/1.9.4 for the behavior in scope. The border state-selection and entity border-flag logic remain the same for non-null entities. The scan candidate set is materially different, but this audit did **not** establish a concrete reachable local-player movement outcome difference from the bounded WORLD-27 border fallback path alone. Therefore no finding is drafted. A trajectory claim would require demonstrating that a newly scanned/skipped candidate contributes a collision box intersecting the queried player shape; the source comparison alone did not establish that.

## Source facts

### Reachable local-player movement path

- In all audited versions, `ClientPlayerEntity extends PlayerEntity`, `PlayerEntity extends LivingEntity`, and `LivingEntity extends Entity`: 1.8.9 `ClientPlayerEntity.java:20`, `PlayerEntity.java:79`, `LivingEntity.java:58`; 1.9.1/1.9.2 `:20`, `:91`, `:75`; 1.9.3/1.9.4 `:21`, `:92`, `:76`.
- `LivingEntity` calls `this.move(velocityX, velocityY, velocityZ)` in its travel path (1.8.9 `LivingEntity.java:1165,1190,1218`; 1.9.1/1.9.2 `:1332,1382,1411,1439`; 1.9.3/1.9.4 `:1341,1391,1420,1448`). The inherited `Entity.move` resolves the swept-shape collision list via `world.getCollisions(this, getShape().expanded(dx,dy,dz))` (1.8.9 `Entity.java:371,439`; 1.9.1/1.9.2 `:438,506`; 1.9.3/1.9.4 `:441,509`). Thus the entity-parameter overload audited here is on the local player's movement path. The earlier sneak-edge queries in the same method also call this overload.

### `World.getCollisions` scan transition

- **1.8.9** `World.java:891-945`: bounds are `floor(minX)`, `floor(maxX + 1.0)`, likewise Y/Z (`:893-898`); loops x then z then y (`:905-909`). There is no x/z edge classification or perimeter exclusion. It calls `isChunkLoaded` at y=64 (`:907`). The entity border flags are sampled once (`:900-901`); while iterating, non-null entity flag is cleared when both cached values are true and set when both are false (`:910-914`). Candidate block state defaults to stone; it switches to world state when `worldBorder.contains(pos) || !bl2` (`:916-920`), then invokes block collision (`:921`).
- **1.9.1 and 1.9.2** `World.java:893-955`: change is present in 1.9.1 and unchanged in 1.9.2 (the `World.java` file hashes are identical). Bounds become `floor(min)-1` and `ceil(max)+1` for all axes (`:895-900`). `q` marks x/z perimeter sides; corners where `q == 2` are skipped, and side-perimeter positions at the lowest/highest scanned y are skipped (`:907-913`). Remaining positions retain the same y=64 chunk-loaded call, cached border-flag transition, and block-state selection (`:910`, `:914-927`). The outer entity collision portion is now guarded for `entity != null`; local-player movement passes a non-null entity (`:935-952`).
- **1.9.3 and 1.9.4** `World.java:899-961`: this form is unchanged between the two endpoint sources (identical `World.java` hashes). It retains the 1.9.1/1.9.2 bounds/perimeter and border selection (`:901-933`); nullable annotations do not alter the local-player non-null path.

The exact candidate bounds are therefore asymmetric in 1.8.9 and expanded in 1.9.1+: for each axis, old iteration starts at `floor(min)` and stops before `floor(max+1)`; new iteration starts at `floor(min)-1` and stops before `ceil(max)+1`, with the stated x/z/y perimeter exclusions. This is a source-level candidate traversal difference, not by itself proof of a different player trajectory.

### Border fallback gate and state updates

`World.isWithinBorder` in 1.8.9 `World.java:947-965`, 1.9.1/1.9.2 `:957-975`, and 1.9.3/1.9.4 `:963-981` uses the same calculation: expand border limits by one when the entity is not outside, contract by one when it is outside, then test the entity's `x` and `z` strictly against those limits. The selected block state remains `Blocks.STONE.defaultState()` outside the world-border block set unless the cached `bl2` says the entity is outside the one-block-expanded threshold; no changed border predicate or fallback state was found for a non-null player.

The cached `bl`/`bl2` values are taken once before the scan in every source form. The loop's flag updates therefore do not recompute the selection predicate mid-scan; for the two matching branches they repeatedly set the same flag value. The new perimeter can change which coordinates execute these lines, but no new border-flag outcome was demonstrated.

### Client chunk path

- In 1.8.9 `World.java:171-176,226-228`, `isChunkLoaded(pos)` passes `allowEmpty=true`; `isChunkLoadedAt` then requires `chunkSource.hasChunk` and, because empty is allowed, does not reject an empty chunk. `ClientWorld.createChunkCache` selects `ClientChunkCache` (`ClientWorld.java:88-91`), whose `hasChunk` returns true (`ClientChunkCache.java:30-33`).
- In 1.9.1/1.9.2, `World.isChunkLoaded(pos)` likewise passes true (`World.java:176-181`), and `ClientWorld.isChunkLoadedAt` returns true immediately for `allowEmpty` (`ClientWorld.java:97-105`). `ClientWorld` creates `ClientChunkCache` (`:97-100`); absent chunks return the empty chunk (`ClientChunkCache.java:51-53`).
- In 1.9.3/1.9.4 the same `allowEmpty=true` path remains (`World.java:182-187`; `ClientWorld.java:98-105`), and absent client chunks still return the empty chunk (`ClientChunkCache.java:55-58`).

Thus, for candidate positions inside the world's x/z/y coordinate domain, the collision scan's `isChunkLoaded(... y=64)` guard does not impose a materially different loaded/nonempty test on the client between 1.8.9 and 1.9.4. The `World.isChunkLoaded` world-height/domain guard changes in 1.9.3, but this particular collision scan checks y=64 in all versions and the scan bounds concern x/z; no player-path difference was established from it.

## Introduction and stability check

| Version | Scan form | Border fallback/player flag form | Client empty-chunk treatment |
|---|---|---|---|
| 1.8.9 | Original floor(max+1), no perimeter skip | Original non-null entity form | `hasChunk && allowEmpty` |
| 1.9.1 | Expanded floor/ceil range; omit x/z corners and y end caps at perimeter | Same effective calculations, plus null guards | `allowEmpty || nonempty` |
| 1.9.2 | Same as 1.9.1 | Same | Same |
| 1.9.3 | Same scan | Same | Same |
| 1.9.4 | Same scan | Same | Same |

1.9.1/1.9.2 identity and 1.9.3/1.9.4 identity are corroborated by the relevant source-file SHA-256 values below. The point-in-time source was not independently reconstructed for commits; these decompiled version directories are the examined primary evidence.

## SHA-256 of examined source files

Paths are relative to each version's `ornithe-feather` directory. Equal hashes indicate byte-identical examined files.

| File | 1.8.9 | 1.9.1 | 1.9.2 | 1.9.3 | 1.9.4 |
|---|---|---|---|---|---|
| `net/minecraft/world/World.java` | `3C04F5B874FBB6692039164C882A3C47FE28C7ECA864E91C9AC57798153888EE` | `CDDA70C97F0E4D6F6C454C8F6D3C0D47F0E0AE612E75062D8FE93DDD3963E6B0` | same as 1.9.1 | `2FE063E0EC224EED9FC7D01B8F788C32035EED5FEE5A9D98EA5E82296236E05A` | same as 1.9.3 |
| `net/minecraft/entity/Entity.java` | `D4C10932CB5BB1067A5A58BE4E1BB1B42BDDE3B6FC893D88178CC07435A1696B` | `74D3AC34D7E6355C8FDCDD777DCD95BA9EF4626718C8772C1B58D0E28419E42A` | same as 1.9.1 | `BCD7FA2206BF8D7271102F6DA7FE2771F96DBE22EC79DAB9F2101A3E29C17EF0` | same as 1.9.3 |
| `net/minecraft/entity/living/LivingEntity.java` | `082831C6578E3A70FA6CEA5B90BC3EEFC26678259B66334470DE22B90B5B0E4E` | `D8824F670037A88753C428C27213989FC5173B1D7C638F498F73395C145B6FD9` | same as 1.9.1 | `BBB7703F18FD5DA05C4E4A43A77EA644B388E63C01D34166D308EA52054BE4E5` | same as 1.9.3 |
| `net/minecraft/client/entity/living/player/ClientPlayerEntity.java` | `B322144FCC965C9BF5F6FF18882D17F6F0E1CDAF0E545B1C7663C662ACEB029B` | `36CBC6F0E7E2D47F4207D15130976860EAC60B4AE6FAC2EF2E8F5A9F719370D7` | same as 1.9.1 | `68F6E640808D8B31C1A99D1470075606A42290600FD45435AA86C15EB8DB5EF0` | same as 1.9.3 |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `E66CB294FC93118148A444BBAFDF4DD57CBF66A23D69B1E8892CEFCCC690AB88` | `D7035F08F03B01823DFF70CA504F7244F9B0753542CC0F6DD7301E66F8866B71` | `1FC5107B9B7F5711105D521A28829F2466FE9F297E832F4D209E6EC422111AAC` | `EF96C8A00443F724EADAD05A6A4DCC8A8A2E23CD4C3390B9E0F1F78C9FF4D1AF` | `D658A0D95452D12BB7E347BFD802240EEECAF7F938E10DCD43E2640434387F85` |
| `net/minecraft/client/world/ClientWorld.java` | `710ABDE0F70C471A081ABDFB3B70DA681C6D817329801F8A2A49AF88A25EE02B` | `17322CE757CEF1D167A4E99E45FA98EBF8A134ADE80C9637AF657359269723A8` | same as 1.9.1 | `8BBDA6E31E1424BF65B89A0C35110F213841695766870CF526BF6E707F67A74B` | same as 1.9.3 |
| `net/minecraft/client/world/chunk/ClientChunkCache.java` | `5F22BCCF9270A107E8471BAB996CF6F9DBB4C92CCD48C8AD0A42144DBF919920` | `027FE333AB8BB1F3B70F445C137FF817A1B6426AD9F11E81BB24A8CBAC0E01EB` | same as 1.9.1 | `08CDDB35ED4FDEE05E28943C16D61EF8119A1DDAC4BAF533F3487202B63CF048` | same as 1.9.3 |

## Endpoint sidecars checked

| Sidecar | SHA-256 |
|---|---|
| 1.8.9 `ornithe-feather.provenance.json` | `BA066FC8F1C7CEB9819D2106338D9E9F2C2B96EB5A8329EB40E171B1F9889185` |
| 1.8.9 `ornithe-feather.sources.sha256` | `9E75F46DC0ED43B6A355BD65DB8A92C93A4DFEAECFA92284187C6FE9410D8004` |
| 1.8.9 `artifacts.sha256` | `DA003358256D1C4402EBB20614651E5410310E871EE913DE2B9C1295A64E1446` |
| 1.9.4 `ornithe-feather.provenance.json` | `5C913715BED763369CEB5FD171CAB3E63C43298023078C3683F96C7EA8FED3CD` |
| 1.9.4 `ornithe-feather.sources.sha256` | `C7B508FE01634887B65919DCD3A900C311A21D9510A1F1AB248D5C17C528AB19` |
| 1.9.4 `artifacts.sha256` | `9527DCA544694DAA3B4A7741BE1A5B4802D8B6665C8A152A408A37A27A1B4D77` |
