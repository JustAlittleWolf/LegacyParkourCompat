# Provider state-domain census (partial)

## Scope and method

This source-only continuation uses the exact five `ornithe-feather` trees named in the assignment and the permitted same-lane provider census/body matrices. Registry identity is bound by `provider-state-census/registered-route-matrix.tsv` (198 A-era IDs/keys, each retained through 1.9.4). Direct method bodies and the 68 B shape replacements are represented by `provider-method-readsets.tsv` (275 rows; body and whole-file SHA-256 columns) and helper call edges by `provider-method-transitive-hooks.tsv` (275 rows). The matrices are first-pass mechanical extracts; getter extraction is not treated as transitive closure.

## Read domains confirmed from routes and exact method bodies

The following are *raw read domains*, kept separate from any Cartesian product or ordered collision-list claim:

| Route family | Provider input/read domain | Source route and limit |
|---|---|---|
| Cake | `BITES` (0–6) | WORLD-17; A `CakeBlock.getCollisionShape` directly reads it. B replacement method is in `replacement-shapes.tsv`. |
| Cocoa | `AGE` (0–2), `FACING` (NORTH/SOUTH/EAST/WEST) | WORLD-10; A collision method calls mutable `updateShape`, whose helper reads both values. Direct-body-only extraction misses these. |
| Doors | lower/upper half metadata, open flag, facing (4 horizontal), hinge side | WORLD-DOOR-SHAPES; A collision method calls `updateShape(WorldView,BlockPos)` → packed combined metadata → shape helper. The read is not visible as `state.get(...)` inside collision entry. |
| Ladder | horizontal `FACING` (4 directions) | WORLD-LADDER-SHAPES; Bounded shape route. |
| Skull | wall-facing values | WORLD-11; Bounded route. |
| Slabs | single/double registered block identity; single slab `HALF` (TOP/BOTTOM) | WORLD-SLAB-SHAPES; A helper calls `isDouble()` then reads `HALF` from the world state when single. |
| Trapdoors | `HALF` (TOP/BOTTOM), `FACING` (4 horizontal), `OPEN` (false/true) | WORLD-TRAPDOOR-SHAPES; route names these state inputs. |
| Fence / wall | four horizontal neighbor connection predicates; wall also above-state | WORLD-FENCE-WALL-SHAPES; actual neighbor state/class/material predicates are not enumerated by this pass. |
| Fence gate | `FACING` (4 horizontal), `OPEN` (false/true) | WORLD-GATE-SHAPES. |
| Pane | east/north/south/west neighbor connection predicates | COLL-02; source body queries those neighbors. Exact connected-state product is not closed here. |
| Stairs | `FACING` (4 horizontal), `HALF` (TOP/BOTTOM); side/behind stair family, half, and facing predicates | WORLD-STAIRS-STRAIGHT/OUTER-SELECT/INNER-SELECT/CORNER-BOXES; exact neighbor arrangements remain in those bounded slices. |
| Snow | `LAYERS` (1–8) | WORLD-SNOW-SHAPE. |
| End portal frame | `EYE` (false/true) | WORLD-03; A `addCollisions` reads the state and conditionally appends the eye box. |
| Piston base/head | base `FACING` (six directions), `EXTENDED` (false/true); head facing/type and neighboring moved/head state | WORLD-14/15/26; full world-relative state product not closed here. |
| Moving piston | block-entity moved state, movement `FACING`, current/last progress and entity collision input | WORLD-12/13; dynamic block-entity state is not a `BlockState` property product. |
| Inherited shape families | Anvil orientation; chest facing and block-entity adjacency/state; bed facing/part; carpet, daylight detector, diode, dragon egg, enchanting table, ender chest, flower pot state inputs as bounded in WORLD-23/24/25 | Existing slices only; no expansion or latest-writer assumption added. |

Fixed/empty providers and generic default routes are covered by the route dispositions in the same-lane provider-body report and WORLD-18/19/23/24/25. Their route presence does not close all property values for the registered class.

## Five-version reconciliation status

The registered-route matrix pairs every A-era registry key to its nearest collision declaration owner across all five versions. The direct/replacement body matrix establishes no direct body hash change for the 40 B direct methods or 17 replacement shape methods among 1.9.1/.2/.3/.4. This is not a proof that the class's helper readers, property definitions, dynamic inputs, or their dispatch semantics are equivalent at each cutover. Existing bounded WORLD slices are reused only for their named domains. No new Cartesian product or geometry/list closure is inferred.

## Residuals

This report does **not** close the requested full owner/state read-set inventory. The first-pass method extraction misses transitive helper reads unless explicitly followed; several examples are recorded above. Exact `BlockState` property declaration ranges and complete enum/range values have not been bound for every registered class in every release. Neighbor state/class/material predicates, block-entity reads, fluid/entity-dependent routes, mutable shared-bound latest-writer conditions, callbacks/support providers, and unbounded state products are not fully enumerated. Accordingly, do not treat this report as complete provider/state-domain coverage or as a pair-freeze claim. The complete per-route collision-list order and final clip/step outcomes are also outside this assignment's read-domain pass.

No tests, build, game, decompile, network, Git mutation, or pair-freeze claim was made.
