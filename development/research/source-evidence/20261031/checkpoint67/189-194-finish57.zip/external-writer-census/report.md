# Direct player movement writer/reader census — 1.8.9 → 1.9.4

## Scope and method

This source-only residual census reconciles direct local-player or inherited player writers/readers across clientbound packet handlers, the local tick chain, block responses, collision movement, and local-world callbacks. Inputs were limited to the historical source run through line 989, current same-lane source reports/matrices named below, and the exact 1.8.9, 1.9.1, 1.9.2, 1.9.3, and 1.9.4 Ornithe Feather source trees with their source-local provenance maps. No product implementation/history, wiki, backlog, another pair lane, or prior audit was read. No tests, build, game, decompile, network lookup, or Git mutation was performed.

The machine-readable route registry is `writer-reader-caller-matrix.tsv`. It distinguishes direct writers from input/reader paths, identifies how the local player reaches each route, maps bounded work to existing source coverage IDs, and preserves exclusions. Searches across all five source trees covered movement field writes/calls (`setPosition`, `setVelocity`, velocity fields, grounded/collision state, shape, flags, riding, wake/sleep, interpolation) in network handlers and the player/entity hierarchy. The census also reconciled the historical EXT-01…05, TICK/WORLD external dependencies, callback slices, and current collision/player-passenger reports. This is a coverage census, not a claim that all collision candidate products or every callback/provider combination is closed.

Endpoint manifests were verified by the current same-lane reports: 1.8.9 `9e75f46dc0ed43b6a355bd65db8a92c93a4dfeaecfa92284187c6fe9410d8004`; 1.9.4 `c7b508fe01634887b65919dcd3a900c311a21d9510a1f1ab248d5c17c528ab19`. Intermediate class files newly used for the mounted piston response were checked against each `.decompile-provenance.json` embedded source row. Relevant full-file SHA-256 identities are:

| Release | `MovingBlockEntity.java` | `Entity.java` | `PlayerEntity.java` |
|---|---|---|---|
| 1.8.9 | `05a5bfbf2556eaa621996bda365b7bab01f5b9060cf773e7b9949ebe2f39fff6` | `d4c10932cb5bb1067a5a58be4e1bb1b42bdde3b6fc893d88178cc07435a1696b` | `e66cb294fc93118148a444bbafdf4dd57cbf66a23d69b1e8892cefccc690ab88` |
| 1.9.1 | `7ad3426bb74c9e69b4f521d20e045b1dc1eafa9b725daf0e2c0b9b718bc2683c` | `74d3ac34d7e6355c8fdcdd777dcd95ba9ef4626718c8772c1b58d0e28419e42a` | `d7035f08f03b01823dff70ca504f7244f9b0753542cc0f6dd7301e66f8866b71` |
| 1.9.2 | `7ad3426bb74c9e69b4f521d20e045b1dc1eafa9b725daf0e2c0b9b718bc2683c` | `74d3ac34d7e6355c8fdcdd777dcd95ba9ef4626718c8772c1b58d0e28419e42a` | `1fc5107b9b7f5711105d521a28829f2466fe9f297e832f4d209e6ec422111aac` |
| 1.9.3 | `50eb847d3ff4ff78441057f397c43e15fb894177f7c5a736a61c22a80f1de467` | `bcd7fa2206bf8d7271102f6da7fe2771f96dbe22ec79dab9f2101a3e29c17ef0` | `ef96c8a00443f724eadad05a6a4dcc8a8a2e23cd4c3390b9e0f1f78c9ff4d1af` |
| 1.9.4 | `50eb847d3ff4ff78441057f397c43e15fb894177f7c5a736a61c22a80f1de467` | `bcd7fa2206bf8d7271102f6da7fe2771f96dbe22ec79dab9f2101a3e29c17ef0` | `d658a0d95452d12bb7e347bfd802240eeecaf7f938e10dcd43e2640434387f85` |

## Census result

No additional eligible direct player position/velocity writer was found beyond the routes in the matrix and existing source reports. Direct client responses remain eligible when they consume equal packet or vanilla state inputs; this census makes no claim about server packet, attack, or physics production. The earlier generic entity-move concern is resolved for the local player: `ClientWorld.getEntity` maps its own network ID to `minecraft.player`; the handler calls virtual `lerpPositionAndAngles`; the exact local dispatch reaches `LivingEntity` in both endpoints, which queues the same interpolation state; and the local `mobTick` consumes that queue. This local route therefore bypasses the changed base `Entity` collision-lift. The wake-up action-2 response remains a conditional direct position difference, and event 3 reaches the inherited `PlayerEntity.die` velocity writer in both releases (the changed direct velocity response is historical EXT-04).

### Mounted player and direct piston response

The piston caller is independently eligible even when the local player is riding. A `MovingBlockEntity.moveEntities` queries intersecting entities and calls `entity.move(...)` directly for a non-slime moved block. In B, 1.9.1 through 1.9.4, it first skips `PistonMoveBehavior.IGNORE`; the exact inherited `Entity.getPistonMoveBehavior()` returns `NORMAL` in each release, and a source search finds no `PlayerEntity` override in any of the five releases. A has no corresponding ignore gate and also calls `Entity.move` directly. A riding relation therefore does not disqualify the player from this external response.

Cross-slice, if the player's root vehicle or another same-root entity is in the swept query and its collision shape intersects the player's candidate query, the A `World.getCollisions` guard comparing `entity.rider`/`entity.vehicle` against the nearby-entity **list object** does not remove that candidate. B's `hasSameVehicle` filter does remove same-root candidates. This is a conditional collision-list input difference for a local player that may be mounted. It establishes neither a final displacement nor a trajectory. The distinct case where a player carries a passenger but is not riding also remains explicitly eligible and is covered in `collision-list-inventory/player-passenger-filter.md`.

## Residuals and verdict

The direct writer/reader routes in the assigned residual census are accounted for in the TSV and tied to bounded existing evidence. The complete author inventory still depends on adjacent source work: exact client WORLD-27 border/effective-cap fallback applicability, the client loaded-chunk collision-candidate gate and cross-slice COLL-01 ordered candidate/provider consequences remain parent-owned and open; complete modifier/effect consumers remain under INV-MODIFIERS; broader collision providers, neighboring state products and callback/support combinations remain under INV-COLLISION and INV-WORLD-MOVEMENT. This census therefore does not independently promote INV-EXTERNAL or close the pair. A fresh independent coverage audit is required after those owners close their remaining inventory rows.

Exclusions remain narrow: server movement/attack producers, damage calculation, health/food production, vehicle-produced rider placement and vehicle physics, non-player physics, modern-only movement inputs, and bed-entry eligibility. Direct player responses and collision-list queries are not excluded merely because the player has a mount relation.

## Intermediate receiver appendix for EXT-ENTITY-MOVE / EXT-ENTITY-TELEPORT

I directly checked the exact 1.9.1–1.9.4 method bodies, dynamic receiver chain, local tick consumer, and hidden source-map rows. In each B release the two packet handlers resolve the entity through `ClientWorld.getEntity`, call `entity.lerpPositionAndAngles(...)`, and then write the packet `onGround` value. `ClientWorld.getEntity` maps a matching local player network ID to `minecraft.player`. There is no exact-signature `lerpPositionAndAngles(DDDFFIZ)V` override in either `PlayerEntity` or `LocalClientPlayerEntity`; the inherited receiver is the paired `LivingEntity` override.

| Source class | 1.9.1/.2 source SHA-256 | 1.9.3/.4 source SHA-256 | Embedded intermediate provenance |
|---|---|---|---|
| `net/minecraft/client/world/ClientWorld.java` | `17322ce757cef1d167a4e99e45fa98ebf8a134ade80c9637af657359269723a8` | `8bbda6e31e1424bf65b89a0c35110f213841695766870cf526bf6e707f67a74b` | all four exact source hashes matched their `.decompile-provenance.json` rows |
| `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `7f67bd2daa792cfc4aac1744d30f9cfdb28306ec55583d474ddc1a251561b1d6` | `5a2fc039b81ec0e77df3354826aaaf00dfa6e0d1296cf111864900932e811a4c` | all four exact source hashes matched their rows |
| `net/minecraft/entity/Entity.java` | `74d3ac34d7e6355c8fdcdd777dcd95ba9ef4626718c8772c1b58d0e28419e42a` | `bcd7fa2206bf8d7271102f6da7fe2771f96dbe22ec79dab9f2101a3e29c17ef0` | all four exact source hashes matched their rows |
| `net/minecraft/entity/living/LivingEntity.java` | `d8824f670037a88753c428c27213989fc5173b1d7c638f498f73395c145b6fd9` | `bbb7703f18fd5da05c4e4a43a77ea644b388e63c01d34166d308ea52054be4e5` | all four exact source hashes matched their rows |
| `net/minecraft/entity/living/player/PlayerEntity.java` | 1.9.1 `d7035f08f03b01823dff70ca504f7244f9b0753542cc0f6dd7301e66f8866b71`; 1.9.2 `1fc5107b9b7f5711105d521a28829f2466fe9f297e832f4d209e6ec422111aac` | 1.9.3 `ef96c8a00443f724eadad05a6a4dcc8a8a2e23cd4c3390b9e0f1f78c9ff4d1af`; 1.9.4 `d658a0d95452d12bb7e347bfd802240eeecaf7f938e10dcd43e2640434387f85` | all four exact source hashes matched their rows; none has a matching lerp override |
| `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `de9ad48bcfb2705ef7a9a63e9401c1742aead183e1e9c2d13f8fe40cca0139eb` | `8aaf711948b7602c2e6c015a37e36ed06073d39727d999d80480b4910b704f5d` | all four exact source hashes matched their rows; none has a matching lerp override |

Method anchors and normalized method-body SHA-256 (method declaration through its matching closing brace) are stable across the stated releases:

| Method | 1.9.1/.2 lines | 1.9.3/.4 lines | Body SHA-256 |
|---|---|---|---|
| `ClientWorld.getEntity(int)` | `ClientWorld.java:219` | `ClientWorld.java:221` | `375598e69c78ffc30f60d65aca9dec7808ee7879c404554655450c381d4b9d4c` |
| `ClientPlayNetworkHandler.handleEntityTeleport` | `:475` | `:476` | `ab9878ee5d00e840fafa6e7f1bb77fd0c1aea3bda643071d51c52b2ed30e3c01` |
| `ClientPlayNetworkHandler.handleEntityMove` | `:506` | `:507` | `eb54c7a6770f9bf3036c3110987dbee4a333930b848a2302e6c94a6419d3e60b` |
| `LivingEntity.lerpPositionAndAngles(DDDFFIZ)` | `LivingEntity.java:1765` | `LivingEntity.java:1774` | `c7245aca52879fa27262b4e1bb24d9222f2ae353ceb479cff56c01146fcdc02d` |
| `LivingEntity.mobTick()` | `LivingEntity.java:1636` | `LivingEntity.java:1645` | `73faf5a1f11327d3efa9acda521d3dc61a5b41e92cb42d2e06f8edcc21a2099d` |
| `Entity.getControllingPassenger()` | `Entity.java:2169` | `Entity.java:2186` | `7d3d8e9b7714e3d6dc05aad366cc893bb0b2260ae845c13577880e696ea04bbd` |
| `Entity.isLogicalSideForUpdatingMovement()` | `Entity.java:2237` | `Entity.java:2254` | `58adb68030bc30d824447f2065a2b9d4e7a04c63332cd8ef0f9c64e9db57d0a2` |
| `LocalClientPlayerEntity.mobTick()` | `LocalClientPlayerEntity.java:601` | `LocalClientPlayerEntity.java:604` | `c83cd2765fadf36a39715995321a5f81eaf1b1fae64bf891a140ad0464773c5a` |

The local override calls `super.mobTick()` in .1/.2 at line 752 and in .3/.4 at line 755. The inherited `Entity.getControllingPassenger()` returns null. Thus `Entity.isLogicalSideForUpdatingMovement()` reduces to `!world.isClient`; on a local client this is false, so `LivingEntity.mobTick`'s additional `!isLogicalSideForUpdatingMovement()` interpolation condition is true. The same queued target/step fields written by the packet handlers are therefore consumed by the local player on all four intermediate releases. This confirms the existing no-delta local receiver conclusion through the intermediate interval; it adds no new behavior claim and does not require server self-ID delivery proof.

