# Independent review: COBWEB / BAMBOO_SAPLING fluid predicate witness

## Decision

**Reject this witness as a source difference.** The reported 1.20 `FlowingFluid.getFlow` call-site change is real, but neither proposed block state distinguishes the predicates. In 1.19.4 both materials already report `blocksMotion() == false`; in 1.20.0 onward `BlockState.blocksMotion()` also returns false for these two registered blocks by explicit identity exclusions. The proposed bounded input therefore produces the same horizontal flow vector on both sides. It does not support a player-movement finding for this pair of witnesses.

The candidate report's specific mistaken premise is that `.noCollider()` leaves `Material.blocksMotion` at its builder default `true`. The exact 1.19.4 implementation sets it to `false`.

## Canonical source identity and file integrity

I independently checked the literal host root with `Test-Path` and `Get-Item -Force`: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.19.4/mojmap` exists. I checked the six exact release directories and found Mojmap source roots for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4. The root-sidecar manifests and ready markers were present for 1.19.4, 1.20.1, 1.20.2, and 1.20.4. For 1.20.0 and 1.20.3 I used `Get-ChildItem -Force` and verified the hidden `mojmap/.decompile-provenance.json`; I did not infer missing provenance from a normal non-hidden directory listing.

| Release | Source identity file SHA-256 |
|---|---|
| 1.19.4 | `mojmap.sources.sha256` — `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` |
| 1.20.0 | `mojmap/.decompile-provenance.json` — `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` |
| 1.20.1 | `mojmap.sources.sha256` — `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` |
| 1.20.2 | `mojmap.sources.sha256` — `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` |
| 1.20.3 | `mojmap/.decompile-provenance.json` — `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` |
| 1.20.4 | `mojmap.sources.sha256` — `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` |

For every source file below, I recomputed SHA-256 and matched it to that release's source-manifest entry or embedded provenance `sources` entry. Mojmap mapping identity comes from the exact release roots and their Mojmap provenance/ready metadata; no online source was used.

| Release | `FlowingFluid.java` | `Material.java` / `BlockBehaviour.java` | `Blocks.java` | `Entity.java` / `Player.java` |
|---|---|---|---|---|
| 1.19.4 | `d84ceb3c0b83da25fb68599e16cc2298106e745a9ef0c9f32f616d097a8ec56c` | `Material.java` `842c7ee4723993c6ee3bf4732343f3225bb05aac5ee80c919c34c3ba1a027431`; `BlockBehaviour.java` `517aa4bd9875e9f7b3f5fba472a84e82afd1e11e35d3c83dc2677d8bbeb4997d` | `a4f2df87c2cae5a3827a818f39f7ad123ee5b18905ead9947efe654421c30ff5` | `Entity.java` `3667fee610cbc5f58012e3a8fb8d6c4849f649fb7fe5300595158112d8b4b58b`; `Player.java` `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2` |
| 1.20.0 | `ba1dff6ccb28b62760c74d66832d8fdbe7a1cdc37b9c5a0ff476bd200215c904` | `BlockBehaviour.java` `5f37987191165379c222c412949a0c80a904bf78a453035b1f9d86c6454510fa`; the old `Material.java` file is absent | `1e7095d1fbfdc8198191f40037997feeca2ec993cc54dd53f2636375cae66b51` | `Entity.java` `94b9c3656715de2d61fa9a02ccef164261e50eb13d6090a6f07e58fe9c5b0759`; `Player.java` `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac` |
| 1.20.1 | `ba1dff6ccb28b62760c74d66832d8fdbe7a1cdc37b9c5a0ff476bd200215c904` | `BlockBehaviour.java` `5f37987191165379c222c412949a0c80a904bf78a453035b1f9d86c6454510fa` | `1e7095d1fbfdc8198191f40037997feeca2ec993cc54dd53f2636375cae66b51` | `Entity.java` `94b9c3656715de2d61fa9a02ccef164261e50eb13d6090a6f07e58fe9c5b0759`; `Player.java` `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac` |
| 1.20.2 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` | `BlockBehaviour.java` `a6d88726ce4642fc0a61f46a01347bb0b74887b61ef55af7e7c76723789a0b57` | `75e8e77adab4a07b02ef95619be83a004f5f79810cf3f07157a713d714881253` | `Entity.java` `d7ee49aaea5e862b92508e767562cabc8f10515605e8fb67565c8c8d5c23b01b`; `Player.java` `25f263692fd6b2a737aa813315022a0caf4e18c3661ba3bd706c6297f909f25c` |
| 1.20.3 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` | `BlockBehaviour.java` `6284a7d08a6d0d475cd4fe8aea62b35153ae8fbc0bce5f51788389f679233b54` | `5392c4349317e55c2989865be38c17b94e6e0543e7017e6a2a64d79217e83643` | `Entity.java` `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9`; `Player.java` `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd` |
| 1.20.4 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` | `BlockBehaviour.java` `6284a7d08a6d0d475cd4fe8aea62b35153ae8fbc0bce5f51788389f679233b54` | `5392c4349317e55c2989865be38c17b94e6e0543e7017e6a2a64d79217e83643` | `Entity.java` `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9`; `Player.java` `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd` |

## Predicate and registration trace

- 1.19.4 `net/minecraft/world/level/material/Material.java:71` declares `WEB` using `.noCollider()`; line 83 declares `BAMBOO_SAPLING` using `.noCollider()`. `Material.Builder.blocksMotion` starts `true` at line 160, but `noCollider()` assigns `this.blocksMotion = false` at lines 182–184. Thus each material predicate is false.
- 1.19.4 `Blocks.java:445–446` registers `COBWEB` with `Material.WEB`; `Blocks.java:3428–3436` registers `BAMBOO_SAPLING` with `Material.BAMBOO_SAPLING`. Both block kinds therefore expose the false material value used by the older `FlowingFluid.getFlow` probe at `FlowingFluid.java:64–75`.
- The 1.20.0 `Blocks.java:750–765` and `5957–5970` retain both registered kinds. Their properties include `.noCollission()` and `.forceSolidOn()` (the latter for both). `BlockBehaviour.BlockStateBase.calculateSolid()` checks `forceSolidOn` at line 429 and can therefore make `isSolid()` true. However, `BlockStateBase.blocksMotion()` at lines 469–472 first compares the owner with `Blocks.COBWEB` and `Blocks.BAMBOO_SAPLING`, returning false for either before consulting `isSolid()`. The 1.20+ predicate is false for both states even with `forceSolidOn`.
- The newer `.noCollission()` controls collision/occlusion properties; the older `.noCollider()` is a `Material.Builder` method that directly clears the old movement predicate. Neither block has a custom `blocksMotion()` override that changes these outcomes. Shape calculation is not reached in the new state predicate for these identities because its explicit short-circuit returns false. Dynamic shape and collision shape do not rescue the claimed difference.
- The same `blocksMotion()` method body is present at 1.20.0, 1.20.1, 1.20.2, 1.20.3 and 1.20.4, confirmed from the exact `BlockBehaviour.java` files above. The call-site spelling changes at 1.20.0 as reported, but these two states evaluate false on both sides.

## Bounded flow input and result

Use a source-water state at the sampled origin with own height `1.0F`; make the east neighbor an empty-fluid `COBWEB` block and the cell below it source water; make the remaining horizontal probes solid and without a contributing lower fluid state. This is a valid bounded `getFlow` input with one nonzero horizontal contribution and no vector cancellation.

At 1.19.4, `FlowingFluid.getFlow` sees the east block's material predicate as false and enters the below-cell probe. At 1.20+, the same block state's `blocksMotion()` is false and enters the same probe. In each case, the sampled lower source contributes `1.0F - (1.0F - 0.8888889F)` (approximately `0.8888889F`) toward east; normalization yields the same `Vec3(1, 0, 0)`. Replacing COBWEB with BAMBOO_SAPLING yields the same predicate and result. The candidate's asserted older zero vector is therefore incorrect.

## Player path check

The sampled `getFlow` result is statically player-reachable: `Entity.tick` calls `updateInWaterStateAndDoFluidPushing` (1.19.4 `Entity.java:430`, 1.20.0 `Entity.java:434`); the water-current path calls `updateFluidHeightAndDoFluidPushing(FluidTags.WATER, 0.014)` (1.19.4 `Entity.java:1080–1083`, 1.20.0 `Entity.java:1184–1187`); and the fluid loop calls `FluidState.getFlow` (1.19.4 `Entity.java:2917`, 1.20.0 `Entity.java:3031`). `Player.isPushedByFluid()` returns `!abilities.flying` in both releases (1.19.4 `Player.java:1848–1850`; 1.20.0 `Player.java:1874–1876`). Thus the path is reachable for a non-flying player, but the per-sample flow vector is equal across releases for the candidate state. This confirms reachability only; no whole-tick trajectory or runtime parity was evaluated.

## Scope limits

This review is limited to the report's proposed COBWEB/BAMBOO_SAPLING witness for the 1.19.4-to-1.20 `FlowingFluid.getFlow` material-to-state predicate change, plus the minimum caller path needed to establish player reachability. It is not a complete fluid-provider closure, full pair inventory, independent coverage audit, or review of other block states that might distinguish the predicates. It does not evaluate trajectory magnitude, run tests/build/gameplay, inspect mod implementations or Git history, consult wiki material, or use network/decompilation tools. No product source, wiki, backlog, or Git file was read or changed. Only this assigned review report was written.
