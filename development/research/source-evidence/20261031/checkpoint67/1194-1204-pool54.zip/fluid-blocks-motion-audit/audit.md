# `FlowingFluid.getFlow` motion-predicate audit

## Result

**Proven predicate difference; intermediate method stable from 1.20 through 1.20.4.** In 1.19.4, the fallback tests `neighborState.getMaterial().blocksMotion()`. Starting at the inspected 1.20 source, it tests `neighborState.blocksMotion()`. A vanilla 1.19.4-era witness is the amethyst bud/cluster family, including `AMETHYST_CLUSTER`, `LARGE_AMETHYST_BUD`, `MEDIUM_AMETHYST_BUD`, and `SMALL_AMETHYST_BUD`.

- 1.19.4 `Material.AMETHYST` uses the builder defaults (`blocksMotion=true`); the corresponding `Blocks` registrations pass that material to `AmethystClusterBlock` and its copied variants.
- The 1.19.4 and 1.20.4 `AmethystClusterBlock` collision shape is direction-dependent and narrow. For the default UP-facing cluster, registered constructor dimensions are 7/16 high and 10/16 wide/deep, so `AABB.getSize()` is `(7/16 + 10/16 + 10/16) / 3 = 9/16`, below the new `0.7291666666666666` solidity threshold. With no force-solid override, modern `BlockState.blocksMotion()` is false for that state. Bud sizes are smaller and also below the threshold. The same UP-facing dry state is valid in both versions.
- A reachable world arrangement exists without an invalid raw state: place an UP-facing dry amethyst cluster on a waterlogged top slab. The slab's water fluid state is immediately below the cluster, the slab's full upper face supports it, and the cluster itself has an empty fluid state. For a flowing-fluid cell horizontally adjacent to the cluster, `getFlow` enters the `affectsFlow(empty)` path; the lower waterlogged slab passes `affectsFlow(same fluid)`. The old material predicate blocks the fallback, while the new state predicate permits the height-difference contribution.
- `Entity.updateFluidHeightAndDoFluidPushing` calls `FluidState.getFlow` for overlapping tagged fluid and accumulates that vector when `isPushedByFluid()` is true. Thus this can alter the player fluid-push vector, not just a rendering or non-player path.

This witness is within the movement scope: existing vanilla blocks and direct player response to fluid flow. It does not rely on a modded or guessed state. The replacement is first present in the inspected 1.20 release; this does not establish behavior before 1.20 or after 1.20.4.

## Exact source identities

Canonical root: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`; Mojmap. For ready-marker trees, the marker's `versionId` and mapping were checked, its source-manifest digest matched the root `mojmap.sources.sha256`, and the `FlowingFluid.java` entry matched the file SHA-256. The 1.20 and 1.20.3 source trees have embedded `.decompile-provenance.json` only; their exact `FlowingFluid.java` entries match those embedded manifests. 1.20.0 retains the legacy embedded-manifest provenance limitation recorded in the allowed support-query closure.

| Version | `FlowingFluid.java` SHA-256 | `getFlow` body SHA-256 | Source identity |
| --- | --- | --- | --- |
| 1.19.4 | `d84ceb3c0b83da25fb68599e16cc2298106e745a9ef0c9f32f616d097a8ec56c` | `557f3de93c12590fd7320d2e7348b5efacc7563c2946e2cbd6f410f9b0822f92` | Ready marker `1.19.4/mojmap`; manifest `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3`; provenance `0efcfc6075852711cff5d62c3177258cba273c206c8a2d2642bdf3487c676b34` |
| 1.20 | `ba1dff6ccb28b62760c74d66832d8fdbe7a1cdc37b9c5a0ff476bd200215c904` | `0857243f0d5144fbfca453ea451de847a47e4ebc34a1e078c85a482536c4c6e4` | Embedded source entry matches; embedded provenance `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` |
| 1.20.1 | `ba1dff6ccb28b62760c74d66832d8fdbe7a1cdc37b9c5a0ff476bd200215c904` | `0857243f0d5144fbfca453ea451de847a47e4ebc34a1e078c85a482536c4c6e4` | Ready marker `1.20.1/mojmap`; manifest `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465`; provenance `5aeb1df09671480aeddb921c919e92098e33d0a0bce47e22f82a865cb32400aa` |
| 1.20.2 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` | `0857243f0d5144fbfca453ea451de847a47e4ebc34a1e078c85a482536c4c6e4` | Ready marker `1.20.2/mojmap`; manifest `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887`; provenance `1dad9f725f6cb25b6568700fa0294f83b66ea9633b0d62ed354d7bd8b45d4f05` |
| 1.20.3 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` | `0857243f0d5144fbfca453ea451de847a47e4ebc34a1e078c85a482536c4c6e4` | Embedded source entry matches; embedded provenance `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` |
| 1.20.4 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` | `0857243f0d5144fbfca453ea451de847a47e4ebc34a1e078c85a482536c4c6e4` | Ready marker `1.20.4/mojmap`; manifest `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1`; provenance `10914d9b7b3fc29de066ca24f7d905e4d4f0a451a6c81729a2d1981addfc1385` |



## Examined evidence

- `FlowingFluid.getFlow`: 1.19.4 and 1.20–1.20.4, full method hashes above. The comparison is isolated to the neighbor motion predicate; the body hash changes between 1.19.4 and 1.20 and is identical from 1.20 through 1.20.4.
- Predicate inputs: 1.19.4 `Material` builder defaults and `blocksMotion`; 1.20.4 `BlockBehaviour.BlockStateBase.calculateSolid`, its cache/init path, `blocksMotion`, force-solid properties and `AABB.getSize`.
- Amethyst cluster/bud registrations, direction-dependent collision shapes, valid UP-facing state, attachment survival check, and shared properties for smaller buds.
- Waterlogged stair/slab fluid-state path; use a top waterlogged slab below the dry cluster to provide both water and sturdy support.
- Player path: `FluidState.getFlow` dispatch and `Entity.updateFluidHeightAndDoFluidPushing` on 1.19.4 and 1.20.4.
- Related predicate safeguards reviewed as examples: `forceSolidOn` preserves motion blocking for empty/dynamic shapes such as moving pistons; `forceSolidOff` is used for selected thin/support shapes. `noCollision`/dynamic shape handling follows the cache and override rules above. No full per-registration truth-table was completed.

## Coverage boundary / next action

This proves at least one valid in-scope state and downstream player response. It is **not** a complete audit of every 1.19.4-era registered block family, all property combinations, all dynamic collision-shape callbacks, or every `forceSolidOn`/`forceSolidOff` and no-collision registration. Continue by enumerating all historical registrations with material-motion flags against modern state solidity, then filter each differing state through valid fluid/support adjacency and the player path. Do not treat this single-operation audit as pair freeze or full pair coverage.


## Source locations

- `1.19.4/mojmap/net/minecraft/world/level/material/FlowingFluid.java`: `getFlow`, lines 53–80; old predicate line 65.
- `1.20.4/mojmap/net/minecraft/world/level/material/FlowingFluid.java`: `getFlow`, lines 54–81; state predicate line 66. The `getFlow` body hash confirms the same implementation in 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4.
- `1.19.4/mojmap/net/minecraft/world/level/material/Material.java`: `AMETHYST` registration around line 101; builder defaults `blocksMotion=true` around lines 164–170; `blocksMotion()` accessor line 134.
- `1.19.4/mojmap/net/minecraft/world/level/block/Blocks.java`: amethyst cluster and bud registrations lines 4224–4242.
- `1.19.4/mojmap/net/minecraft/world/level/block/AmethystClusterBlock.java`: directional shape setup and `getShape` lines 24–45; attachment `canSurvive` lines 64–68.
- `1.20.4/mojmap/net/minecraft/world/level/block/AmethystClusterBlock.java`: direction-shaped boxes in constructor lines 49–57; `getShape` lines 63–77; attachment check lines 83–88.
- `1.20.4/mojmap/net/minecraft/world/level/block/state/BlockBehaviour.java`: collision shape uses state shape unless `hasCollision` is false, lines 333–336; `calculateSolid` lines 471–491; cache initialization lines 493–500; state `blocksMotion()` lines 512–515.
- `1.20.4/mojmap/net/minecraft/world/phys/AABB.java`: average-dimension `getSize`, lines 250–255.
- `1.19.4/mojmap/net/minecraft/world/level/block/SlabBlock.java`: waterlogged property and TOP shape lines 26–34, 47–57; `getFluidState` around lines 98–102. `1.20.4` has the corresponding declarations at lines 26–35, 54–65, 100–103.
- `1.20.4/mojmap/net/minecraft/world/level/block/AmethystClusterBlock.java`: `canSurvive` lines 83–88 checks the support face opposite `FACING`.
- `1.19.4/mojmap/net/minecraft/world/entity/Entity.java`: fluid scan and `getFlow` accumulation in `updateFluidHeightAndDoFluidPushing`, lines 2887–2933. `1.20.4/mojmap/net/minecraft/world/entity/Entity.java`: same call path, lines 3037–3084.
