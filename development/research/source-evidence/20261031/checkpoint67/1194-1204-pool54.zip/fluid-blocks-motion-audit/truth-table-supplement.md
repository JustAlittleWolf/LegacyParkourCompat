# `FlowingFluid.getFlow` registration truth-table supplement

## Corrected result

The amethyst cluster/bud witness in the earlier draft is invalid. The 1.20 registrations at `Blocks.java:6873–6893` add `.forceSolidOn()` to `AMETHYST_CLUSTER`, and 1.20.4 does so at `Blocks.java:6816–6830`; the smaller buds use `Properties.ofLegacyCopy(AMETHYST_CLUSTER)` (1.20 `Blocks.java:6884–6915`; 1.20.4 `Blocks.java:6831–6863`). `BlockState.blocksMotion()` therefore returns true for those states despite their narrow collision shapes, matching old `Material.AMETHYST.blocksMotion() == true`. Preserve the earlier files as requested, but do not rely on that draft's witness.

The pane family was a candidate because the all-disconnected state has a narrow 2/16 × 1 × 2/16 center column (average dimension 5/12), below the modern 0.7291666666666666 average-size threshold. It is **not** a witness: `calculateSolid()` also accepts any collision bounds with `Ysize >= 1.0`, and every pane state retains the center column's full block height. One-connection and higher-connection states remain motion-blocking as well. The pane candidate is rejected; the hypothesized lava arrangement cannot establish a player-current change.

## Material and shape checks

The 1.19.4 `Material` builder defaults `blocksMotion=true` and `noCollider()` sets it false. `notSolidBlocking()` does not change that value. Materials with old false values include AIR/STRUCTURAL_AIR/PORTAL, cloth decoration, plant and water-plant families, water/lava/fire, decoration/web, powder snow, bamboo sapling, frogspawn and the replaceable plant variants. All current non-motion results below are derived from the corresponding vanilla material flag, property override, dynamic/no-collision path, and collision bounds; no guessed or modded state was used.

| Registration/state family checked | Old material result | Modern state result | Source-level disposition |
| --- | --- | --- | --- |
| Iron bars, glass pane, stained glass panes | true | true, including disconnected state | Core column has `Ysize=1`, and `calculateSolid()` explicitly accepts `Ysize >= 1.0`, even though average size is 5/12. All states preserve at least the same full-height core. |
| Amethyst cluster and buds | true | true | `.forceSolidOn()` is set on the cluster and copied into buds. The earlier draft's proposed mismatch is reversed by this override. |
| Material-false static candidates from direct registrations: cocoa; comparator/repeater; lily pad; sea pickle; candles; carpets; potted plants; skull/head and wall-head families; end rod; ladder; snow layers; azalea; chorus plant/flower; big dripleaf | false | false for examined states | Shape-bound candidates such as cocoa (largest bounds 8/16 × 9/16 × 8/16; average 25/48), sea pickle, candles, pots, skulls, carpets, and redstone plates stay below threshold. End rod and ladder also stay below it. Azalea, chorus, big dripleaf, and other explicit exceptions use `forceSolidOff`; thin snow states are explicitly forced off. |
| No-collision registrations | false when old material is non-motion; otherwise old material retained | false absent force override | Empty collision shape makes `calculateSolid()` false; registration scan found no 1.19.4-era old-motion-true/common registration with `noCollission()` and a modern `forceSolidOn()` override. The decorated pot is modern-only and excluded. |
| Dynamic-shape registrations checked | material-dependent | false without cache; explicit force flags take precedence | `calculateSolid()` returns false for a null cache. The checked modern force-on dynamic families (pistons, shulker boxes, bamboo, pointed dripstone) have old motion-true materials; powder snow and scaffolding have old motion-false materials and remain false. |
| Full/large static collision families in the direct-registration scan | true | true | Reviewed state-shape families include cubes, logs/rotated pillars, slabs, stairs, doors/trapdoors, fences, anvil, brewing stand, grindstone, daylight detector, cactus, and other registered full/large shapes. The modern test uses collision-bounds average and the full-height clause; door/trapdoor thickness reaches the exact average threshold. |

The selected fluid-current path was traced as a validation of the rejected pane proposal. `FlowingFluid.getFlow` checks a horizontal neighbor with empty fluid, then conditionally looks one block down; `affectsFlow` accepts empty fluid and same-type fluid. A pane beside lava with lava below its position can be dry because `SimpleWaterloggedBlock` waterlogging is specific to water. However, since the pane state remains motion-blocking, both predicate versions skip that lower lookup. This is not a witness and creates no player push difference.

## Registration scan boundary

The source scan counted 998 syntactic `Blocks.register` declarations in 1.19.4 and 1,052 in 1.20.4, with 991 common resource IDs. Seven historical IDs are absent in 1.20.4 (`grass`, `pumpkin`, `melon`, `attached_pumpkin_stem`, `attached_melon_stem`, `pumpkin_stem`, `melon_stem`); replacements are not treated as the same raw state. The direct-expression scan identified 407 common old-motion-true registrations with no direct collision/dynamic/force flag token; pane and amethyst states were checked explicitly, and the other direct families were screened by their shared collision implementations.

This is not a completed exhaustive registration census. In 240 common IDs the old registration does not mention a `Material.*` token in its own registration segment because it aliases/copies a property or uses a helper. Those entries require following the exact property lineage before a complete material-by-state truth table can be claimed. No difference has been established in those rows here. The pink-petals registration is gated by the 1.20 feature flag in the old source and is excluded as a modern-only feature. The scan also does not prove every state combination of every dynamic collision callback. This supplement closes the pane and amethyst false leads only; it does not freeze the pair or assert no vanilla witness exists.

## Operation and player path references

- 1.19.4 Mojmap `FlowingFluid.getFlow`, `FlowingFluid.java:53–80`: fallback guard is `neighborState.getMaterial().blocksMotion()` (line 65). The old source's body SHA is recorded in `audit.md`.
- 1.20 Mojmap `FlowingFluid.getFlow`, `FlowingFluid.java:54–81`: guard is `neighborState.blocksMotion()` (line 66). Its body hash is the same in 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4; the exact intermediate identities/hashes are recorded in `audit.md`.
- 1.19.4 Mojmap `Material.java:88,92,134,160–183`: GLASS/METAL declarations, `blocksMotion` accessor, builder default, and no-collider setter.
- 1.19.4 Mojmap `Blocks.java:1489–1510,2047–2050`: iron bars, glass pane, and white stained pane registrations. The 15 other stained colors use the same `StainedGlassPaneBlock`/`Material.GLASS` registration pattern.
- 1.20 Mojmap `Blocks.java:2603–2612,3340–3344`; 1.20.4 Mojmap `Blocks.java:2603–2612,3340–3344`: matching pane-family registrations, no force-solid or no-collision calls.
- 1.19.4 Mojmap `IronBarsBlock.java:18–25` and `CrossCollisionBlock.java:35–80,89–100,107–132`; 1.20.4 Mojmap `IronBarsBlock.java:20–32` and `CrossCollisionBlock.java:33–85,94–100,107–133`: constructor defaults, state-to-index mapping, center-column bounds, collision lookup, and waterlogged fluid state.
- 1.20.4 Mojmap `BlockBehaviour.java:471–515`: force-on/off, null-cache/empty-shape behavior, AABB threshold/full-height clause, and the two state-specific exclusions.
- 1.20.4 Mojmap `FlowingFluid.java:59–83,101–103`: neighbor and lower-fluid calculation; empty and same-fluid acceptance.
- 1.19.4 Mojmap `Entity.java:2887–2933` and 1.20.4 Mojmap `Entity.java:3037–3084`: player/entity fluid scan invokes `FluidState.getFlow()` and adds the vector if `isPushedByFluid()`.

## Source identity

Canonical source root is `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft` (Mojmap, read-only). The shared scan cross-checked source-file entries against the version ready manifests or embedded provenance maps for `Blocks.java`, `IronBarsBlock.java`, `CrossCollisionBlock.java`, `BlockBehaviour.java`, `AABB.java`, and `Material.java` where present. Root identity digests and limitations are in `audit.md`. Selected source-file SHA-256 values:

| Source | SHA-256 |
| --- | --- |
| 1.19.4 `Blocks.java` | `a4f2df87c2cae5a3827a818f39f7ad123ee5b18905ead9947efe654421c30ff5` |
| 1.20 `Blocks.java` | `1e7095d1fbfdc8198191f40037997feeca2ec993cc54dd53f2636375cae66b51` |
| 1.20.4 `Blocks.java` | `5392c4349317e55c2989865be38c17b94e6e0543e7017e6a2a64d79217e83643` |
| 1.19.4 `Material.java` | `842c7ee4723993c6ee3bf4732343f3225bb05aac5ee80c919c34c3ba1a027431` |
| 1.19.4 / 1.20.1 `IronBarsBlock.java` | `422fc9a4125e1d53a001c631c15e45eb5dafdfd0f6c2c41ed31c27ac66f861a4` |
| 1.20.4 `IronBarsBlock.java` | `3c7dbb0b6f67e06ef27fad7d9697c58ae12c870d838c039f1e22054e6f042c82` |
| 1.19.4 / 1.20 / 1.20.1 / 1.20.2 `CrossCollisionBlock.java` | `de1c71e81995e9d7e66d829904e7aeaf2d15dbc88d30a30c20c6dd384b5a4c79` |
| 1.20.3 / 1.20.4 `CrossCollisionBlock.java` | `60faee3288389c1a82980adc8838a2e29ca14f6cdd09c3781c031d6d82b38e0a` |
| 1.20.4 `BlockBehaviour.java` | `6284a7d08a6d0d475cd4fe8aea62b35153ae8fbc0bce5f51788389f679233b54` |
| 1.20.4 `AABB.java` | `13ab54ef7b11abbe41465580eb5cddb05a4bad3178995d4609c252d70b96cad9` |
