# Independent provider and context audit (source-only)

Assignment: 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, 1.20.4; canonical Mojmap source trees only.

## Source identity and limits

Source root resolved as `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<release>/mojmap`. The exact `1.20` and `1.20.3` roots have `.decompile-provenance.json`; every file containing a scanned provider method plus the registration, shulker BE, support, entity-collision, and collision-iterator files matched its manifest source hash (138 checks for 1.20, 139 for 1.20.3). Manifest input identities bind those trees to exact Mojang client and mapping artifacts. The `1.19.4`, `1.20.1`, `1.20.2`, and `1.20.4` roots have no manifest, so they are legacy sources with unverified provenance under the decompiler guide. Directory names and stable local fingerprints do not prove artifact identity. This limits exact-source acceptance for claims depending on those sides.

## Frozen provider inventory

All direct `public VoxelShape` declarations for `getShape`, `getCollisionShape`, `getBlockSupportShape`, `getInteractionShape`, `getOcclusionShape`, and `getVisualShape` in `net/minecraft/world/level/block` were scanned for all six versions. The complete per-release method/file/line/body-hash inventory is `provider-methods.csv`; it contains 181/184/184/185/185/185 overrides, respectively. `Blocks.java` is the registration owner and includes helper factories, so effective properties must be read at the helper call site as well as at direct registrations. Factory flags were checked for every explicit `.dynamicShape()` call: moving piston, bamboo, scaffolding, powder snow, pointed dripstone, and shulker boxes are marked dynamic in each checked release. Shulkers are not a static-to-dynamic registration transition in this interval.

The inherited defaults and dispatch are in `block/state/BlockBehaviour.java`: `getCollisionShape(state, world, pos, context)` returns empty when collision is disabled, otherwise dispatches to `state.getShape(world,pos)` by default; state `getShape` dispatches to the block provider. State collision-shape fast-path caching is only used when the block is not marked dynamic. Entity block iteration (`world/level/BlockCollisions.java`) calls each state’s `getCollisionShape` with its entity `CollisionContext`; `Entity.collideBoundingBox` consumes that iterator during movement collision. `Entity.isColliding` separately calls the contextual collision provider. This is the direct shape-to-player movement collision path.

`getBlockSupportShape` is consumed by `SupportType` (`FULL`, `CENTER`, `RIGID`) through block face support predicates. No direct use appears in `Entity`, `LivingEntity`, or `Player` movement classes in this source range. `getInteractionShape` is a non-player interaction/raycast path and is not a movement consumer. Outline shape is used for selection/raycast; it only reaches movement when a default collision provider delegates to outline shape. Fluid pushing/swimming reads `FluidState` and entity fluid APIs; fluid block outline/collision shape is not the fluid-motion consumer.

## Dynamic inputs and cached solid predicate

Shape inputs are not limited to raw `BlockState`: providers take `BlockGetter`, `BlockPos`, and often `CollisionContext`; the source inventory includes providers that read neighboring states, block entities, or entity context, plus state-keyed geometry. The inspected dynamic examples include connection shapes (fences/walls/panes), directional/hinged/half shapes (doors, trapdoors, stairs), multi-part moving pistons, and block-entity geometry (shulkers). Exact full provider bodies still need independent per-class review; see `unexamined-provider-classes.txt`.

Shulker trace: `Blocks.shulkerBox(...)` applies `.forceSolidOn().dynamicShape()` in 1.20 through 1.20.4 (the 1.19.4 helper also applies `.dynamicShape()`). `ShulkerBoxBlock.getShape` reads the block entity and returns its `getBoundingBox(state)`, falling back to a full cube if the BE is missing. `ShulkerBoxBlockEntity.getBoundingBox` uses the block state `FACING` and `0.5F * getProgress(1.0F)`; progress is animation state held as `progressOld`/`progress` and updated by its block-entity tick. The default block collision provider delegates to state outline shape, so the entity-context `BlockCollisions` route sees this BE-dependent geometry. Separately, the block entity's opening path pushes intersecting entities via `MoverType.SHULKER_BOX`; that is a direct response path, not the shape iterator.

`BlockBehaviour.BlockStateBase.calculateSolid()` is a distinct legacy predicate. It returns forced-on/off values first; otherwise it reads the cached default collision shape only when cache exists, and dynamic states without a cache return false. Shulkers separately force solid on. This cached `legacySolid` result powers `isSolid`/`blocksMotion` and related predicates; it does not memoize or supply the runtime geometry used by `Entity.collideBoundingBox`. Do not conflate this predicate with the dynamic shape path.

## Adjacent scan results and candidate cutovers

Provider method source/body hashes produce the following paired changes, each requiring semantic follow-up against exact raw states and helper definitions:

- 1.19.4→1.20: `CropBlock`, `BeetrootBlock`, `CarrotBlock`, `PotatoBlock`, and `TorchflowerCropBlock` switch their age lookup from `getValue(getAgeProperty())` to `getAge(state)`. These are source-body rewrites, but `CropBlock.getAge(state)` in 1.20 still returns `state.getValue(getAgeProperty())`; the inspected crop shape result is equivalent for the same raw state. `PitcherCropBlock` adds an age/half keyed outline and a separate age-zero bulb collision shape; `SnifferEggBlock` adds a shape provider (same in 1.20 and 1.20.1).
- 1.20.1→1.20.2: `PinkPetalsBlock.getShape` changes from a constant 16×3×16 outline to a shape-table lookup keyed by `FACING` and `AMOUNT`; same raw state values can therefore select differing bounds across this cutover. `ChorusFlowerBlock` adds a support shape (1,0,1)-(15,15,15), replacing inherited full-cube support geometry for the same state. This changes support predicates and block placement/survival semantics, but is not a direct player collision provider.
- 1.20.2→1.20.3: `DoorBlock.getShape` is rewritten from switch statement to switch expression while preserving the same `FACING`, `OPEN`, and `HINGE` selection and AABB returns; source indicates syntax/control-structure rewrite only, no same-state geometry difference. Provider ownership also moves `getShape` from `TorchBlock` to `BaseTorchBlock`, while `AbstractGlassBlock.getVisualShape` disappears and `TransparentBlock.getVisualShape` appears. These inheritance/visual-only movements have not been behavior-audited here.
- 1.20→1.20.1 and 1.20.3→1.20.4: no direct provider method-body hash changes.

The scan compared direct provider override bodies and direct registration dynamic-shape markers, but did not compare every helper, static shape table, inherited provider, state definition, registration argument, neighbor rule, or consumer for every class. The exact provider classes not yet manually reviewed are listed in `unexamined-provider-classes.txt`; this audit is not full-pair coverage closure or independent acceptance.

## Files

- `provider-methods.csv`: frozen inventory with method IDs, version, relative path, line, and body hash.
- `unexamined-provider-classes.txt`: exact direct-provider classes awaiting individual context/body review.



## Erratum, provenance and support-consumer closure

This addendum supersedes the earlier source-identity paragraph above; that paragraph incorrectly concluded four roots lacked provenance because it checked only for an embedded manifest. The independent baseline above is preserved unchanged.

I inspected each version parent directory with `Get-ChildItem -Force` and verified the parent-level ready/provenance/source-manifest sidecars. For each of the four sidecar-backed releases, the `mojmap.ready.json` `sourceManifestSha256` matches the actual `mojmap.sources.sha256`; every listed source file was then SHA-256 checked against that manifest. All file counts match and there are zero mismatches:

| Release | Mapping | Source files checked | `mojmap.sources.sha256` SHA-256 | Client SHA-256 |
| --- | --- | ---: | --- | --- |
| 1.19.4 | mojmap | 4,740 | `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` | `0e79cf7f07c107e9a1fe22ed703e472372b44149e64114944f0811abbd25f3ec` |
| 1.20 | mojmap | 6 manifest-checked provider/consumer files | embedded manifest SHA-256 `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` | `5ac9ead135746f5f27048f2e01d8d5bdc2dabc4d91422f73ef2435f4c3d24aff` |
| 1.20.1 | mojmap | 4,786 | `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` | `56b71336d2b4fdffd197f56595b0da93e32a946f78f382a299b8f4b92758bb0f` |
| 1.20.2 | mojmap | 4,904 | `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` | `fa1a19be56a506426308abbc1cad85f299a7fc6dae4335559351ba0246713fda` |
| 1.20.3 | mojmap | 6 manifest-checked provider/consumer files | embedded manifest SHA-256 `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` | `5ac9ead135746f5f27048f2e01d8d5bdc2dabc4d91422f73ef2435f4c3d24aff` |
| 1.20.4 | mojmap | 5,048 | `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` | `9221ab461a491bf9661cd8e773a5e662aaa43d600fa7970b8c12bbfb0431b838` |

For 1.20 and 1.20.3, the six listed checks are the embedded-manifest checked provider/consumer files in the prior audit; the full provider inventory source files were checked against the embedded manifest (138 and 139 source-file checks respectively, zero failures). Thus all six roots have version-bound Mojmap source identities and intact provider inventory files. The four parent-sidecar source-manifest SHA values above bind the full declared source trees.

The support-shape consumer search was repeated for all six releases. In `Entity.java`, `LivingEntity.java`, `Player.java`, and `client/player/LocalPlayer.java`, there are no calls to `getBlockSupportShape`, `SupportType`, or `isFaceSturdy`. Globally, direct `getBlockSupportShape` consumption is confined to `SupportType` calculations and `MultifaceBlock`'s attachment predicate; there is no player movement, jump, auto-jump, or support-selection route through this provider. The source-backed `ChorusFlowerBlock` support-shape change is placement/block-support behavior only and is excluded from player movement scope.

`PinkPetalsBlock` is absent from the 1.19.4 source tree and was introduced only in 1.20. It is not part of the 1.19.4-era block domain and its later outline-shape change is excluded from historical 1.19.4 player-movement findings.

Hash binding: this addendum was appended to the independent audit whose pre-erratum SHA-256 was `0a8478ce6f5ac03854aaef0642308977b2740e2ad9813e4b5b08c56acf27d69b`. The final audit hash is supplied in the completion message. This corrects provenance and closes only the named support consumer and feature-domain questions; it does not close the pair inventory or its listed unexamined classes.
