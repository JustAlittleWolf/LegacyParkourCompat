# Movement slowdown callback continuation (partial)

## Scope and evidence gate

Compared exact Mojmap 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4 sources in the canonical `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\<version>\mojmap` tree. Source identities are the ones recorded in the parent `callback-census.md`: versioned `mojmap.sources.sha256` manifests for 1.19.4/1.20.1/1.20.2/1.20.4, legacy embedded `.decompile-provenance.json` maps for 1.20 and 1.20.3. Every present class in this continuation was checked against its sidecar or embedded manifest entry; all matched. This slice does not freeze the pair.

## Result

No concrete changed on-foot player slowdown operation was found in this subset.

`Entity.checkInsideBlocks` enumerates integer block positions covering the entity bounding box inset by `1.0E-7` at min/max and calls each state's `entityInside`; the caller follows movement/collision in `Entity.move` (`Entity.java`: 1.19.4 lines 896–922 and 1.20.4 lines 968–998). `Entity.makeStuckInBlock` resets fall distance and stores its supplied multiplier (1.19.4 lines 2208–2211; 1.20.4 lines 2354–2357). At the start of a later `Entity.move`, if the stored vector's squared length exceeds `1.0E-7`, the requested displacement is component-multiplied by the vector, then the stored vector is reset to zero and entity velocity is set to zero (1.19.4 lines 562–566; 1.20.4 lines 609–613). `LivingEntity.travel` invokes `move(MoverType.SELF, getDeltaMovement())` in its movement branches (1.19.4 lines 2016, 2031, 2074, 2155; 1.20.4 lines 2067, 2082, 2125, 2205). `LocalPlayer` has no `makeStuckInBlock` override or separate stuck-multiplier consumer in any of the six files; the local player uses inherited player/living-entity movement. `Player.makeStuckInBlock` forwards only when `!abilities.flying` (1.19.4 lines 1610–1614; 1.20.4 lines 1566–1570).

### Contact callbacks that set slowdown

- `WebBlock.entityInside` unconditionally supplies `Vec3(0.25, 0.05F, 0.25)`.
- `SweetBerryBushBlock.entityInside` supplies `Vec3(0.8F, 0.75, 0.8)` only for `LivingEntity`, excluding foxes and bees. Its later age/server/movement-gated damage branch is excluded from this movement comparison.
- `PowderSnowBlock.entityInside` supplies `Vec3(0.9F, 1.5, 0.9)` when the entity is not a `LivingEntity` or its feet block state is this powder snow block. For a player this means the feet state must be powder snow. Its `canEntityWalkOnPowderSnow` footwear predicate and collision shape are separate shape/state dependencies; no change in its slowdown write was found.

The block callbacks retain these values and gates across all six sources. Observed hash groups (SHA-256, relative paths under `net/minecraft/world/level/block/`):

| Class | 1.19.4–1.20.1 | 1.20.2 | 1.20.3–1.20.4 |
|---|---|---|---|
| `WebBlock.java` | `eb8f4433705367aa7ce23c5a6071955b4d67728e299a2993285c6405ce638e49` | same | `87238b193dc86aa01fa70814bf5056a68392eeeb3afb8421e92c20868418a593` |
| `SweetBerryBushBlock.java` | `aaf99e276258941ad011a913c518db6604351637601cbbf5e4a6cd6815520a64` | `73375b2cb49efcbc3e64b49cac0fad3b30dd6a583518242df13c221ad8844cf5` | `9910ebffc04f6c935761d856e743e67fad3359d8db97ac99db9d41c0223cc48` |
| `PowderSnowBlock.java` | `40b15b7239a24058cc34ed9f1ede0611edde897badbef5486c493cf620949c5d` | `f94f20b85520194757470722de071fb781107acdadee16598cf401d18248c09f` | `302e784a106a37b00aafa0ff7ac5d638c78ccb61f34c2efac4d952f6a284a55c` |

The different whole-file hashes in Sweet Berry and Powder Snow include other block changes; the relevant callback gates and multiplier assignments were compared directly and are unchanged.

### Scaffolding, ladders, dripleaf, and remaining `makeStuckInBlock` calls

`BigDripleafBlock.entityInside` only runs server-side and changes tilt state when tilt is `NONE`, the entity is grounded above the `0.6875F` threshold, and no neighbor signal is present. It does not write player velocity or slowdown state; the tilt-state consequence and resulting shape change are excluded from this subset. `ScaffoldingBlock` and `LadderBlock` declare no `entityInside`/`makeStuckInBlock` callback. Climb movement is resolved in `LivingEntity.onClimbable`: non-spectators check whether the feet block state is in `BlockTags.CLIMBABLE`, or is an open trapdoor over a same-facing ladder; the result feeds ladder/climb travel branches. The `onClimbable` gate and travel operations were compared and have no movement-code delta across these releases. Exact tags and contextual collision shapes remain separate dependencies, so this is not closure of the broader climb lane.

A source-wide search for `makeStuckInBlock` in these six versions found the three block callbacks above, plus `Entity`, `Player`, `Spider`, and `WitherBoss` implementations. `Player`'s flying gate remains unchanged; Spider/Wither are non-player implementations and excluded. `Entity.move`'s multiplier consume/reset/velocity-zero sequence remains unchanged in all six versions. `LivingEntity.travel`'s self-move call sequence remains unchanged. `LocalPlayer` contributes no separate implementation of this mechanism.

One surrounding caller change was noted but does not yield an in-scope operation here: from 1.20.2, `Entity.checkInsideBlocks` returns early if the entity is no longer alive between scanned cells. That can affect later callbacks after an entity-killing contact; it is tied to death/damage behavior, which is excluded by this assignment.

## Hash inventory

All hashes below were checked against the exact root source manifest or legacy embedded source map for their release:

| Source class | 1.19.4 | 1.20 / 1.20.1 | 1.20.2 | 1.20.3 / 1.20.4 |
|---|---|---|---|---|
| `Entity.java` | `3667fee610cbc5f58012e3a8fb8d6c4849f649fb7fe5300595158112d8b4b58b` | `94b9c3656715de2d61fa9a02ccef164261e50eb13d6090a6f07e58fe9c5b0759` | `d7ee49aaea5e862b92508e767562cabc8f10515605e8fb67565c8c8d5c23b01b` | `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9` |
| `LivingEntity.java` | `c8d91af61f87aaa1666de79696d7cd9d4a8212d05f873bdaf28d7bb2926bf165` | `decf8cd70d194098ad51d0c82e5a0087e0687881e0a2dc66456f2ba6ea76676f` | `5c481da1ffc8684c4b30171c92e61fad751e6a3a708d5bc6486acf9f6ff69828` | `f7bc53db24c1798f19f9bd6f6356c86d5e560e9c8e8aac60decaf15cc785e07d` |
| `Player.java` | `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2` | `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac` | `25f263692fd6b2a737aa813315022a0caf4e18c3661ba3bd706c6297f909f25c` | `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd` |
| `LocalPlayer.java` | `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58` | `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2` | `bb5cbfb03656a1866bb77c00431618befE792081223b35db4bd121ecbb151fd5` | same |
| `BigDripleafBlock.java` | `b27695e811d04d0cfe97d4f92c4f7a32f687d8e5bd6f1019d2bd4a754cf7fe02` | `910a0c0ab94c7b76f69b53ee31bee45bc3ecdda38d483f1662bb75fd513f31d8` | `ca5892747404d11c09cd3eda093be12122406a1c1465dfed0077ae3bde3c8bc3` | `fb273abc814e61708fe0f19ecae2d15baf231f0c53fd3e5555a7e6e8cf3465c1` |
| `ScaffoldingBlock.java` | `fe0d38c1f1f06453fb42aad778d0ae8a8a5e13db335be9b465ca8c7653339eec` | same | same | `7e794a606f5dca4e5e02214bd0821b05c1ae2e654c164e146ad3d6e71dbee83f` |
| `LadderBlock.java` | `67c9784a299c0acda09e76bb9e497ac84fa9a1a431d5af8cb88e44c996b279df` | same | same | `e7c9138b8dd1be383cf242d47b07741f8c16899c447cad30e04e9b4ff64a379d` |

## Remaining scope

This closes only the named slowdown callback subset and the shared multiplier store/consumer. Continue the parent census with other direct player state/velocity callbacks, remaining contact/step/fall method bodies, shape/state/tag dependencies, block push and piston interactions, plus caller-side logical-client applicability. No pair freeze is warranted from this continuation alone.
