# Lane coverage: movement effects, attributes, equipment, fluids, callbacks, external inputs

## Source identity

Canonical read-only source root: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`, Mojmap, exact versions 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, 1.20.4. Release `mojmap.ready.json` / `mojmap.provenance.json` / `mojmap.sources.sha256` identities were checked where present. 1.20 and 1.20.3 use embedded `.decompile-provenance.json` manifests; the embedded provenance layout was checked. SHA-256 of the exact files used for the findings (`LivingEntity.java`, `LocalPlayer.java`, `ClientPacketListener.java`) matched each release's root or embedded source manifest across all six releases. The 1.19.4 and 1.20.1 source-manifest SHA-256 values are `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` and `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465`; the legacy embedded 1.20 provenance SHA-256 is `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f`. Other sidecar identities are in the source tree and were inspected but not copied here.

## Findings drafted

- `jump-boost-precision.md`: float/double operation change in inherited jump calculation, exact boundary at 1.20.
- `local-player-spectator-velocity.md`: newly added local-player callback zeros Y velocity on spectator game-mode update, exact boundary at 1.20.

## Examined slices without separate findings

- `LivingEntity`/`Player` jump, fluid travel, slow-falling and levitation branches; `Player.isAffectedByFluids`, `Player.travel`, water swimming, flying, and jump callbacks. `isAffectedByFluids()` remains `!abilities.flying`. The movement bodies in these slices retain their fluid coefficients and branch order across the pair, apart from the drafted jump calculation. `LivingEntity.travel` adds `resetFallDistance()` when Slow Falling or Levitation is active in the 1.20 line; this changes a fall-distance bookkeeping field but does not alter the position/velocity calculation in that branch. Record as movement-state candidate for independent scope judgment rather than a separate position/velocity finding.
- `Player.travel` drops `checkMovementStatistics` in 1.20.4; movement statistics and associated food-exhaustion production are excluded.
- Effects: `MobEffect` modifier application changes from concrete modifiers to modifier templates in 1.20.2. The amplifier scaling remains `base amount * (amplifier + 1)`, and `AttributeInstance.calculateValue` retains the same addition, multiply-base, then multiply-total order. `LivingEntity.refreshDirtyAttributes` added for max-health and max-absorption clamping only; it does not change movement attributes. These are API/data lifecycle changes without a player movement delta in the examined path.
- Movement attributes: `Attributes.MOVEMENT_SPEED` and `FLYING_SPEED` keep their values; `AttributeInstance` modifier evaluation order remains the same. `Attributes` additions/registration reorder examined; no movement attribute value change.
- Equipment: `LivingEntity.updateFallFlying` continues checking chest-slot Elytra and `ElytraItem.isFlyEnabled`; the movement eligibility/order is unchanged in the endpoint and 1.20.2/1.20.3 source slices inspected. `Item` and `ItemStack` hash changes include unrelated refactors; broader equipment producer/registration closure remains open.
- Fluids and block callbacks: `FluidState` is byte-identical across all six releases. `FlowingFluid`, `BubbleColumnBlock` and `PowderSnowBlock` change in portions inspected, but their movement-facing entity callbacks/surface behavior showed no movement delta in endpoint method slices; `FlowingFluid` changes are fluid spread/replaceability gates, and the identified BubbleColumn/PowderSnow edits are codec or material-to-block predicate refactors. Full callback/provider closure remains open.
- External inputs: compared `ClientPacketListener` movement packet handler declarations for `handleSetEntityMotion`, `handleTeleportEntity`, `handleMoveEntity`, `handleUpdateMobEffect`, `handleRemoveMobEffect`, `handlePlayerAbilities`, and `handleUpdateAttributes` across endpoints and intermediates; no candidate movement rewrite was found in those handlers. A more exhaustive line-by-line audit of every handler and every direct callback is still required to close this lane.

- `LocalPlayer.aiStep`: in 1.20.2 a new `!isPassenger()` guard is added to the crouching assignment, and pose eligibility switches to `canPlayerFitWithinBlocksAndEntitiesWhen`. This may change the local player's crouch state while mounted; `Entity.move` has a crouching-dependent collision/step gate, but I have not closed whether the mounted player reaches that movement path or whether the change is limited to excluded vehicle control. Keep as an unresolved candidate; next action is trace `LocalPlayer` riding tick / movement callers and compare the intermediate implementation.

## Partial and unexamined areas / next bounded action

This lane is partial. Remaining work: inspect exact `LocalPlayer` tick, input-to-impulse, `ClientPacketListener` relevant handler bodies, `ServerPlayer` dynamic overrides and related effect synchronization through all intermediates; trace movement-relevant attribute/equipment modifier sources and item registrations; close all fluid/player direct callbacks and external packet state writers. No pair freeze is claimed.



## Spectator callback evidence identities

Both callback source files matched each release's manifest entry. Exact Mojmap source identities:

| Release | Source manifest/provenance SHA-256 | `LocalPlayer.java` SHA-256 | `ClientPacketListener.java` SHA-256 |
| --- | --- | --- | --- |
| 1.19.4 | `mojmap.sources.sha256`: `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` | `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58` | `bcc74e52a32d20a3e993ebe4e08fffe8caca7481fad8f326dacdc93796b2b715` |
| 1.20 | embedded `.decompile-provenance.json`: `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` | `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2` | `8b21ccd4106abb0698f6872250e665ae3f0fc942c8953b9ddd45976660ed624b` |
| 1.20.1 | `mojmap.sources.sha256`: `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` | `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2` | `8b21ccd4106abb0698f6872250e665ae3f0fc942c8953b9ddd45976660ed624b` |
| 1.20.2 | `mojmap.sources.sha256`: `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` | `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` | `0208f6942035adaf2e787546851ca296f0e7ec2179d3610f694911eda5283264` |
| 1.20.3 | embedded `.decompile-provenance.json`: `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` | `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` | `ff9c8222614551075b03454ee78712b0d39f0f51845e74bff76a81486f09b42f` |
| 1.20.4 | `mojmap.sources.sha256`: `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` | `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` | `ff9c8222614551075b03454ee78712b0d39f0f51845e74bff76a81486f09b42f` |

The `LocalPlayer.java` SHA-256 is identical across 1.20.2–1.20.4.

