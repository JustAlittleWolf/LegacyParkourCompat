# Jump boost precision

1.19.4 Mojmap: `net/minecraft/world/entity/LivingEntity.java`, `getJumpPower` (1947–1949), `getJumpBoostPower` (1951–1953), and `jumpFromGround` (1955 onward).
1.20 Mojmap: `net/minecraft/world/entity/LivingEntity.java`, the same methods at 1969–1990; unchanged in 1.20.1 (same method bodies and file hash) and retained in 1.20.2, 1.20.3, and 1.20.4 (`getJumpPower` 2000, `getJumpBoostPower` 2004, `jumpFromGround` 2008 in 1.20.4).

Difference: 1.19.4 computes `getJumpPower()` as a `float` and `getJumpBoostPower()` as a `double`, then adds them into a `double` in `jumpFromGround()` before storing the vertical component. In 1.20, `getJumpBoostPower()` returns `float`; `getJumpPower()` adds the base jump and boost inside a float expression, and `jumpFromGround()` stores that result. The Player override of `jumpFromGround()` calls `super`, so ordinary player jumps with Jump effect use this calculation. The changed float addition can round the combined vertical launch velocity before it is widened by `setDeltaMovement`.

Movement meaning: with a nonzero Jump effect and a reachable ground jump, the resulting upward velocity can differ by float-rounding error. Exact boundary is 1.20: the same calculation persists in 1.20.1, 1.20.2, 1.20.3, and 1.20.4. No Player override of `getJumpPower` or `getJumpBoostPower` was found in the endpoint trees; Player's `jumpFromGround()` delegates to the inherited implementation.
