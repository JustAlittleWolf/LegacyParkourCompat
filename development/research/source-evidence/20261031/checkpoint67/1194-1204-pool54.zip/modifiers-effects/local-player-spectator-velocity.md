# Local player spectator velocity callback

1.19.4 Mojmap: `net/minecraft/client/player/LocalPlayer.java` has no `onGameModeChanged(GameType)` method. In `ClientPacketListener.applyPlayerInfoUpdate`, the `UPDATE_GAME_MODE` branch only updates the cached `PlayerInfo` game mode; it does not call the local player.

1.20 Mojmap: `LocalPlayer.onGameModeChanged(GameType)` zeros only the Y component of current delta movement when the argument is `SPECTATOR`. `ClientPacketListener.applyPlayerInfoUpdate` invokes it in the `UPDATE_GAME_MODE` branch when the cached `PlayerInfo` game mode differs from the packet entry, the local player exists, and the packet profile UUID matches that player; the call occurs before updating the cached `PlayerInfo` game mode. The same callback and guarded caller are present in 1.20.1, 1.20.2, 1.20.3 and 1.20.4. In 1.20.4 Mojmap these are `LocalPlayer.java` lines 1052–1055 and `ClientPacketListener.java` lines 1734–1739.

Difference: starting in 1.20, this player-info packet path can immediately replace local-player vertical velocity with zero when the incoming game mode is spectator, retaining horizontal velocity. This trigger is the local player's `UPDATE_GAME_MODE` player-info entry. The separate `ClientboundGameEventPacket.CHANGE_GAME_MODE` branch in `handleGameEvent` updates `MultiPlayerGameMode` and does not call this callback.

Movement meaning: for an airborne local player with nonzero Y velocity, a matching `UPDATE_GAME_MODE` entry whose game mode is spectator leaves the player with zero Y velocity before later movement. This is a direct player movement-state response to a valid raw packet input, within the project's movement scope; the project's undefined behavior for profile switching does not apply to this game-mode packet.

Exact boundary: 1.20. The callback is present in 1.20 and 1.20.1 (identical `LocalPlayer.java` and `ClientPacketListener.java` file hashes), and remains unchanged in 1.20.2, 1.20.3 and 1.20.4. The exact source release, Mojmap sidecar/embedded manifest and file SHA identities for all six compared releases are recorded in `coverage.md`.
