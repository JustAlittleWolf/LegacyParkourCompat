# Fluid material/state lineage closure

## Result

The unresolved no-direct-material cohort closes with **no same-raw-state `Material.blocksMotion()` / `BlockState.blocksMotion()` mismatch** among its common registrations. I traced all 240 rows across 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4. The old material resolves for every row, and every state family resolves to the same boolean in the modern state predicate. No valid fluid arrangement in this cohort can create a `FlowingFluid.getFlow` or `canSpreadTo` difference through this predicate.

This checks both call sites that use the changed predicate:

- 1.19.4 `FlowingFluid.getFlow` reads `getBlockState(neighbor).getMaterial().blocksMotion()` (Mojmap `FlowingFluid.java:53–80`, predicate at 65). 1.20 through 1.20.4 read `getBlockState(neighbor).blocksMotion()` (the same method body with the predicate at line 66 in the 1.20 trees).
- 1.19.4 `FlowingFluid.canHoldFluid` uses the old material predicate after its existing exclusions (`FlowingFluid.java:377–393`); 1.20 through 1.20.4 use `!state.blocksMotion()` (`FlowingFluid.java:378–390` in 1.20.3/1.20.4). `canSpreadTo` calls `canHoldFluid` after fluid replacement and collision-wall checks (`1.19.4:395–396`; `1.20.4:391–392`).

In the targeted rows, the 11 no-collision button registrations resolve to old `Material.DECORATION`, whose own builder sets `blocksMotion=false`; their modern `noCollission()` property produces an empty collision shape and `blocksMotion=false`. The other 229 rows have old motion blocking true and modern state motion blocking true for every valid state. The modern static-collision, force, and cache paths were checked per state family below.

The in-scope direct player path remains `Entity.updateFluidHeightAndDoFluidPushing` → `FluidState.getFlow` → `FlowingFluid.getFlow` → accumulated delta movement (`1.20.4 Entity.java:3037–3084`). The spread path is `FlowingFluid.tick` → `spread` / `spreadToSides` → `canSpreadTo` → `canHoldFluid`; it can affect later player fluid contact, but the 240-row predicate values do not diverge. No valid witness state is established by this closure.

## Exact registration census

The previous string-literal-only count of 991 common IDs omitted six registrations whose first argument became a `ResourceKey<Block>` in 1.20.3. Resolving those keys yields **997 common resource IDs across all six releases**. The targeted set is still exactly 240; the six key-based IDs have direct old `Material.*` expressions and do not change that cohort count.

| Release | Parsed registered block IDs |
| --- | ---: |
| 1.19.4 | 998 |
| 1.20 | 1,003 |
| 1.20.1 | 1,003 |
| 1.20.2 | 1,003 |
| 1.20.3 | 1,058 |
| 1.20.4 | 1,058 |
| All-six intersection | 997 |
| All-six intersection with no `Material.*` token in its 1.19.4 registration expression | 240 |

The all-six intersection is the set intersection of the six parsed registration-ID sets, not an endpoint-only intersection. `grass` is the sole 1.19.4 ID absent from each 1.20+ registration set. Five IDs first appear in 1.20; 56 IDs first appear in 1.20.3. Those one-sided additions are outside the all-six common set.

The six IDs that need key resolution are `attached_melon_stem`, `attached_pumpkin_stem`, `melon`, `melon_stem`, `pumpkin`, and `pumpkin_stem`. Each has one `register(ResourceKey<Block>, ...)` declaration in 1.20.3 `Blocks.java` and one in 1.20.4 `Blocks.java`; each key has one matching `createKey("id")` declaration in `net/minecraft/references/Blocks.java`. Their registration/key lines are respectively:

| ID | Blocks.java registration line (1.20.3 and 1.20.4) | references/Blocks.java key line |
| --- | ---: | ---: |
| `pumpkin` | 2613 | 9 |
| `melon` | 2624 | 12 |
| `attached_pumpkin_stem` | 2628 | 11 |
| `attached_melon_stem` | 2637 | 14 |
| `pumpkin_stem` | 2646 | 10 |
| `melon_stem` | 2661 | 13 |

In 1.19.4 through 1.20.2 these same six IDs each appear once as string-literal block registrations. [registration-roster.tsv](registration-roster.tsv) includes all 240 lineaged rows plus six `ResourceKey-bridge` rows; for each of those six IDs it preserves the registration expression and line in all six releases. The supplemental [resourcekey-bridges.tsv](resourcekey-bridges.tsv) records the exact one-per-ID occurrence counts, key declaration locations, `Blocks.java` and `references/Blocks.java` hashes, and validated release identities for the two keyed versions.

## Complete alias/helper resolution for the 240 rows

The six-version roster is [registration-roster.tsv](registration-roster.tsv). Its 240 `lineaged-no-direct-old-Material` rows are the target cohort; six additional `ResourceKey-bridge` rows document the keyed IDs that correct the common-ID count. [resourcekey-bridges.tsv](resourcekey-bridges.tsv) provides one row per ID per keyed release with occurrence counts and source identity. [material-lineage.tsv](material-lineage.tsv) resolves each target ID to an old material, its `blocksMotion` value, its recursive property-copy/factory path, and the modern property flags/basis for every 1.20 release. [census.py](census.py) regenerates the roster, bridge table, and material lineage from the canonical source trees and checks the exact counts.

Old material resolution found 164 `Properties.copy(parent)` registrations and 76 helper-factory registrations. The copy rows reference 73 distinct immediate parent constants; recursive copy depth is at most four. No old material lineage was unresolved. The helper-factory counts and resolved old material are:

| Old helper | Rows | Resolved old material |
| --- | ---: | --- |
| `bed` | 16 | `WOOL` |
| `log` | 19 | `WOOD` |
| `netherStem` | 4 | `NETHER_WOOD` |
| `stainedGlass` | 16 | `GLASS` |
| `leaves` | 8 | `LEAVES` |
| `woodenButton` | 9 | `DECORATION` |
| `stoneButton` | 2 | `DECORATION` |
| `pistonBase` | 2 | `PISTON` |
| **Total** | **76** | |

The 164 copy-derived rows resolve to 12 material classes: `STONE` 98, `METAL` 31, `WOOD` 29, `CAKE` 17, `GLASS` 17, `WOOL` 16, `DECORATION` 11, `LEAVES` 8, `NETHER_WOOD` 6, `AMETHYST` 3, `DIRT` 2, and `PISTON` 2. The single category with `blocksMotion=false` is `DECORATION` (11 rows); the other 229 use old materials whose builder leaves `blocksMotion=true`. `Material.Builder` defaults the flag to true; `noCollider()` clears it (`1.19.4 Material.java:160–183`; `DECORATION` declaration at line 70). `BlockBehaviour.Properties.noCollission()` is a separate property and does not rewrite a block's `Material` (`1.19.4 BlockBehaviour.java:929–937`).

The modern lineage counts match across all five 1.20 releases:

| Modern gate or geometry path | Rows | Old result | Modern result |
| --- | ---: | ---: | ---: |
| `forceSolidOn` (22 walls, 17 cake/candle-cake IDs, 3 amethyst buds) | 42 | true | true |
| `noCollission()` button helpers (9 wooden, 2 stone) | 11 | false | false |
| Cached collision-shape bounds | 187 | true | true |
| `forceSolidOff` in this property lineage | 0 | — | — |
| `dynamicShape` in this property lineage | 0 | — | — |

The 22 modern wall registrations set `forceSolidOn`. `CAKE` sets it and candle-cake variants inherit it through `ofLegacyCopy`; amethyst buds inherit it from `AMETHYST_CLUSTER`. These flags are copied by the modern legacy-copy factories. The 11 buttons call the `woodenButton`/`stoneButton` factory; the old factory uses `Material.DECORATION`, and the modern factory uses `.noCollission()`. Button `FACE`, `FACING`, and `POWERED` variants change their outline shape, but the no-collision property makes every collision shape empty.

The cached-shape group covers 187 rows in these families: 53 stairs (49 `StairBlock`, 4 weathering-copper stairs), 28 slabs (24 `SlabBlock`, 4 weathering-copper slabs), 23 rotated pillars, 23 generic full/large blocks, 16 beds, 16 stained-glass blocks, 8 leaves blocks, 8 experience-drop ores, 4 weathering-copper full blocks, 2 piston bases, 3 cauldrons, and one each of redstone ore, tinted glass, and mud. State shape cases that change bounds were checked:

- Stairs vary by facing, half, and inner/outer/straight shape; each composed collision shape retains unit-block bounds. Slabs vary by top/bottom/double and waterlogging; a half slab has average bounds size `(1 + 1 + 0.5) / 3 = 5/6`, above the `0.7291666666666666` cutoff.
- Beds vary by facing, part, and occupancy; their collision bounds are 1 × 9/16 × 1, with average size 41/48, above the cutoff. Log axis states and the leaf/stained-glass/tinted-glass states retain full-block collision shapes. `noOcclusion()` does not disable collision; only `noCollission()` clears `hasCollision`.
- Piston bases vary by `EXTENDED` and `FACING`. The unextended state is a cube. Extended horizontal states have bounds 12/16 × 1 × 1; extended vertical states have bounds 1 × 12/16 × 1. Each average is 11/12, above the cutoff.
- Cauldron liquid/content states have collision bounds reaching Y=1, so they pass the full-height clause. The remaining block/ore/weathering-copper full shapes also pass the cutoff.

The 1.20.2 → 1.20.3 collision-geometry source diff was also checked for every cached-shape family. Relevant shape/collision methods and bounds expressions remain the same; the `AmethystClusterBlock` constructor only spells the same numeric bounds with `16.0F` instead of `16`, and the `BlockBehaviour` property-copy implementation was split into `ofLegacyCopy`/`ofFullCopy` while retaining the copied collision and force flags. No state-dependent collision-bounds change was found in the cohort across the six source versions. The census script resolves each registration and property lineage; the shape-family check above bounds the possible cached-shape outcomes by the named vanilla block implementation and its enumerated state dimensions.

In 1.20.4, `BlockStateBase.calculateSolid` checks `forceSolidOn`, then `forceSolidOff`, then null cache/empty collision shape, then accepts bounds with average size at least `0.7291666666666666` **or Y size at least 1** (`BlockBehaviour.java:471–491`). `initCache` leaves the cache null only when `Block.hasDynamicShape()` is true and then calculates the state result (`:493–500`); `blocksMotion()` returns the cached result except for cobweb and bamboo sapling (`:512–515`). The only `hasDynamicShape()` definition is `Block.java:470`, which returns the properties flag; no lineaged row or copy ancestor sets `dynamicShape`. Therefore no unresolved dynamic-shape callback can change this cohort's result. The Y-size clause remains part of the decision; this report does not revive the disproven pane candidate.

## Source identity and hashes

Canonical tree: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`, Mojmap. Exact release identity was checked through ready-marker sidecars for 1.19.4, 1.20.1, 1.20.2, and 1.20.4; 1.20 and 1.20.3 use embedded source manifests. Every selected Java source hash in [source-hashes.tsv](source-hashes.tsv) matches its exact root or embedded source manifest. The provenance digests are:

| Release | Identity evidence |
| --- | --- |
| 1.19.4 | ready marker `versionId=1.19.4`, `mapping=mojmap`; source-manifest SHA-256 `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` |
| 1.20 | embedded provenance SHA-256 `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f`; 4,786 source entries; embedded input is `.../9e7847f933f4e81e45dd1dfb24bab7d4324ca023/1.20.json` (SHA-256 `24f4700f86471b6f3d3e4d68fefcd4177820dade5ce003c095fcf0e429abbc5f`) and client JAR `.../e575a48efda46cf88111ba05b624ef90c520eef1/client.jar` (SHA-256 `5ac9ead135746f5f27048f2e01d8d5bdc2dabc4d91422f73ef2435f4c3d24aff`) |
| 1.20.1 | ready marker `versionId=1.20.1`, `mapping=mojmap`; source-manifest SHA-256 `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` |
| 1.20.2 | ready marker `versionId=1.20.2`, `mapping=mojmap`; source-manifest SHA-256 `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` |
| 1.20.3 | embedded provenance SHA-256 `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f`; 5,048 source entries; embedded input is `.../86c3a686b59ee1bcd70febee4de962ec3e1a5d87/1.20.3.json` (SHA-256 `05e727aac55594b6014e9714ad38fa16af09f075daf5efa0f5743f2453fa8fc2`) and client JAR `.../b178a327a96f2cf1c9f98a45e5588d654a3e4369/client.jar` (SHA-256 `bef21938224902dd925e2d89dcfe1d2540656d4cf7a5abd2b93e0402d135c655`) |
| 1.20.4 | ready marker `versionId=1.20.4`, `mapping=mojmap`; source-manifest SHA-256 `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` |

The hash table records 117 selected source files across the six trees, including every release's `Blocks.java`, `BlockBehaviour.java`, `FlowingFluid.java`, `Entity.java`, the relevant block classes, old `Material.java`, and 1.20.3/1.20.4 `references/Blocks.java`. The reference-file hashes and the `Blocks.java` hashes bind the six ResourceKey bridges above.
