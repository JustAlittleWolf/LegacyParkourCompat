"""Rebuild the bounded common-registration roster from canonical Mojmap sources.

Run from the repository root with Python 3.10+: python <this-file>.
This scanner reads Blocks.java and, only for ResourceKey registrations,
references/Blocks.java; it does not load, mutate, or run Minecraft.
"""

from __future__ import annotations

import pathlib
import re
import hashlib
import json


SOURCE_ROOT = pathlib.Path(r"D:\Javastuff\LegacyParkourCompat\decompiled_minecraft")
OUTPUT = pathlib.Path(".native-source/20261031/1194-1204-pool54/fluid-material-lineage/registration-roster.tsv")
LINEAGE_OUTPUT = pathlib.Path(".native-source/20261031/1194-1204-pool54/fluid-material-lineage/material-lineage.tsv")
BRIDGE_OUTPUT = pathlib.Path(".native-source/20261031/1194-1204-pool54/fluid-material-lineage/resourcekey-bridges.tsv")
VERSIONS = ("1.19.4", "1.20", "1.20.1", "1.20.2", "1.20.3", "1.20.4")
DECLARATION = re.compile(r"public\s+static\s+final\s+Block\s+(\w+)\s*=\s*register\s*\(")
RESOURCE_KEY = re.compile(r"(?:net\.minecraft\.references\.)?Blocks\.(\w+)")
HELPER_MATERIAL = {
    "bed": "WOOL",
    "log": "WOOD",
    "netherStem": "NETHER_WOOD",
    "stainedGlass": "GLASS",
    "leaves": "LEAVES",
    "woodenButton": "DECORATION",
    "stoneButton": "DECORATION",
    "pistonBase": "PISTON",
}
HELPERS = "|".join(HELPER_MATERIAL)
RESOURCE_KEY_BRIDGES = (
    "attached_melon_stem",
    "attached_pumpkin_stem",
    "melon",
    "melon_stem",
    "pumpkin",
    "pumpkin_stem",
)


def registrations(version: str) -> dict[str, tuple[str, int, str]]:
    source = SOURCE_ROOT / version / "mojmap/net/minecraft/world/level/block/Blocks.java"
    text = source.read_text(encoding="utf-8")
    found: dict[str, tuple[str, int, str]] = {}
    for match in DECLARATION.finditer(text):
        pos = match.end()
        depth = 1
        in_string = False
        escaped = False
        while pos < len(text) and depth:
            char = text[pos]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
            elif char == '"':
                in_string = True
            elif char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            pos += 1
        if depth:
            raise ValueError(f"unclosed registration call in {source} at {match.start()}")
        args = text[match.end() : pos - 1]
        resource = re.match(r'\s*"([^"]+)"\s*,', args)
        if resource is not None:
            resource_id = resource.group(1)
        else:
            reference = RESOURCE_KEY.match(args.strip())
            if reference is None:
                raise ValueError(f"unparsed registry ID in {source} at {match.start()}")
            reference_source = SOURCE_ROOT / version / "mojmap/net/minecraft/references/Blocks.java"
            references = reference_source.read_text(encoding="utf-8")
            key = re.search(
                rf"\b{re.escape(reference.group(1))}\s*=\s*createKey\(\"([^\"]+)\"\)", references
            )
            if key is None:
                raise ValueError(f"unresolved resource key {reference.group(1)} in {source} at {match.start()}")
            resource_id = key.group(1)
        if not resource_id:
            raise ValueError(f"unparsed registry ID in {source} at {match.start()}")
        line = text.count("\n", 0, match.start()) + 1
        if resource_id in found:
            raise ValueError(f"duplicate block ID {resource_id} in {source}")
        found[resource_id] = (match.group(1), line, " ".join(args.split()))
    return found


def property_parent(args: str) -> str | None:
    parent = re.search(r"Properties\s*\.\s*(?:copy|ofLegacyCopy|ofFullCopy)\s*\(\s*(\w+)", args)
    if parent is not None:
        return parent.group(1)
    stair = re.search(r"\b(?:legacyStair|stair)\s*\(\s*(\w+)", args)
    return stair.group(1) if stair is not None else None


def old_material(
    block_id: str,
    old: dict[str, tuple[str, int, str]],
    const_to_id: dict[str, str],
    seen: tuple[str, ...] = (),
) -> tuple[str, tuple[str, ...]]:
    if block_id in seen:
        raise ValueError(f"material-copy cycle: {seen + (block_id,)}")
    args = old[block_id][2]
    direct = re.search(r"\bMaterial\.([A-Z_]+)\b", args)
    if direct is not None:
        return direct.group(1), seen + (block_id,)
    parent = property_parent(args)
    if parent is not None:
        parent_id = const_to_id.get(parent)
        if parent_id is None:
            raise ValueError(f"unresolved old copy parent {parent} for {block_id}")
        return old_material(parent_id, old, const_to_id, seen + (block_id,))
    helper = re.search(rf"\b({HELPERS})\s*\(", args)
    if helper is not None:
        return HELPER_MATERIAL[helper.group(1)], seen + (f"{block_id}[factory:{helper.group(1)}]",)
    raise ValueError(f"unresolved old material lineage for {block_id}: {args}")


def modern_flags(
    block_id: str,
    registrations_by_id: dict[str, tuple[str, int, str]],
    const_to_id: dict[str, str],
    seen: tuple[str, ...] = (),
) -> set[str]:
    if block_id in seen:
        raise ValueError(f"modern property-copy cycle: {seen + (block_id,)}")
    args = registrations_by_id[block_id][2]
    flags = {flag for flag in ("forceSolidOn", "forceSolidOff", "noCollission", "dynamicShape") if f"{flag}(" in args}
    parent = property_parent(args)
    if parent is not None:
        parent_id = const_to_id.get(parent)
        if parent_id is None:
            raise ValueError(f"unresolved modern copy parent {parent} for {block_id}")
        flags |= modern_flags(parent_id, registrations_by_id, const_to_id, seen + (block_id,))
    else:
        helper = re.search(rf"\b({HELPERS})\s*\(", args)
        if helper is not None and helper.group(1) in ("woodenButton", "stoneButton"):
            flags.add("noCollission")
    return flags


def modern_property_path(
    block_id: str,
    registrations_by_id: dict[str, tuple[str, int, str]],
    const_to_id: dict[str, str],
    seen: tuple[str, ...] = (),
) -> tuple[str, ...]:
    if block_id in seen:
        raise ValueError(f"modern property-copy cycle: {seen + (block_id,)}")
    args = registrations_by_id[block_id][2]
    parent = property_parent(args)
    if parent is not None:
        parent_id = const_to_id.get(parent)
        if parent_id is None:
            raise ValueError(f"unresolved modern copy parent {parent} for {block_id}")
        marker = " via stair factory" if re.search(r"\b(?:legacyStair|stair)\s*\(", args) else ""
        return (f"{block_id}{marker}",) + modern_property_path(parent_id, registrations_by_id, const_to_id, seen + (block_id,))
    helper = re.search(rf"\b({HELPERS})\s*\(", args)
    if helper is not None:
        return (f"{block_id}[factory:{helper.group(1)}]",)
    return (f"{block_id}[direct properties]",)


def release_identity(version: str) -> str:
    version_root = SOURCE_ROOT / version
    marker = version_root / "mojmap.ready.json"
    if marker.exists():
        ready = json.loads(marker.read_text(encoding="utf-8"))
        if ready.get("versionId") != version or ready.get("mapping") != "mojmap":
            raise ValueError(f"ready-marker identity mismatch for {version}")
        return f"ready:{version}/mojmap manifest={ready['sourceManifestSha256']}"
    embedded_path = version_root / "mojmap/.decompile-provenance.json"
    embedded = json.loads(embedded_path.read_text(encoding="utf-8"))
    package = next(
        (key for key in embedded["inputs"] if key.endswith(f"/{version}.json") and "piston-meta.mojang.com/v1/packages/" in key),
        None,
    )
    client = next(
        (key for key in embedded["inputs"] if key.endswith("/client.jar") and "piston-data.mojang.com" in key),
        None,
    )
    if package is None or client is None:
        raise ValueError(f"embedded exact-release inputs missing for {version}")
    return (
        f"embedded:{version}/mojmap provenance={hashlib.sha256(embedded_path.read_bytes()).hexdigest()} "
        f"package={package} sha256={embedded['inputs'][package]} client={client} sha256={embedded['inputs'][client]}"
    )


def main() -> None:
    by_version = {version: registrations(version) for version in VERSIONS}
    common = set.intersection(*(set(by_version[version]) for version in VERSIONS))
    lineaged = sorted(
        block_id for block_id in common if "Material." not in by_version["1.19.4"][block_id][2]
    )
    counts = {version: len(by_version[version]) for version in VERSIONS}
    if counts != {"1.19.4": 998, "1.20": 1003, "1.20.1": 1003, "1.20.2": 1003, "1.20.3": 1058, "1.20.4": 1058}:
        raise ValueError(f"registration census changed: {counts}")
    if len(common) != 997 or len(lineaged) != 240:
        raise ValueError(f"bounded cohort changed: common={len(common)}, lineaged={len(lineaged)}")

    roster_ids = sorted(set(lineaged) | set(RESOURCE_KEY_BRIDGES))
    if not set(RESOURCE_KEY_BRIDGES) <= common:
        raise ValueError("ResourceKey bridge IDs are not all in the six-version intersection")
    columns = ["row_kind", "resource_id"]
    for version in VERSIONS:
        columns.extend((f"{version}_constant", f"{version}_line", f"{version}_register_args"))
    rows = ["\t".join(columns)]
    for block_id in roster_ids:
        kind = "lineaged-no-direct-old-Material" if block_id in lineaged else "ResourceKey-bridge; direct old Material"
        row = [kind, block_id]
        for version in VERSIONS:
            constant, line, args = by_version[version][block_id]
            row.extend((constant, str(line), args))
        rows.append("\t".join(row))
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text("\n".join(rows) + "\n", encoding="utf-8")
    old = by_version["1.19.4"]
    old_by_constant = {constant: block_id for block_id, (constant, _, _) in old.items()}
    lineage_header = ["resource_id", "old_material", "old_blocksMotion", "old_property_lineage"]
    for version in VERSIONS[1:]:
        lineage_header.extend((f"{version}_modern_property_lineage", f"{version}_modern_property_flags", f"{version}_modern_blocksMotion_basis"))
    lineage_rows = ["\t".join(lineage_header)]
    for block_id in lineaged:
        material, path = old_material(block_id, old, old_by_constant)
        old_motion = "false" if material == "DECORATION" else "true"
        lineage = " -> ".join(path)
        row = [block_id, material, old_motion, lineage]
        for version in VERSIONS[1:]:
            regs = by_version[version]
            by_constant = {constant: current_id for current_id, (constant, _, _) in regs.items()}
            flags = modern_flags(block_id, regs, by_constant)
            property_path = " -> ".join(modern_property_path(block_id, regs, by_constant))
            if "forceSolidOn" in flags:
                basis = "true: forceSolidOn"
            elif "forceSolidOff" in flags:
                basis = "false: forceSolidOff"
            elif "noCollission" in flags:
                basis = "false: noCollission -> empty collision shape"
            elif "dynamicShape" in flags:
                basis = "false: dynamic shape leaves cache null"
            else:
                basis = "true: cached collision bounds; see audit.md geometry-family review"
            row.extend((property_path, ",".join(sorted(flags)) or "none", basis))
        lineage_rows.append("\t".join(row))
    LINEAGE_OUTPUT.write_text("\n".join(lineage_rows) + "\n", encoding="utf-8")
    bridge_header = (
        "version\tresource_id\tregistration_line\tregistration_occurrences\tresource_key_symbol\t"
        "key_declaration_line\tkey_declaration_occurrences\tBlocks.java_sha256\t"
        "references/Blocks.java_sha256\tvalidated_release_identity"
    )
    bridge_rows = [bridge_header]
    for version in ("1.20.3", "1.20.4"):
        blocks_path = SOURCE_ROOT / version / "mojmap/net/minecraft/world/level/block/Blocks.java"
        refs_path = SOURCE_ROOT / version / "mojmap/net/minecraft/references/Blocks.java"
        blocks_text = blocks_path.read_text(encoding="utf-8")
        refs_text = refs_path.read_text(encoding="utf-8")
        for block_id in RESOURCE_KEY_BRIDGES:
            constant, line, args = by_version[version][block_id]
            ref = RESOURCE_KEY.match(args)
            if ref is None:
                raise ValueError(f"{version} {block_id} lacks the expected ResourceKey registration")
            symbol = ref.group(1)
            key_decls = list(re.finditer(rf"\b{re.escape(symbol)}\s*=\s*createKey\(\"{re.escape(block_id)}\"\)", refs_text))
            if len(key_decls) != 1 or len(re.findall(rf"\bregister\s*\(\s*net\.minecraft\.references\.Blocks\.{re.escape(symbol)}\b", blocks_text)) != 1:
                raise ValueError(f"{version} {block_id} ResourceKey occurrence count changed")
            key_line = refs_text.count("\n", 0, key_decls[0].start()) + 1
            blocks_hash = hashlib.sha256(blocks_path.read_bytes()).hexdigest()
            refs_hash = hashlib.sha256(refs_path.read_bytes()).hexdigest()
            bridge_rows.append(
                "\t".join(
                    (
                        version,
                        block_id,
                        str(line),
                        "1",
                        symbol,
                        str(key_line),
                        "1",
                        blocks_hash,
                        refs_hash,
                        release_identity(version),
                    )
                )
            )
    BRIDGE_OUTPUT.write_text("\n".join(bridge_rows) + "\n", encoding="utf-8")
    print(f"registrations={counts}; common={len(common)}; no-direct-old-Material={len(lineaged)}")
    print(f"wrote {len(roster_ids)} registration rows, {len(lineaged)} material lineages, and {len(bridge_rows) - 1} ResourceKey bridge records")


if __name__ == "__main__":
    main()
