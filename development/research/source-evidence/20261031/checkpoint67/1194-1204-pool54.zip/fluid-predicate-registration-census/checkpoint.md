# Bounded census checkpoint — FlowingFluid neighbor predicate

## Exact local inputs and source coverage

The literal canonical source path D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.19.4/mojmap passed Test-Path and Get-Item before analysis. The six-release Mojmap roster, local official version catalog/package SHA-1s, output-root provenance locations, and SHA-256 hashes for FlowingFluid, Blocks, Block, BlockBehaviour, BlockState, and Material are recorded in source-roster.md. The official local version_manifest_v2.json SHA-256 is AC37F92737DF1A9D7660047136FEDD3EDEBD90BD6E552F53DDC3F222079BC8FA. Embedded .decompile-provenance.json is present only in 1.20 and 1.20.3 roots; 1.19.4, 1.20.1, 1.20.2, and 1.20.4 are legacy roots with no local per-release cache sidecars.

Blocks.java declared-field counts: 1.19.4: 998; 1.20/1.20.1/1.20.2: 1003 each; 1.20.3/1.20.4: 1058 each. These counts have not been normalized to the complete common registered-ID intersection.

## Predicate change and negative candidate checks

In 1.19.4 FlowingFluid.getFlow lines 53-66, when a neighbor fluid state affects flow and has own height zero, the below-fluid lookup is gated by !neighborState.getMaterial().blocksMotion(). In 1.20 through 1.20.4 the same branch at lines 54-67 uses !neighborState.blocksMotion(). The predicate cutover is bounded after 1.19.4 and by 1.20; checked endpoint/intermediate bodies use the modern predicate.

The following plausible material/state mismatches were checked and rejected:

- Slabs: old registrations include STONE-material slabs, but modern calculateSolid() tests AABB.getSize() >= 0.7291666666666666 or Y size >= 1.0. AABB.getSize() is the mean of X/Y/Z sizes, so bottom/top slabs with dimensions 1 × 0.5 × 1 have 0.8333 and remain modern solid. Double slabs are solid as well. Not a witness.
- Buttons: 1.19.4 Blocks.java helper registrations use Material.DECORATION, which is old non-blocking (noCollider); modern registration uses noCollission(), yielding empty cached collision and modern non-blocking. Not a mismatch.
- Pressure plates: 1.19.4 stone plate uses Material.STONE (old blocking); 1.20.4 stone plate has noCollission() but also forceSolidOn(). In modern calculateSolid(), force-solid-on wins before cache/empty-shape checks, so modern blocksMotion() is true. Not a mismatch. Wood-family plates similarly require each exact registration force flag checked before making a claim.

Relevant exact 1.20.4 BlockBehaviour.java: calculateSolid lines 471-500; blocksMotion lines 512-515. These branches establish why the slab and pressure-plate guesses fail.

## Result and open gates

No same-ID/state mismatch candidate was fully confirmed in this checkpoint, so there is no valid arrangement/vector effect to report. This does not establish absence across the pair: the complete registered-block-ID intersection was not computed, and the registered state domains were not enumerated.

Remaining precise source inventory: up to 998 old registered Blocks fields and 1058 modern registered fields before matching/exclusion; no normalized intersection-row count is available. Still unclosed are every matching family/state row, the full forceSolidOn/Off caller list, all cached versus no-cache/dynamic-shape classes, collision-shape overrides, copied material-property lineage, reverse-direction mismatches, and exclusions. The method-level cutover is recorded, but registration/state proof across all six sources and full negative closure are not complete. This checkpoint does not freeze the pair.
