# Fixed partial collision shapes: bounded source slice

Scope is limited to two fixed partial shape providers. Sources are the canonical read-only Mojmap trees for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4. This report does not claim overall pair freeze.

## Independent baseline and partition

The initial 1.19.4 source scan found 132 block-source files containing getShape or getCollisionShape references or declarations. This is a provider seed, not closure.

Process note: I opened the permitted fixed-special and state-provider report contents before completing the independent baseline. After the baseline, I rehashed all three permitted reports and reread the current state-provider report, then used them only to partition adjacent assignments. The two candidates here, minecraft:moss_carpet (CarpetBlock) and minecraft:honey_block (HoneyBlock), are absent from the fixed full-cube report and the explicit state/context/dynamic families. Their result below is derived from the exact sources. This lane is not blind to those permitted partitions.

## Source provenance

Each source identity is the SHA-256 of the exact source manifest or embedded provenance record. All 54 target or exploratory source files read for this slice were rehashed against the corresponding source map; every match passed. The per-file hashes are in source-hashes.csv.

| Release | Source identity SHA-256 |
|---|---|
| 1.19.4 | 6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3 |
| 1.20 | 573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f |
| 1.20.1 | 858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465 |
| 1.20.2 | e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887 |
| 1.20.3 | c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f |
| 1.20.4 | fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1 |


Partition-input checksums at the time of final review:

- shape-provider-residual.csv: b5ed33bdbd04f23d79954520c35e8ddc7fc0548fabe1bbfd51288eb9e29af72f
- blocks-motion-fixed-special.md: 5253ecaef6a1ea648fc14e4f1aae8e22a872762079ae487682c52ff5c6f85846
- stateful-provider-review.md: 5e522831d828b62995f50c8df7671b6aa5555df61f992f74bfbc7042cdd64678

The 1.19.4 baseline scan rehashed 397 Java files under net/minecraft/world/level/block/ against the canonical mojmap.sources.sha256; there were zero mismatches. The 1.19.4 source identity is the hash listed above.

## Results

The full release / ID / raw-state table is fixed-partial-state-table.csv (12 rows). Neither class defines state properties; each inherits Block.createBlockStateDefinition, which adds none, so each ID has exactly one valid default raw state. Carpet inherits BlockBehaviour.getCollisionShape: collision is empty only when hasCollision is false, otherwise the provider delegates to the state shape. Honey overrides getCollisionShape with its fixed SHAPE. Neither box depends on state, world, position or CollisionContext.

| ID | Provider | All valid raw states | Collision bounds in all six releases | 1.19.4 material bit | calculateSolid in every 1.20+ release |
|---|---|---|---|---|---|
| minecraft:moss_carpet | CarpetBlock | singleton default state | [0,1] × [0,1/16] × [0,1] | PLANT, false | false: extent average 11/16 = 0.6875, Y size 1/16; neither threshold passes |
| minecraft:honey_block | HoneyBlock | singleton default state | [1/16,15/16] × [0,15/16] × [1/16,15/16] | CLAY, true | true: extent average 43/48 = 0.8958333333333333, above 0.7291666666666666 |

In all five modern releases, both registrations use Properties.of() with collision enabled by default, forceSolidOn=false, forceSolidOff=false and dynamicShape=false. Honey's noOcclusion() changes occlusion only. The static collision caches are present and nonempty, so calculateSolid reaches its bounds test. Its gate order is forceSolidOn, forceSolidOff, absent cache, empty collision shape, then bounds threshold. The method body and cutoff match in 1.20 through 1.20.4. AABB.getSize() is the mean of the three extents. The legacy material bits in the hash-verified residual census are Material.PLANT (false) and Material.CLAY (true) from the 1.19.4 registrations.

The exact source definitions yield the same bounds throughout the six releases: CarpetBlock.SHAPE = Block.box(0,0,0,16,1,16); HoneyBlock.SHAPE = Block.box(1,0,1,15,15,15). Block.box scales coordinates by 1/16. For these two IDs the old blocksMotion bit equals the modern calculateSolid result. This closes only these fixed collision boxes and their cached solidity results, not full-player runtime parity.

## Remaining work and handoff

remaining-unclassified-ids.csv lists every residual ID after removing only these two. It contains 836 IDs and 4,180 modern registration rows. Those IDs are unclassified in this bounded lane and may include state/context/dynamic providers or other fixed partial and directional families. No ambiguity remains inside the two closed rows. Reconcile the adjacent source lanes before any pair freeze.





## Exact source anchors

- 1.19.4: CarpetBlock.SHAPE/getShape, CarpetBlock.java:14,21; HoneyBlock.SHAPE/getCollisionShape, HoneyBlock.java:27,38; registration/materials, Blocks.java:3879,4477; no-property Block state definition, Block.java:428; Block.box scaling, Block.java:140.
- 1.20.4: CarpetBlock.java:16,28; HoneyBlock.java:29,45; registrations, Blocks.java:6584,7397; no-property Block state definition, Block.java:426; Block.box scaling, Block.java:146; collision delegate and calculateSolid, BlockBehaviour.java:334,471.
- The per-file SHA-256 table covers all six exact releases, including each anchor file. Methods in the five modern BlockBehaviour sources were inspected individually; calculateSolid gate order and threshold are identical across 1.20–1.20.4.

