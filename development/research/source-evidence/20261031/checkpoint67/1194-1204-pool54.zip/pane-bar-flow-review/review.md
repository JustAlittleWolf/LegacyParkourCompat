# Independent source review: bars/panes and fluid-flow `blocksMotion`

**Verdict: REJECT.** The proposed 1.19.4→1.20+ change in the `blocksMotion` query is real at the API/call-site level, and the path can reach player movement, but Iron Bars and all Stained Glass Pane states remain `blocksMotion == true` on both sides. An adjacent fluid under either block therefore cannot activate the proposed new flow contribution. The concrete equal-input `getFlow` result is identical; this is not a historical movement finding.

## Exact source identities

Canonical source root (read-only): `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/`, Mojmap for all six exact releases: `1.19.4`, `1.20`, `1.20.1`, `1.20.2`, `1.20.3`, `1.20.4`.

All six source files cited below match their source-manifest or embedded-provenance SHA-256 entries. The four sidecar-backed trees are `1.19.4`, `1.20.1`, `1.20.2`, `1.20.4`; `1.20` and `1.20.3` have legacy `.decompile-provenance.json` embedded source maps, and the cited per-file hashes match those entries. The source identity is sufficient for this bounded read-only comparison; no regeneration was performed.

## Difference and state lineage

- `1.19.4`, `net/minecraft/world/level/material/FlowingFluid.java:53-98`, `getFlow`: when a horizontal neighbor has zero own fluid height, the below-neighbor lookup is gated by `!neighborBlockState.getMaterial().blocksMotion()` (line 65).
- `1.20` through `1.20.4`, same path/member at lines 54-99: that gate calls `!neighborBlockState.blocksMotion()` (line 66). The rest of this `getFlow` procedure is identical for this slice. The lookup could add a horizontal height-difference term if the neighbor state were non-motion-blocking and water existed below it.
- Old `Material.METAL` (Iron Bars) and `Material.GLASS` (Stained Glass Panes) both use the default `Material.Builder.blocksMotion = true`; neither material calls `noCollider()`. `Material.blocksMotion()` returns that stored flag (`1.19.4/net/minecraft/world/level/material/Material.java:108-136, 158-184`). Iron Bars are registered with `Properties.of(Material.METAL, ...)` (`Blocks.java:1489-1497`); each stained pane is registered with `Properties.of(Material.GLASS)...noOcclusion()` (white at `Blocks.java:2047-2049`, same constructor/property pattern for all dye colors). Thus old material result is `true` for all corresponding blocks/states.
- Modern `BlockBehaviour.BlockStateBase.blocksMotion()` returns `isSolid()` except for Cobweb/Bamboo Sapling; `isSolid()` returns cached `legacySolid` (`BlockBehaviour.java`: 1.20-1.20.2 lines 428-476; 1.20.3-1.20.4 lines 471-519). Cache creation computes `legacySolid` from `calculateSolid()`. It is not forcibly disabled here: `noOcclusion()` controls occlusion, while `forceSolidOff` is a distinct early-return gate in `calculateSolid()`.
- Iron Bars and Stained Glass Panes extend `CrossCollisionBlock`. Its collision shape is built from a center post `Block.box(7,0,7,9,16,9)` unioned with up to four directional arms (`CrossCollisionBlock.makeShapes`: 1.19.4–1.20.2 lines 46-85; 1.20.3–1.20.4 lines 50-89); `getCollisionShape` selects only by the four N/E/S/W connection flags (lines 95-108/99-112). The center post exists even when all connections are false and spans the full Y interval 0..16. The cached collision shape therefore always has `bounds().getYsize() == 1.0` for every directional combination. `calculateSolid()` returns true whenever the collision bounds' Y size is at least 1.0 (1.20–1.20.2 lines 428-450; 1.20.3–1.20.4 lines 471-493). Waterlogged is not part of the shape index and does not change that result.
- The block default state has N/E/S/W false and WATERLOGGED false; placement/update set the four connection flags and waterlogged state separately (`IronBarsBlock` constructor, `getStateForPlacement`, `updateShape`, `createBlockStateDefinition`; `StainedGlassPaneBlock` delegates to this state definition and registers the same defaults). I checked every connection variant, not just the all-false default: all retain the full-height center collision post, so modern `blocksMotion()` is true for all 16 directional combinations and both waterlogged values. `Blocks.IRON_BARS` and every colored `*_STAINED_GLASS_PANE` retain the same constructors/property flags from 1.20 through 1.20.4; in 1.20.3, codec additions do not change state shape or registration properties.

## Reachability and equal-input computation

The route is movement-reachable in principle: `LivingEntity` tick calls `updateInWaterStateAndDoWaterCurrentPushing`; `Entity.updateFluidHeightAndDoFluidPushing` queries each intersected water `FluidState.getFlow(...)` and adds its scaled vector to entity delta movement (1.19.4 `Entity.java:1080-1084, 2887-2928`; 1.20.4 `Entity.java:1195-1199, 3037-3078`). `Player.isPushedByFluid()` returns `!abilities.flying` (1.19.4 `Player.java:1848-1849`; 1.20.4 `Player.java:1804-1805`), and player travel delegates to `LivingEntity.travel` (`Player.java:1440-1464` / `1451-1473`).

A naturally realizable test arrangement is a source-water cell at `(0,0,0)`, an unwaterlogged Iron Bars (or Stained Glass Pane) state east at `(1,0,0)`, source water directly below it at `(1,-1,0)`, and a solid support north of the pane at `(1,0,-1)` so it is normally placeable and connected. Its north connection may be true; as shown above, that does not change its full-height collision or `blocksMotion` result. Leave the other horizontal neighbors and their below cells empty. Use the same exact raw states and heights on both sides; the center fluid is non-falling source water (own height 1).

For the east-neighbor branch, both versions see empty fluid at the pane cell, so `$$8 == 0`; old `Material.GLASS/METAL.blocksMotion()` is true and modern pane/bar `BlockState.blocksMotion()` is true. Both skip reading/using the source water below. Every other horizontal neighbor has no fluid below, so all accumulated `$$9` terms remain 0. Both `getFlow` outputs are exactly `Vec3(0.0, 0.0, 0.0)` before and after normalization. If the queried block were actually non-motion-blocking, that arrangement would instead add `1 - (1 - 0.8888889F)` east and normalize to eastward flow, but no valid Iron Bars or Stained Glass Pane state supplies that input. This counterfactual is not evidence for a finding.

## Intermediate cutovers

| Release | `getFlow` gate | State result for every Iron Bars / stained pane variant | Output for the equal-input arrangement |
|---|---|---:|---|
| 1.19.4 | Material `blocksMotion()` | true | `(0,0,0)` |
| 1.20 | BlockState `blocksMotion()` | true | `(0,0,0)` |
| 1.20.1 | BlockState `blocksMotion()` | true | `(0,0,0)` |
| 1.20.2 | BlockState `blocksMotion()` | true | `(0,0,0)` |
| 1.20.3 | BlockState `blocksMotion()` | true | `(0,0,0)` |
| 1.20.4 | BlockState `blocksMotion()` | true | `(0,0,0)` |

No intermediate release yields a changed gate result for these blocks. Therefore there is no applicable 1.19.4→1.20+ movement delta to accept.

## Source SHA-256

Hashes below are exact file hashes verified against the source manifest or embedded source provenance for each listed release. Grouped releases share identical file bytes.

| Source file/member | Release(s) | SHA-256 |
|---|---|---|
| `FlowingFluid.java`, `getFlow` | 1.19.4 | `d84ceb3c0b83da25fb68599e16cc2298106e745a9ef0c9f32f616d097a8ec56c` |
| `FlowingFluid.java`, `getFlow` | 1.20, 1.20.1 | `ba1dff6ccb28b62760c74d66832d8fdbe7a1cdc37b9c5a0ff476bd200215c904` |
| `FlowingFluid.java`, `getFlow` | 1.20.2–1.20.4 | `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb` |
| `BlockBehaviour.java`, `calculateSolid`/`blocksMotion` | 1.19.4 | `517aa4bd9875e9f7b3f5fba472a84e82afd1e11e35d3c83dc2677d8bbeb4997d` |
| `BlockBehaviour.java`, `calculateSolid`/`blocksMotion` | 1.20–1.20.1 | `5f37987191165379c222c412949a0c80a904bf78a453035b1f9d86c6454510fa` |
| `BlockBehaviour.java`, `calculateSolid`/`blocksMotion` | 1.20.2 | `a6d88726ce4642fc0a61f46a01347bb0b74887b61ef55af7e7c76723789a0b57` |
| `BlockBehaviour.java`, `calculateSolid`/`blocksMotion` | 1.20.3–1.20.4 | `6284a7d08a6d0d475cd4fe8aea62b35153ae8fbc0bce5f51788389f679233b54` |
| `CrossCollisionBlock.java`, shape construction/index | 1.19.4–1.20.2 | `de1c71e81995e9d7e66d829904e7aeaf2d15dbc88d30a30c20c6dd384b5a4c79` |
| `CrossCollisionBlock.java`, shape construction/index | 1.20.3–1.20.4 | `60faee3288389c1a82980adc8838a2e29ca14f6cdd09c3781c031d6d82b38e0a` |
| `IronBarsBlock.java`, defaults/placement/properties | 1.19.4–1.20.2 | `422fc9a4125e1d53a001c631c15e45eb5dafdfd0f6c2c41ed31c27ac66f861a4` |
| `IronBarsBlock.java`, defaults/placement/properties | 1.20.3–1.20.4 | `3c7dbb0b6f67e06ef27fad7d9697c58ae12c870d838c039f1e22054e6f042c82` |
| `StainedGlassPaneBlock.java`, defaults/color | 1.19.4–1.20.2 | `50ff551441e265b0cec725e6df4e1fb1b6faa07a4a5188cf1635ac1f38d80462` |
| `StainedGlassPaneBlock.java`, defaults/color | 1.20.3–1.20.4 | `17c9aa18495f34d84c60e313df407f5c920fdd71c56ddc92d125f39d4c677787` |
| `Blocks.java`, registrations | 1.19.4 | `a4f2df87c2cae5a3827a818f39f7ad123ee5b18905ead9947efe654421c30ff5` |
| `Blocks.java`, registrations | 1.20–1.20.1 | `1e7095d1fbfdc8198191f40037997feeca2ec993cc54dd53f2636375cae66b51` |
| `Blocks.java`, registrations | 1.20.2 | `75e8e77adab4a07b02ef95619be83a004f5f79810cf3f07157a713d714881253` |
| `Blocks.java`, registrations | 1.20.3–1.20.4 | `5392c4349317e55c2989865be38c17b94e6e0543e7017e6a2a64d79217e83643` |

Movement-path endpoint file hashes (same read-only source identities): `1.19.4 Entity.java` `3667fee610cbc5f58012e3a8fb8d6c4849f649fb7fe5300595158112d8b4b58b`, `LivingEntity.java` `c8d91af61f87aaa1666de79696d7cd9d4a8212d05f873bdaf28d7bb2926bf165`, `Player.java` `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2`; `1.20.4 Entity.java` `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9`, `LivingEntity.java` `f7bc53db24c1798f19f9bd6f6356c86d5e560e9c8e8aac60decaf15cc785e07d`, `Player.java` `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd`. No finding is recommended, so these are contextual only.




Old Material.java property definitions (GLASS, METAL, default builder flag) SHA-256 for 1.19.4: 842c7ee4723993c6ee3bf4732343f3225bb05aac5ee80c919c34c3ba1a027431.
