# Fixed-default provider reconciliation baseline

Captured before residual classification from the assigned source-only inputs.

## Canonical Mojmap source identities

| Release | Identity | SHA-256 | Source files rehashed |
|---|---|---|---:|
| 1.19.4 | `mojmap.sources.sha256` | `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` | 4,740 |
| 1.20 | `.decompile-provenance.json` | `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` | 4,786 |
| 1.20.1 | `mojmap.sources.sha256` | `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` | 4,786 |
| 1.20.2 | `mojmap.sources.sha256` | `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` | 4,904 |
| 1.20.3 | `.decompile-provenance.json` | `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` | 5,048 |
| 1.20.4 | `mojmap.sources.sha256` | `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` | 5,048 |

All listed file hashes were rechecked from the canonical `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<release>/mojmap` trees using the state-shape provenance verifier. Sidecar and embedded provenance identities matched the recorded hashes.

## Input artifact SHA-256 baseline

- `blocks-motion-state-shapes/fixed-default-provider-handoff.csv`: `a14ec49b4dde151711c74440e508e0ada5410d6f73e4bf444ae23acfa8865ec7`
- `independent-blocks-motion-audit/state-domain-roster.json`: `ce08fad89e0102e58c52628f18302cf2053e2608dee81f8fa6cae124d8b01698`
- `independent-blocks-motion-audit/geometry-residual-matrix.csv`: `70aba17e17b099e86d87b613f225ea10938e08cd0d3deddba7f88bb241528675`
- `blocks-motion-static-shapes/base-block-collision-parity.csv`: `5dd174de3fedf4f44eb691dedc89b576f4fad3d2358c411b7bab36a11af03e52`
- `blocks-motion-fixed-special/fixed-full-cube-parity.csv`: `1dd4a1c2e374c144df0ccbbd7aa9452d216b45cdf0834d59902a589380589799`
- `independent-blocks-motion-audit/source-hashes.json`: `bf825b2d01a199d8a0ca010174204ea2f9680279fc1acda132393972ece45909`
- `independent-blocks-motion-audit/SHA256SUMS.txt`: `dd3ea56b0ffb467ea4e9a860c2745e5c17d5a09f52e3e102b004d0b6cc9db54f`

Baseline cardinalities: handoff 1,835 rows / 367 IDs / five modern releases; base table 795 rows / 159 IDs; special table 580 rows / 116 IDs. This baseline records inputs, not acceptance or pair coverage.

## Erratum: source identity transcription

The original baseline transcription used the incorrect 1.20.1 digest `858b56764113e591c60d9d7b7529fe6ca3848bb06ec238c2ef70ab381022fcc7`. Re-running `verify-source-provenance.ps1` against the canonical trees confirmed the corrected 1.20.1 `mojmap.sources.sha256` identity is `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` (4,786 source files rehashed; `mojmap.ready.json` records the same manifest digest). The corrected digest is used in the table above; the prior transcription is retained here for audit history.

The first correction also retained an extra `4` in the 1.20 digest, transcribed as `573f0bb3e18e39ae882769a007a1c97d711da1230344f9a1c894eb407ef58030f`. Rehashing the embedded `.decompile-provenance.json` confirms the correct digest `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f`, now shown in the table above; this supersedes the prior statement that the baseline value was correct. The same six-release verifier run succeeded for all other sidecar and embedded provenance identities and every listed source file.

