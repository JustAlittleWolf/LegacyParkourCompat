# Fixed-default provider reconciliation (1.19.4→1.20.4 source set)

## Result

All 1,835 fixed-default-provider handoff rows (367 IDs × five modern releases) are closed. Every row has old Material.blocksMotion() == true, modern hasCollision == true, forceSolidOn == false, forceSolidOff == false, dynamicShape == false, and the cached-shape calculation path. The primary-source class chain for each constructor reaches BlockBehaviour without declaring getShape or getCollisionShape; this makes inherited BlockBehaviour.getShape return the same Shapes.block() for every valid state, position, neighbor arrangement, world, and collision context. Its bounds are [0,1] × [0,1] × [0,1]; getSize == 1, so the modern calculateSolid result is true in every row.

The matrix [fixed-default-reconciliation.csv](fixed-default-reconciliation.csv) supplies the per-ID/release result, old and modern registration fields/lines, gates, bounds and prior-closure partition. [class-provider-chains.csv](class-provider-chains.csv) supplies the complete primary-source superclass chain and source file for every constructor/release pair. Its block-class file paths are relative to net/minecraft/world/level/block/; the terminal provider is net/minecraft/world/level/block/state/BlockBehaviour.java. The supplied checksum ledger and all 57 source-file records in source-hashes.json were independently rehashed successfully. The canonical six-release source manifests/provenance have hashes recorded in [baseline.md](baseline.md); every enumerated source file was also rehashed by the published provenance verifier.

## Exact overlap partition

| Partition | Handoff rows | Distinct IDs |
|---|---:|---:|
| Already closed by 159-ID base-Block table | 770 | 154 |
| Already closed by 116-ID special full-cube table | 580 | 116 |
| Closed by this fixed-default residual | 485 | 97 |
| **Total** | **1835** | **367** |

The base-Block table's 159th IDs include five dead coral block registrations not present in the state-shape handoff at any modern release: minecraft:dead_brain_coral_block, minecraft:dead_bubble_coral_block, minecraft:dead_fire_coral_block, minecraft:dead_horn_coral_block, minecraft:dead_tube_coral_block. Those five remain closed by the base-Block result but are outside this handoff partition. Handoff overlap is 154 IDs (770 rows), not 159 IDs.

No fixed-default provider class remains unresolved in this bounded group. This result does not close state/context/dynamic providers, the wider geometry residual inventory, intermediate patch boundaries, full-pair coverage, acceptance, or runtime parity.

## Exact provider and predicate source anchors

Relative paths below are under D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<release>/mojmap/.

| Release | BlockBehaviour.getShape line | BlockBehaviour.getCollisionShape line | BlockStateBase.Cache.calculateSolid line | Shapes.block line | Shapes.BLOCK construction line |
|---|---|---|---|---|
| 1.20 | 285 | 290 | 428 | 42 | 18 |
| 1.20.1 | 285 | 290 | 428 | 42 | 18 |
| 1.20.2 | 285 | 290 | 428 | 42 | 18 |
| 1.20.3 | 329 | 334 | 471 | 42 | 18 |
| 1.20.4 | 329 | 334 | 471 | 42 | 18 |

calculateSolid in 1.20–1.20.4 checks forceSolidOn, forceSolidOff, absent cache, and empty shape before returning bounds.getSize() >= 0.7291666666666666 || bounds.getYsize() >= 1.0. Shapes.block returns BLOCK, initialized from a 1×1×1 discrete voxel shape filled at its only cell and wrapped as CubeVoxelShape, so the unit bounds follow directly. Its complete body and the provider methods were read in each exact release; source identities and Java source hashes are listed in the baseline and source hash ledger.

