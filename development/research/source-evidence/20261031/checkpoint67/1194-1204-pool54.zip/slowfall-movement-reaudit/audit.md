# 1.19.4–1.20.4 fall-distance reset movement re-audit

Verdict: the reported change has a bounded, source-supported in-scope player movement witness for Levitation. The witness requires an effect transition between travel calls; a continuously active Levitation effect in 1.19.4 resets fall distance at the end of each travel call, so it cannot accumulate the required state across ordinary ticks. Pure Slow Falling does not establish this movement witness.

## Scope and evidence identity

Project scope baseline: `README.md`, orchestration workflow, shared discovery workflow, and source discovery workflow. The scope includes player movement and direct player responses/predicates reading vanilla state; damage calculation is excluded. The movement call must be client-authoritative and must not be logical-server physics.

All four exact roots were checked with literal `Test-Path`/`Get-Item`:

- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.19.4/mojmap`
- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20/mojmap`
- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20.3/mojmap`
- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20.4/mojmap`

The 1.19.4 and 1.20.4 roots each have `mojmap.provenance.json` and `mojmap.ready.json` (four endpoint sidecars total). Their ready metadata says exact IDs 1.19.4 and 1.20.4, namespace `mojmap`, source counts 4,740 and 5,048, and client SHA-256 `0e79cf7f07c107e9a1fe22ed703e472372b44149e64114944f0811abbd25f3ec` and `9221ab461a491bf9661cd8e773a5e662aaa43d600fa7970b8c12bbfb0431b838`, respectively. Sidecar file SHA-256 values: 1.19.4 provenance `0efcfc6075852711cff5d62c3177258cba273c206c8a2d2642bdf3487c676b34`, ready `59f59ab516d41eb97e09d63256ee26a68c15102052bf7acafdbd5440b72547d0`; 1.20.4 provenance `10914d9b7b3fc29de066ca24f7d905e4d4f0a451a6c81729a2d1981addfc1385`, ready `6225b97979420cc743c8b7156a0ce512ef27d0dbf48bfffbc40d3e1c8cb044d1`.

With `-Force`, the hidden embedded `.decompile-provenance.json` exists in 1.20 and 1.20.3. Its inputs identify metadata/client versions 1.20 and 1.20.3, respectively. Relevant client.jar hashes are `5ac9ead135746f5f27048f2e01d8d5bdc2dabc4d91422f73ef2435f4c3d24aff` and `bef21938224902dd925e2d89dcfe1d2540656d4cf7a5abd2b93e0402d135c655`; client mapping hashes are `fdd921d6bcc7657850f78514d36bb57af0b8a340786d12c46ec18d9c46c039de` and `ad03c803d866062909dd378ed5f1611687dc0ed0a76cc7fd57e968a99d641e5f`. Embedded source hashes were checked against the actual files.

Actual SHA-256 of the three compared source files, in order `LivingEntity.java`, `Player.java`, `LocalPlayer.java`:

- 1.19.4: `c8d91af61f87aaa1666de79696d7cd9d4a8212d05f873bdaf28d7bb2926bf165`; `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2`; `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58`.
- 1.20: `decf8cd70d194098ad51d0c82e5a0087e0687881e0a2dc66456f2ba6ea76676f`; `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac`; `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2`.
- 1.20.3 and 1.20.4: `f7bc53db24c1798f19f9bd6f6356c86d5e560e9c8e8aac60decaf15cc785e07d`; `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd`; `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` (identical source bytes across those two roots).

## Call order and change

In 1.19.4 `LivingEntity.travel(Vec3)` at lines 1983–2112 handles descending Slow Falling at lines 1986–1990 and resets fall distance there, before ordinary movement. In the ordinary branch it calls `handleRelativeFrictionAndCalculateMovement` at 2092; that helper at 2152–2162 moves with `MoverType.SELF` before returning a `Vec3`. Only after that return does the Levitation branch adjust the returned Y component and reset fall distance at 2093–2096. So the player edge-backoff sees the pre-reset fall distance under Levitation.

In 1.20, the same travel/helper sequence is at `LivingEntity.java` lines 2004–2162 and 2171–2213. The old in-branch reset is gone. `LivingEntity.aiStep()` lines 2590–2604 now resets fall distance for either Slow Falling or Levitation at 2596–2598 before calling `travel` at 2603. 1.20.3 and 1.20.4 preserve this order exactly: `aiStep` lines 2590–2604, reset at 2596–2598; ordinary travel/helper at 2035–2162 and 2202–2213. The 1.20.3 and 1.20.4 three relevant source files are byte-identical.

The move dispatch is reachable dynamically: `LocalPlayer.aiStep()` calls `super.aiStep()` after client input processing (1.19.4 line 795; 1.20+ line 800). `LocalPlayer.isLocalPlayer()` returns true (1.19.4 lines 344–345; 1.20+ lines 346–348); `Entity.isControlledByLocalInstance()` delegates to that result when the controlling passenger is a Player. `LocalPlayer.move()` calls `super.move()` (1.19.4 lines 880–885; 1.20+ lines 871–877). `Entity.move()` calls virtual `maybeBackOffFromEdge` before collision (1.19.4 lines 549–570; 1.20+ lines 593–616); `Player` supplies the relevant override.

`Player.maybeBackOffFromEdge()` (1.19.4 lines 1041–1093; 1.20 lines 1043–1095; 1.20.3/1.20.4 lines 1048–1100) gates on not flying, requested Y `<= 0`, `MoverType.SELF` or `PLAYER`, and `isStayingOnGroundSurface()` (shift). Its `isAboveGround()` predicate is `onGround || (fallDistance < maxUpStep && !noCollision(box.move(0, fallDistance - maxUpStep, 0)))` (1.19.4 lines 1095–1099; 1.20 lines 1097–1101; 1.20.3/1.20.4 lines 1102–1106). The subsequent safety loops reduce horizontal request in 0.05 increments while the box shifted down by `maxUpStep` has no collision.

`handleRelativeFrictionAndCalculateMovement` sends the current velocity to `move(SELF, ...)` first, then returns the post-move velocity; Levitation transforms that returned velocity afterward. The difference is not that the effect’s new vertical velocity is passed to edge-backoff: the critical change is that the `fallDistance` read by the edge predicate is reset before versus after that virtual move.

## Bounded movement witness

Two-tick seam and equal inputs:

1. At the end of client tick N−1, the player is airborne and descending; local movement has accumulated `fallDistance >= maxUpStep`. Levitation is not yet active during tick N−1's `travel`, so its old-path post-move reset does not clear that value.
2. Before tick N's `LocalPlayer.aiStep` reaches `super.aiStep`, Levitation becomes active via a valid client effect update. At tick N start the same valid raw player state is used in both versions: `onGround == false`, not flying, `noPhysics == false`, crouch/shift active, current `deltaMovement.y <= 0`, nonzero horizontal movement, and `fallDistance >= maxUpStep`.
3. Geometry at tick N: the bounding box shifted down by `maxUpStep` collides with the support under the current footprint, but the requested horizontal move carries it beyond the support edge. Choose displacement such that at least one 0.05 backoff step can remove the unsupported portion while the first shifted-box query at the current footprint is colliding. The player is still airborne at the actual box position (so `onGround` stays false).

In 1.19.4, `isAboveGround()` is false because `fallDistance >= maxUpStep`; ordinary movement therefore passes the requested horizontal component through the edge-backoff gate unchanged. In 1.20–1.20.4, `aiStep` sets fall distance to zero first; since `maxUpStep > 0` and the box shifted down by `maxUpStep` intersects the support, `isAboveGround()` is true. The edge-backoff loop trims the horizontal request until the shifted box would collide with support. That changes same-tick player position under identical state and movement input. Later gravity/Levitation Y update and resulting fall-distance damage/other outputs are not the asserted effect; damage calculation, attack, and statistics are excluded.

The required state is narrowly bounded to the stated effect-arrival seam. Without a Levitation transition after a prior tick's travel and before the next travel, the 1.19.4 Levitation path resets fall distance every tick, so this particular witness does not persist. For Slow Falling, its 1.19.4 reset already precedes movement when requested Y is nonpositive; when Y is positive the edge-backoff Y gate fails. Thus the Slow Falling reset relocation alone has no such edge-backoff witness.

No product/wiki/backlog files, implementations, tests, builds, game launches, decompilation, network, or Git operations were used. This is a bounded source result, not whole-pair coverage or runtime parity evidence.
