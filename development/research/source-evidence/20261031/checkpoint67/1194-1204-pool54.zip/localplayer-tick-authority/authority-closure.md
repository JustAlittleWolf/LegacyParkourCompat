# LocalPlayer tick authority residual closure

## Scope and evidence set

Read-only canonical Mojmap trees: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap/` for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4. No wiki, product implementation, sibling native-source output or backlog was read. No decompile, build, test or launch was run.

Exact provenance and LocalPlayer source identity were checked in every tree. The 1.20 and 1.20.3 trees have embedded `.decompile-provenance.json` manifests; their `sources[net/minecraft/client/player/LocalPlayer.java]` hashes match a fresh SHA-256 of that source. The other four versions have root `mojmap.provenance.json`, `mojmap.ready.json` and `mojmap.sources.sha256` sidecars; the ready marker's source-manifest SHA-256 matches the manifest file, and the LocalPlayer entry matches a fresh SHA-256 of the source.

| Release | Mojmap provenance | `LocalPlayer.java` SHA-256 |
| --- | --- | --- |
| 1.19.4 | root sidecars; ready marker versionId 1.19.4, mapping mojmap | `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58` |
| 1.20 | embedded tree manifest | `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2` |
| 1.20.1 | root sidecars; ready marker versionId 1.20.1, mapping mojmap | `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2` |
| 1.20.2 | root sidecars; ready marker versionId 1.20.2, mapping mojmap | `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` |
| 1.20.3 | embedded tree manifest | `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` |
| 1.20.4 | root sidecars; ready marker versionId 1.20.4, mapping mojmap | `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` |

## Authority and reachability

`LocalPlayer` extends `AbstractClientPlayer`, which extends `Player`; `ServerPlayer` separately extends `Player`. Across all six trees, the only call site for the virtual `serverAiStep()` besides override/super declarations is `LivingEntity.aiStep()`. That call is inside the `!isImmobile()` / `isEffectiveAi()` branch. The client LocalPlayer override of `isEffectiveAi()` returns `true` unconditionally. Thus, during its ordinary, non-passenger tick, LocalPlayer.aiStep reaches LocalPlayer.serverAiStep unless dead or sleeping; the `serverAiStep` name does not make this operation server-only.

Client tick route: `Minecraft.tick()` calls `ClientLevel.tickEntities()`; that method calls `tickNonPassenger` for non-passengers, and `tickNonPassenger` invokes the entity's virtual `tick()`. `MultiPlayerGameMode` constructs the local player as `new LocalPlayer(..., ClientLevel, ...)`. The chain is LocalPlayer.tick -> AbstractClientPlayer.tick -> Player.tick -> LivingEntity.tick -> virtual `this.aiStep()` -> LocalPlayer.aiStep -> Player.aiStep -> LivingEntity.aiStep -> virtual `this.serverAiStep()` -> LocalPlayer.serverAiStep. `AbstractClientPlayer.tick()` first snapshots deltaMovement for interpolation, then calls Player.tick; that interpolation snapshot is not a movement input. LocalPlayer.tick() does the simulation in super.tick() before sending movement state in sendPosition(); its passenger branch sends rotation/input and vehicle packets.

Spectator boundary: `Player.tick()` sets `noPhysics` and clears onGround for spectators, but `Player.isImmobile()` only adds sleeping to `LivingEntity.isImmobile()` (which checks dead/dying); spectator mode is not an immobility gate. On-foot spectator LocalPlayer therefore reaches serverAiStep. Within that method, only the extra LocalPlayer copies from input into `xxa`, `zza` and `jumping`, plus view bob updates, are gated by `isControlledCamera()`. Spectator camera targeting may make this false, but it does not prevent the inherited call path.

Logical-server boundary: ServerLevel's non-passenger entity tick invokes virtual `tick()` on server entities. Server players are `ServerPlayer extends Player`, not LocalPlayer; ServerPlayer has no `serverAiStep()` override in these trees. Its LivingEntity.aiStep call therefore dispatches through Player.serverAiStep, whose body calls super, updates swing time and sets yHeadRot. The client-only LocalPlayer override is not on the integrated-server or dedicated-server object hierarchy.

Passenger/vehicle boundary: ClientLevel does not call tick() on passengers. Its passenger walker calls virtual `rideTick()`; LocalPlayer.rideTick calls super.rideTick and forwards directional input to a controlled Boat. Thus a mounted LocalPlayer does not reach LocalPlayer.aiStep/serverAiStep by this tick route. Vehicle motion runs in the vehicle tick path; it is outside this slice. The LocalPlayer riding input forwarding is a separate direct player response.

Attack/damage boundary: LocalPlayer.serverAiStep has no attack or damage calls. Its super chain in Player.serverAiStep only updates swing animation timing and yHeadRot. Attack initiation is a separate MultiPlayerGameMode action path; damage resolution is outside this tick method and outside the assigned movement slice. `Mob.serverAiStep()` is a separate final override in the Mob hierarchy and is not an ancestor/caller override for Player or LocalPlayer.

## Adjacent movement entry and deltas

The LocalPlayer.serverAiStep body is byte-identical across all six releases (extracted-body SHA-256 `37dbe9a94f0d54e3ca49e8f43e244a91be243b88f771955bf420b671a65ad8db`). It first calls `super.serverAiStep()`, then, only when the local player is the current camera entity, copies `input.leftImpulse`, `input.forwardImpulse`, and `input.jumping` into `xxa`, `zza`, and `jumping`, and updates the previous/current view bob fields. `isControlledCamera()` is the unchanged identity check `minecraft.getCameraEntity() == this`. No independent delta exists in this method or its camera predicate.

LocalPlayer.tick() has the same gates and order in all versions: require the current chunk, call `super.tick()`, then either run passenger packet handling or `sendPosition()`, followed by ambient-sound ticks. Its only source-level differences from 1.19.4 to 1.20 are renamed level/onGround accessors; 1.20 through 1.20.4 bodies match exactly. These are source/API spelling changes, not a changed tick authority or order.

Adjacent LocalPlayer.aiStep() differs at two cuts:

- 1.19.4 -> 1.20: `handleNetherPortalClient()` becomes guarded by `!(minecraft.screen instanceof ReceivingLevelScreen)`; no movement state write in that guard changes. Other differences in this method at this cut are accessor spelling.
- 1.20 -> 1.20.1: body identical.
- 1.20.1 -> 1.20.2: crouching computation adds `!isPassenger()` and replaces `canEnterPose(CROUCHING/STANDING)` with `canPlayerFitWithinBlocksAndEntitiesWhen(CROUCHING/STANDING)`. The new Player predicate builds the candidate pose bounding box from player dimensions at current position and asks `level.noCollision`; the former Entity predicate used `getBoundingBoxForPose` and the same noCollision query. This is a source-level rewrite, but it has no reachable local-player movement difference in this tick path: ClientLevel ticks passengers only through rideTick, so `!isPassenger()` is true whenever LocalPlayer.aiStep runs; the old `canEnterPose` and new Player fit predicate build the same pose AABB and issue the same `noCollision` query (1.20.1 Entity.java 2731-2736; 1.20.2 EntityDimensions.java 17-25; Player.java 403-405).
- 1.20.2 -> 1.20.3 -> 1.20.4: body identical.

The crouching field write is consumed immediately by LocalPlayer.isCrouching()/isMovingSlowly(); `input.tick(isMovingSlowly(), ...)` updates input impulses before the parent AI path. Later in the normal tick, Player.updatePlayerPose() calls setPose based on shift, vehicle, swim/fall states and pose fit. No trajectory effect is asserted here.

Movement-state path from serverAiStep: on the non-passenger route, `xxa`/`zza`/`jumping` feed the remaining LivingEntity.aiStep jump and travel operations. That method damps impulses, evaluates jumping, constructs the travel vector and invokes virtual `travel`. Player.travel delegates to LivingEntity.travel (with player swimming/flying handling); its on-foot branches use `moveRelative` and `move`. LocalPlayer overrides `move` only to call super then update auto-jump. Entity.move performs collision resolution, setPos and velocity clipping, making those the terminal position/velocity writer dependencies. This assignment did not compare those broader collision/travel operations for all six releases; they remain separate movement slices for the pool to cover.

## Coverage conclusion

Closed for `LocalPlayer.serverAiStep`, its camera predicate, and virtual authority/reachability classification across 1.19.4 -> 1.20 -> 1.20.1 -> 1.20.2 -> 1.20.3 -> 1.20.4. No serverAiStep finding. The adjacent LocalPlayer.aiStep has a source-level crouch-eligibility rewrite at 1.20.1 -> 1.20.2, but it is semantically equal on its reachable local-player tick path for the reasons above. Other travel, collision, pose implementation and direct-response operations are not closed by this note.

## Source anchors

All paths below are relative to `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap/`.

- 1.19.4 `net/minecraft/client/player/LocalPlayer.java`: `tick()` 187-205; `isEffectiveAi()` 486-488; `serverAiStep()` 609-620; `isControlledCamera()` 622-624; `aiStep()` 645-800; `rideTick()` 855-862; `move()` 880-885.
- 1.20 `net/minecraft/client/player/LocalPlayer.java`: `tick()` 189-207; `serverAiStep()` 612-623; `isControlledCamera()` 625-627; `aiStep()` 648-806; `rideTick()` 847-854; `move()` 872-877.
- 1.20.1 `net/minecraft/client/player/LocalPlayer.java`: same method lines as 1.20; `aiStep()` crouch block 657-665.
- 1.20.2 `net/minecraft/client/player/LocalPlayer.java`: `tick()` 188-206; `isEffectiveAi()` 487-489; `serverAiStep()` 610-621; `isControlledCamera()` 623-625; `aiStep()` crouch block 655-664; `rideTick()` 846-853; `move()` 871-876.
- 1.20.4 `net/minecraft/client/player/LocalPlayer.java`: same relevant method lines as 1.20.2; `aiStep()` crouch block 655-664.
- Representative call/override chain in 1.20.4: `net/minecraft/client/player/LocalPlayer.java` extends AbstractClientPlayer and `net/minecraft/client/player/AbstractClientPlayer.java` extends Player; AbstractClientPlayer.tick() 54-57 snapshots delta movement then calls super. `net/minecraft/world/entity/LivingEntity.java` `tick()` 2269-2310 and `aiStep()` 2511-2559 (virtual `serverAiStep()` call at 2557), empty `serverAiStep()` 2668-2669, `travel()` 2035-2167; `net/minecraft/world/entity/player/Player.java` `tick()` 224-295, `serverAiStep()` 499-502, `aiStep()` 506-523, `isImmobile()` 1038-1040, `travel()` 1451-1473, `updatePlayerPose()` 373-405; `net/minecraft/world/entity/Entity.java` `isControlledByLocalInstance()` 2945-2947, `isEffectiveAi()` 2949-2951, `move()` 596 onward; `net/minecraft/client/multiplayer/ClientLevel.java` `tickEntities()`/`tickNonPassenger()`/`tickPassenger()` 250-290; `net/minecraft/server/level/ServerPlayer.java` declaration at 155; `net/minecraft/server/level/ServerLevel.java` `tickNonPassenger()`/`tickPassenger()` 723-750. Corresponding control flow and override bodies were spot-checked in 1.19.4; serverAiStep references/overrides and LocalPlayer bodies were enumerated in all six release trees.
- Pose dependency pair: 1.20.1 `net/minecraft/world/entity/Entity.java` `canEnterPose()` 1891-1893 and `net/minecraft/world/entity/player/Player.java` `updatePlayerPose()` 372-400; 1.20.2 `net/minecraft/world/entity/player/Player.java` `updatePlayerPose()` 373-401 and `canPlayerFitWithinBlocksAndEntitiesWhen()` 403-405.





## Erratum E1 — passenger tick dispatch

**Hash binding:** This erratum supersedes the passenger exclusion and the derived “semantically equal” crouching conclusion in the report revision with SHA-256 `6292f266ff8a83c5440288ac3a33f1e2cc2da19d50b941d2a8111b2d0e183d43`. The earlier statement that a mounted LocalPlayer does not reach `LocalPlayer.aiStep()` or `LocalPlayer.serverAiStep()` is withdrawn.

**Corrected source call chain, present in each of 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4:** `ClientLevel.tickPassenger` invokes the passenger's virtual `rideTick()`. `LocalPlayer.rideTick()` calls `super.rideTick()`; on the client, `Player.rideTick()` takes its `else` branch and calls `LivingEntity.rideTick()`; that calls `Entity.rideTick()`. `Entity.rideTick()` first sets delta movement to zero, then calls virtual `this.tick()`. That dispatches to `LocalPlayer.tick()`, which calls `AbstractClientPlayer.tick()` -> `Player.tick()` -> `LivingEntity.tick()`; `LivingEntity.tick()` calls virtual `this.aiStep()`, dispatching to `LocalPlayer.aiStep()` -> `Player.aiStep()` -> `LivingEntity.aiStep()`. The latter reaches virtual `this.serverAiStep()` and dispatches to `LocalPlayer.serverAiStep()` unless the player is dead or sleeping. After the nested tick returns, Entity.rideTick positions the passenger on its vehicle; control then unwinds through LivingEntity.rideTick, Player.rideTick and LocalPlayer.rideTick.

The decompiled bodies are stable for the parts establishing this route: `ClientLevel.tickPassenger` body SHA-256 `8250cf8d8dfa8f578c8ce4339817adefb382c067a0479de83d794a8bfcf4bbed` in all six; `LocalPlayer.rideTick` `943eb94aa0f39ecedb59f5f092b87472e67d9602ca8bf8a69b5ff598f366e179` in all six; `LivingEntity.rideTick` `628ff1f01f6b47974ced0040c332a996ca7dc392df15ec98530232fd8ac51afe` in all six; and `Entity.rideTick` `43517964ced514b86e5ad8ea85c0b1328eb7aaa9786e6ae10aed367795c1b75f` in all six. `Player.rideTick` has release-specific bodies (1.19.4 `d590c0aa363edb382883ead3a0778a163ecebe12a578f9e8dfe10efb25c2f042`; 1.20 through 1.20.2 `3b09c8a4dd4ea86d47ddbf63c06238edad5764640b8b471f6963332f3423a546`; 1.20.3 and 1.20.4 `ca512663ac1c4a7db7b32d657a91116ed04d3eb0f6cb2dbd1beeb4942e5f95f1`). The exact 1.20.3 Player rideTick simplification removes riding-stat collection; it does not alter the virtual tick call.

**Crouching gate disposition:** `LocalPlayer.aiStep()` is reached while the LocalPlayer is a passenger through this route. Therefore the new `!this.isPassenger()` condition at 1.20.2 is not constant true. Although the old pose-fit and new player-fit helpers produce the same candidate pose AABB for the inspected releases, the additional passenger predicate changes whether the `crouching` field is set. That field feeds `isCrouching()` -> `isMovingSlowly()` -> `input.tick(...)`; later in the same nested tick, LocalPlayer.serverAiStep copies the resulting input impulses to `xxa`/`zza`, and LocalPlayer.tick's passenger branch sends those impulses plus jumping/shift state in `ServerboundPlayerInputPacket`. When the controlled vehicle is a Boat, LocalPlayer.rideTick, after its super call returns, forwards `input.left/right/up/down` to Boat.setInput. Preserve the 1.20.1 -> 1.20.2 gate as potentially movement-relevant until these crouch/input consumers and packet/vehicle semantics are reconciled; no trajectory outcome is asserted.

**Scope boundary:** Boat/entity physics continues through the vehicle's own tick and is excluded non-player physics. The LocalPlayer-side crouch/input write and passenger packet/boat-input forwarding are direct player responses and cannot be excluded merely because the tick began as a passenger. The parent remains responsible for deciding whether this belongs to a separate accepted movement finding after the input consumers are closed.

**Corrected coverage conclusion:** `LocalPlayer.serverAiStep` and `isControlledCamera()` remain identical across the six releases. Its authority applies both to the ordinary non-passenger tick and to the nested passenger tick reached via `Entity.rideTick()`. The 1.20.1 -> 1.20.2 LocalPlayer.aiStep crouch gate remains open as a reachable source difference; it is not semantically closed by pose-AABB equivalence alone.

**Additional source anchors:**
- 1.19.4: `net/minecraft/client/multiplayer/ClientLevel.java` `tickPassenger()` 269-280; `net/minecraft/client/player/LocalPlayer.java` `tick()` 187-205 and `rideTick()` 855-862; `net/minecraft/world/entity/player/Player.java` `rideTick()` 476-489; `net/minecraft/world/entity/LivingEntity.java` `rideTick()` 2690-2695; `net/minecraft/world/entity/Entity.java` `rideTick()` 1714-1720.
- 1.20.4: `net/minecraft/client/multiplayer/ClientLevel.java` `tickPassenger()` 279-290; `net/minecraft/client/player/LocalPlayer.java` `tick()` 188-206 and `rideTick()` 846-853; `net/minecraft/world/entity/player/Player.java` `rideTick()` 487-496; `net/minecraft/world/entity/LivingEntity.java` `rideTick()` 2741-2746; `net/minecraft/world/entity/Entity.java` `rideTick()` 1828-1834.

**Attack/damage call evidence:** In both 1.19.4 and 1.20.4, `Player.serverAiStep()` only calls its super, `updateSwingTime()` and assigns `yHeadRot`; `LocalPlayer.serverAiStep()` only delegates to that and handles the camera/input fields above. The actual local attack action is dispatched from `Minecraft` input handling (`Minecraft.java` 1601 in 1.19.4; 1689 in 1.20.4) to `MultiPlayerGameMode.attack(Player, Entity)` (`MultiPlayerGameMode.java` 385 and 379 respectively), then the Player attack method is separate (`Player.java` 1101 and 1108). This is independent of the tick override chain and excluded attack/damage operation.
