# Independent residual source audit: 1.19.4 → 1.20.4

## Result

Local slice complete for the sampled ordinary player movement/input path and the support-query dependency noted below. No new eligible source-backed movement delta was confirmed in this slice. This is **not** pair freeze: direct block responses, historical collision-shape providers and their contextual dependencies remain open across the pair.

## Source identity

Canonical read-only root: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`; mapping family: Mojmap. Release order checked: 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, 1.20.4. Four releases have root source manifests; their SHA-256 values are below. The 1.20 and 1.20.3 trees instead contain hidden `mojmap/.decompile-provenance.json` embedded source maps; their sidecar SHA-256 values are included. Checked the sampled Java file hashes against each root source manifest or embedded source map. The 1.20 embedded-provenance limitation remains as stated in the permitted 1.19.4→1.20.1 support-query closure.

| Release | Source identity SHA-256 | Type |
|---|---|---|
| 1.19.4 | `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` | `mojmap.sources.sha256` |
| 1.20 | `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` | hidden `mojmap/.decompile-provenance.json` |
| 1.20.1 | `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` | `mojmap.sources.sha256` |
| 1.20.2 | `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` | `mojmap.sources.sha256` |
| 1.20.3 | `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` | hidden `mojmap/.decompile-provenance.json` |
| 1.20.4 | `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` | `mojmap.sources.sha256` |

Sampled full-file SHA-256 (identical values are grouped by release):

| Source file | Releases : SHA-256 |
|---|---|
| `net/minecraft/client/player/LocalPlayer.java` | 1.19.4: `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58`; 1.20/1.20.1: `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2`; 1.20.2–1.20.4: `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5` |
| `net/minecraft/world/entity/player/Player.java` | 1.19.4: `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2`; 1.20/1.20.1: `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac`; 1.20.2: `25f263692fd6b2a737aa813315022a0caf4e18c3661ba3bd706c6297f909f25c`; 1.20.3/1.20.4: `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd` |
| `net/minecraft/client/player/KeyboardInput.java` | 1.19.4–1.20.4: `a8064906872955a3520398ab5b2a326552d424f41887d1294aa6a038e2623ff0` (byte-identical; input scaling body unchanged); source is reachable at `KeyboardInput.tick`, lines 21–36. |

## Audited paths and comparisons

- **Input and crouch slowdown:** `LocalPlayer.aiStep` computes `crouching`, then calls `input.tick(isMovingSlowly(), sneakSpeed)`; `isMovingSlowly()` returns `isCrouching() || isVisuallyCrawling()`; the local `KeyboardInput.tick` scales both impulses by the passed factor when true. Relevant locations: 1.19.4 `LocalPlayer.java:645–665`, `:600–608`; 1.20/1.20.1 `:648–665`, `:603–611`; 1.20.2–1.20.4 `:646–665`, `:601–609`; `KeyboardInput.java:21–36` on all six.
- **1.20.2 crouch-predicate candidate (resolved; no finding):** 1.20.2 adds `!isPassenger()` and replaces `canEnterPose(Pose.CROUCHING/STANDING)` with `canPlayerFitWithinBlocksAndEntitiesWhen(...)` in the `LocalPlayer.aiStep` assignment (`1.20.1:660–663`; `1.20.2:658–662`; retained through 1.20.4). For ordinary non-passenger movement, the predicates use the same `level.noCollision(this, pose AABB deflated by 1.0E-7)`: `Entity.canEnterPose` calls `getBoundingBoxForPose`, which uses the requested dimensions at the entity's feet-centered position (`1.20.1 Entity.java:1891–1892, 2731–2737`); the player helper builds the same box using `getDimensions(pose).makeBoundingBox(position())` (`1.20.2 Player.java:403–404`). The added passenger guard is reached only while riding; passenger/vehicle movement is excluded from this ordinary movement slice. Though the assignment feeds the slowdown path, the eligible non-passenger predicate/math is unchanged.
- **Player pose:** the 1.20.2 `Player.updatePlayerPose` uses the corresponding player-fit helper in place of `canEnterPose` (`1.20.1 Player.java:372–399`, 1.20.2 `:373–404`); inspected helper/AABB construction above. No distinct ordinary player pose/collision delta was established here.
- **1.20.3 travel candidate (excluded):** `Player.travel` retains swimming adjustment and flight adjustment with the same order/constants, but drops pre/post-position snapshots and the trailing `checkMovementStatistics(...)` call between 1.20.2 (`Player.java:1450–1478`) and 1.20.3 (`:1451–1472`); 1.20.4 matches 1.20.3. The removed method awards distance stats and produces movement exhaustion/food changes. Statistics and food production are explicitly outside the assigned movement scope; no movement-state write was removed.
- **Support query dependency:** the 1.19.4→1.20 `Entity.move`/support-selection redesign and its `CollisionGetter`/`BlockCollisions` trace are already treated in the permitted `support-query-closure.md` (including its bounded FarmBlock disposition). I did not create a duplicate finding. That closure explicitly leaves shape-provider and other collision dependencies open.
- **Intermediate continuity:** `LocalPlayer.java` hashes match across 1.20/1.20.1 and 1.20.2/1.20.3/1.20.4; `Player.java` matches 1.20/1.20.1 and 1.20.3/1.20.4. The checked `Input.java` is byte-identical across all six. This supplements, but does not replace, method-level review of other movement and collision sources.

## Coverage state and open dependencies

Examined ordinary tick/input path slices in `LocalPlayer`, `KeyboardInput`, `Player`, and the cited `Entity` pose predicate, plus the previously traced support-selector dependency in `Entity`, `CollisionGetter`, and `BlockCollisions`. This is residual sampling, not a complete reachable-tick inventory. Still unexamined or only partially examined: remaining `LivingEntity`/`Entity` travel and movement writers/consumers; all collision-context and fluid interactions; all block collision/support shape providers, neighboring-state/tag/registration dependencies; direct block and external-event player responses; and exact replacement/absence checks for those slices in every intermediate release. Pair freeze remains open pending full inventory and independent coverage audit.

No product sources, tests, builds, game sessions, decompilation, network or Git writes were used.

