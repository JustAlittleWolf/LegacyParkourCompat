$root='D:\Javastuff\LegacyParkourCompat\decompiled_minecraft'
$versions=@('1.19.4','1.20','1.20.1','1.20.2','1.20.3','1.20.4')
$names='getShape|getCollisionShape|getInteractionShape|getOcclusionShape|getVisualShape|getBlockSupportShape|getFaceOcclusionShape|getEntityInsideCollisionShape|isCollisionShapeFullBlock|isFaceSturdy|isPathfindable|skipRendering|useShapeForLightOcclusion|propagatesSkylightDown|isSolidRender|canOcclude|updateShape|updateIndirectNeighbourShapes|updateFromNeighbourShapes|getStateForPlacement|createBlockStateDefinition|rotate|mirror|neighborChanged|onPlace|onRemove|setPlacedBy'
$pattern='(?m)^\s*(?:public|protected)\s+[^;{}\r\n]+?\b(?<name>'+ $names +')\s*\([^;{}\r\n]*?\)\s*(?:throws [^{]+)?\{'
function Get-ShapeMethods([string]$version){
  $base=Join-Path (Join-Path (Join-Path $root $version) 'mojmap') 'net/minecraft/world/level/block'
  $files=@(Get-ChildItem -LiteralPath $base -Recurse -File -Filter '*.java')
  $dict=@{}
  foreach($file in $files){
    $text=[IO.File]::ReadAllText($file.FullName)
    foreach($m in [regex]::Matches($text,$pattern)){
      $open=$text.IndexOf('{',$m.Index); $depth=0; $end=-1
      for($i=$open;$i -lt $text.Length;$i++){ if($text[$i] -eq '{'){$depth++} elseif($text[$i] -eq '}'){$depth--;if($depth -eq 0){$end=$i+1;break}} }
      if($end -lt 0){continue}
      $rel=$file.FullName.Substring($base.Length+1).Replace('\','/')
      $sig=$text.Substring($m.Index,$open-$m.Index).Trim() -replace '\$\$\d+[A-Za-z]?','$$'
      $sig=$sig -replace '\s+',' '
      $key="$rel|$($m.Groups['name'].Value)|$sig"
      $body=$text.Substring($m.Index,$end-$m.Index) -replace '\$\$\d+[A-Za-z]?','$$' -replace '\s+',' '
      $dict[$key]=$body
    }
  }
  return $dict
}
$all=@{}
foreach($v in $versions){$all[$v]=Get-ShapeMethods $v; Write-Output "$v methods=$($all[$v].Count) files=$(($all[$v].Keys | ForEach-Object {($_ -split '\|')[0]} | Sort-Object -Unique).Count)"}
for($j=0;$j -lt $versions.Length-1;$j++){
  $a=$versions[$j];$b=$versions[$j+1];$da=$all[$a];$db=$all[$b]
  $keysA=@($da.Keys);$keysB=@($db.Keys);$both=@($keysA | Where-Object {$db.ContainsKey($_)});$changed=@($both | Where-Object {$da[$_] -cne $db[$_]});$removed=@($keysA | Where-Object {!$db.ContainsKey($_)});$added=@($keysB | Where-Object {!$da.ContainsKey($_)})
  Write-Output "`n$a=>$b common=$($both.Count) changed=$($changed.Count) removed=$($removed.Count) added=$($added.Count)"
  foreach($k in $changed){Write-Output "CHG $k"};foreach($k in $removed){Write-Output "OLD $k"};foreach($k in $added){Write-Output "NEW $k"}
}


