$root = 'D:\Javastuff\LegacyParkourCompat\decompiled_minecraft'
$versions = @('1.19.4', '1.20', '1.20.1', '1.20.2', '1.20.3', '1.20.4')
$methodPattern = '(?m)^\s*(?:public|protected|private)\s+(?:static\s+)?(?:final\s+)?(?<returnType>VoxelShape(?:\[\])?)\s+(?<name>[A-Za-z_$][\w$]*)\s*\([^;{}\r\n]*?\)\s*(?:throws [^{]+)?\{'
function Get-ShapeMethods([string]$version) {
    $base = Join-Path (Join-Path (Join-Path $root $version) 'mojmap') 'net/minecraft/world/level/block'
    $methods = @{}
    foreach ($file in Get-ChildItem -LiteralPath $base -Recurse -File -Filter '*.java') {
        $source = [IO.File]::ReadAllText($file.FullName)
        foreach ($match in [regex]::Matches($source, $methodPattern)) {
            $open = $source.IndexOf('{', $match.Index)
            $depth = 0
            for ($i = $open; $i -lt $source.Length; $i++) {
                if ($source[$i] -eq '{') { $depth++ }
                elseif ($source[$i] -eq '}') { $depth--; if ($depth -eq 0) { $end = $i + 1; break } }
            }
            if (-not $end) { continue }
            $relative = $file.FullName.Substring($base.Length + 1).Replace('\', '/')
            $signature = ($source.Substring($match.Index, $open - $match.Index) -replace '\$\$\d+[A-Za-z]?', '$$' -replace '\s+', ' ').Trim()
            $key = "$relative|$($match.Groups['name'].Value)|$signature"
            $body = $source.Substring($match.Index, $end - $match.Index) -replace '\$\$\d+[A-Za-z]?', '$$' -replace '\s+', ' '
            $methods[$key] = $body
            Remove-Variable end -ErrorAction SilentlyContinue
        }
    }
    return $methods
}
$all = @{}
foreach ($version in $versions) { $all[$version] = Get-ShapeMethods $version; Write-Output "$version VoxelShape methods=$($all[$version].Count)" }
for ($i = 0; $i -lt $versions.Length - 1; $i++) {
    $before = $all[$versions[$i]]; $after = $all[$versions[$i + 1]]
    $common = @($before.Keys | Where-Object { $after.ContainsKey($_) })
    $changed = @($common | Where-Object { $before[$_] -cne $after[$_] })
    $removed = @($before.Keys | Where-Object { -not $after.ContainsKey($_) })
    $added = @($after.Keys | Where-Object { -not $before.ContainsKey($_) })
    Write-Output "`n$($versions[$i])=>$($versions[$i + 1]) common=$($common.Count) changed=$($changed.Count) removed=$($removed.Count) added=$($added.Count)"
    foreach ($key in $changed) { Write-Output "CHG $key" }
    foreach ($key in $removed) { Write-Output "OLD $key" }
    foreach ($key in $added) { Write-Output "NEW $key" }
}
