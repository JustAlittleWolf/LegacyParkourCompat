# 1.19.4→1.20.4 block shape and state census

## Scope and source identity

Read-only Mojmap sources at `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`, in release order 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, 1.20.4. The 1.19.4, 1.20.1, 1.20.2, and 1.20.4 root ready/provenance sidecars identify the matching release and Mojmap namespace; every source file hash matched its manifest (4,740; 4,786; 4,904; 5,048 files). 1.20 and 1.20.3 have no root sidecars; their embedded `.decompile-provenance.json` identifies the client jar and Mojmap mapping objects for the exact releases, with 4,786 and 5,048 source-file hashes checked. Thus 1.20/1.20.3 provenance is embedded-only.

Census artifacts in this lane:

- `enumerate-shape-provider-methods.ps1`: 847, 862, 862, 871, 887, 887 public/protected provider and state/neighbor methods across 206, 209, 209, 209, 213, 213 block source files.
- `enumerate-all-shape-methods.ps1`: 198, 201, 201, 202, 202, 202 `VoxelShape` methods in the block tree, including private helpers.
- `enumerate-shape-state-fields.ps1`: 657, 669, 669, 672, 671, 678 static shape/property fields.
- `enumerate-block-registrations.ps1`: direct `Blocks.java` registrations and collision/occlusion/solidity flags; 998, 1003, 1003, 1003, 1058, 1058 registrations.

The scripts normalize decompiler synthetic parameter names and whitespace, then compare each adjacent pair. I also inspected the root `BlockBehaviour` state wrappers and defaults separately: all 29 shape/accessor/sturdiness methods compared identical in all five adjacent transitions. Text extraction is a census aid; it is not a Java parser and does not replace review of the candidates below. Registration expressions routed through helper factories are not fully expanded by the registration script.

Exact no-diff accessor groups in `BlockBehaviour`/its state implementation include block-level `getOcclusionShape`, `getBlockSupportShape`, `getInteractionShape`, `getShape`, `getCollisionShape`, `isCollisionShapeFullBlock`, `isOcclusionShapeFullBlock`, and `getVisualShape`, plus state-level `isSolidRender`, `canOcclude`, shape/collision/support/visual/interaction accessors, and both `isFaceSturdy` overloads. Same-version sets checked at the candidate classes are Door `{HALF,FACING,OPEN,HINGE,POWERED}`, Repeater `{FACING,DELAY,LOCKED,POWERED}`, Comparator `{FACING,MODE,POWERED}`, and RedStoneWire `{NORTH,EAST,SOUTH,WEST,POWER}`. Crop age-to-shape tables are unchanged. Barrier alone adds `WATERLOGGED`; skull classes add `POWERED` in 1.20.2, but the new properties do not alter their fixed-state collision shape. Dynamic state sets and shape provider methods were scanned across all block-tree classes, not only this shortlist.

## Player-path trace

`Entity.collide` gathers `CollisionGetter.getBlockCollisions`; that enumerator asks each block state for `getCollisionShape` with the entity collision context. `BlockBehaviour.getCollisionShape` gates the state shape with `hasCollision`. `DiodeBlock.getShape` returns the constant 16×2×16 plate, and repeater/comparator registrations do not set no-collision, so their shape is on the player movement collision path.

Support search in the allowed `support-query-closure.md` uses collision-shape intersections and does not call `getBlockSupportShape`, `SupportType`, `isFaceSturdy`, or solid predicates to select the player’s supporting block. Across the six sources, `getBlockSupportShape` call sites outside wrappers are block/support-placement logic; `Entity` collision/support search uses collision shapes. Therefore Chorus Flower’s new support-shape override does not enter that player support path.

`Entity` fluid sampling queries `BlockGetter.getFluidState` while traversing the entity bounding box. Barrier waterlogging changes fluid state in newer versions but not collision geometry for a fixed state; this is recorded below as newer vanilla behavior rather than a same-state movement-shape difference.


## State-transition differences resolved against movement scope

The following exact-source differences change the vanilla block state through neighbor updates, not the direct `getShape` or `getCollisionShape` result for the same current raw block state. The project invariant preserves vanilla block states and emulates player movement, so these state replacement/retention differences are outside movement emulation.

- **Repeater and comparator support loss (1.20.2):** `RepeaterBlock.updateShape` adds a DOWN-neighbor check that returns air when `DiodeBlock.canSurviveOn` fails; `ComparatorBlock` gains the same rule. In 1.19.4/1.20.1 neither transition is present. `DiodeBlock.getShape` returns the same constant 16×2×16 plate in every release; comparator inherits it. Both registrations have collision enabled, but the old and new clients return the same collision shape for the same current block state. The difference occurs only after support changes and one version replaces the state with air; a movement hook must not replay that vanilla update.
- **Door half reconciliation (1.20.3):** for a fixed `DoorBlock` state, the old switch and new switch-expression `getShape` select the same directional/open/hinge box; all door shape fields and state properties are unchanged. `updateShape` changes how an unlike vertical DoorBlock neighbor is accepted and which block state is retained. Same-type valid pairs agree. Mixed-type reconciliation is a vanilla state transition, not a changed direct shape response for a fixed raw state, so it is outside movement emulation.
- **Barrier waterlogging (1.20.2):** adds a WATERLOGGED property and fluid-state response, but no collision/outline shape override or shape-affecting state gate. It does not create a collision-shape difference for a fixed state. The new fluid state belongs to the newer vanilla block-state behavior and is outside this shape census.
- **Redstone wire support loss (1.20.2):** its new removal rule is also a state transition. The registration is `noCollision`; the old and new same-state collision result remains empty.

No changed direct same-state `getShape`/`getCollisionShape` result or same-state shape predicate for an existing 1.19.4 block remains in this census. The player collision caller is traced above to establish the path that a direct shape difference would affect; the reviewed candidates do not meet that condition.

## Other checked adjacent differences and dispositions

- 1.19.4→1.20: Beetroot/Potato/Carrot/Crop `getShape` now obtains age through `getAge(state)` instead of directly reading the age property. In 1.19.4 and 1.20.4, `CropBlock.getAge` reads the same property; each crop age-to-shape table is unchanged. No geometry difference found. The Torchflower version is new-feature-only and excluded.
- 1.20→1.20.1: no changed direct/inherited block shape provider or registered shape/property field found.
- 1.20.1→1.20.2: Pink Petals’ shape becomes state-dependent, but Pink Petals is absent from the 1.19.4 block registry and is outside the historical-block census. Chorus Flower adds `getBlockSupportShape`; excluded from player collision/support per trace above. Skull POWERED state, dispenser/hopper neighbor gates, and other changed callbacks do not feed a changed collision shape. Repeater/comparator and Barrier are resolved in the state-transition section above.
- 1.20.2→1.20.3: Torch shape/update methods move unchanged from `TorchBlock` to `BaseTorchBlock`; AbstractGlassBlock visual/skylight methods move unchanged to `TransparentBlock`. `ConcretePowderBlock` still solidifies on the same `touchesLiquid` predicate at update and placement, returning the same concrete default state; its full-block collision geometry is unchanged. AttachedStem and ChorusPlant placement updates affect plant growth/connectivity; no movement collision provider changes. Rail rotation switch was rewritten with equivalent state mapping and rail is non-collidable. Door state reconciliation is resolved in the state-transition section above.
- 1.20.3→1.20.4: no direct/inherited block shape provider or registered shape/property field differences found.
- 1.19.4→1.20 contains broad `forceSolidOn/Off` and predicate-flag registration shifts as the `legacySolid` classification was introduced. Those flags do not select `BlockBehaviour.getCollisionShape`; movement collision remains controlled by `hasCollision` and the shape provider. No `Entity` player movement call to `isSolid()`/`blocksMotion()` was found in this check; suffocation/damage and visual occlusion consumers are outside the movement-shape path.

## Coverage limits and next bounded action

The full block-tree provider/state-property census and base state wrappers are covered. The direct registration parser may miss flags supplied inside helper factories or properties copied from helper-created blocks. The remaining bounded source action is to close `Blocks.java` helper/factory registration expansion for shape/collision flags; this census establishes no direct movement-emulation candidate. No freeze, acceptance, or implementation claim is made here.

## Scope conclusion

The direct same-state shape review resolves the Repeater/Comparator, Door, Barrier, and Redstone Wire observations as state-transition or newer-state differences outside movement emulation. The only differing common-block shape provider bodies were found equivalent after following their property/helper dependencies (crop age shape lookup and Door direction switch). The remaining incomplete item is helper-factory expansion in block registrations, recorded above; no pair-freeze or acceptance claim is made.




