import pathlib, re, hashlib, json, difflib
root=pathlib.Path(r'D:\Javastuff\LegacyParkourCompat\decompiled_minecraft')
versions=['1.19.4','1.20','1.20.1','1.20.2','1.20.3','1.20.4']
classes={'LocalPlayer':'net/minecraft/client/player/LocalPlayer.java','Player':'net/minecraft/world/entity/player/Player.java','LivingEntity':'net/minecraft/world/entity/LivingEntity.java','Entity':'net/minecraft/world/entity/Entity.java'}
out=pathlib.Path(r'C:\Users\Wolfi\.codex\worktrees\56a8\LegacyParkourCompat\.native-source\20261031\1194-1204-pool54\full-player-graph-closure')
# Verify sidecars/embedded manifest and source hashes.
with (out/'source-identities.txt').open('w',encoding='utf-8') as f:
  for v in versions:
    base=root/v; src=base/'mojmap'; f.write(f'[{v}]\n')
    side=base/'mojmap.sources.sha256'
    if side.exists():
      lines=side.read_text(encoding='utf-8').splitlines(); manifest={}
      for ln in lines:
        m=re.match(r'^([0-9a-f]{64}) \*(.+)$',ln)
        if m: manifest[m.group(2)]=m.group(1)
      f.write(f'source-sidecar sha256={hashlib.sha256(side.read_bytes()).hexdigest()}\n')
      ready=json.loads((base/'mojmap.ready.json').read_text(encoding='utf-8'))
      prov=json.loads((base/'mojmap.provenance.json').read_text(encoding='utf-8'))
      f.write(f"ready version={ready['versionId']} mapping={ready['mapping']} client={ready['clientSha256']} sidecarMatch={ready['sourceManifestSha256']==hashlib.sha256(side.read_bytes()).hexdigest()}\n")
      f.write(f"provenance version={prov['versionId']} namespace={prov['namespace']} mappingOption={prov['exactRun']['mappingOption']} tools={prov['tools']}\n")
      for rel in classes.values():
        actual=hashlib.sha256((src/rel).read_bytes()).hexdigest(); f.write(f'{rel} sha256={actual} sidecar={manifest.get(rel)} match={actual==manifest.get(rel)}\n')
    else:
      manifest_path=src/'.decompile-provenance.json'; manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
      f.write(f'embedded-manifest sha256={hashlib.sha256(manifest_path.read_bytes()).hexdigest()} pipeline={manifest.get("pipeline")}\n')
      for rel in classes.values():
        actual=hashlib.sha256((src/rel).read_bytes()).hexdigest(); f.write(f'{rel} sha256={actual} embedded={manifest["sources"].get(rel)} match={actual==manifest["sources"].get(rel)}\n')
      for name,h in manifest['inputs'].items():
        if re.search(r'/client\.(jar|txt)$',name): f.write(f'pinned={name} sha256={h}\n')
    f.write('\n')
