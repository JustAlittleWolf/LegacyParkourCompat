# Full player movement graph closure: 1.19.4–1.20.4 Mojmap

## Scope and evidence

Compared adjacent releases only: 1.19.4→1.20, 1.20→1.20.1, 1.20.1→1.20.2, 1.20.2→1.20.3, and 1.20.3→1.20.4. Inputs are the exact Mojmap trees at `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\<version>\mojmap`.

`source-identities.txt` records each release's ready/provenance identity (four campaign-sidecar pairs and two embedded manifests) and verifies source SHA-256s for LocalPlayer, Player, LivingEntity, and Entity against those manifests. `dependency-identities.txt` binds caller/input/effect/attribute/collision-helper classes. The method inventory and adjacent raw method-hash/range matrix for every method in the four core classes is `method-caller-matrix.txt`; exact paired core-body diffs for movement candidates are `relevant-method-diffs.txt`. Hashes are SHA-256 of the UTF-8 decompiled method text including declaration/body; class hashes and source-manifest identities are recorded separately.

## Reachable on-foot call graph and authority

- `Minecraft.tick` calls `ClientLevel.tickEntities` for entity simulation and separately calls `ClientLevel.tick` for the level/block phase. `ClientLevel.tickEntities` calls `tickNonPassenger` for each nonremoved root entity. `tickNonPassenger` updates prior-position/tick counters and invokes virtual `Entity.tick()`.
- The local player's normal on-foot virtual chain is `LocalPlayer.tick → Player.tick → LivingEntity.tick → Entity.tick`; after the base work, `LivingEntity.tick` calls virtual `this.aiStep()`, dispatching `LocalPlayer.aiStep → Player.aiStep → LivingEntity.aiStep`.
- `LocalPlayer.aiStep` consumes stored `Input` (`jumping`, `shiftKeyDown`, forward/side impulses), computes sprint/crouch/slow-input state, calls `input.tick(...)`, then reaches `super.aiStep()`. `Input.java` and `KeyboardInput.java` have identical file hashes for all six releases. Keyboard-device mapping is an input boundary; comparisons here use equal stored raw input values.
- `LivingEntity.aiStep` makes the jump decision and dispatches virtual `jumpFromGround()` or the fluid-jump methods, then dispatches virtual `travel(Vec3)`. Player's override calls through `Player.travel` where applicable; `LivingEntity.travel` selects fluid/ground/flight movement, reaches `handleRelativeFrictionAndCalculateMovement`, then `Entity.move(MoverType.SELF, delta)`.
- `Entity.move` resolves collision-adjusted delta, calls `setPos`, updates collision/on-ground/support state, applies post-move block-speed factor to delta movement, and accumulates fall/walk movement state. `setPos` is the position/AABB writer; `setDeltaMovement` is the velocity writer. `LivingEntity` reads effect, attribute, equipment/enchantment, ability, pose, sprint, and fluid state on the path. `Player.tick` calls `updatePlayerPose()` after its `super.tick()` returns, so that pose/dimensions write follows this tick's AI/travel/move and feeds later ticks.
- Passenger authority is explicitly distinguished: `ClientLevel.tickPassenger` calls virtual `rideTick()`. `Entity.rideTick()` calls virtual `this.tick()`, so a passenger player still reaches the LocalPlayer override. Player/LivingEntity ride wrappers and `travelRidden`/`tickRidden` are present in the method matrix but are excluded from this on-foot comparison. In 1.20.3, `Player.rideTick` only drops movement-statistics accumulation; `Player.travel` only drops position-delta bookkeeping and `checkMovementStatistics`.

The matrix has complete method inventories for all four core classes and every adjacent pair. It includes unchanged/shifted methods as ranges and hashes, not just detected differences. `ClientLevel.tickEntities` in 1.20.3 adds a tick-freeze gate, but `TickRateManager.isEntityFrozen` explicitly excludes every `Player`; it does not suppress the local player's on-foot tick.

## Adjacent cutover outcomes

### 1.19.4 → 1.20

**Eligible: jump-boost jump velocity precision changes.** `LivingEntity.getJumpBoostPower` changes from `double` returning the float product `0.1F * (amplifier + 1)` (float product widened on return), and `jumpFromGround` adds that widened boost to float `getJumpPower()` in double precision, to `float` `0.1F * (amplifier + 1.0F)` and a float addition inside `getJumpPower() = 0.42F * getBlockJumpFactor() + getJumpBoostPower()`. `jumpFromGround` then widens the combined float for the double-argument velocity setter. With equal valid jump-effect amplifier and block factor, the vertical velocity can differ from the changed intermediate rounding; no trajectory inference is made. Primary source: `LivingEntity.java` 1.19.4 lines 1947–1965 vs 1.20 lines 1969–1986; `Player.jumpFromGround` still delegates to `super` in both.

**Eligible: footing/support block selection feeding later movement math.** `Entity.move` now records `verticalCollisionBelow` and calls `setOnGroundWithKnownMovement(verticalCollisionBelow, resolvedDelta)`, which maintains `mainSupportingBlockPos` via `Level.findSupportingBlock` and a prior-horizontal-position fallback. `Entity.getOnPos(float)` now prefers that support position, applies fence/wall/gate handling, and otherwise falls back to the floor at `y-offset`; `getBlockPosBelowThatAffectsMyMovement()` changes from `BlockPos.containing(x, bb.minY - 0.5000001, z)` to `getOnPos(0.500001F)`. This position is consumed by jump-factor lookup in `LivingEntity.getJumpPower`, friction in `LivingEntity.travel`, block-speed factor post-move, and player auto-jump state. A changed support block can therefore change a movement factor when the associated blocks have different jump/friction/speed values, or at support/edge/fence geometries where the selected position differs. `Entity.move` itself still derives the on-ground boolean from the downward vertical collision. Primary source: `Entity.java` old `move` 549–681, `setOnGround` 541–543, `getOnPos` 728–742, `getBlockPosBelowThatAffectsMyMovement` 760–762; new `move` 593–722, support setters 553–589, `getOnPos` 798–815, below-position helper 790–792. Block/support search is an external provider boundary listed under residuals.

**Eligible: fall-distance reset gate/order changes.** In 1.19.4, `travel` resets fall distance for Slow Falling only under `deltaMovement.y <= 0`, and resets for Levitation in its later Levitation travel branch. In 1.20, `aiStep` resets it immediately before travel whenever either Slow Falling or Levitation is active; the Slow Falling reset is removed from its old conditional, and the Levitation reset is removed from its old travel branch. Equal effect/velocity states with upward Slow Falling, or with effect-driven ordering relative to travel/collision state, can yield a different fall-distance state. Fall damage resolution itself remains excluded. Primary source: `LivingEntity.java` 1.19.4 `travel` 1983–2116 and `aiStep` 2454–2582; 1.20 `aiStep` 2473–2604 and `travel` 2004–2135.

Other movement-named core methods in this pair change only field access (`level` to `level()`, `onGround` to `onGround()`), local names/profiler scopes, or source/callback/step emission code. `Player.travel`, `Player.maybeBackOffFromEdge`, `LivingEntity.handleRelativeFrictionAndCalculateMovement`, water slowdown/depth-strider and Soul Speed paths preserve their movement operations. Portal visual state/screen gating and movement event/sound changes are not movement-state changes. `Entity.move`'s new support choice remains eligible; its sound/event deltas do not.

### 1.20 → 1.20.1

No methods changed in LocalPlayer, Player, LivingEntity, or Entity (method counts and method hashes match). The stored input classes, ClientLevel entry methods and their files are also identical. No bounded core-graph movement difference found.

### 1.20.1 → 1.20.2

No bounded eligible on-foot movement difference found in the paired core graph. The changed `LocalPlayer.aiStep` adds `!isPassenger()` to the crouching-state expression (passenger-only) and routes crouch/standing checks through new `Player.canPlayerFitWithinBlocksAndEntitiesWhen`. For a Player, both the old `Entity.getBoundingBoxForPose(pose).deflate(1.0E-7)` and new `getDimensions(pose).makeBoundingBox(position()).deflate(1.0E-7)` use the same pose dimensions, `float width / 2.0F`, Y+height, AABB component order and 1e-7 deflation (`EntityDimensions.makeBoundingBox` is byte-identical); both call `Level.noCollision` with the same entity. `Player.updatePlayerPose` changes to the helper but uses the same selected poses and fallback order. The changed `Player.aiStep` entity list loop is iteration syntax only.

`LivingEntity.aiStep` extracts the prior position/rotation interpolation statements into `lerpPositionAndRotationStep` with the same operations and order; movement's jump/travel math is otherwise unchanged. `LivingEntity.setSprinting` removes the sprint modifier by its UUID directly rather than first checking then removing the same modifier; both resolve to the same `AttributeInstance.removeModifier(UUID)` no-op/present behavior. New dirty-attribute processing in `LivingEntity.tick` and effect handlers calls `onAttributeUpdated` only to clamp `MAX_HEALTH`/`MAX_ABSORPTION`; it does not write a movement attribute. `AttributeInstance.calculateValue` retains `ADDITION → MULTIPLY_BASE → MULTIPLY_TOTAL` order. Movement-speed base remains `0.7F`; Speed/Slowness modifiers remain +0.2F/−0.15F total multipliers; Jump, Slow Falling, Levitation and Dolphin's Grace movement reads/definitions remain unchanged. `MobEffect`'s 1.20.2 attribute-template refactor retains the same `amount * (amplifier + 1)` modifier amount formula for movement effects.

### 1.20.2 → 1.20.3

Core movement bodies in this graph are unchanged except `Player.travel` deletes only old/new position snapshots and the final `checkMovementStatistics` call; that reporting/statistic operation is excluded. `Player.rideTick` deletes passenger movement statistics, also excluded. `LocalPlayer`, LivingEntity movement decisions, Entity collision/support/movement writers and input classes have unchanged paired method hashes. ClientLevel's new tick-freeze check excludes `Player` as described above.

### 1.20.3 → 1.20.4

LocalPlayer, Player, LivingEntity and Entity files are byte-identical; ClientLevel and the stored input files are byte-identical. No bounded on-foot movement difference found.

## Inventory and method-hash artifacts

- `method-caller-matrix.txt`: SHA-256, declaration/body line range, and changed/added/removed method list for every method in LocalPlayer, Player, LivingEntity, Entity across the six sources.
- `relevant-method-diffs.txt`: paired unified diffs for changed movement-path methods.
- `source-identities.txt`: canonical ready/provenance, mapping, pinned input and four core source-file hashes.
- `dependency-identities.txt`: caller/input/effect/attribute/enchantment/dimensions/Level hashes for all six exact sources.
- `verify_sources.py`, `method_diff.py`, and `diff_selected.py`: local static inventory scripts, all in this owned scratch directory.

## Exact residuals

1. Collision and provider dependency closure remains with the separate block/provider lane: `Level.noCollision`, `getCollisions`, `findSupportingBlock`, block/fluid collision-shape/state providers, `getFriction`, `getJumpFactor`, `getSpeedFactor`, and block callbacks reached after movement (`fallOn`, `updateEntityAfterFallOn`, step effects). The on-foot graph identifies each call boundary but does not claim those inventories are closed here.
2. Fluid controls in LocalPlayer/Player/LivingEntity/Entity were paired, including water/lava branch gates and post-fluid movement setters. The current/water-force provider boundary calls through `FluidState.getFlow`/fluid state and is not an external block/provider inventory closure in this assignment.
3. Direct packet handlers that write or reconcile the local player's position/velocity and external effect/attribute synchronization were not inventoried; compare their raw outcomes as fixed inputs. Device-to-key mapping and packet creation are likewise outside the stored-Input graph.
4. Vehicle/non-player riding and their `travelRidden`/`tickRidden` branches are excluded; the dynamic `Entity.rideTick → this.tick()` authority is documented but not claimed as on-foot coverage.
5. These are the five named source cutovers only. No exact intermediate patch-boundary search, runtime parity check, build, test, game launch, source regeneration or product/research write was performed.

