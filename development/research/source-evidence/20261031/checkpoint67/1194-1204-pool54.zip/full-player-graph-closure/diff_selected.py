from pathlib import Path
import re, difflib
root=Path(r'D:\Javastuff\LegacyParkourCompat\decompiled_minecraft'); out=Path(r'C:\Users\Wolfi\.codex\worktrees\56a8\LegacyParkourCompat\.native-source\20261031\1194-1204-pool54\full-player-graph-closure')
versions=['1.19.4','1.20','1.20.1','1.20.2','1.20.3','1.20.4']; classes={'LocalPlayer':'net/minecraft/client/player/LocalPlayer.java','Player':'net/minecraft/world/entity/player/Player.java','LivingEntity':'net/minecraft/world/entity/LivingEntity.java','Entity':'net/minecraft/world/entity/Entity.java'}
access=re.compile(r'^\s*(?:public|protected|private)\s+(?:(?:static|final|synchronized|abstract|native|strictfp)\s+)*[\w.$<>?,\[\]@ ]+\s+(\w+)\s*\(')
def methods(text):
 lines=text.splitlines(); found={}; i=0
 while i<len(lines):
  m=access.match(lines[i])
  if not m: i+=1; continue
  start=i; sig=[lines[i]]; j=i
  while '{' not in '\n'.join(sig) and j+1<len(lines) and ';' not in '\n'.join(sig): j+=1; sig.append(lines[j])
  joined='\n'.join(sig)
  if '{' not in joined or ')' not in joined: i+=1; continue
  signature=re.sub(r'\s+',' ',joined[:joined.index('{')]).strip(); key=m.group(1)+' '+signature[signature.find('('):]
  depth=0; end=None
  for k in range(j,len(lines)):
   depth+=lines[k].count('{')-lines[k].count('}')
   if depth==0: end=k; break
  if end is None: i=j+1; continue
  found[key]=(start+1,end+1,'\n'.join(lines[start:end+1])); i=end+1
 return found
allm={}
for v in versions:
 for cls,rel in classes.items(): allm[v,cls]=methods((root/v/'mojmap'/rel).read_text(encoding='utf-8'))
want={'LocalPlayer':['tick','aiStep','canAutoJump','updateAutoJump','handleNetherPortalClient','moveTowardsClosestSpace'],'Player':['tick','aiStep','rideTick','travel','jumpFromGround','maybeBackOffFromEdge','updatePlayerPose','setSprinting','getSpeed','getSpeedFactor'],'LivingEntity':['tick','baseTick','aiStep','travel','jumpFromGround','getJumpPower','getJumpBoostPower','getFrictionInfluencedSpeed','handleRelativeFrictionAndCalculateMovement','handleOnClimbable','getSpeed','getWaterSlowDown','isAffectedByFluids','updateFallFlying','tickEffects','setSprinting','getAttributeValue','getAttribute','getSpeed'],'Entity':['tick','tickNonPassenger','tickPassenger','rideTick','baseTick','move','moveRelative','checkFallDamage','getBlockSpeedFactor','getBlockJumpFactor','getOnPos','getBlockPosBelowThatAffectsMyMovement','updateInWaterStateAndDoFluidPushing','updateFluidHeightAndDoFluidPushing','updateSwimming','setOnGround','setPos','setDeltaMovement','setPose','refreshDimensions','getBoundingBoxForPose','canEnterPose','getBoundingBox','getDeltaMovement','isSprinting','isInWater','isUnderWater','isInLava','isAffectedByFluids']}
with (out/'relevant-method-diffs.txt').open('w',encoding='utf8') as f:
 for a,b in zip(versions,versions[1:]):
  f.write(f'## {a} -> {b}\n')
  for cls,names in want.items():
   left=allm[a,cls]; right=allm[b,cls]
   for name in names:
    keys=sorted(set(k for k in set(left)|set(right) if k.startswith(name+' ')))
    for k in keys:
     if k not in left or k not in right or left[k][2]==right[k][2]: continue
     f.write(f'### {cls}.{k}\nold {left[k][0]}-{left[k][1]}\nnew {right[k][0]}-{right[k][1]}\n')
     diff=list(difflib.unified_diff(left[k][2].splitlines(),right[k][2].splitlines(),fromfile=a,tofile=b,n=4))
     # Trim unchanged leading package/mapping names? Preserve source context.
     f.write('\n'.join(diff)+'\n')
