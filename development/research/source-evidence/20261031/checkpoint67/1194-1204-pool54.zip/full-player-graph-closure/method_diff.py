from pathlib import Path
import re, hashlib, difflib, collections
root=Path(r'D:\Javastuff\LegacyParkourCompat\decompiled_minecraft')
versions=['1.19.4','1.20','1.20.1','1.20.2','1.20.3','1.20.4']
classes={'LocalPlayer':'net/minecraft/client/player/LocalPlayer.java','Player':'net/minecraft/world/entity/player/Player.java','LivingEntity':'net/minecraft/world/entity/LivingEntity.java','Entity':'net/minecraft/world/entity/Entity.java'}
out=Path(r'C:\Users\Wolfi\.codex\worktrees\56a8\LegacyParkourCompat\.native-source\20261031\1194-1204-pool54\full-player-graph-closure')
access=re.compile(r'^\s*(?:public|protected|private)\s+(?:(?:static|final|synchronized|abstract|native|strictfp)\s+)*[\w.$<>?,\[\]@ ]+\s+(\w+)\s*\(')
# Method extraction uses declaration line and brace-depth body extent, method AST-like boundaries sufficient for decompiled Java.
def methods(text):
  lines=text.splitlines(); found=[]; i=0
  while i<len(lines):
    m=access.match(lines[i])
    if not m: i+=1; continue
    start=i; sig=[lines[i]]; j=i
    while '{' not in '\n'.join(sig) and j+1<len(lines) and ';' not in '\n'.join(sig):
      j+=1; sig.append(lines[j])
    joined='\n'.join(sig)
    if '{' not in joined or ')' not in joined:
      i+=1; continue
    # Keep overload keys by declaration signature before body.
    signature=re.sub(r'\s+',' ',joined[:joined.index('{')]).strip()
    name=m.group(1); open_line=j; depth=0; end=None
    for k in range(open_line,len(lines)):
      # Comments/string braces are very rare in these movement methods; count source braces.
      depth+=lines[k].count('{')-lines[k].count('}')
      if k==open_line and depth==0: end=k; break
      if k>open_line and depth==0: end=k; break
    if end is None: i=j+1; continue
    body='\n'.join(lines[start:end+1])
    key=name+' '+signature[signature.find('('):]
    found.append((key,start+1,end+1,body))
    i=end+1
  return {k:(a,b,body) for k,a,b,body in found}
allm={}
for v in versions:
  for cls,rel in classes.items(): allm[v,cls]=methods((root/v/'mojmap'/rel).read_text(encoding='utf-8'))
with (out/'method-caller-matrix.txt').open('w',encoding='utf-8') as f:
  for older,newer in zip(versions,versions[1:]):
    f.write(f'## {older} -> {newer}\n')
    for cls in classes:
      a=allm[older,cls]; b=allm[newer,cls]; keys=sorted(set(a)|set(b)); diffs=[]
      for k in keys:
        if k not in a: diffs.append((k,'ADDED',None,b[k]))
        elif k not in b: diffs.append((k,'REMOVED',a[k],None))
        elif a[k][2]!=b[k][2]: diffs.append((k,'CHANGED',a[k],b[k]))
      f.write(f'### {cls}: methods old={len(a)} new={len(b)} changed={len(diffs)}\n')
      for k,kind,x,y in diffs:
        f.write(f'{kind} {k} old={x[0]}-{x[1]}' if x else f'{kind} {k} old=absent')
        f.write(f' new={y[0]}-{y[1]}\n' if y else ' new=absent\n')
  f.write('\n## Per-source-class method hashes and ranges\n')
  for v in versions:
    f.write(f'### {v}\n')
    for cls in classes:
      f.write(f'{cls}\n')
      for k,(a,b,body) in sorted(allm[v,cls].items()): f.write(f'{a}-{b} sha256={hashlib.sha256(body.encode()).hexdigest()} {k}\n')
