# Crouching and pose follow-up (coverage erratum)

## Verdict

The 1.20.2 `LocalPlayer` crouching change does not alter on-foot player movement or pose dimensions. It changes the crouching-derived input slowdown only while the player is a passenger. That input then steers the vehicle; passenger position is assigned by the vehicle. This falls under the project exclusion for vehicle/non-player physics. No movement finding is warranted for this slice.

## Exact source review

Compared Mojmap releases 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4. The six relevant source entries (`LocalPlayer.java`, `Player.java`, `Entity.java`, `EntityDimensions.java`, `CollisionGetter.java`, `LivingEntity.java`) matched their recorded source manifests in every release. Source identity metadata: ready sidecars identify 1.19.4, 1.20.1, 1.20.2 and 1.20.4 as Mojmap; the embedded legacy provenance files for 1.20 and 1.20.3 have SHA-256 `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` and `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dce0f`. Each embedded source map matches the relevant sources, and those source hashes equal the adjacent ready release (1.20 = 1.20.1; 1.20.3 = 1.20.4).

Across 1.19.4, 1.20 and 1.20.1, `LocalPlayer.aiStep` sets `crouching` from flying/swimming gates, `canEnterPose(CROUCHING)`, then shift-or-standing-fit. In 1.20.2 onward it adds `!isPassenger()` and calls `canPlayerFitWithinBlocksAndEntitiesWhen` in place of `canEnterPose`. For non-passengers, these fit helpers use the same pose dimensions, the same player-position bounding box, `deflate(1.0E-7)`, and the same `level.noCollision(this, box)` query. Old `Entity.getBoundingBoxForPose` builds min/max from `getX/Y/Z` and `getDimensions(pose)`; new `EntityDimensions.makeBoundingBox(position())` uses the same float half-width/height and min/max operations. The `noCollision` query checks block and entity collisions in both forms. The 1.20.2 helper is retained in 1.20.3 and 1.20.4.

`Player.updatePlayerPose` runs from `Player.tick`. Its method changes to use the new helper, but candidate-pose selection and gates are otherwise unchanged: `isSpectator() || isPassenger()` already accepts the chosen pose without the fit query; non-passenger checks use the equivalent geometry above. `Entity` refreshes dimensions when synced pose changes. The helper replacement therefore introduces no on-foot pose or bounding-box difference.

`LocalPlayer.isMovingSlowly()` is `isCrouching() || isVisuallyCrawling()` and its only locomotion consumer in this path is `input.tick(this.isMovingSlowly(), sneakBonus)`. Consequently the added passenger guard clears crouch slowdown while riding. The only other `Player.isCrouching()` consumers in these sources are walking-stat accounting and hand-position calculation.

Passenger position authority is external to the player's own move: `Player.rideTick` delegates to `Entity.rideTick`; the latter zeros the passenger's delta movement, ticks it, and calls `getVehicle().positionRider(this)`, whose default implementation sets the passenger position from the vehicle's passenger position plus the rider offset. `LocalPlayer.tick` uses its passenger branch to send player input and, for a locally controlled root vehicle, a vehicle movement packet. On locally controlled `LivingEntity` vehicles, `LivingEntity.aiStep` calls `travelRidden` with the rider/player input; that vehicle method applies its ridden input/speed and calls the vehicle's `travel`. Thus the passenger-only slowdown difference feeds vehicle control and vehicle-authored passenger positioning.

## Scope

This note covers only the crouching/pose follow-up. It does not close the full 1.19.4→1.20.4 pair and does not make a pair-freeze claim.
