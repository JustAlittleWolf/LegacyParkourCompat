# Scope erratum: BarrierBlock waterlogging is post-profile

Bound to `barrier-waterlogged-flow-push.md` SHA-256 `e2492e2e710e4189d17d9d9449b2e092a4921a504b91ff8fe38efbc545a0524a` (the original draft is unchanged).

The source trace establishes a real modern player-fluid-push consequence for a waterlogged barrier state, but that state is not eligible for historical emulation against profile 1.19.4. The 1.19.4 `BarrierBlock` has no `WATERLOGGED` property, no waterlogged placement/update behavior, and inherits an empty fluid state. The property and behavior first appear in 1.20.2, after the selected historical profile. Under the project scope rule, features introduced after a selected profile retain modern behavior; only introduction or later changes to a feature already present at that profile form a historical comparison boundary.

Conclusion: **no accepted historical movement finding or compatibility delta follows from this candidate for 1.19.4 → 1.20.4.** Its modern velocity consequence remains a valid source observation, but it must not be used to emulate away post-profile BarrierBlock waterlogging. This conclusion is limited to `BarrierBlock.WATERLOGGED` and does not generalize to other waterlogged blocks or features.
