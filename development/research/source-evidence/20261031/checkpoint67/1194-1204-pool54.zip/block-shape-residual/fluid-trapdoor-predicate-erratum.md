# Erratum: trapdoor motion predicate remains true at equality

This is a separate correction; it leaves the existing fluid-trapdoor draft untouched.

In Mojmap 1.20 through 1.20.4, `BlockBehaviour.BlockStateBase.calculateSolid` accepts `AABB.getSize() >= 0.7291666666666666`. `AABB.getSize()` is the average of its three dimensions. `TrapDoorBlock` uses collision boxes with dimensions `1`, `1`, and `3/16` for both open orientations and top/bottom closed states, so the average is exactly `0.7291666666666666`. Equality passes the `>=` gate. The cached solid result is therefore true, and `BlockState.blocksMotion()` returns that result for trapdoors (the only explicit false exceptions are cobweb and bamboo sapling).

Relevant source: 1.19.4 Mojmap `TrapDoorBlock.java`, shape constants at lines 36–42 and `getShape` at lines 60–74; `Material.java`, `METAL`/`WOOD` and `Builder.blocksMotion = true` at lines 81–93 and 158–183; `FlowingFluid.java`, material `blocksMotion` gate at lines 64–72. 1.20.4 Mojmap `TrapDoorBlock.java`, unchanged 3/16 shape constants at lines 43–49; `AABB.java`, average calculation at lines 250–255; `BlockBehaviour.java`, `calculateSolid` at lines 471–501 and `blocksMotion` at lines 512–519; `FlowingFluid.java`, state `blocksMotion` gate at lines 65–75.

Correction: an open trapdoor does not become non-blocking under the 1.20+ cached shape predicate. The exact threshold equality keeps `blocksMotion()` true, matching the older wood/metal material predicate for this flow branch. Do not use a below-threshold result or a trapdoor-flow difference claim for this case.

The same shape constants and threshold gate were checked in 1.20, 1.20.1, 1.20.2 and 1.20.3; relevant source hashes match each release's source manifest (the 1.20.3 release uses its embedded legacy source map).
