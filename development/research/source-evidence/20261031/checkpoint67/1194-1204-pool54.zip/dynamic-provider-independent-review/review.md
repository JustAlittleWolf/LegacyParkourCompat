# Independent review: dynamic provider closure

## Verdict and review boundary

**Source recheck: supported for the five assigned families and six sampled releases.** I independently retraced the registration, contextual collision dispatch, provider/state inputs, moving-piston block-entity path, powder-snow movement contact, and relevant fluid paths in canonical Mojmap sources for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4. No additional movement-relevant delta was found in those slices. The honey-piston edge case is a supplement to the existing `sticky-piston-edge-support` operation, not a second finding.

This review does not close the complete player tick inventory, unsampled patch boundaries, or runtime parity. The source author disclosed that same-lane reports had been opened before their baseline; I did not use those reports and retraced the assigned source claims from the canonical trees. This verdict is bound to the current closure file SHA-256 `2321A127B0B7351DA598AF5C31E6E8B6CE406AEC149D1FFA73B761DFC421EF35` and its `source-file-hashes.csv`.

## Source identity check

Canonical root: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<release>/mojmap/` (read-only). All **67** source entries in the supplied CSV were hashed directly against that root; there were **zero mismatches**. I independently confirmed the exact source-root identity and count:

| Release | Root identity | SHA-256 | Source files |
|---|---|---|---:|
| 1.19.4 | `mojmap.sources.sha256` | `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` | 4,740 |
| 1.20 | `.decompile-provenance.json` | `573f0bb3e18e39ae882769a007a1c97d711da1230344f9a1c894eb407ef58030f` | 4,786 |
| 1.20.1 | `mojmap.sources.sha256` | `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` | 4,786 |
| 1.20.2 | `mojmap.sources.sha256` | `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` | 4,904 |
| 1.20.3 | `.decompile-provenance.json` | `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` | 5,048 |
| 1.20.4 | `mojmap.sources.sha256` | `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` | 5,048 |

For the sidecar roots, the ready marker's `sourceManifestSha256` matches the actual sidecar digest. For 1.20 and 1.20.3, the provenance-file digest matches the cited root identity and its `sources` object contains the stated number of paths. These checks bind the checked source files to the six exact Mojmap roots; they are not claims that every source file outside the supplied CSV was rehashed during this review.

## Independent source checks

### Contextual collision dispatch and registrations

In all six releases, `BlockBehaviour.BlockStateBase.getCollisionShape(BlockGetter, BlockPos, CollisionContext)` dispatches to `getBlock().getCollisionShape(state, world, pos, context)`. The inherited provider alone checks `hasCollision`; an override executes directly. `BlockCollisions.computeNext` skips cursor corners and has the existing edge/large-shape and moving-piston cursor gates, then calls that contextual state provider. It does not reject a candidate merely because `Properties.noCollission()` set `hasCollision` false. A scaffold cell overlapping the player's collision volume is among the interior candidate cells; its custom provider therefore remains reachable.

This establishes the parent-sensitive scaffolding path: at 1.19.4 `Blocks.SCAFFOLDING` registers `noCollission()` and `dynamicShape()` (`Blocks.java:3525`); at 1.20.4 those remain (`Blocks.java:6015`). `ScaffoldingBlock.getCollisionShape` (`ScaffoldingBlock.java:117` in 1.19.4; `:124` in 1.20.4) returns `STABLE_SHAPE` when the context is above a full block and not descending. Otherwise it returns the two-pixel bottom shape only for `DISTANCE != 0`, `BOTTOM`, and context above `BELOW_BLOCK`; else it returns empty. The override does not call `super`. The outline's held-scaffolding-item branch is `getShape`, not movement collision. `DISTANCE`/`BOTTOM` are derived by unchanged `getDistance`, `isBottom`, and `updateShape`; `WATERLOGGED` only selects fluid.

The registration changes at 1.20 add `.forceSolidOn()` to bamboo, moving piston, and pointed dripstone; their 1.19.4 materials have `blocksMotion == true`, and modern dynamic-shape cached-solid evaluation honors the force-on flag before the absent dynamic cache. Powder snow retains collision-enabled properties while its legacy powder-snow material has `blocksMotion == false`; modern dynamic cache absence and no force flag also yield false. Scaffolding remains false for the cached motion predicate: its legacy decoration material does not block motion, and its modern dynamic registration has neither force flag. These registration/cached-predicate facts do not short-circuit the contextual provider path above.

### Family trace and equal-input comparison

Method-body SHA-256 values below were computed directly from brace-delimited Mojmap method bodies. Each listed body has the same digest at **all six** sampled releases; local callsites and state inputs were also checked in each root.

| Family | Same-body slices across all six roots | State/context and movement result |
|---|---|---|
| Bamboo | `BambooStalkBlock.getShape` `805a65046cef88155809fa5f43a36c38b651d3cb3b4645cbf8b01ace2e97bb9f`; `getCollisionShape` `9eaad915141f8f069e8a2055bbddc0f52a1e13290194cb5234ccdf8f4171de53`; `updateShape` `8b449b1c3435b3a48f3422e48284915989eb086e7fdef7f31bef9697ac8c5b9a` | Outline uses `LEAVES == LARGE`; collision is the same central 3-pixel column. Both add the registration's deterministic XZ state offset. `AGE`, other leaf values, `STAGE`, and growth-neighbor updates do not change same-state geometry. No in-scope contact or fluid callback exists. |
| Moving piston | `MovingPistonBlock.getCollisionShape` `f4fd8ef6c6e5f171afbfe07d054169af1d0f75c1fa92f72b949ad60d51a9b36e`; `PistonMovingBlockEntity.getCollisionShape` `0f17f4415b7deda7855f525aa86299e9396452f39b8ba453cccf9e6e7008f864` | The block provider returns the BE's contextual shape or empty without a BE. BE collision geometry uses moved state, direction, extending/source-piston fields and progress, including the piston-push no-clip case; those bodies match across the six roots. Direct BE movement remains a distinct callback path. The honey sticky-entity predicate is the sole reviewed source change here, detailed below. |
| Pointed dripstone | `getShape` `8b1d52967efbd8798b98572a0d97b685cbf8d3a74b7675a064d672960546eb78`; `updateShape` `46e9f0a9215d25749e2a6f4d2bd54797bc5bd1d7dfef466be4e02e93de20cc36`; `getFluidState` `3ee0d235a9006b28f5b3aac97cf05e2c941eccf975d9edd70abbaea5177302db` | `THICKNESS` chooses the tip/merge/frustum/middle/base box and `TIP_DIRECTION` chooses the up/down tip. XZ offset is applied after shape selection. `WATERLOGGED` does not affect geometry and selects source water through an unchanged fluid provider. Neighbor-derived state and movement-excluded stalagmite fall damage are unchanged. |
| Powder snow | `getCollisionShape` `b9be28df6db5fbe7138c878a90414528451b479ead30097ac51f0def201d794a`; `entityInside` `58490bea8ac76c526aa579040ed6e23b5bfa26c6e5aa56ee864bfc3db6aa9eb6`; `canEntityWalkOnPowderSnow` body identical in all roots | Collision first returns the 0.9-high falling shape when `fallDistance > 2.5F`; otherwise the inherited full state shape is returned only to a falling block or a walkable entity above the block and not descending; other contexts get empty. `canEntityWalkOnPowderSnow` is the same walkable-mob tag or living-entity leather-boots check. The same provider inputs yield the same result in every release. On client contact, eligible living-player feet trigger `makeStuckInBlock(0.9F, 1.5, 0.9F)`; the unchanged callback also sets the powder-snow flag. Its fire/block-destruction branch is server-only. |
| Scaffolding | `getShape` `eb1c3862d144aae15f9ccb2e6b64a91537f84251a6e8eba8ac40adb5710d0224`; `getCollisionShape` `0a340ec9e62da2d4d3e0e023a4cf8fa99111cb88be972a57013bbad29c0dd585`; `updateShape` `a1afed7d9340bc7a3933d253fc277039c7f6f8e8fbc4eb8008f7015c2928d7fc`; `getDistance` `fbc6e3967dfdfe7c4e902322b9087809873c4f06c7370056cfbdcc807e23e3c2`; `getFluidState` `3ee0d235a9006b28f5b3aac97cf05e2c941eccf975d9edd70abbaea5177302db` | Same `DISTANCE`, `BOTTOM`, and context select the same stable/bottom/empty collision shape. The held-item outline branch does not enter movement collision. Neighbor support recomputation and waterlogged source-water fluid are identical. The custom-provider collision remains reachable despite `noCollission()` as established above. |

The same-state check found no changed output for any equal raw block state and equal provider context among those five family providers. Registration force-solid flags are predicate changes only and preserve the old cached motion-blocking truth values for the corresponding registrations.

### Powder-snow contact-loop gate at 1.20.2

`Entity.checkInsideBlocks` computes the same epsilon-inset bounding-box cell range and visits X/Y/Z in the same order at 1.20.1 and 1.20.2. The 1.20.2 body adds `if (!this.isAlive()) return;` inside the innermost loop (`Entity.java:977`); the body hash changes from `5d2f28b60388260956d87cc227ba1d6b88fec2128764764c0dcec8050320e072` to `57c0af19078b6cea4c9b2b97d6e38cd6a2779d66257c3b6f7bda835224527bf3`. For the active LocalPlayer movement path, this does not prune the reviewed family callbacks: LocalPlayer's `hurt` override returns false in both versions (1.20.1 `LocalPlayer.java:150`, 1.20.2 `:149`), the powder-snow callback does not remove the entity, and the other four reviewed families have no lethal player contact callback. If the entity is already dead/removed before this traversal, subsequent cell callbacks are skipped in 1.20.2; that is outside active LocalPlayer movement. The powder-snow callback itself is unchanged, and so are the `makeStuckInBlock` method and the movement multiplier consumption relevant to the next move.

### Honey-piston edge witness: duplicate supplement only

I confirmed the source delta in `PistonMovingBlockEntity.moveStuckEntities` and `matchesStickyCritera`: the 1.19.4 query box's top is `1.5000000999999998`; 1.20+ uses `1.5000010000000001`. The old filter required `PushReaction.NORMAL`, grounded status, and entity X/Z center inside the swept AABB. The 1.20+ filter keeps normal push reaction and grounded status, then accepts either `isSupportedBy(movingBlockPos)` or the old center-in-AABB test. `Entity.isSupportedBy` compares the recorded main supporting block position with that exact position.

Thus an otherwise identical candidate whose entity AABB intersects the old swept query, whose center is just outside its horizontal bounds, and whose main support position is the moving honey-block position is rejected by 1.19.4 and accepted by 1.20+. The query uses entity-box intersection (`EntitySection.java:32`), so center-outside/AABB-overlap is a reachable query result. `moveEntityByPiston` then applies the progress delta. The slightly taller newer query does not invalidate a witness that already intersects the old query: the same entity remains in the new query. This is the already-accepted sticky-piston support-position operation; this review adds no duplicate finding and does not renew its separate acceptance verdict.

## Residuals

- These are six sampled exact Mojmap releases. Intermediate patch introductions and the unexamined minor versions remain unknown.
- The assignment closes these five dynamic-provider families only. It does not establish full-pair movement inventory closure, runtime trajectory parity, or implementation correctness.
- The 1.20.2 alive check skips later contact callbacks only after `isAlive()` becomes false during the cell scan. The reviewed client LocalPlayer path cannot reach that transition through the five assigned callbacks; other block callback families were outside this bounded review.

No product changes, source generation, tests, builds, game launches, network access, backlog/wiki edits, or Git operations were performed.
