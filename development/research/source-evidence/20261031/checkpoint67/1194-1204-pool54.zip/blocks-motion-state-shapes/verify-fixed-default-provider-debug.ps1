$ErrorActionPreference='Stop'
$versions=@('1.20','1.20.1','1.20.2','1.20.3','1.20.4')
$base='D:/Javastuff/LegacyParkourCompat/decompiled_minecraft'
$excluded=@('SlabBlock','StairBlock','DoorBlock','TrapDoorBlock','FenceBlock','BedBlock','AnvilBlock','EndPortalFrameBlock','ComposterBlock','ChestBlock','TrappedChestBlock','EnderChestBlock')
$matrix=Import-Csv '.native-source/20261031/1194-1204-pool54/independent-blocks-motion-audit/geometry-residual-matrix.csv'
$targetClasses=@($matrix|Where-Object {$_.release -eq '1.20.4' -and $_.constructor -notin $excluded}|Select-Object -ExpandProperty constructor -Unique)
$fixedByVersion=@{}
foreach($v in $versions){
  $root=Join-Path $base "$v/mojmap/net/minecraft/world/level/block"
  $classMap=@{}
  foreach($f in Get-ChildItem $root -Filter '*.java'){
    $txt=[IO.File]::ReadAllText($f.FullName)
    $m=[regex]::Match($txt,'(?m)(?:public\s+|protected\s+|abstract\s+|final\s+)*class\s+(\w+)(?:<[^>]+>)?\s+extends\s+(\w+)')
    if($m.Success){$classMap[$m.Groups[1].Value]=@{base=$m.Groups[2].Value;hasShape=[bool]([regex]::IsMatch($txt,'(?m)\bVoxelShape\s+(?:getShape|getCollisionShape)\s*\('))}}
  }
  $fixed=@()
  foreach($c in $targetClasses){
    $x=$c;$has=$false
    while($x -and $x -ne 'Object'){
      if($classMap.ContainsKey($x)){
        if($classMap[$x].hasShape){$has=$true;break}
        $x=$classMap[$x].base
      }else{break}
    }
    if(!$has -and $x -eq 'BlockBehaviour'){$fixed+=$c}
  }
  $fixed=@($fixed|Sort-Object -Unique)
  Write-Output "\$v fixed=$($fixed -join ',')"
  $fixedByVersion[$v]=$fixed
  Write-Output "$v default-inherited classes=$($fixed.Count)"
}
foreach($v in $versions){if(($fixedByVersion[$v] -join ',') -ne ($fixedByVersion['1.20.4'] -join ',')){throw "$v default provider set differs"}}
$roster=Get-Content '.native-source/20261031/1194-1204-pool54/independent-blocks-motion-audit/state-domain-roster.json' -Raw|ConvertFrom-Json
$out=@()
foreach($v in $versions){foreach($r in $roster){$m=$r.modern|Where-Object version -eq $v|Select-Object -First 1;if($m -and $m.constructor -in $fixedByVersion[$v]){$out += [pscustomobject]@{release=$v;id=$r.id;constructor=$m.constructor;oldMaterial=$r.oldMaterial;oldBlocksMotion=$r.oldBlocksMotion;motionGate=$m.motionGate}}}}
$out|Export-Csv -NoTypeInformation -Encoding utf8 (Join-Path $PSScriptRoot 'fixed-default-provider-handoff.csv')
"handoff rows=$($out.Count) unique IDs=$(@($out|Select-Object -ExpandProperty id -Unique).Count)"

