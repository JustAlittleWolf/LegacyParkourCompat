$ErrorActionPreference = 'Stop'
$base = 'D:/Javastuff/LegacyParkourCompat/decompiled_minecraft'
$versions = @('1.19.4','1.20','1.20.1','1.20.2','1.20.3','1.20.4')
foreach ($v in $versions) {
  $root = Join-Path $base $v; $ready = $null
  $src = Join-Path $root 'mojmap'
  if (Test-Path (Join-Path $src '.decompile-provenance.json')) {
    $p = Get-Content (Join-Path $src '.decompile-provenance.json') -Raw | ConvertFrom-Json
    $map = @{}; foreach ($prop in $p.sources.PSObject.Properties) { $map[$prop.Name] = $prop.Value }
    $identity = '.decompile-provenance.json'
    $identityHash = (Get-FileHash (Join-Path $src $identity) -Algorithm SHA256).Hash.ToLowerInvariant()
  } else {
    $ready = Get-Content (Join-Path $root 'mojmap.ready.json') -Raw | ConvertFrom-Json
    $manifestPath = Join-Path $root $ready.sourceManifest
    $identity = $ready.sourceManifest
    $identityHash = (Get-FileHash $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($identityHash -ne $ready.sourceManifestSha256) { throw "$v source manifest SHA mismatch" }
    $map = @{}
    foreach ($line in Get-Content $manifestPath) {
      if ($line -match '^([0-9a-f]{64}) \*(.+)$') { $map[$Matches[2]] = $Matches[1] } else { throw "$v malformed source hash line: $line" }
    }
  }
  $checked = 0
  foreach ($entry in $map.GetEnumerator()) {
    $path = Join-Path $src ($entry.Key -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (!(Test-Path -LiteralPath $path)) { throw "$v missing source $($entry.Key)" }
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne [string]$entry.Value) { throw "$v hash mismatch $($entry.Key)" }
    $checked++
  }
  if ($checked -ne $ready.sourceFileCount -and $ready) { throw "$v count $checked != ready count $($ready.sourceFileCount)" }
  Write-Output "$v identity=$identity sha256=$identityHash checkedSources=$checked"
}


