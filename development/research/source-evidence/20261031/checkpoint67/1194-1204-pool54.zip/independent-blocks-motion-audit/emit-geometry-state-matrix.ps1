$ErrorActionPreference = 'Stop'
$base = '.native-source/20261031/1194-1204-pool54/independent-blocks-motion-audit'
$rosterPath = Join-Path $base 'state-domain-roster.json'
$data = Get-Content -Raw -LiteralPath $rosterPath | ConvertFrom-Json
$rows = foreach ($version in @('1.20','1.20.1','1.20.2','1.20.3','1.20.4')) {
    foreach ($entry in $data) {
        $modern = $entry.modern | Where-Object version -EQ $version
        if ($modern.motionGate -EQ 'cached-shape') {
            [pscustomobject]@{
                release = $version
                id = $entry.id
                oldField = $entry.oldField
                oldMaterial = $entry.oldMaterial
                oldBlocksMotion = $entry.oldBlocksMotion
                aliasOrHelper = $entry.oldMaterialSource
                modernField = $modern.field
                constructor = $modern.constructor
                sourceLine = $modern.line
                stateDomain = 'class-defined valid BlockState domain; exhaustive states not enumerated'
                proofStatus = 'OPEN'
                reason = 'calculateSolid requires every valid state collision bounds; no complete state-bound evaluation recorded'
            }
        }
    }
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $base 'geometry-residual-matrix.csv')
$groups = $rows | Group-Object release,oldBlocksMotion,constructor | Sort-Object Name
$lines = @(
    '# Cached-shape state-domain matrix',
    '',
    'Generated from the independently preserved 997-row `state-domain-roster.json` and canonical source registrations. Each CSV row is one common raw block registration in one modern release. The provider grouping key is release + old bit + registered constructor; members use that class collision provider or inherited provider, while the valid state-domain proof remains open. Rows retain old material alias/helper lineage separately.',
    '',
    'Every `proofStatus=OPEN` row is a precise residual. No full set of valid states and exact collision bounds has been recorded for every cached-shape provider, so no statement of zero mismatches follows.',
    '',
    '## Registration-row counts',
    '',
    '| Release | Old false cached-shape | Old true cached-shape | Total |',
    '|---|---:|---:|---:|'
)
foreach ($version in @('1.20','1.20.1','1.20.2','1.20.3','1.20.4')) {
    $falseCount = @($rows | Where-Object { $_.release -EQ $version -AND -NOT $_.oldBlocksMotion }).Count
    $trueCount = @($rows | Where-Object { $_.release -EQ $version -AND $_.oldBlocksMotion }).Count
    $lines += "| $version | $falseCount | $trueCount | $($falseCount + $trueCount) |"
}
$lines += ''
$lines += '## Provider/state-domain groups with residual rows'
$lines += ''
$lines += '| Release | Old bit | Constructor/provider group | Residual registration rows |'
$lines += '|---|---:|---|---:|'
foreach ($group in $groups) {
    $parts = $group.Name -split ', '
    $lines += "| $($parts[0]) | $($parts[1]) | $($parts[2]) | $($group.Count) |"
}
$lines += ''
$lines += 'Exact residual IDs, old fields/materials, modern constructor, and registration line are in `geometry-residual-matrix.csv`. Inherited provider semantics must be checked at the exact release source; class names are a grouping index, not assumed equivalent geometry.'
$lines | Set-Content -Encoding UTF8 (Join-Path $base 'geometry-state-matrix.md')
$aliasRows = foreach ($entry in $data | Where-Object { $_.oldMaterialSource -NE 'direct' }) {
    foreach ($version in @('1.20','1.20.1','1.20.2','1.20.3','1.20.4')) {
        $modern = $entry.modern | Where-Object version -EQ $version
        [pscustomobject]@{
            id = $entry.id
            oldField = $entry.oldField
            oldMaterial = $entry.oldMaterial
            oldBlocksMotion = $entry.oldBlocksMotion
            oldMaterialSource = $entry.oldMaterialSource
            oldExpression = $entry.oldExpression
            modernRelease = $version
            modernField = $modern.field
            modernConstructor = $modern.constructor
            modernGate = $modern.motionGate
            modernValue = $modern.motionValue
            modernExpression = $modern.registrationExpression
            sourceLine = $modern.line
        }
    }
}
$aliasRows | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $base 'alias-helper-lineage.csv')
$aliasNote = @"

## Old material alias/helper rows

alias-helper-lineage.csv contains all 240 registrations whose old material is recursively obtained through a copied property or helper factory, expanded into five modern release rows each (1,200 rows). It carries old field/material/bit and source expression plus modern field, constructor, registration expression, gate and line. This is separate from the cache-backed geometry residual CSV.
"@
Add-Content -Encoding UTF8 (Join-Path $base 'geometry-state-matrix.md') $aliasNote

