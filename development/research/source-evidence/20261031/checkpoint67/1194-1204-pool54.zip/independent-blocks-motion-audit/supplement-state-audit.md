# Supplemental block-motion state audit (2026-10-31)

## Scope and outcome

This supplement extends the blind, source-only common-ID roster in `audit.md`. The 997 common registrations and their old material identities are resolved; the material bit is constant for each old block registration. Modern `BlockState.blocksMotion()` is state-specific: `BlockStateBase.initCache()` caches `collisionShape` only when the block has no dynamic shape, then computes `legacySolid`; `blocksMotion()` additionally excludes `Blocks.COBWEB` and `Blocks.BAMBOO_SAPLING` by identity.

The full raw-state truth table is **not closed**. No eligible-player movement-output candidate is accepted from this slice, and no claim of equivalence is made. State-dependent collision geometry remains unenumerated for the exact cached-shape families listed below. The decision is therefore “incomplete; no surviving candidate established,” not “no mismatch.” This separates static predicate classification from the fluid consumer/call-path results in `audit.md`.

## Exact predicate and classification

Exact source: 1.20.4 `net/minecraft/world/level/block/state/BlockBehaviour.java:471-491, 496-518`.

`calculateSolid()` returns true in order for `forceSolidOn`; false for `forceSolidOff`; false when `cache == null`; false for empty collision shape; otherwise it tests `bounds.getSize() >= 0.7291666666666666 || bounds.getYsize() >= 1.0`. `getSize()` is the mean of the three AABB extents. `initCache()` avoids creating a cache for dynamic-shape blocks, then invokes this predicate. `blocksMotion()` returns false for the two identity exceptions, else `legacySolid`.

Old truth source: 1.19.4 `net/minecraft/world/level/material/Material.java:119,134,160-183`; `blocksMotion` defaults true in `Builder` and `.noCollider()` clears it. The registration roster recursively resolves copied properties/helper factories; all 997 common registrations resolve to an old material and bit, with 775 true and 222 false.

The extracted effective modern configuration groups (identical in 1.20, 1.20.1, 1.20.2; 1.20.3 and 1.20.4 identical) are:

| Gate | 1.20–1.20.2 | 1.20.3–1.20.4 | Old bit agreement at gate |
|---|---:|---:|---|
| forceSolidOn | 178 | 195 | true |
| forceSolidOff | 8 | 8 | false |
| noCollision | 122 | 122 | false |
| cache absent from dynamic shape | 1 | 1 | false |
| identity exception (cobweb, bamboo sapling) | 2 | 2 | false |
| collision-bounds predicate required | 686 | 669 | 597 true / 89 false |

The 17-row change from cached-shape to force-on between 1.20.2 and 1.20.3 is registration/property-flag lineage, not a shape outcome. Every decisive flag/identity gate agrees with the old bit. The remaining state-dependent rows all require collision-shape bounds to decide.

## Geometry checked as boundary controls

These controls are source/formula checks, not a claim that all cached-shape families have been enumerated:

- Bottom/top slabs have bounds `1 × 1/2 × 1`, giving mean `5/6`, above the threshold. Double slabs are full height.
- Stair shape unions span one block on all axes, regardless of facing, half, or stair shape; their bounds meet the predicate.
- Door bounds have two full extents and one `3/16` extent; the mean is exactly the source threshold. Trapdoors likewise retain two unit extents and a `3/16` extent in their closed/open orientations. This is equality, not a rounding approximation.
- Beds have `1 × 9/16 × 1` bounds. Carpets have `1 × 1/16 × 1` bounds and are old-false (`CLOTH_DECORATION`), thus below threshold as expected.
- The previously questioned stone slab is old-true (`STONE`): its mean bound is `5/6`, not below threshold. Snow layer is old-false (`TOP_SNOW`) and modern no-collision; it is not the old `SNOW` material.

## Remaining open state families

The exact common-ID rows and per-version constructor/gate/expression data are in `state-domain-roster.json`. The shape-gated families below are deliberately still open as a complete raw-valid-state enumeration. Counts are registration rows, not state counts.

Old-false cached-shape rows (89 each release): `FlowerPotBlock` 35; `WoolCarpetBlock` 16; `CandleBlock` 17; `SkullBlock` 5; `WallSkullBlock` 4; `CarpetBlock`, `CocoaBlock`, `ComparatorBlock`, `LightBlock`, `PiglinWallSkullBlock`, `PlayerHeadBlock`, `PlayerWallHeadBlock`, `RepeaterBlock`, `SeaPickleBlock`, `WaterlilyBlock`, `WitherSkullBlock`, and `WitherWallSkullBlock` 1 each.

Old-true cached-shape rows (597 each release through 1.20.2; 580 in 1.20.3/1.20.4 after the 17 force-on transitions) include these state-variable families requiring all legal shape states checked: `SlabBlock`, `StairBlock`, `DoorBlock`, `TrapDoorBlock`, `FenceBlock`, `StainedGlassPaneBlock`/`IronBarsBlock`, `BedBlock`, `LayeredCauldronBlock`/`LavaCauldronBlock`, `CampfireBlock`, `ComposterBlock`, `CactusBlock`, `FarmBlock`, `DirtPathBlock`, `HoneyBlock`, `MudBlock`, `SoulSandBlock`, `SnowyDirtBlock`, `LeavesBlock` and its species subclasses, `PistonBaseBlock`, `PistonHeadBlock`, `HugeMushroomBlock`, `CoralBlock`, and `SculkShriekerBlock`. The remaining old-true rows include static-full/cuboid and custom collision classes; each still belongs to the unclosed set until state bounds (or a justified invariant) are recorded. The roster is the exhaustive member list; this grouped list calls out property/state-dependent families, not a filtered candidate list.

In particular, no candidate is inferred merely from a thin or empty collision shape: `forceSolidOn`, `forceSolidOff`, `noCollision`, dynamic cache absence, and the identity exceptions precede/use distinct gates exactly as above.

## Reproduction and source identity

`derive-state-roster.ps1` produces the state-domain roster from the frozen registration-expression and roster inputs, resolving old material copy/helper chains and modern property copy/helper chains. Run from the project root in PowerShell:

```powershell
& '.native-source/20261031/1194-1204-pool54/independent-blocks-motion-audit/derive-state-roster.ps1' | Out-Null
```

The roster records each common block ID, old field/material/expression/bit, and all five modern registration expressions, constructors, raw flags, effective property flags, and selected motion gate. This reproduces registration/property-gate counts, not a geometry/state-table proof.

The source root is the read-only canonical `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<release>/mojmap`. Release identity is bound by the root sidecars for 1.19.4 (`6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3`), 1.20.1 (`858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465`), 1.20.2 (`e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887`), and 1.20.4 (`fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1`); 1.20 and 1.20.3 are bound by their `mojmap/.decompile-provenance.json` hashes `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` and `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` respectively. No network/mapping lookup or candidate output was used.
