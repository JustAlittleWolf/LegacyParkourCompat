$ErrorActionPreference = 'Stop'
$root = 'D:/Javastuff/LegacyParkourCompat/decompiled_minecraft'
$outDir = 'C:/Users/Wolfi/.codex/worktrees/56a8/LegacyParkourCompat/.native-source/20261031/1194-1204-pool54/independent-blocks-motion-audit'
$versions = @('1.19.4','1.20','1.20.1','1.20.2','1.20.3','1.20.4')
$results = @()
function Find-CallEnd([string]$s,[int]$start) {
    $depth=0; $quote=[char]0; $escaped=$false
    for($i=$start;$i -lt $s.Length;$i++) {
        $c=$s[$i]
        if($quote -ne [char]0) { if($escaped){$escaped=$false} elseif($c -eq '\'){$escaped=$true} elseif($c -eq $quote){$quote=[char]0}; continue }
        if($c -eq '"' -or $c -eq "'"){$quote=$c;continue}
        if($c -eq '('){$depth++} elseif($c -eq ')'){$depth--;if($depth -eq 0){return $i}}
    }
    throw 'Unclosed call'
}
foreach($v in $versions) {
    $dir=Join-Path $root "$v/mojmap"
    $blocksPath=Join-Path $dir 'net/minecraft/world/level/block/Blocks.java'
    $src=[IO.File]::ReadAllText($blocksPath)
    $refs=@{}
    $refPath=Join-Path $dir 'net/minecraft/references/Blocks.java'
    if(Test-Path $refPath){ $rt=[IO.File]::ReadAllText($refPath); foreach($m in [regex]::Matches($rt,'ResourceKey<Block>\s+(\w+)\s*=\s*createKey\("([^"]+)"\)')){$refs[$m.Groups[1].Value]=$m.Groups[2].Value} }
    $roster=@()
    $rx='public\s+static\s+final\s+Block\s+(\w+)\s*=\s*register\s*\('
    foreach($m in [regex]::Matches($src,$rx)) {
        $end=Find-CallEnd $src ($m.Index+$m.Length-1)
        $args=$src.Substring($m.Index+$m.Length,$end-($m.Index+$m.Length))
        $first=[regex]::Match($args,'^\s*(?:"([^"\\]*(?:\\.[^"\\]*)*)"|([\w.]+))')
        if(!$first.Success){throw "$v missing registration key for $($m.Groups[1].Value)"}
        $kind='string';$id=$first.Groups[1].Value
        if(!$first.Groups[1].Success){$key=$first.Groups[2].Value;$kind='symbol';$short=$key.Split('.')[-1];if($refs.ContainsKey($short)){$kind='ResourceKey';$id=$refs[$short]}else{$id=$key}}
        $roster+=@{field=$m.Groups[1].Value;id='minecraft:'+ $id;idKind=$kind}
    }
    $prov=Join-Path $dir '.decompile-provenance.json';$manifest=Join-Path $root "$v/mojmap.sources.sha256"
    if(Test-Path $prov){$identity='provenance sha256 '+(Get-FileHash -Algorithm SHA256 $prov).Hash;$data=Get-Content $prov -Raw | ConvertFrom-Json;$expected=$data.sources.PSObject.Properties['net/minecraft/world/level/block/Blocks.java'].Value}
    elseif(Test-Path $manifest){$identity='mojmap.sources.sha256 sha256 '+(Get-FileHash -Algorithm SHA256 $manifest).Hash;$line=Select-String -Path $manifest -Pattern '\*net/minecraft/world/level/block/Blocks.java$'|Select-Object -First 1 -ExpandProperty Line;$expected=($line -split '\s+')[0]}
    else{throw "No source identity for $v"}
    $actual=(Get-FileHash -Algorithm SHA256 $blocksPath).Hash
    if($expected -and $expected.ToLower() -ne $actual.ToLower()){throw "Blocks.java hash mismatch for $v"}
    $results+=@{version=$v;identity=$identity;blocksSha256=$actual;registryEntryCount=$roster.Count;resourceKeyBackedCount=@($roster|Where-Object idKind -eq ResourceKey).Count;stringBackedCount=@($roster|Where-Object idKind -eq string).Count;unresolved=@($roster|Where-Object {$_.id -like '*UNRESOLVED*'}).Count;roster=$roster}
    Write-Output "$v count=$($roster.Count) ResourceKey=$(@($roster|Where-Object idKind -eq ResourceKey).Count) string=$(@($roster|Where-Object idKind -eq string).Count) hash=$actual $identity"
}
$results | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 (Join-Path $outDir 'registration-rosters.json')

