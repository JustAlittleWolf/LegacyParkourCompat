# Independent block-motion and fluid audit

Scope: exact local Mojmap sources for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4. This report was derived without reading sibling campaign outputs, implementations, wiki material, Git history, online mappings, or network sources. No game, build, test, or decompile was run.

## Source identity and report binding

Source root: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap/`. The exact source-set identities supplied by the source owner were independently checked against the local root sidecars/manifests:

| Release | Identity file SHA-256 |
| --- | --- |
| 1.19.4 | `mojmap.sources.sha256`: `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` |
| 1.20 | `.decompile-provenance.json`: `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` |
| 1.20.1 | `mojmap.sources.sha256`: `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` |
| 1.20.2 | `mojmap.sources.sha256`: `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` |
| 1.20.3 | `.decompile-provenance.json`: `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` |
| 1.20.4 | `mojmap.sources.sha256`: `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` |

Every inspected source file listed in `source-hashes.json` matched its own entry in that release's manifest/provenance source map. That hash matrix includes `Blocks.java`, `BuiltInRegistries.java`, `Block.java`, `BlockBehaviour.java`, `SlabBlock.java`, `AABB.java`, `FlowingFluid.java`, `Material.java` where present, `Entity.java`, `LivingEntity.java`, and `references/Blocks.java` where present.

| Artifact | SHA-256 |
| --- | --- |
| `registration-rosters.json` | `79c7064725deaaa997871e24f9fe61de88ffebb49ec7d4e3096a024bfe77f437` |
| `source-hashes.json` | `bf825b2d01a199d8a0ca010174204ea2f9680279fc1acda132393972ece45909` |
| `extract-rosters.ps1` | `d7bced64bd7ee6a94f1c03854c0867812f710532feb3ce8760ebee90f271db11` |

The roster is reproducible with `extract-rosters.ps1` in this directory from PowerShell. It lexes each `Blocks.java` registration call with balanced-parenthesis handling, resolves `ResourceKey` names through `net/minecraft/references/Blocks.java`, rejects missing IDs, and verifies each `Blocks.java` hash against its exact source identity.

## Registration universe

The complete `Blocks` field-registration roster contains 998, 1003, 1003, 1003, 1058, and 1058 entries, respectively. The intersection across all six releases is 997 IDs; the union is 1059 IDs. There are no duplicate or unresolved registry IDs in any roster.

| Release | String-ID registrations | ResourceKey-ID registrations | Total |
| --- | ---: | ---: | ---: |
| 1.19.4 | 998 | 0 | 998 |
| 1.20 | 1003 | 0 | 1003 |
| 1.20.1 | 1003 | 0 | 1003 |
| 1.20.2 | 1003 | 0 | 1003 |
| 1.20.3 | 1052 | 6 | 1058 |
| 1.20.4 | 1052 | 6 | 1058 |

The registration deltas are: 1.19.4→1.20 adds `calibrated_sculk_sensor`, `pitcher_crop`, `pitcher_plant`, `sniffer_egg`, and `suspicious_gravel`; 1.20→1.20.1 and 1.20.1→1.20.2 have no ID delta; 1.20.2→1.20.3 adds 56 IDs and removes `grass` in favor of `short_grass`; 1.20.3→1.20.4 has no ID delta. The full sorted field-to-ID roster is in `registration-rosters.json`.

The registry writer is `Blocks.register(String, Block)` on all sides. The `Blocks.register(ResourceKey<Block>, Block)` overload is present from 1.20.2; exactly six built-in fields use it in 1.20.3 and 1.20.4, resolving to `minecraft:pumpkin`, `minecraft:pumpkin_stem`, `minecraft:attached_pumpkin_stem`, `minecraft:melon`, `minecraft:melon_stem`, and `minecraft:attached_melon_stem`. The `BuiltInRegistries.BLOCK` search found no additional block-registry writer outside `Blocks.java`; other `BLOCK_*` hits were distinct registries such as block entity types and block predicate types.

## Motion predicate and dependency trace

In 1.19.4, `BlockBehaviour.BlockStateBase` holds a `Material`; the relevant predicate is `Material.blocksMotion()` (1.19.4 `Material.java`, lines 108–135). `Material.Builder` starts with `blocksMotion = true` and `.noCollider()` sets it false (lines 160–183). `BlockBehaviour.Properties.noCollission()` separately clears `hasCollision` and `canOcclude`; it does not rewrite that material flag (1.19.4 `BlockBehaviour.java`, lines 929–933). Property copies carry the material and collision settings.

Starting in 1.20, the deprecated block-state `blocksMotion()` uses `isSolid()`, backed by `legacySolid`. `initCache()` creates a per-state collision cache unless `dynamicShape` is set, then calls `calculateSolid()` (1.20/1.20.1 `BlockBehaviour.java`, lines 428–472). The calculation is ordered: `forceSolidOn` returns true; otherwise `forceSolidOff` returns false; otherwise a missing cache or empty collision shape returns false; otherwise it checks the cached collision-shape bounds, with `getSize() >= 0.7291666666666666` or `getYsize() >= 1.0`. `AABB.getSize()` is the arithmetic mean of the three extents, not volume (1.20.1 `AABB.java`, lines 243–253). `blocksMotion()` then explicitly returns false for `COBWEB` and `BAMBOO_SAPLING` before consulting `isSolid()`.

That predicate body and order are unchanged through 1.20.4. The core dependency changes are pinned in the source hash matrix: `BlockBehaviour.java` changes at 1.20, 1.20.2, and 1.20.3; its `calculateSolid()`/`blocksMotion()` bodies remain identical across those changes. `Blocks.java` also changes in 1.20.2 and 1.20.3, but the roster accounts for the new and removed IDs. Static property copies preserve the collision, dynamic-shape and force-solid settings (`Properties.copy` in 1.20.1; `ofLegacyCopy` and `ofFullCopy` in 1.20.4). Shared block factories in `Blocks.java` include the `stair`, `legacyStair`, `shulkerBox`, `pistonBase`, button, pot, and candle constructors; all feed into the same cached state predicate.

The key exceptions checked against their old material identity show the intent of the overrides: pressure plates use `forceSolidOn` in modern registrations although their collision shape is thin; the 1.19.4 registrations use `Material.STONE`, `WOOD`, or `METAL`, all of whose builders retain `blocksMotion=true`. Chain, signs, wall signs, dynamic moving piston, shulker boxes, and other narrow/dynamic collision cases are also marked `forceSolidOn`. `LADDER`, `SNOW`, `END_ROD`, and selected plant-like blocks use `forceSolidOff` where old registration materials are non-blocking; for snow specifically, 1.19.4 uses `Material.TOP_SNOW`, whose `.noCollider()` makes `blocksMotion=false`. Cobweb's old `Material.WEB` is non-blocking and its modern special-case remains false despite `forceSolidOn` supporting its separate `isSolid()` value. These examples were cross-checked directly; this report does not infer a complete per-state classification for all 1,059 IDs from those examples.

## Movement-reachable fluid use

`FlowingFluid.getFlow()` is the direct fluid-motion use: it walks horizontal neighbors, accepts empty or same-type adjacent fluid (`affectsFlow`), checks the neighbor's block motion predicate when the neighbor fluid height is zero, then samples fluid below that neighbor. The 1.19.4 call is `getBlockState(pos).getMaterial().blocksMotion()` (`FlowingFluid.java`, lines 53–103); 1.20 onward calls `getBlockState(pos).blocksMotion()` at the same point. `Entity` invokes `FluidState.getFlow()` while updating entity fluid pushing and adds the resulting vector to movement (`Entity.java`, 1.19.4 lines 2917–2923; 1.20.1 lines 3031–3037). This path is reachable for players and affects movement output.

`LivingEntity.randomTeleport()` also reads this predicate while searching downward for a landing block (1.19.4 around lines 3037–3040; 1.20.1 around lines 3059–3063); it is a direct player-position response when invoked for a player. Its call-order and predicate substitution were inspected.

`FlowingFluid.canHoldFluid()` and `canSpreadTo()` were checked in all six exact releases. `canSpreadTo()` retains the same three-part conjunction. `canHoldFluid()` changes its material exclusions to concrete portal/structure block IDs in 1.20, and 1.20.2 adds a `null` player argument to `LiquidBlockContainer.canPlaceLiquid`; the latter body then remains identical through 1.20.4. These decide where native fluid simulation can place/spread fluid; they are not themselves player movement outputs for equal raw block/fluid states. Differences in later world state from native fluid simulation are outside this equal-input movement comparison. No evidence here authorizes historical fluid simulation.

## Candidate verdict, exclusions, and completeness

No eligible equal-state movement difference is accepted from this audit. The direct `getFlow()` and player `randomTeleport()` consumers were traced, but an exhaustive equivalence proof over every registered block's every state-specific collision shape has not been completed. Therefore the **registration universe and method/call-path inventory are complete; the block-motion classification slice is not complete**, and absence of a candidate is not a pair-level no-difference verdict.

Excluded or rejected leads:

- Stone slab: rejected. A 1×0.5×1 collision-shape bound has `getSize() = (1 + 0.5 + 1) / 3 = 0.8333…`, above the modern threshold, so it does not establish a changed `blocksMotion` value.
- Snow layer: rejected. The 1.19.4 block uses `Material.TOP_SNOW`, not `Material.SNOW`; `TOP_SNOW.noCollider()` sets its old `blocksMotion` false, matching the modern `forceSolidOff()` result.
- `canHoldFluid`/`canSpreadTo`: excluded as world fluid placement/spread decisions rather than immediate movement output under equal raw inputs.
- Enderman, dolphin AI, heightmaps, rendering/occlusion and non-player lava/fluid simulation consumers: excluded from the requested player-movement output slice.

Open gate: enumerate/compare the old material motion bit against modern calculated cached solidity for all valid states of the common 997-ID intersection, following each registered class's collision shape, state-dependent shape, dynamic cache, copied properties and force-solid flags. Then reconcile each per-state result with the direct movement consumers above. Until that gate is closed, do not claim the complete block/fluid slice has no movement difference.
