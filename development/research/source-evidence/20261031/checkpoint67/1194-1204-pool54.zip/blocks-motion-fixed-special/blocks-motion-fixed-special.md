# Fixed full-cube special shape families

Bounded source-only continuation over `shape-provider-residual.csv`. The residual input SHA-256 is `b5ed33bdbd04f23d79954520c35e8ddc7fc0548fab e1bbfd51288eb9e29af72f` (spaces omitted: `B5ED33BDBD04F23D79954520C35E8DDC7FC0548FABE1BBFD51288EB9E29AF72F`). Source-set identities are from the verified Mojmap manifest sidecars; all source-file records in the supplied `source-hashes.json` matched their source identities.

| Release | Mojmap source identity SHA-256 |
|---|---|
| 1.19.4 | `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3` |
| 1.20 | `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` |
| 1.20.1 | `858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465` |
| 1.20.2 | `e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887` |
| 1.20.3 | `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f` |
| 1.20.4 | `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1` |

## Closed family slice

Selected registrations: `RotatedPillarBlock`, `GlazedTerracottaBlock`, `ConcretePowderBlock`, `StainedGlassBlock`, `SlimeBlock`, `SpongeBlock`, `InfestedBlock`, and `LeavesBlock` (116 distinct IDs; 580 rows across the five modern releases). In each of the six exact releases these classes declare no `getShape` override. Their superclass chains likewise resolve to `BlockBehaviour.getShape`, which returns the block state shape. The relevant classes and inheritance chains were checked in every release. `BlockStateBase.Cache` obtains its collision shape through `BlockBehaviour.getCollisionShape`; these registrations use default `hasCollision=true` and default `forceSolidOn=false` / `forceSolidOff=false`, and do not set dynamic shape. The inherited state shape is `Shapes.block()`, whose bounds are `[0,1] × [0,1] × [0,1]`.

The 1.20+ calculation is `forceSolidOn`, `forceSolidOff`, cache absent, empty shape, then bounds (`AABB.getSize() >= 0.7291666666666666 || getYsize() >= 1.0`). Default false force flags and the cached unit cube make every selected row true. The input's old `Material.blocksMotion()` bit is true for every selected ID. Thus there are zero mismatches for this selected family slice. The per-ID/per-release values are in `fixed-full-cube-parity.csv`.

Exact method anchors (same relevant bodies across releases): `BlockBehaviour.getShape` around line 329, `getCollisionShape` around 335, `BlockStateBase.Cache.calculateSolid` around 471, `BlockBehaviour.Properties` defaults for collision/force flags around 960–978, and `Shapes.block` around line 42 in 1.20.4. The 1.20.3/1.20.4 `StainedGlassBlock` superclass changes from `AbstractGlassBlock` to `TransparentBlock`; neither adds a shape override, so the result is unchanged.

## Remaining work and limits

The other 722 IDs (3,610 release rows) remain unclassified in this worker output. All varying state/context/dynamic providers remain open, as do other potentially fixed-shape subclass families until individually traced. This is not a complete provider residual closure or pair-level coverage claim. No exact intermediate patch boundary is established.

