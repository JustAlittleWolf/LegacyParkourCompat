# Independent review: direct player response closure

## Verdict

The central finding is source-supported: the 1.20 `UPDATE_GAME_MODE` response clears only local-player Y velocity on a changed game mode targeting spectator. The closure's specific exclusions for the 1.20.2 remote interpolation rewrite are supported by the local-player control gate. No contrary source evidence was found in the bounded checks below.

This is a bounded review, not a full independent audit of every method-body hash or all six source manifests. The coordinating agent requested wind-down before that full audit was complete. Treat the closure's broad inventory and complete provenance-manifest assertions as not independently certified by this review.

## Verified source evidence

- Exact Java source file hashes for the mode-update witness match the closure for 1.19.4 and 1.20: `ClientPacketListener.java` is `bcc74e52a32d20a3e993ebe4e08fffe8caca7481fad8f326dacdc93796b2b715` / `8b21ccd4106abb0698f6872250e665ae3f0fc942c8953b9ddd45976660ed624b`; `LocalPlayer.java` is `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58` / `69a2d043d2c0595bd364d625a5445e4934d9e07fef020cd79fafb42f59952ac2`; `ClientboundPlayerInfoUpdatePacket.java` is `cbbd8a6a2b8023c337ed8676762e5f4f61dcfc2d5dec050b5ed62eafbcf275ca` in both.
- In 1.19.4, `ClientPacketListener.applyPlayerInfoUpdate`'s `UPDATE_GAME_MODE` arm only sets the cached `PlayerInfo` mode. In 1.20 through 1.20.4, it first requires cached mode inequality, a non-null `minecraft.player`, and matching local player UUID to the entry profile UUID; then it calls `LocalPlayer.onGameModeChanged` before storing the new cached mode.
- `LocalPlayer.onGameModeChanged` is present in 1.20 through 1.20.4 and only acts for `GameType.SPECTATOR`, replacing the Y component of current delta movement with `0.0`. The `Vec3.with(Axis.Y, ...)` operation leaves X/Z components unchanged. The exact listed callback line locations are 1.20/1.20.1 at 1053–1057 and 1.20.2–1.20.4 at 1052–1056.
- The packet dispatch through `ClientboundPlayerInfoUpdatePacket.handle(ClientGamePacketListener)` exists in the checked sources; source file hash is identical for 1.19.4 and 1.20 as reported.
- `LocalPlayer.isEffectiveAi()` returns true in the checked endpoint sources (1.19.4 and 1.20.4); `Entity.isControlledByLocalInstance()` uses the controlled passenger's local-player test or `isEffectiveAi()`. The packet movement handlers gate interpolation and on-ground writes behind `!isControlledByLocalInstance()`. This supports excluding the altered remote entity interpolation behavior for an ordinary local player. I did not exhaustively re-open the intermediate control helpers or all adjacent packet handlers.
- `handleExplosion` in 1.19.4 retains the player knockback as `setDeltaMovement(current.add(packet knockback))`; 1.20.3+ forwards additional interaction/particle properties into `Explosion`. I did not independently validate every explosion finalization branch, but nothing in the checked handler changes the explicit player knockback operation.

## Source identity and coverage limits

All six assigned roots exist with the described sidecar or embedded provenance layout. The 1.19.4 source manifest had 4,740 entries and all 4,740 source hashes matched the tree. The 1.20.1 source manifest had 4,786 entries and all 4,786 source hashes matched the tree. Hash checks of the main witness files were made across all six releases; intermediate and later hashes are recorded in the terminal command output available to the coordinator, but were not transcribed here. I did not complete per-file manifest validation for 1.20, 1.20.2, 1.20.3 or 1.20.4, nor independently confirm every ready/provenance digest, jar/mapping identity or listed packet-handler body hash.

No test, build, launch, decompile, network lookup, Git operation, product/wiki/backlog inspection, or delegation was performed.
