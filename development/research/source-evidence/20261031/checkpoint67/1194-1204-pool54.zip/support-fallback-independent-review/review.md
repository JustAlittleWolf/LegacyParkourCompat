# Independent review: support fallback threshold supplement

## Verdict

The supplement's central source claim is confirmed. The 1.19.4 double fallback and the 1.20–1.20.4 float-argument fallback can return different Y cells for the same player coordinates and block state. This is reachable with an empty support cache and affects both movement speed damping and the shallow-water grounded-jump path. The supplement is additional evidence for the existing `getBlockPosBelowThatAffectsMyMovement` selector operation; it does not establish a separate operation.

## Source identity and expression/cutover

I read the assigned supplement and independently checked `Entity.java` in all six canonical Mojmap trees under `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap`. Direct SHA-256 values match the supplement:

| Release | Entity.java SHA-256 | Provenance source |
| --- | --- | --- |
| 1.19.4 | `3667fee610cbc5f58012e3a8fb8d6c4849f649fb7fe5300595158112d8b4b58b` | root `mojmap.sources.sha256` and `mojmap.provenance.json` |
| 1.20 | `94b9c3656715de2d61fa9a02ccef164261e50eb13d6090a6f07e58fe9c5b0759` | embedded `mojmap/.decompile-provenance.json` source entry |
| 1.20.1 | `94b9c3656715de2d61fa9a02ccef164261e50eb13d6090a6f07e58fe9c5b0759` | root `mojmap.sources.sha256` and `mojmap.provenance.json` |
| 1.20.2 | `d7ee49aaea5e862b92508e767562cabc8f10515605e8fb67565c8c8d5c23b01b` | root `mojmap.sources.sha256` and `mojmap.provenance.json` |
| 1.20.3 | `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9` | embedded `mojmap/.decompile-provenance.json` source entry |
| 1.20.4 | `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9` | root `mojmap.sources.sha256` and `mojmap.provenance.json` |

The root manifests identify their exact release and `mojmap` namespace. The embedded provenance maps contain the same `Entity.java` hashes as the files; their input metadata pins the associated version client/mapping inputs. The six source files contain the claimed cutover: 1.19.4 `Entity.getBlockPosBelowThatAffectsMyMovement()` returns `BlockPos.containing(position.x, boundingBox.minY - 0.5000001, position.z)` (line 760); 1.20 first calls `getOnPos(0.500001F)` (line 790); that call remains in 1.20.1 (790), 1.20.2 (792), 1.20.3 (793) and 1.20.4 (793). Each 1.20+ `getOnPos(float)` empty-cache branch floors `position.y - amount`.

At `Y=1.5000005`, the old double expression is `1.0000004`, which floors to 1. Java widens the exact float argument `0.500001F` to double for subtraction; the resulting Y is `0.9999994867210388`, which floors to 0. The ordinary entity box has `minY == position.y`, so substituting its feet coordinate does not erase the split.

For a populated support cache, the 1.20+ `getOnPos(0.500001F)` path uses the cached block's X/Z, but since the argument is greater than `0.5F`, its ordinary non-fence/wall/gate branch replaces Y with `floor(position.y - amount)` (`Entity.java` 1.20.2 lines 800–815). With aligned cached X/Z, the same threshold still selects Y=0 where the old direct expression selects Y=1. A cache with different X/Z can independently shift the sampled column, so that extra difference should not be attributed to this threshold. The supplement's empty-cache witness avoids that confound and is sufficient on its own.

## Reachability and witnesses

`Entity.move()` calls `setOnGroundWithKnownMovement(verticalCollisionBelow, resolvedMovement)` after resolving collisions (1.20.2 `Entity.java` line 642). `checkSupportingBlock(false, ...)` empties `mainSupportingBlockPos` (lines 583–586), so an ordinary airborne movement read reaches the empty-cache fallback. The same `move()` path calls `getBlockSpeedFactor()` unconditionally before multiplying X/Z delta movement (line 703; 1.19.4 line 660). Both versions use the current block's factor unless it is 1.0; otherwise they consult this selector (1.20.2 lines 825–830, 1.19.4 lines 750–757).

* **Honey speed fixture:** At X/Z=0.5, Y=1.5000005, with air at `(0,1,0)`, honey at `(0,0,0)`, and no fluid, the empty-cache selector returns air in 1.19.4 and honey in 1.20+. Current block speed is 1.0 in both. `Blocks.HONEY_BLOCK` has `.speedFactor(0.4F)` in 1.20.2 `Blocks.java` line 6660 (the supplement's cited earlier source also matches). Thus equal nonzero horizontal movement input is retained on the old lookup and multiplied by 0.4 on the new lookup.
* **Shallow-water jump fixture:** With flowing water `LEVEL=7` at `(0,1,0)`, honey at `(0,0,0)`, and the player at the same Y, `FlowingFluid.getOwnHeight()` is amount/9F and `WaterFluid.getAmount()` returns `LEVEL`; the water surface is `1 + 7/9`. `Entity.updateFluidHeightAndDoFluidPushing()` deflates the AABB by 0.001 and records the positive surface overlap (1.20.2 lines 3036, 3054–3059), about 0.27678 here. `getFluidJumpThreshold()` is 0.4 (Entity line 3111). In `LivingEntity.aiStep()`, when jumping, in water, and at/below that threshold, `jumpFromGround()` runs even though `onGround()` is false (lines 2561–2575). The block at `blockPosition()` is water and has jump factor 1.0, so `getBlockJumpFactor()` falls through to the selector (Entity lines 819–823). The old selector returns water (factor 1); the new selector returns honey (`.jumpFactor(0.5F)`, `Blocks.java` line 6660). With no Jump Boost, `getJumpPower()` is multiplied by that factor (LivingEntity lines 2003–2004), changing the vertical velocity write. Honey's collision top at Y=1 is below the feet; water is non-colliding, so these blocks do not ground the player.

All four supplemental fixture source hashes recorded for 1.20.2 and both recorded 1.19.4 fixture hashes were recomputed directly and match. The movement consumers and the values above are source-derived; no runtime trajectory is claimed.

## Classification

This is a second concrete applicability witness for the same `Entity.getBlockPosBelowThatAffectsMyMovement()` operation used by speed and jump-factor readers. The speed/jump consumers are separate call sites but not separate selector operations. Keep the supplement with the existing support-selector finding; do not open a duplicate finding for the precision witness.
