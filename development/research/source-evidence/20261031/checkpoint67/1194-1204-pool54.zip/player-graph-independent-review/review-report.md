# Independent review: 1.19.4–1.20.4 player graph closure

## Verdict

**Accept the 1.19.4→1.20 fall-distance reset difference as movement-eligible, with a narrowed movement claim.** The source change is not only fall tracking: for Slow Falling, resetting before travel in 1.20 can change the input to the local player's same-tick edge-backoff movement guard. Do not justify it through fall damage or attack bookkeeping. The Levitation reset relocation is source-confirmed, but the report does not yet establish a distinct on-foot movement consequence for the common ground-travel branch, where 1.19.4 already resets before `Entity.move`.

The core source identities and the reported method inventory are consistent with the six canonical Mojmap roots. This review does **not** close the pair: the closure report explicitly leaves block/provider, fluid-flow, external packet/effect inputs, and non-on-foot branches open, and it does not inspect intermediate patch releases. Its coverage is a bounded core player-graph audit, not full-pair freeze.

## Input identity and integrity

Literal `Test-Path -LiteralPath` and `Get-Item -LiteralPath` checks succeeded for `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.19.4/mojmap` before the other roots were read. The same exact-root check succeeded for 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4. Four releases use adjacent `mojmap.sources.sha256` / ready / provenance files; 1.20 and 1.20.3 instead use the hidden `.decompile-provenance.json` inside the source root. Hidden entries were enumerated with `-Force`.

I independently compared the four core source-file SHA-256s (`LocalPlayer`, `Player`, `LivingEntity`, `Entity`) against those source manifests for all six roots; all 24 match. The adjacent ready manifest matches its sidecar digest for every sidecar-backed root. The closure report SHA-256 is exactly the assigned prior-child identity `37E48511DD6DE65BF0DF19A5662AFEE67A87AA705C66A7E35E42F81E75039AF1`.

| Version | Source root | `LivingEntity.java` SHA-256 | `Player.java` SHA-256 |
| --- | --- | --- | --- |
| 1.19.4 | `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.19.4/mojmap` | `c8d91af61f87aaa1666de79696d7cd9d4a8212d05f873bdaf28d7bb2926bf165` | `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2` |
| 1.20 | `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20/mojmap` | `decf8cd70d194098ad51d0c82e5a0087e0687881e0a2dc66456f2ba6ea76676f` | `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac` |
| 1.20.1 | `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20.1/mojmap` | `decf8cd70d194098ad51d0c82e5a0087e0687881e0a2dc66456f2ba6ea76676f` | `873d82c6f5471d06812929e471d970fd973bfbe21638e4e348a6fcde45637dac` |
| 1.20.2 | `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20.2/mojmap` | `5c481da1ffc8684c4b30171c92e61fad751e6a3a708d5bc6486ac9f96ff69828` | `25f263692fd6b2a737aa813315022a0caf4e18c3661ba3bd706c6297f909f25c` |
| 1.20.3 | `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20.3/mojmap` | `f7bc53db24c1798f19f9bd6f6356c86d5e560e9c8e8aac60decaf15cc785e07d` | `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd` |
| 1.20.4 | `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.20.4/mojmap` | `f7bc53db24c1798f19f9bd6f6356c86d5e560e9c8e8aac60decaf15cc785e07d` | `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd` |

Bound input artifacts: `closure-report.md` SHA-256 `37E48511DD6DE65BF0DF19A5662AFEE67A87AA705C66A7E35E42F81E75039AF1`; `source-identities.txt` `DBBCE22F543595775B80805B7049D9B849F4398BA48FB7B73F3302BFF2A24156`; `dependency-identities.txt` `12E2B5AE95AB11AA287D33BAE180FBCB04D004F84815149901059F17E4BE61A8`; `method-caller-matrix.txt` `BA62C41D5C2C486FE29B0060E92AC8E62B7A3E1E3A4FABC396B2002D6D802C71`; `relevant-method-diffs.txt` `152737D1934C16045D7291EDA0FC7EABCC6F6BF92E24108E4027B256FA0021A8`.

## Reset timing and on-foot movement path

The virtual path reaches the changed code for the local player: 1.19.4 `LocalPlayer.aiStep` calls `super.aiStep()` at lines 645–795, and `Player.aiStep` calls `super.aiStep()` at lines 499–516; the corresponding 1.20 calls are at `LocalPlayer.java` 648–801 and `Player.java` 500–517. That dispatch reaches `LivingEntity.aiStep` before it calls virtual `travel`. The exact full-file hashes are recorded above and in the bound `source-identities.txt` artifact.

In 1.19.4, `LivingEntity.travel` only resets for Slow Falling inside `isControlledByLocalInstance()` when the pre-travel vertical velocity is already nonpositive: `getDeltaMovement().y <= 0.0` and `hasEffect(SLOW_FALLING)` at lines 1983–1990. In 1.20, `LivingEntity.aiStep` resets whenever either Slow Falling or Levitation is present, before the `travel` / `travelRidden` dispatch at lines 2565–2573. For an equal starting state with Slow Falling, `0.003 <= deltaMovement.y < 0.08`, no Levitation, no jump, no water/elytra branch, gravity enabled, local control and otherwise equal travel inputs, the old predicate does not reset. The ordinary gravity path subtracts `0.08` from vertical travel velocity in 1.19.4 `LivingEntity.travel` lines 2103–2110, so it can request a nonpositive SELF move while retaining the incoming nonzero fall distance. The corresponding 1.20 path requests the same movement delta after first clearing fall distance.

That state is read by the player's movement code in both releases. `LivingEntity.travel` issues a virtual SELF move; `LocalPlayer.move` delegates with `super.move` before its auto-jump postprocessing (1.19.4 `LocalPlayer.java` 880–885; 1.20 872–877). `Entity.move` calls virtual `maybeBackOffFromEdge` before collision resolution (1.19.4 `Entity.java` 549–569; 1.20 lines 593–613). The dispatch reaches `Player.maybeBackOffFromEdge` (1.19.4 `Player.java` 1041–1093; 1.20 1043–1095), whose gate requires nonflying, requested `y <= 0`, SELF/PLAYER mover type, `isStayingOnGroundSurface()` and `isAboveGround()`. `isStayingOnGroundSurface()` is the shift-key predicate in both (`Player.java` 308–310 / 309–311). `isAboveGround()` reads `fallDistance` directly and compares it with `maxUpStep()` before a downward `noCollision` query (`Player.java` 1095–1099 / 1097–1101). Equal geometry and raw input can therefore make the old/new fall-distance input select different edge-backoff behavior; the claim is movement-eligible under the project rule for direct player responses/predicates. It is conditional on the method gates and collision geometry; no particular trajectory outcome is claimed.

The Levitation clause also moves the reset earlier. In the ordinary ground branch, however, the 1.19.4 reset at `LivingEntity.travel` lines 2094–2096 precedes its later movement call, so the report should avoid implying that the gate/order shift alone proves a ground-branch movement difference for Levitation. Its other branch behavior needs its own concrete path before being used as movement evidence.

## Candidate separation and residuals

The fall-distance reset is a distinct operation from the candidate jump-boost precision change (jump-velocity arithmetic) and support-position selector (block-position choice feeding factors); this is not a duplicate of either. Attack-only `fallDistance` use is excluded. Fall-damage amount/resolution and landing damage are not used to establish this verdict.

The report's residuals remain valid limits: block/collision/support providers and callbacks, fluid-flow providers, externally synchronized packet/effect outcomes, excluded riding branches, and unexamined intermediate patch boundaries prevent treating these five adjacent cuts as complete movement-pair freeze. No tests, build, game launch, decompile, network access, wiki/product inspection or changes outside this reviewer-owned directory were performed.
