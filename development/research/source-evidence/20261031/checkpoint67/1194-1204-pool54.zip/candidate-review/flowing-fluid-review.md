# Independent source review: flowing-fluid neighbor motion predicate

**Input revision:** `.native-source/20261031/1194-1204-pool54/fluid-blocks-motion-audit/flowing-fluid-neighbor-motion-predicate.md`  
**SHA-256:** `A60AF01182CCF3AE0EB3A168F1629C36CB5C6B2117958C4509C10CA98A9888EA`  
**Decision: ACCEPT**

## Source delta and identity

In 1.19.4 `FlowingFluid.getFlow` (lines 53–82), the zero-own-height horizontal-neighbor fallback tests `!neighborState.getMaterial().blocksMotion()`. In 1.20 through 1.20.4, the same branch tests `!neighborState.blocksMotion()`; the guard order, below-neighbor fluid read, `0.8888889F` offset, and signed direction accumulation remain the same. The exact `FlowingFluid.java` SHA-256s by release are 1.19.4 `D84CEB3C0B83DA25FB68599E16CC2298106E745A9EF0C9F32F616D097A8EC56C`; 1.20 and 1.20.1 `BA1DFF6CCB28B62760C74D66832D8FDBE7A1CDC37B9C5A0FF476BD200215C904`; 1.20.2, 1.20.3, and 1.20.4 `0F44B1AF25533DD8A1FBFEC13B279739341DB0C563568337A2825D3E46A1A5BB`. This establishes a 1.20 cutover, unchanged in later intermediates.

The 1.19.4 raw hashes for `Material.java`, `Blocks.java`, `AmethystClusterBlock.java`, `SlabBlock.java`, `Entity.java`, and `Player.java` are respectively `842C7EE4723993C6EE3BF4732343F3225BB05AAC5EE80C919C34C3BA1A027431`, `A4F2DF87C2CAE5A3827A818F39F7AD123EE5B18905EAD9947EFE654421C30FF5`, `36BE6A85711030E84249DDF37259CA62718DCD403DBD73A9C37A718C42681568`, `8D0ABA6039A7F1CD0BA3EBC32A6C614877848BA0428B11B2117710B288059B00`, `3667FEE610CBC5F58012E3A8FB8D6C4849F649FB7FE5300595158112D8B4B58B`, and `5E4436AFCCB361156F8184E7A5CFD91D5B12DCFE8F5937B4AC23DD3EDDA737A2`. For 1.20–1.20.1, the relevant raw file hashes match each other; for 1.20.2–1.20.4, FlowingFluid, AmethystClusterBlock, Entity, and Player match across that group, with later SlabBlock and Blocks/cluster hashes matching 1.20.4. Available root manifests match the raw files. The author supplied the corresponding exact embedded source-map identity audit for 1.20 and 1.20.3, closing the identity chain for all six versions; the embedded manifest hashes are `573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f` and `c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f`.

## Same-state witness and flow direction

All witness states exist in 1.19.4: a source-water block, non-falling level-7 flowing water, waterlogged top slab, dry up-facing amethyst cluster, and full solid blocks. `AMETHYST_CLUSTER` is registered using `Material.AMETHYST`; the material builder defaults `blocksMotion` to true. Its up-facing collision bounds are 10/16 × 7/16 × 10/16, so their mean size is 27/48 = 0.5625, below the 1.20 solidity threshold, and its Y size is below 1. There is no force-solid override in the cluster registration. Thus the old material predicate is true while the newer state predicate is false for the same dry cluster state.

A non-cancelling arrangement is: let P=(0,1,0) be non-falling level-7 water, with a full solid floor at (0,0,0); let the north neighbor N=(0,1,-1) be the only same-level water source, also over a solid floor; let E=(1,1,0) be a dry up-facing amethyst cluster over a waterlogged top slab at (1,0,0); and make P's west and south neighbors full motion-blocking dry walls. The top slab's full top face supports the cluster, and placing the cluster into the empty cell above it yields `WATERLOGGED=false`. The lower slab still exposes source water. P remains level 7 because it has only one same-level source neighbor; the waterlogged slab below E is not counted by the horizontal source-neighbor conversion check.

At P, the north source has height 8/9 while P has height 7/9, giving a `-1/9` gradient; the NORTH step sign makes the accumulated Z term `+1/9` (south). The east cluster has empty fluid state, so `affectsFlow` admits it. Old code skips its lower-cell read because Material.AMETHYST blocks motion. New code reads the source water in the slab below E; subtracting the `8/9 - 8/9` offset leaves a `+7/9` gradient, contributing positive X (east). West and south are blocked, so they add no fallback terms. Before normalization the old vector is `(0,0,1/9)` and the modern vector is `(7/9,0,1/9)`; `getFlow` normalizes both, producing south versus a southeast vector. The predicate change therefore changes current direction for identical valid states and cannot cancel in this layout.

The dry cluster adjacent to flowing water is transient because the cluster is waterloggable and a later flowing-fluid tick can fill it. That does not close the witness: after P is reached as level 7, its water update is scheduled with water's 5-tick delay; placement of the dry cluster does not immediately waterlog it. A grounded player can occupy P and receive the differing current during the interval before that scheduled spread updates the cluster. This review's accepted witness is specifically that reachable transient state, not an indefinitely stable dry cluster beside water.

## Player path and scope

The 1.19.4 and 1.20.4 `Entity.updateFluidHeightAndDoFluidPushing` methods scan the player's intersected water cells, call the fluid state's `getFlow`, aggregate it, and add the scaled vector to delta movement. `Player.isPushedByFluid` returns true when the player is not flying. The player can stand on P's solid floor while its bounding box intersects the level-7 water. These are direct player movement effects; every state in the witness is available in the selected 1.19.4 profile, so this is an in-scope historical movement difference rather than a modern-only feature.

No unresolved dynamic override or source dependency remains. The candidate is accepted with the concrete witness and transient timing above closing the cancellation and reachability questions.

## Reopened verdict — supersedes the prior ACCEPT

**Input revision:** `.native-source/20261031/1194-1204-pool54/fluid-blocks-motion-audit/flowing-fluid-neighbor-motion-predicate.md`  
**SHA-256:** `A60AF01182CCF3AE0EB3A168F1629C36CB5C6B2117958C4509C10CA98A9888EA`  
**Renewed decision: REJECT**

The source predicate replacement and its 1.20 cutover remain accurate, but the draft's decisive same-state witness and its claim that amethyst states produce a different predicate result are false. Exact `Blocks.java` registration inspection across all six selected releases shows the decisive state initialization:

- In 1.19.4, `AMETHYST_CLUSTER` is registered with `Material.AMETHYST`; its default material builder sets `blocksMotion=true`. The three bud registrations copy the cluster properties, so the family also has old material solidity.
- In 1.20, 1.20.1, and 1.20.2, the cluster registration calls `.forceSolidOn()`, and each bud registration also calls `.forceSolidOn()` after copying cluster properties.
- In 1.20.3 and 1.20.4, the cluster calls `.forceSolidOn()`. Each bud uses `Properties.ofLegacyCopy(AMETHYST_CLUSTER)`, which copies the cluster's `forceSolidOn` flag into the bud properties.

`BlockBehaviour.BlockStateBase.calculateSolid` checks `forceSolidOn` first and returns true before consulting the collision-shape threshold. `blocksMotion()` returns `isSolid()`, which uses that cached result. Therefore every dry up-facing cluster or bud in the proposed witness has `blocksMotion()==true` in 1.20–1.20.4, matching `Material.AMETHYST.blocksMotion()==true` in 1.19.4. The lower waterlogged slab is consequently suppressed by both predicates. The directional flow arithmetic in the proposed layout does not rescue the witness: its east contribution is absent in both releases, so the asserted south-versus-southeast divergence is not established.

Raw registration/state-owner source SHA-256s verified for this reopen:

| Release(s) | `Blocks.java` | `BlockBehaviour.java` | `AmethystClusterBlock.java` |
|---|---|---|---|
| 1.19.4 | `A4F2DF87C2CAE5A3827A818F39F7AD123EE5B18905EAD9947EFE654421C30FF5` | `517AA4BD9875E9F7B3F5FBA472A84E82AFD1E11E35D3C83DC2677D8BBEB4997D` | `36BE6A85711030E84249DDF37259CA62718DCD403DBD73A9C37A718C42681568` |
| 1.20, 1.20.1 | `1E7095D1FBFDC8198191F40037997FEECA2EC993CC54DD53F2636375CAE66B51` | `5F37987191165379C222C412949A0C80A904BF78A453035B1F9D86C6454510FA` | `4ACDDEBCE57EE400C2D50E6AAC3C2538380893B406A24282A29F9D45511E5D67` |
| 1.20.2 | `75E8E77ADAB4A07B02EF95619BE83A004F5F79810CF3F07157A713D714881253` | `A6D88726CE4642FC0A61F46A01347BB0B74887B61EF55AF7E7C76723789A0B57` | `4ACDDEBCE57EE400C2D50E6AAC3C2538380893B406A24282A29F9D45511E5D67` |
| 1.20.3, 1.20.4 | `5392C4349317E55C2989865BE38C17B94E6E0543E7017E6A2A64D79217E83643` | `6284A7D08A6D0D475CD4FE8AEA62B35153AE8FBC0BCE5F51788389F679233B54` | `44E2A8C5EC6B0D1BD382BB131BC32AEA724D211AA67F34F18CBCDAF1734F3410` |

The 1.19.4 `Material.java` remains SHA-256 `842C7EE4723993C6EE3BF4732343F3225BB05AAC5EE80C919C34C3BA1A027431`; it is not present in the later versions. These actual file hashes match the source identity evidence already recorded above for the exact six-release Mojmap inputs, including the embedded source-map manifests for 1.20 and 1.20.3. The other claim dependencies (FlowingFluid predicate cutover and player fluid-pushing caller) do not repair the failed amethyst witness. Withdraw the claimed movement consequence and this candidate pending a different, source-verified same-state witness using a block whose old material flag and modern forced/cached solidity actually differ.
