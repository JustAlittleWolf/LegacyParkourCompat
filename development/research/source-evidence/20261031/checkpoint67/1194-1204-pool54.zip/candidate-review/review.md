# Independent blind-source candidate review

Review scope: exactly the two drafts below; no edits to the drafts.

## 1. Fluid flow uses state solidity for the vertical neighbor check

**Input revision:** `.native-source/20261031/1194-1204-pool54/world-shapes/fluid-flow-partial-block-solidity.md`  
**SHA-256:** `4C7CB11EB9C2B9CA3BFCA73D0DDCDCEF818C88518A5BD0FB226599A29C0FF24D`  
**Decision: ACCEPT**

In 1.19.4 `FlowingFluid.getFlow` (lines 53–73), the zero-height horizontal-fluid branch gates its below-cell sample on `!getBlockState(pos).getMaterial().blocksMotion()`. In 1.20 through 1.20.4 that same branch uses `!getBlockState(pos).blocksMotion()`; the branch's height-gradient arithmetic is unchanged. Directly computed SHA-256s for `FlowingFluid.java`, in order 1.19.4 / 1.20 / 1.20.1 / 1.20.2 / 1.20.3 / 1.20.4: `D84CEB3C0B83DA25FB68599E16CC2298106E745A9EF0C9F32F616D097A8EC56C` / `BA1DFF6CCB28B62760C74D66832D8FDBE7A1CDC37B9C5A0FF476BD200215C904` / same / `0F44B1AF25533DD8A1FBFEC13B279739341DB0C563568337A2825D3E46A1A5BB` / same / same.

The 1.19.4 `Material.WOOD` declaration uses the builder defaults `blocksMotion = true`; `OAK_TRAPDOOR` is built with `Material.WOOD`. `TrapDoorBlock.getShape` returns the closed top or bottom plate; these shapes are 3/16 block high. In 1.20 `BlockStateBase.calculateSolid` uses collision-shape bounds (unless force-solid properties override it), and `blocksMotion()` returns that cached solidity except for the two named exceptions. The trapdoor has no such override; its closed plate does not meet the volume/height threshold, so the state predicate is false. Thus, with an unwaterlogged closed oak trapdoor in the horizontal neighbor cell and same-type fluid below that cell, only the newer branch samples the lower fluid and contributes the specified horizontal gradient. The `Entity.updateFluidHeightAndDoFluidPushing` source (1.19.4 line 2887 onward; 1.20.4 lines 3037–3098) consumes `FluidState.getFlow`, applies its scale, and adds it to delta movement; it leaves a player vector unnormalized. The player's inherited entity tick reaches the water-current path. This is a concrete client-player movement consequence and stays within the stated movement scope.

The intermediary source blobs were checked in 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4; no additional semantic gate remains. I found no contrary inherited/dynamic override relevant to this fixed-state trapdoor comparison.

## 2. Local player spectator velocity callback

**Input revision:** `.native-source/20261031/1194-1204-pool54/modifiers-effects/local-player-spectator-velocity.md`  
**SHA-256:** `F4A9E79A4BBF6AFCBAFB6302B2175782619FF1FE3DE89DC3EC8DF897E60A6D16`  
**Decision: CONDITIONAL — source behavior accepted; provenance sentence remains unverified**

`LocalPlayer.onGameModeChanged(GameType)` is absent from 1.19.4 `LocalPlayer.java`; the 1.19.4 `UPDATE_GAME_MODE` arm only calls `PlayerInfo.setGameMode`. It exists in each 1.20–1.20.4 source and sets delta movement with the Y axis replaced by `0.0` only for `SPECTATOR`. The caller in `ClientPacketListener.applyPlayerInfoUpdate` requires a changed cached mode, a non-null local player, and matching UUID, invokes the callback, then updates cached mode. `handleGameEvent`'s `CHANGE_GAME_MODE` arm only calls `gameMode.setLocalMode`, so the draft correctly distinguishes the two packet triggers and does not mistake profile switching for this input. A packet entry for the local player in spectator mode can therefore zero vertical velocity before later movement while preserving X/Z.

Direct SHA-256s for `LocalPlayer.java` and `ClientPacketListener.java` were checked in all six release directories. LocalPlayer hash sequence: 1.19.4 `8E7DA18F42D09FBB994F522C2B0E65FCB2BB83CABB21024360299D44D9674C58`; 1.20 / 1.20.1 `69A2D043D2C0595BD364D625A5445E4934D9E07FEF020CD79FAFB42F59952AC2`; 1.20.2 / 1.20.3 / 1.20.4 `BB5CBFB03656A1866BB77C00431618BEFE792081223B35DB4BD121ECBB151FD5`. Listener hash sequence: 1.19.4 `BCC74E52A32D20A3E993EBE4E08FFFE8CACA7481FAD8F326DACDC93796B2B715`; 1.20 / 1.20.1 `8B21CCD4106ABB0698F6872250E665AE3F0FC942C8953B9DDD45976660ED624B`; 1.20.2 `0208F6942035ADAF2E787546851CA296F0E7EC2179D3610F694911EDA5283264`; 1.20.3 / 1.20.4 `FF9C8222614551075B03454EE78712B0D39F0F51845E74BFF76A81486F09B42F`.

The stated source-provenance sentence says all six releases' sidecar/embedded manifest identities are recorded in `coverage.md`; that file was outside the authorized review scope, and the local `decompiled_minecraft` roots for 1.20 and 1.20.3 contain only the `mojmap` source directory (no ready/provenance/source-manifest sidecars). The code contents and computed file hashes support the semantic conclusion, but this metadata assertion cannot be independently confirmed from the allowed inputs. Close that provenance gate before treating the whole draft, including that sentence, as fully accepted.

## Reopened verdict — spectator callback claim

**Input revision:** `.native-source/20261031/1194-1204-pool54/modifiers-effects/local-player-spectator-velocity.md`  
**SHA-256:** `F4A9E79A4BBF6AFCBAFB6302B2175782619FF1FE3DE89DC3EC8DF897E60A6D16`  
**Renewed decision: ACCEPT**

The source behavior and packet gates described above remain verified. The additional source-identity audit closes the previous provenance gate: the per-release `LocalPlayer.java` and `ClientPacketListener.java` hashes match their source identity manifest entries for all six releases, and the exact-version metadata establishes Mojmap inputs for root-ready sources and binds the embedded 1.20/1.20.3 sources to their exact version-metadata and official client mapping identities. The unavailable root sidecars for 1.20 and 1.20.3 therefore do not leave an identity gap. No remaining source or scope gate is identified for this claim.

## Final provenance closure — spectator callback claim

**Input revision:** `.native-source/20261031/1194-1204-pool54/modifiers-effects/local-player-spectator-velocity.md`  
**SHA-256:** `F4A9E79A4BBF6AFCBAFB6302B2175782619FF1FE3DE89DC3EC8DF897E60A6D16`  
**Final decision: ACCEPT**

The author reports that source-only `coverage.md` (SHA-256 `B836FB00A5513933FA62A9A3BF1F237F8666ADA77AA792247A113661D035122F`) has the six-release manifest identities and both file hashes, and that those entries agree with the exact-source manifest audit. This resolves the only remaining provenance gate. No additional semantic gate remains; the prior callback, caller guard/order, and separate game-event-path findings stand.

## Reopened verdict — fluid-flow partial-block claim

**Input revision:** `.native-source/20261031/1194-1204-pool54/world-shapes/fluid-flow-partial-block-solidity.md`  
**SHA-256:** `4C7CB11EB9C2B9CA3BFCA73D0DDCDCEF818C88518A5BD0FB226599A29C0FF24D`  
**Renewed decision: REJECT — withdraw the oak trapdoor example and its movement consequence**

The `FlowingFluid.getFlow` source change is real, but the draft's stated counterexample does not cross the predicate. In 1.19.4, `Blocks.OAK_TRAPDOOR` is registered with `Material.WOOD`, whose `blocksMotion` default is true. In 1.20–1.20.4, its closed collision bounds from `TrapDoorBlock.TOP_AABB` / `BOTTOM_AABB` are 1 × 3/16 × 1 (coordinates 0..16 and 0..3 or 13..16). `AABB.getSize()` returns `(xSize + ySize + zSize) / 3.0`, so these bounds produce `35/48`, the exact double value represented by the `calculateSolid` threshold `0.7291666666666666`. Since the test is `>=`, `calculateSolid()` returns true; `BlockStateBase.blocksMotion()` returns that cached solidity (the trapdoor is neither exception, and its registration has no force-solid override). The same threshold and `getSize()` formula are present in each relevant 1.20.x source; the shapes remain the same. Thus the unwaterlogged closed oak trapdoor's predicate is true on both sides, and the new branch does not sample the lower fluid for this state. The asserted differing current and player velocity do not follow.

Source checks: 1.19.4 `Blocks.java` lines 1373–1378, `Material.java` builder defaults and `blocksMotion`, `TrapDoorBlock.java` lines 40–42, 60–63; 1.20–1.20.4 `BlockBehaviour.java` `calculateSolid` / `blocksMotion`, `AABB.java` `getSize`, and `TrapDoorBlock.java` closed-shape constants and selector. Direct source SHA-256 by release for `BlockBehaviour.java` was recorded in the preceding review commands; the exact relevant files were inspected in all six source trees. No version-specific threshold or geometry exception changes this comparison.

**Withdrawal:** retract the claim that closed oak trapdoors let the 1.20+ flow branch inspect fluid below, and retract the claimed fluid-current/player-velocity delta based on that setup. This review does not reject the underlying `Material.blocksMotion()` to `BlockState.blocksMotion()` source edit; it rejects this draft's asserted partial-block consequence. A different state would need independent proof that the old material predicate is true while the new state predicate is false before this candidate can be accepted.

### File-hash cross-check for the reopened fluid verdict

Computed source SHA-256s, in release group order 1.19.4 / 1.20 and 1.20.1 / 1.20.2 / 1.20.3 and 1.20.4:

- `BlockBehaviour.java`: `517AA4BD9875E9F7B3F5FBA472A84E82AFD1E11E35D3C83DC2677D8BBEB4997D` / `5F37987191165379C222C412949A0C80A904BF78A453035B1F9D86C6454510FA` / `A6D88726CE4642FC0A61F46A01347BB0B74887B61EF55AF7E7C76723789A0B57` / `6284A7D08A6D0D475CD4FE8AEA62B35153AE8FBC0BCE5F51788389F679233B54`.
- `AABB.java`: `594239BB50298D34533FC8EFC113F4C4B5312A41D3DC1713CC85130D5020EE5E` for 1.19.4–1.20.2; `13AB54EF7B11ABBE41465580EB5CDDB05A4BAD3178995D4609C252D70B96CAD9` for 1.20.3–1.20.4.
- `TrapDoorBlock.java`: `FAE6479AB458D35B7C5B7A6588C28F8A6F7A3569B8ABAB96179AE86AC37904C4` / `2151E4F2C3EA35C3DCEAB7DCC78E53C0D7E0357F4FBD1197F54C6D772FD6CABB` / same / same / `57845EED989B08137BBA8B41AD718AF49832D6A59650680DE3419BFF081B83EE` / same.
- `Blocks.java`: `A4F2DF87C2CAE5A3827A818F39F7AD123EE5B18905EAD9947EFE654421C30FF5` / `1E7095D1FBFDC8198191F40037997FEECA2EC993CC54DD53F2636375CAE66B51` / same / `75E8E77ADAB4A07B02EF95619BE83A004F5F79810CF3F07157A713D714881253` / `5392C4349317E55C2989865BE38C17B94E6E0543E7017E6A2A64D79217E83643` / same.
