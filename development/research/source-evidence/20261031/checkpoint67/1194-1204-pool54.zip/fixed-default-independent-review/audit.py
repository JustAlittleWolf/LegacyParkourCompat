import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(r"C:/Users/Wolfi/.codex/worktrees/56a8/LegacyParkourCompat")
LAB = ROOT / ".native-source/20261031/1194-1204-pool54"
GROUP = LAB / "blocks-motion-fixed-default-residual"
SOURCES = Path(r"D:/Javastuff/LegacyParkourCompat/decompiled_minecraft")
VERSIONS = ["1.20", "1.20.1", "1.20.2", "1.20.3", "1.20.4"]
errors = []
checks = []

def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))
    if not ok:
        errors.append(f"{name}: {detail}")

def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

matrix = rows(GROUP / "fixed-default-reconciliation.csv")
chains = rows(GROUP / "class-provider-chains.csv")
handoff = rows(LAB / "blocks-motion-state-shapes/fixed-default-provider-handoff.csv")
base = rows(LAB / "blocks-motion-static-shapes/base-block-collision-parity.csv")
special = rows(LAB / "blocks-motion-fixed-special/fixed-full-cube-parity.csv")
check("reconciliation sha", hashlib.sha256((GROUP / "reconciliation.md").read_bytes()).hexdigest().upper() == "8A47A88908C10909C94028DB5F00532017565E7ACB26B4C927DB3B7BDDF3FE48")
check("matrix cardinality", len(matrix) == 1835, str(len(matrix)))
ids = {r["id"] for r in matrix}
check("distinct IDs", len(ids) == 367, str(len(ids)))
check("five modern releases per ID", all(Counter(r["release"] for r in matrix if r["id"] == bid) == Counter(VERSIONS) for bid in ids))
check("unique ID/release rows", len({(r["id"], r["release"]) for r in matrix}) == len(matrix))
check("handoff rows match matrix keyset", {(r["id"],r["release"]) for r in handoff} == {(r["id"],r["release"]) for r in matrix}, f"handoff={len(handoff)} matrix={len(matrix)}")
check("old blocksMotion true", all(r["oldBlocksMotion"].lower() == "true" for r in matrix))
check("fixed modern gates", all(r["forceSolidOn"].lower() == "false" and r["forceSolidOff"].lower() == "false" and r["hasCollision"].lower() == "true" and r["dynamicShape"].lower() == "false" and r["calculateSolid"].lower() == "true" and r["parity"].lower() == "true" for r in matrix))
check("provider/bounds", all(r["provider"] == "inherited BlockBehaviour.getShape -> Shapes.block" and r["bounds"] == "[0,1] x [0,1] x [0,1]" and r["getSize"] == "1" and r["ySize"] == "1" for r in matrix))

# Artifact identity checks described by the baseline.
baseline_hashes = {
 "blocks-motion-state-shapes/fixed-default-provider-handoff.csv":"a14ec49b4dde151711c74440e508e0ada5410d6f73e4bf444ae23acfa8865ec7",
 "independent-blocks-motion-audit/state-domain-roster.json":"ce08fad89e0102e58c52628f18302cf2053e2608dee81f8fa6cae124d8b01698",
 "independent-blocks-motion-audit/geometry-residual-matrix.csv":"70aba17e17b099e86d87b613f225ea10938e08cd0d3deddba7f88bb241528675",
 "blocks-motion-static-shapes/base-block-collision-parity.csv":"5dd174de3fedf4f44eb691dedc89b576f4fad3d2358c411b7bab36a11af03e52",
 "blocks-motion-fixed-special/fixed-full-cube-parity.csv":"1dd4a1c2e374c144df0ccbbd7aa9452d216b45cdf0834d59902a589380589799",
 "independent-blocks-motion-audit/source-hashes.json":"bf825b2d01a199d8a0ca010174204ea2f9680279fc1acda132393972ece45909",
 "independent-blocks-motion-audit/SHA256SUMS.txt":"dd3ea56b0ffb467ea4e9a860c2745e5c17d5a09f52e3e102b004d0b6cc9db54f",
}
artifact_results=[]
for rel, expected in baseline_hashes.items():
    actual=hashlib.sha256((LAB/rel).read_bytes()).hexdigest()
    artifact_results.append((rel, expected, actual, actual==expected))
check("baseline artifacts", all(x[3] for x in artifact_results), str([x[0] for x in artifact_results if not x[3]]))
for rel, expected in [("fixed-default-reconciliation.csv",None),("class-provider-chains.csv",None),("reconciliation.md",None),("baseline.md",None)]:
    artifact_results.append(("blocks-motion-fixed-default-residual/"+rel, expected, hashlib.sha256((GROUP/rel).read_bytes()).hexdigest(), True))

# The published per-file ledger is rehashed directly against canonical Mojmap source.
ledger=json.loads((LAB/"independent-blocks-motion-audit/source-hashes.json").read_text(encoding="utf-8"))
source_hash_results=[]
for rec in ledger:
    src=SOURCES/rec["version"]/"mojmap"/Path(rec["rel"])
    actual=hashlib.sha256(src.read_bytes()).hexdigest().upper() if src.is_file() else "MISSING"
    expected=rec["sha256"].upper()
    ok=actual==expected==rec["manifestExpected"].upper() and rec["matches"]
    source_hash_results.append((rec["version"],rec["rel"],expected,actual,ok))
check("57 source hash records", len(source_hash_results)==57 and all(x[4] for x in source_hash_results), f"records={len(source_hash_results)} failures={[x[:2] for x in source_hash_results if not x[4]]}")

# Verify the exact source-set identities recorded in the baseline, including manifests
# that cover all decompiled files rather than only the sampled hash ledger.
source_identities={
 "1.19.4":("mojmap.sources.sha256","6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3"),
 "1.20":("mojmap/.decompile-provenance.json","573f0bb3e18e39ae882769a007a1c97d711da123034f9a1c894eb407ef58030f"),
 "1.20.1":("mojmap.sources.sha256","858b56764113e591c60d09bc63e4d90f9c1d67a705645f0c793e8b28f2378465"),
 "1.20.2":("mojmap.sources.sha256","e439ff7e1d3f1d31e01be1edd141f94d917a9dc7fa0de5f69904544cbbe62887"),
 "1.20.3":("mojmap/.decompile-provenance.json","c3d605e55b287e800a86af8567a75edcb009d1a9a1744cfcb4e6f47667dcee0f"),
 "1.20.4":("mojmap.sources.sha256","fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1"),
}
identity_results=[]
for v,(rel,want) in source_identities.items():
    p=SOURCES/v/rel
    got=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else "MISSING"
    identity_results.append((v,rel,want,got,got.lower()==want.lower()))
check("six canonical source-set artifacts present",all(x[3]!="MISSING" for x in identity_results),str([x for x in identity_results if x[3]=="MISSING"]))
identity_mismatches=[x for x in identity_results if not x[4]]
baseline_path=GROUP/"baseline.md"
baseline_text=baseline_path.read_text(encoding="utf-8")
baseline_hash=hashlib.sha256(baseline_path.read_bytes()).hexdigest().upper()
check("corrected author baseline digest",baseline_hash=="DC3CB94E219AAEE3F734E55E31405A9F110809CFD0A5ED0E4438BC4E89BFB9E8",baseline_hash)
baseline_identity_presence=[(v,want,want in baseline_text) for v,(_,want) in source_identities.items() if v in ("1.20","1.20.1")]
check("baseline table includes corrected 1.20 and 1.20.1 identities",all(x[2] for x in baseline_identity_presence),str(baseline_identity_presence))

# Rehash every entry in each complete release inventory, not just the bounded 57-file
# evidence ledger. This reruns the exact source-set integrity check for all six releases.
full_inventory_results=[]
for v,(identity_rel,expected_identity) in source_identities.items():
    root=SOURCES/v/"mojmap"
    provenance=root/".decompile-provenance.json"
    sidecar=SOURCES/v/"mojmap.sources.sha256"
    if provenance.is_file():
        full_manifest=json.loads(provenance.read_text(encoding="utf-8"))["sources"]
        kind="embedded provenance"
    elif sidecar.is_file():
        full_manifest={}
        for line in sidecar.read_text(encoding="utf-8").splitlines():
            parts=line.split(None,1)
            if len(parts)==2:
                full_manifest[parts[1].lstrip("* ").replace("\\","/")]=parts[0].lower()
        kind="sha256 manifest"
    else:
        full_inventory_results.append((v,identity_rel,0,0,expected_identity,"MISSING","MISSING",False))
        continue
    failed=[]
    for rel,want in full_manifest.items():
        src=root/Path(rel)
        got=hashlib.sha256(src.read_bytes()).hexdigest() if src.is_file() else "MISSING"
        if got.lower()!=want.lower(): failed.append((rel,want,got))
    actual_identity=hashlib.sha256((SOURCES/v/identity_rel).read_bytes()).hexdigest() if (SOURCES/v/identity_rel).is_file() else "MISSING"
    count_expected={"1.19.4":4740,"1.20":4786,"1.20.1":4786,"1.20.2":4904,"1.20.3":5048,"1.20.4":5048}[v]
    ok=len(full_manifest)==count_expected and not failed and actual_identity.lower()==expected_identity.lower()
    full_inventory_results.append((v,kind,len(full_manifest),count_expected,expected_identity,actual_identity,"; ".join(f"{x[0]} expected {x[1]} got {x[2]}" for x in failed[:3]),ok))
check("all six full source inventories rehashed",all(x[-1] for x in full_inventory_results),str([(x[0],x[2],x[3],x[6]) for x in full_inventory_results if not x[-1]]))

# Validate every listed class and superclass edge against primary Java sources, then search
# every chain member for shape overrides or registration-only collision exceptions.
chain_map={(r["release"],r["constructor"]):r for r in chains}
check("chain table unique",len(chain_map)==len(chains),f"rows={len(chains)} unique={len(chain_map)}")
used_keys={(r["release"],r["constructor"]) for r in matrix}
check("every matrix key has chain",used_keys.issubset(chain_map),f"missing={sorted(used_keys-set(chain_map))[:12]}")
shape_override_hits=[]
chain_source_missing=[]
edge_mismatches=[]
exception_hits=[]
seen_files=set()
for key in sorted(used_keys):
    chainrow=chain_map[key]
    release, constructor=key
    chain=chainrow["superclassChain"].split(" -> ")
    parsed=[]
    for token in chain:
        m=re.match(r"([A-Za-z_$][\w$]*)\((.*?):\d+\)",token)
        if not m:
            m=re.match(r"(BlockBehaviour)\((net/minecraft/world/level/block/state/BlockBehaviour\.java)\)",token)
        if not m:
            edge_mismatches.append((key,"unparsed token",token)); continue
        cls, file=m.groups()[:2]
        line_match=re.search(r":(\d+)\)",token)
        if file.startswith("net/"):
            relative=Path(file)
        else:
            relative=Path("net/minecraft/world/level/block")/file
        source=SOURCES/release/"mojmap"/relative
        if not source.is_file():
            chain_source_missing.append((key,str(relative))); continue
        text=source.read_text(encoding="utf-8")
        seen_files.add((release,str(relative)))
        # Named top-level declaration and superclass of that named type.
        decl=re.search(r"\b(?:public\s+)?(?:abstract\s+)?(?:class|record)\s+"+re.escape(cls)+r"\b([^\{]*)",text)
        if not decl:
            edge_mismatches.append((key,"no class decl",cls,str(relative))); continue
        if line_match:
            source_line=int(line_match.group(1))
            declaration_line=text[:decl.start()].count("\n")+1
            if source_line!=declaration_line:
                edge_mismatches.append((key,"class declaration line mismatch",cls,source_line,declaration_line))
        parsed.append((cls,decl.group(1),text,str(relative)))
        # Java methods with either target name in each class file are unexpected here.
        if cls != "BlockBehaviour" and re.search(r"\b(?:public|protected)\s+(?:static\s+)?(?:[\w.$<>?,\[\]]+\s+)+(?:getShape|getCollisionShape)\s*\(",text):
            shape_override_hits.append((key,cls,str(relative)))
        if re.search(r"\.(?:noCollission|noCollision|dynamicShape|forceSolidOn|forceSolidOff)\s*\(",text,re.I):
            exception_hits.append((key,cls,str(relative)))
    # check each superclass link based on declared extends name
    if len(parsed)==len(chain):
        for i in range(len(parsed)-1):
            wanted=parsed[i+1][0]
            if not re.search(r"\bextends\s+"+re.escape(wanted)+r"\b",parsed[i][1]):
                edge_mismatches.append((key,"extends mismatch",parsed[i][0],parsed[i][1],wanted))
        if not parsed[-1][0].startswith("BlockBehaviour"):
            edge_mismatches.append((key,"wrong terminal",parsed[-1][0]))
        if chainrow["overridesGetShapeOrGetCollisionShape"]!="none":
            edge_mismatches.append((key,"table says override",chainrow["overridesGetShapeOrGetCollisionShape"]))
check("all chain source files present",not chain_source_missing,str(chain_source_missing[:10]))
check("all superclass edges validated",not edge_mismatches,str(edge_mismatches[:20]))
check("no chain shape override",not shape_override_hits,str(shape_override_hits[:20]))
check("no chain registration exceptions",not exception_hits,str(exception_hits[:20]))

# Rehash every source file in the 356 resolved superclass chains against its exact
# release's complete source manifest, plus the old registration/material source files.
manifest_fail=[]
verified_files=0
for v in VERSIONS+["1.19.4"]:
    root=SOURCES/v/"mojmap"
    provenance=root/".decompile-provenance.json"
    sidecar=SOURCES/v/"mojmap.sources.sha256"
    if provenance.is_file():
        manifest=json.loads(provenance.read_text(encoding="utf-8"))["sources"]
    elif sidecar.is_file():
        manifest={}
        for line in sidecar.read_text(encoding="utf-8").splitlines():
            parts=line.split(None,1)
            if len(parts)==2:
                manifest[parts[1].lstrip("* ").replace("\\","/")]=parts[0].lower()
    else:
        manifest_fail.append((v,"no complete source manifest")); continue
    relevant={Path(rel).as_posix() for rv,rel in seen_files if rv==v}
    if v=="1.19.4":
        relevant.update(("net/minecraft/world/level/block/Blocks.java","net/minecraft/world/level/material/Material.java"))
    for rel in sorted(relevant):
        expected=manifest.get(rel)
        src=root/Path(rel)
        actual=hashlib.sha256(src.read_bytes()).hexdigest() if src.is_file() else "MISSING"
        verified_files+=1
        if expected is None or actual.lower()!=expected.lower():
            manifest_fail.append((v,rel,expected,actual))
check("complete manifest hashes for all chain sources",not manifest_fail,f"files={verified_files} failures={manifest_fail[:12]}")

# Verify exact static registration references and old release registration lines.
registration_fail=[]
for r in matrix:
    for relcol,fieldcol,linecol in [("1.19.4","oldRegistrationField","oldRegistrationLine"),(r["release"],"modernRegistrationField","modernRegistrationLine")]:
        src=SOURCES/relcol/"mojmap/net/minecraft/world/level/block/Blocks.java"
        if not src.is_file():
            registration_fail.append((r["id"],relcol,"missing Blocks.java")); continue
        lines=src.read_text(encoding="utf-8").splitlines()
        n=int(r[linecol]); field=r[fieldcol]
        if n<1 or n>len(lines) or not re.search(r"\b"+re.escape(field)+r"\s*=",lines[n-1]):
            registration_fail.append((r["id"],relcol,field,n,lines[n-1] if 1<=n<=len(lines) else "line OOB"))
check("registration source line anchors",not registration_fail,str(registration_fail[:20]))
material_source=(SOURCES/"1.19.4/mojmap/net/minecraft/world/level/material/Material.java").read_text(encoding="utf-8")
material_fail=[]
for mat in sorted({r["oldMaterial"] for r in matrix}):
    decl=re.search(r"public\s+static\s+final\s+Material\s+"+re.escape(mat)+r"\s*=.*?;",material_source,re.S)
    if not decl or ".noCollider()" in decl.group(0):
        material_fail.append((mat,"missing or blocksMotion=false builder"))
check("old Material.blocksMotion provenance",not material_fail,str(material_fail))

# Verify the exact registration expressions for every handoff ID/release and exclude
# explicit property overrides that would invalidate the fixed-default gate.
expressions=json.loads((LAB/"independent-blocks-motion-audit/registration-expressions.json").read_text(encoding="utf-8"))
expr_index={(r["version"],r["field"]):r for r in expressions}
expr_fail=[]
for r in matrix:
    old_item=expr_index.get(("1.19.4",r["oldRegistrationField"]))
    if old_item is None or old_item["id"]!=r["id"] or int(old_item["line"])!=int(r["oldRegistrationLine"]):
        expr_fail.append(("1.19.4",r["id"],"old expression/registration mismatch")); continue
    item=expr_index.get((r["release"],r["modernRegistrationField"]))
    if item is None or item["id"]!=r["id"] or int(item["line"])!=int(r["modernRegistrationLine"]):
        expr_fail.append((r["release"],r["id"],"missing or mismatched exact registration expression")); continue
    if re.search(r"\.(?:noCollission|noCollision|dynamicShape|forceSolidOn|forceSolidOff)\s*\(",item["expression"],re.I):
        expr_fail.append((r["release"],r["id"],item["expression"]))
check("exact modern expressions and default flags",not expr_fail,str(expr_fail[:20]))
row_expr_helpers=sorted({expr_index[(r["release"],r["modernRegistrationField"])]["expression"].split("(",1)[0]
                         for r in matrix
                         if not expr_index[(r["release"],r["modernRegistrationField"])]["expression"].startswith("new ")})
# These are the only factory/helper forms remaining after exact row-to-expression matching.
# The independent source trace below confirms their complete definitions in each release.
helper_def_fail=[]
for v in VERSIONS:
    blocks=(SOURCES/v/"mojmap/net/minecraft/world/level/block/Blocks.java").read_text(encoding="utf-8")
    for name in row_expr_helpers:
        if not re.search(r"\b"+re.escape(name)+r"\s*\([^)]*\)\s*\{",blocks):
            helper_def_fail.append((v,name,"missing helper body"))
            continue
        # Scope helper body with balanced braces and look for properties that invalidate
        # this fixed-default classification.
        m=re.search(r"\b"+re.escape(name)+r"\s*\([^)]*\)\s*\{",blocks)
        start=m.end()-1; depth=0; end=start
        for end in range(start,len(blocks)):
            if blocks[end]=="{": depth+=1
            elif blocks[end]=="}":
                depth-=1
                if depth==0: break
        body=blocks[start:end+1]
        if re.search(r"\.(?:noCollission|noCollision|dynamicShape|forceSolidOn|forceSolidOff)\s*\(",body,re.I):
            helper_def_fail.append((v,name,"helper changes fixed-default properties"))
check("registration helper closure",not helper_def_fail,f"helpers={row_expr_helpers} failures={helper_def_fail[:10]}")

# Recompute overlap against the distinct ID sets, by release and in total.
set_base={r["id"] for r in base}; set_special={r["id"] for r in special};
partition=Counter(r["partition"] for r in matrix)
partition_ids=defaultdict(set)
for r in matrix: partition_ids[r["partition"]].add(r["id"])
expected_partitions={
 "already closed by base Block table":(770,154,set(ids)&set_base-set_special),
 "already closed by special full-cube table":(580,116,set(ids)&set_special),
 "closed here: fixed default provider":(485,97,set(ids)-set_base-set_special),
}
# Normalize precise wording while keeping source artifact text as-is.
actual_normalized=Counter()
for label,n in partition.items():
    if label=="already closed by base Block table": actual_normalized["already closed by base Block table"] += n
    elif label=="already closed by special full-cube table": actual_normalized["already closed by special full-cube table"] += n
    elif label=="closed here: fixed default provider": actual_normalized["closed here: fixed default provider"] += n
check("partition row totals", actual_normalized==Counter({k:v[0] for k,v in expected_partitions.items()}),str(actual_normalized))
check("partition ID totals", {k:len(partition_ids[k]) for k in expected_partitions}=={k:v[1] for k,v in expected_partitions.items()},str({k:len(partition_ids[k]) for k in partition_ids}))
base_overlap=ids & set_base
special_overlap=ids & set_special
new_ids=ids-set_base-set_special
check("overlap recomputes",(len(base_overlap),len(special_overlap),len(new_ids))==(154,116,97),f"base={len(base_overlap)} special={len(special_overlap)} new={len(new_ids)}")
check("five dead coral base-only IDs",len(set_base-ids)==5 and all(x.endswith("coral_block") for x in set_base-ids),str(sorted(set_base-ids)))
check("base and special disjoint among handoff",not (base_overlap & special_overlap),str(sorted(base_overlap & special_overlap)))

# Register exact source provider anchors and calculateSolid predicates in all five releases.
provider_fail=[]
for v in VERSIONS:
    basep=SOURCES/v/"mojmap/net/minecraft/world/level/block/state/BlockBehaviour.java"
    shape=SOURCES/v/"mojmap/net/minecraft/world/phys/shapes/Shapes.java"
    state=basep  # BlockStateBase.Cache is a nested class in BlockBehaviour in these mappings.
    for p in (basep,shape):
        if not p.is_file(): provider_fail.append((v,"missing",str(p))); continue
    if any(not (SOURCES/v/"mojmap/net/minecraft/world/level/block/state/"+x).is_file() for x in []): pass
    bt=basep.read_text(encoding="utf-8")
    st=shape.read_text(encoding="utf-8")
    ctext=state.read_text(encoding="utf-8")
    m=re.search(r"public\s+VoxelShape\s+getShape\s*\([^)]*\)\s*\{",bt)
    if not m or "return Shapes.block();" not in bt[m.start():m.start()+300]: provider_fail.append((v,"getShape","provider body does not return Shapes.block"))
    m=re.search(r"public\s+VoxelShape\s+getCollisionShape\s*\([^)]*\)\s*\{",bt)
    if not m or "this.hasCollision ? $$0.getShape($$1, $$2) : Shapes.empty()" not in bt[m.start():m.start()+400]: provider_fail.append((v,"getCollisionShape","default shape/hasCollision gate changed"))
    m=re.search(r"public\s+static\s+VoxelShape\s+block\s*\(\)\s*\{",st)
    if not m or "return BLOCK;" not in st[m.start():m.start()+150]: provider_fail.append((v,"Shapes.block","does not return BLOCK"))
    if not re.search(r"BLOCK\s*=\s*Util\.make\(\(\)\s*->\s*\{\s*DiscreteVoxelShape\s+\$*\w+\s*=\s*new BitSetDiscreteVoxelShape\(1,\s*1,\s*1\);\s*\$*\w+\.fill\(0,\s*0,\s*0\);\s*return new CubeVoxelShape\(\$*\w+\);",st):
        provider_fail.append((v,"Shapes.BLOCK","not initialized from filled 1x1x1 CubeVoxelShape"))
    if "getSize() >= 0.7291666666666666" not in ctext or "getYsize() >= 1.0" not in ctext or "forceSolidOn" not in ctext or "forceSolidOff" not in ctext:
        provider_fail.append((v,"calculateSolid","predicate terms not found"))
check("exact provider predicate source",not provider_fail,str(provider_fail[:20]))

property_default_fail=[]
for v in VERSIONS:
    bt=(SOURCES/v/"mojmap/net/minecraft/world/level/block/state/BlockBehaviour.java").read_text(encoding="utf-8")
    if not re.search(r"boolean\s+hasCollision\s*=\s*true\s*;",bt): property_default_fail.append((v,"hasCollision default"))
    for name in ("dynamicShape","forceSolidOn","forceSolidOff"):
        if not re.search(r"boolean\s+"+name+r"\s*;",bt): property_default_fail.append((v,name+" default false"))
check("Properties fixed-default source",not property_default_fail,str(property_default_fail))

out=ROOT/".native-source/20261031/1194-1204-pool54/fixed-default-independent-review"
with (out/"audit-results.txt").open("w",encoding="utf-8",newline="\n") as f:
    f.write("Fixed-default reconciliation independent audit\n")
    f.write(f"Matrix rows={len(matrix)} IDs={len(ids)}; chain rows={len(chains)}; used constructor/release keys={len(used_keys)}; ledger files={len(ledger)}\n")
    f.write(f"Class Java sources checked={len(seen_files)}; source hash rows checked={len(source_hash_results)}\n\n")
    for name,ok,detail in checks:
        f.write(("PASS" if ok else "FAIL")+" | "+name+(" | "+detail if detail else "")+"\n")
    f.write("\nArtifact SHA-256 checks\n")
    for rel,expected,actual,ok in artifact_results:
        f.write(f"{'PASS' if ok else 'FAIL'} | {rel} | expected={expected or 'review-calculated'} | actual={actual}\n")
    f.write("\n## Re-run addendum\n")
    f.write(f"Baseline artifact SHA-256: {baseline_hash}; complete manifest inventories rehashed: {sum(x[2] for x in full_inventory_results)} files across six releases.\n")
    if not identity_mismatches:
        f.write("All six corrected source-set digests match their named artifacts; every file in each complete source inventory matches its manifest. The earlier 1.20/1.20.1 digest discrepancy is resolved.\n")
    f.write("\nCorrected canonical source-set identity rehashes\n")
    for v,rel,want,got,ok in identity_results:
        f.write(f"{'PASS' if ok else 'MISMATCH'} | {v} | {rel} | baseline={want} | actual={got}\n")
    f.write("\nFull release source inventory rehashes\n")
    for v,kind,count,expected_count,want,got,detail,ok in full_inventory_results:
        f.write(f"{'PASS' if ok else 'FAIL'} | {v} | {kind} | files={count}/{expected_count} | identity expected={want} actual={got}"+(f" | {detail}" if detail else "")+"\n")
    if identity_mismatches:
        f.write("The named source-set artifact digests differ from the corrected expected values above.\n")
    if not all(x[2] for x in baseline_identity_presence):
        f.write("The supplied baseline file hash is correct, but its text still omits or misstates one corrected source-set digest listed above.\n")
    f.write("\nFailures\n"+("\n".join(errors) if errors else "none")+"\n")
if errors:
    raise SystemExit("AUDIT FAIL: "+"; ".join(errors[:6]))
print(f"PASS: {len(checks)} checks; {len(matrix)} rows; {len(ids)} IDs; {len(used_keys)} constructor/release pairs; {len(source_hash_results)} source-file hashes; report {out/'audit-results.txt'}")
