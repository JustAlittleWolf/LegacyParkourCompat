# Independent stateful-shape review

## Review identity and inputs

Read-only review of `blocks-motion-state-shapes/stateful-provider-review.md` at SHA-256 `0c7a589f16c45b380366fdc5219f79a3969a6eb80dc6e033041ce0db056187e2` (verified at review start). Its current referenced tables and source census inputs were also rehashed:

- `dynamic-shape-ids.csv`: `8529a4b3bad168b084b485661ec5988c6a9b6866166b0f638167554c16bb66a1`.
- `fixed-default-provider-handoff.csv`: `a14ec49b4dde151711c74440e508e0ada5410d6f73e4bf444ae23acfa8865ec7`.
- `remaining-constructor-groups.csv`: empty; SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
- `independent-blocks-motion-audit/state-domain-roster.json`: `ce08fad89e0102e58c52628f18302cf2053e2608dee81f8fa6cae124d8b01698`.
- `shape-state-census/shape-state-census.md`: `8c35d78ffa66726326e259294818fae4ec8d85805b4ddcd96fe8a285325bd9a8`.
- The four census scripts match their recorded hashes in the census. The `verify-source-provenance.ps1` script also matches its recorded hash.

I ran only the read-only provenance checker. It verified all manifest-listed Java source files and exact identities for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4 (4,740; 4,786; 4,786; 4,904; 5,048; and 5,048 files). No source generation, tests, build, game launch, network access, or writes outside this review directory were used.

## Verdict

The corrected shulker registration classification and the cached-ID arithmetic are supported. The cached-shape result partition is arithmetically complete: `367 + 161 + 12 + 115 + 14 = 669` IDs in each of the five modern releases. The roster agrees on 669 `cached-shape` rows per release, with 580 old-motion-true and 89 old-motion-false rows. The dynamic table contains 22 IDs per modern release (17 shulkers and five other IDs).

The report needs corrections before its exact-bound rows and its collision-path exclusions can be accepted as written. I found two literal bound/size errors and three incorrect or ambiguous collision-gate descriptions. These do not change the stated `calculateSolid` booleans for the two numeric errors, but they prevent accepting the current text as an exact state-domain closure report.

## Accepted source checks

### Shulker helper expansion and erratum

The prior shulker cached/dynamic transition is correctly retracted and must stay retracted. `Blocks.shulkerBox` applies `dynamicShape()` in 1.19.4, 1.20, and 1.20.3; the relevant helper body is unchanged at 1.20.1/.2 and 1.20.4. The 1.20+ helper additionally applies `forceSolidOn()`. Its nested `.mapColor(...)` helper argument explains the registration parser miss. The helper is invoked for the default shulker plus the 16 dye variants.

Across the six exact sources, `ShulkerBoxBlock.getShape` obtains the block entity and uses `Shapes.create(entity.getBoundingBox(state))`, with full-cube fallback when absent. `ShulkerBoxBlockEntity.getBoundingBox` uses the same `0.5F * getProgress(1.0F)` factor, and `Shulker.getProgressAabb` applies the same facing-directed extension. The provider is dynamic and player-reachable through the block-collision iterator. The EAST-facing full-open fixture in the reviewed report has a 0.1-block gap and clips the proposed -0.5 X movement to -0.1 in each endpoint; it is a valid reachability fixture, not evidence of a cross-version mismatch.

The registration helper audit is supported for the queried hidden flags: `stoneButton` and `woodenButton` supply no-collision; `shulkerBox` supplies dynamic and force-on in 1.20+; no conflicting shulker full-cube closure is supported.

### Solidity gate and player collision consumer

The 1.20–1.20.4 `BlockBehaviour.BlockStateBase.calculateSolid()` method body is identical across all five releases. Its gate order is force-on, force-off, missing cache, empty cached collision shape, then `AABB.getSize() >= 0.7291666666666666`, or failing that `AABB.getYsize() >= 1.0`. A dynamic provider with no force-on therefore has a null cache and returns false at this predicate.

The actual player collision path is separate and was checked: `Entity.collide` delegates its box movement to collision collection; `CollisionGetter.getBlockCollisions` creates `BlockCollisions`; the iterator obtains each block state’s `getCollisionShape` with the entity context; the returned shapes are clipped against the moving player box. `BlockBehaviour.getCollisionShape` returns empty only when `hasCollision` is false; otherwise it calls the state shape. Consequently `forceSolidOff` and a false old `Material.blocksMotion()` bit do not mean that a block is absent from player collision.

The source census dispositions for same-current-state shape candidates remain supported by the examined providers: the 1.20.3 DoorBlock switch rewrite maps the same facing/open/hinge boxes; Repeater/Comparator support-loss changes replace states rather than changing the shape of a fixed state; Barrier adds fluid state without changing collision geometry; Redstone Wire remains no-collision. These are not same-state collision-shape movement differences. The player-path trace is relevant to the shape providers; it does not make the `calculateSolid()` predicate itself a collision input.

### Counted cached and dynamic rows

The referenced roster agrees with the report’s 669 cached IDs per modern release, and the fixed handoff has 367 rows in every modern release. The 161 selector-family arithmetic and its named totals reconcile: 53 slabs, 49 stairs, 12 doors, 12 trapdoors, 11 fences, 16 beds, 3 anvils, one end portal frame, one composter, and 3 chest-family registrations. The 12 dimension-stable IDs and 115 thin/inherited IDs also reconcile to the named registrations in the report. The 14 final constructor families reconcile when the powder-snow cauldron is counted only in the earlier cauldron tranche (it is listed again as a cross-reference, not a fifteenth final family). The empty residual CSV is consistent with the cached-shape-only partition.

Wall and fence-gate registrations are not missing cached-shape groups: the roster shows 22 `WallBlock` and 11 `FenceGateBlock` registrations per modern release, all old-motion-true and `forceSolidOn`. That short-circuits `calculateSolid` before cached bounds. The report should state this gate disposition next to its initial wall/gate candidate rows; their geometry still belongs to direct collision-shape review, but not to the cached `calculateSolid` bounds total.

## Required corrections

1. **Wall skull bounds conflict with the source and with the erratum.** In the thin-family table (reviewed report line 107), the ordinary `WallSkullBlock` boxes have 8/16 extents on X, Y, and Z for every facing: e.g. NORTH is `[4,4,8]–[12,12,16]`. The Piglin wall skull has extents 10/16, 8/16, 8/16. `AABB.getSize()` averages the extents, so the family maximum is `13/24`, not `2/3`. The report’s later erratum gives the correct maximum size but does not repair the table’s `(16,8,8)/16` extent claim or its `2/3` table result. Correct that row to ordinary `(8,8,8)/16`, piglin `(10,8,8)/16`, maximum `13/24`.

2. **Decorated pot size is miscomputed.** In the final-family sentence (reviewed report line 142), DecoratedPot uses `[1/16,0,1/16]–[15/16,1,15/16]`: extents are `14/16 × 1 × 14/16`. Since `AABB.getSize()` is `(xSize + ySize + zSize)/3`, the size is `11/12`, not `23/24`. The modern result remains true either way. Also retain a scope note: its 1.19.4 registration is behind `requiredFeatures(FeatureFlags.UPDATE_1_20)`, so the old source material bit is not by itself proof that a normal 1.19.4 map can contain this post-era feature.

3. **Candle and cocoa are wrongly described as no-collision exclusions.** The exclusion section says their modern `noCollision` gate is true. The 1.20.4 roster instead says `cached-shape`, `noCollision=false` for all candle IDs and cocoa; their exact `Blocks` helper/registration has no `.noCollission()`. Their providers therefore enter the ordinary player collision path. They are already included in the 115 thin/inherited closure, where their small boxes stay below the `calculateSolid` threshold; keep those rows there, remove the no-collision exclusion wording, and do not describe their outlines as movement-irrelevant. `CandleBlock.java` is byte-identical at 1.19.4–1.20.2 and has the same 1.20.3/1.20.4 body; Cocoa’s shape tables/provider are unchanged in the reviewed source census despite non-shape class changes. I found no same-state geometry change in these providers.

4. **Snow’s force-off gate is not a collision gate.** `SnowLayerBlock` is `forceSolidOff` but `noCollision=false` in the source-derived roster. Its layer-dependent shape still reaches `Entity` collision. It may be excluded from the cached-solid calculation because force-off returns first, but not by calling it non-collision. State explicitly that the layer shape stays on the movement path and cite the reviewed equality of its provider across these endpoints, or retain it as a separate shape-parity residual if that equality is not part of this review.

5. **Scaffolding raw-provider residual versus movement residual.** The dynamic table correctly leaves its raw provider geometry unevaluated, but its registration is `noCollision=true` in all five modern releases. The exact `BlockBehaviour.getCollisionShape` gate returns `Shapes.empty()` before a scaffolding state/context shape can reach `Entity.collide`. Keep it as an unchecked raw dynamic provider if desired, but classify it as an ordinary player-block-collision exclusion rather than a movement-relevant residual.

## Open residuals and acceptance boundary

The report correctly does not claim complete dynamic-provider closure. Four non-shulker families remain movement-relevant and open in each of five modern releases: `bamboo`, `moving_piston`, `pointed_dripstone`, and `powder_snow` (20 ID-release rows). `scaffolding` has five unchecked raw-provider rows but is excluded from ordinary player block collision by `noCollision`; it is not an open player-collision geometry case. Shulker geometry/provider state is checked and equal at the six endpoints; its prior transition remains retracted.

I accept the corrected helper expansion, solidity gate order, cached/dynamic counts, and the named selector-domain coverage subject to the exact table corrections and gate wording above. I do not accept the report as a complete stateful player-collision closure while the four dynamic families remain open. No runtime parity conclusion is made.
