# Follow-up review of corrected stateful-shape report

## Identity

Reviewed `blocks-motion-state-shapes/stateful-provider-review.md` at SHA-256 `75da1ff4301b8e515df9eb720d3c46d84ff34d2b7b98caaa5e4608acdc9cd268` (verified at start). Read-only provenance verification again matched all six release identities and source-file counts. This addendum supersedes only the scaffolding disposition in my earlier `review.md`; it does not make a pair-freeze claim.

## Corrected rows and gates

- **WallSkull bounds:** corrected as requested. Ordinary wall-skull boxes have extents `(8,8,8)/16`; piglin wall-skull maximum extents are `(10,8,8)/16`, so the largest mean is `13/24`.
- **DecoratedPot:** corrected size to `11/12` for extents `14/16 × 1 × 14/16`; the 1.19.4 registration is explicitly identified as gated by `FeatureFlags.UPDATE_1_20`.
- **Candle, Cocoa, SnowLayer:** the corrected report now says these registrations remain collision-enabled and on the player path. Snow’s `forceSolidOff` only fixes `calculateSolid`; it does not bypass collision-shape dispatch.
- **Scaffolding:** the corrected report correctly retracts my earlier no-collision exclusion. The custom `getCollisionShape` override is invoked despite the registration’s `.noCollission()` property.

## Scaffolding dispatch and provider equality

The six exact `Blocks.java` registrations all apply `.noCollission().dynamicShape()` to `ScaffoldingBlock`. The registration flag alone does not exclude the provider because the player collision dispatch skips the default provider:

1. `Entity.collide(Vec3)` sends the moving player box through block-collision collection.
2. `CollisionGetter.getBlockCollisions` constructs `BlockCollisions` with `onlySuffocatingBlocks=false`.
3. `BlockCollisions` directly calls `BlockState.getCollisionShape(world, pos, collisionContext)`; it does not test `hasCollision`.
4. The contextual `BlockStateBase.getCollisionShape` overload directly calls `this.getBlock().getCollisionShape(state, world, pos, context)`.
5. Java virtual dispatch selects `ScaffoldingBlock.getCollisionShape`, which does not call the superclass. The superclass default’s `hasCollision ? state.getShape(...) : Shapes.empty()` guard is therefore never reached.

The override returns `STABLE_SHAPE` when `context.isAbove(Shapes.block(), pos, true) && !context.isDescending()`. Otherwise it returns `UNSTABLE_SHAPE_BOTTOM` when `DISTANCE != 0`, `BOTTOM` is true, and `context.isAbove(BELOW_BLOCK, pos, true)`; otherwise it returns empty. This proves a reachable nonempty player collision path (including the ordinary standing-on-scaffolding stable shape) despite `noCollision=true`.

I compared `ScaffoldingBlock.getCollisionShape`, its selector dependencies and all static collision-shape definitions at 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3 and 1.20.4. The method and definitions are identical at all six endpoints. The stable shape is the top plate at Y 14/16–1 plus four 2/16-wide corner posts; the unstable shape adds the same 2/16 bottom plate and four low edge rails; the special bottom shape is the full-XZ 2/16 bottom plate. Context predicates, state predicates, output-shape selection and constants match. `DISTANCE` ranges 0–7; `BOTTOM` is boolean; `WATERLOGGED` does not select collision geometry. Neighboring blocks affect those state values, but the provider itself reads the same current-state/context inputs in every release.

Whole-file hashes for `ScaffoldingBlock.java` are identical at 1.19.4 through 1.20.2 (`fe0d38c1f1f06453fb42aad778d0ae8a8a5e13db335be9b465ca8c7653339eec`) and identical again at 1.20.3/1.20.4 (`7e794a606f5dca4e5e02214bd0821b05c1ae2e654c164e146ad3d6e71dbee83f`). The file-level split is due to unrelated source changes; the collision override and its shape definitions are identical across both groups.

**Scaffolding result:** close its dynamic provider geometry as same-state equal across these six endpoints. Do not exclude it on `noCollision`; its collision override bypasses that default guard. The shape provider is movement-reachable, but this review found no cross-version provider difference.

## Residuals and verdict

The dynamic inventory remains 22 IDs per modern release: 17 shulkers plus bamboo, moving piston, pointed dripstone, powder snow and scaffolding. Shulkers and scaffolding now have source-equal provider geometry/reachability reviews. Four movement-relevant families remain open in each of the five modern releases: bamboo, moving piston, pointed dripstone and powder snow, totaling 20 open ID-release rows. Their state/context/provider geometry remains a residual; no pair freeze is claimed.

I accept the corrected WallSkull, DecoratedPot, Candle, Cocoa and SnowLayer rows. I also accept scaffolding as reviewed equal provider geometry with the collision-path correction above. The earlier report’s 4-family residual count is the correct open movement-geometry count after that closure; its dynamic inventory count remains five non-shulker IDs per release.

## Final verification of corrected report

Final target verified at SHA-256 `7c6249f3087e29b7c15b2016ae9e9b5310b5c1fe37636ead0f1bf6643e6d6d1d`. The report now has the corrected ordinary/piglin wall-skull extents and `13/24` maximum; DecoratedPot `11/12` and the 1.19.4 `UPDATE_1_20` feature gate; collision-enabled Candle/Cocoa/SnowLayer wording; and the dynamic, collision-enabled, no-force-off PowderSnow distinction. Its Scaffolding section correctly treats the custom override as player-reachable despite `noCollision=true`, records the equal provider behavior across six endpoints, and closes only that family’s geometry. Four dynamic families remain open (20 modern ID-release rows). **Verdict:** these corrections are accurately reflected; accept this bounded source review, with no pair freeze or runtime-parity claim.
