# Cached block-motion parity: base `Block` shape

## Scope and evidence

This closes the common registrations whose constructed class is `Block` in every modern release, using read-only Mojmap sources at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap` for 1.19.4, 1.20, 1.20.1, 1.20.2, 1.20.3, and 1.20.4. The independently established slice is the base class's inherited `BlockBehaviour.getShape` provider; this report does not claim completion for other subclasses.

Artifact hashes checked before use:

- `../independent-blocks-motion-audit/state-domain-roster.json`: `ce08fad89e0102e58c52628f18302cf2053e2608dee81f8fa6cae124d8b01698` (also matches its `SHA256SUMS.txt` entry).
- `../shape-state-census/shape-state-census.md`: `8c35d78ffa66726326e259294818fae4ec8d85805b4ddcd96fe8a285325bd9a8`.
- `../independent-blocks-motion-audit/source-hashes.json`: `bf825b2d01a199d8a0ca010174204ea2f9680279fc1acda132393972ece45909` (also matches its `SHA256SUMS.txt` entry).

The ten source files in `source-hashes.json` were independently rehashed against their listed SHA-256 values for all six releases (no mismatch). Their records bind to the six Mojmap source identities recorded in that artifact. `BlockBehaviour.java` was also checked directly in all six releases: `getShape(BlockState, BlockGetter, BlockPos, CollisionContext)` returns `Shapes.block()` in every one. `Shapes.java` is byte-identical in all six releases (`ec207e73b8e9de4b1234132f81126973f0cb2bb37646b070d273259f2e91311a`); its `block()` returns the unit cube. `BlockBehaviour.getCollisionShape` returns empty only when `hasCollision` is false, otherwise delegates to the state shape. For this group, the collision-enabled registration rows are the cached-shape rows in the verified roster; any force-on rows are true before shape inspection. The modern calculation order is independently read from each release's exact `BlockBehaviour.java`: force-on, force-off, null cache, empty shape, then bounds check. The 1.20+ bound rule is `getSize() >= 0.7291666666666666 || getYsize() >= 1.0`. `AABB.getSize()` is `(xSize + ySize + zSize) / 3.0`; for the unit cube both measured values are exactly `1.0`.

## Result

There are 159 common IDs whose registered class is exactly `Block` in every 1.20–1.20.4 release. Across all valid states and all six releases, their collision bounds are `[0,1] × [0,1] × [0,1]`: the state shape is independent of state, world, position, and collision context. In 1.19.4, all 159 have old `Material.blocksMotion() == true`. In each modern release, all 159 calculate to true: the five effective `forceSolidOn` registrations take the first gate; the remaining 154 reach the cached unit-cube bounds and pass. There are zero mismatches in 795 registration/release rows.

The detailed row table is [`base-block-collision-parity.csv`](base-block-collision-parity.csv), with release, ID, material bit, effective flags, exact bounds, calculated result, and equality. It includes all 159 IDs in each of the five modern releases. The old bit is the same 1.19.4 input for each repeated release row.

## Residuals

`shape-provider-residual.csv` enumerates all 838 other common IDs, with one row per ID and modern release (4,190 rows). These are excluded from this bounded result because their provider identity is not `Block` in every compared release; their collision shape, inheritance, state domain, and/or context path needs its own closure before deriving bounds. Two rows (`minecraft:melon` in 1.20.3 and 1.20.4) use base `Block` only in the newer releases but are residual because the provider is not base `Block` throughout the pair. This roster is intentionally precise about every excluded class/ID and release; it does not assert that every residual provider is state-dependent.

No pair-level no-difference, acceptance, or runtime-parity claim follows from this slice.
