# Local spectator transition clears vertical velocity
1.19.4, Mojmap: `net/minecraft/client/player/LocalPlayer.java`, no `onGameModeChanged(GameType)` operation.
1.20, Mojmap: `net/minecraft/client/player/LocalPlayer.java`, `onGameModeChanged(GameType)`, lines 1053–1056; `net/minecraft/client/multiplayer/ClientPacketListener.java`, player-info update caller, lines 1745–1748.
Difference: 1.20 adds a local-player callback that, when the received game mode is `SPECTATOR`, writes the existing delta movement with its Y component replaced by `0.0`; 1.19.4 has no corresponding callback. The update is triggered while the client processes a game-mode change for its local player.
Movement meaning: this directly changes local player vertical movement state at the mode transition. It is a player-state difference, separate from the tick movement formulas; no trajectory claim is made.
