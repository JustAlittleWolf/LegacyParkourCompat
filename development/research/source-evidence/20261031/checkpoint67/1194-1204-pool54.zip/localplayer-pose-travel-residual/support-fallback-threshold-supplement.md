# Support fallback threshold witness

## Source identity

Canonical input: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap`, with exact source hashes checked against each tree’s root source manifest or embedded provenance. `Entity.java` SHA256 by release: 1.19.4 `3667fee610cbc5f58012e3a8fb8d6c4849f649fb7fe5300595158112d8b4b58b`; 1.20 `94b9c3656715de2d61fa9a02ccef164261e50eb13d6090a6f07e58fe9c5b0759`; 1.20.1 same as 1.20; 1.20.2 `d7ee49aaea5e862b92508e767562cabc8f10515605e8fb67565c8c8d5c23b01b`; 1.20.3 `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9`; 1.20.4 same as 1.20.3.

Supplemental fixture sources (all actual files matched their recorded source hash): 1.20.2 `LivingEntity.java` `5c481da1ffc8684c4b30171c92e61fad751e6a3a708d5bc6486ac9f96ff69828`, `Blocks.java` `75e8e77adab4a07b02ef95619be83a004f5f79810cf3f07157a713d714881253`, `FlowingFluid.java` `0f44b1af25533dd8a1fbfec13b279739341db0c563568337a2825d3e46a1a5bb`, `WaterFluid.java` `3e10320356b11d415d8e4f3ea2b7fbb27e5bd8abdc45d524afb18b834e613e5f`.

Earlier-side fixture references: 1.19.4 `LivingEntity.java` `c8d91af61f87aaa1666de79696d7cd9d4a8212d05f873bdaf28d7bb2926bf165`, `Blocks.java` `a4f2df87c2cae5a3827a818f39f7ad123ee5b18905ead9947efe654421c30ff5`. These files also matched the 1.19.4 root source manifest.

## Fallback expressions and reachability

1.19.4, Mojmap: `net/minecraft/world/entity/Entity.java`, `getBlockPosBelowThatAffectsMyMovement()`, lines 760–762, returns `BlockPos.containing(position.x, boundingBox.minY - 0.5000001, position.z)`.

1.20, Mojmap: `net/minecraft/world/entity/Entity.java`, `getBlockPosBelowThatAffectsMyMovement()`, lines 790–792, returns `getOnPos(0.500001F)`. In `getOnPos(float)`, lines 798–814, an empty `mainSupportingBlockPos` falls back to `floor(position.x)`, `floor(position.y - amount)`, `floor(position.z)`. The same expressions are present in 1.20.1, 1.20.2, 1.20.3 and 1.20.4.

In 1.20+, `Entity.move()` calls `setOnGroundWithKnownMovement(verticalCollisionBelow, resolvedMovement)` after collision resolution (1.20 lines 640–642; same operation in later releases). A false grounded result clears `mainSupportingBlockPos` in `checkSupportingBlock()`. `Entity.move()` then calls `getBlockSpeedFactor()` unconditionally on its ordinary physics path (1.20 lines 700–702; 1.19.4 lines 659–661). Therefore an airborne, non-spectator player reaches the movement-factor read with no cached supporting block. `getBlockSpeedFactor()` reads the fallback block unless the current block is water or a bubble column (1.19.4 lines 750–757; 1.20 lines 823–830).

## Same-state witnesses

Use a non-spectator LocalPlayer at X=0.5, Z=0.5, Y=1.5000005, with feet equal to the AABB minimum Y, no cached support, and otherwise identical movement state in both source versions. The threshold literals evaluate as follows:

| Expression | Y result | Floored block Y |
| --- | ---: | ---: |
| 1.19.4: `1.5000005 - 0.5000001` | 1.0000004 | 1 |
| 1.20+: `1.5000005 - (double)0.500001F` | 0.9999994867210388 | 0 |

**Speed-factor fixture.** Set `(0,1,0)` to air and `(0,0,0)` to honey block, with no fluid at the player. The player is airborne, so `mainSupportingBlockPos` is empty after movement resolution. Both versions read air at `blockPosition()` `(0,1,0)`. The 1.19.4 fallback also reads air, giving speed factor `1.0`; the 1.20+ fallback reads honey, giving `0.4F`. The vanilla honey registration is `.speedFactor(0.4F)` in both 1.19.4 `Blocks.java` lines 3879–3886 and 1.20+ `Blocks.java` (e.g. 1.20.2 lines 6660–6664). The subsequent `Entity.move()` write multiplies X/Z delta movement by that factor. For the same nonzero horizontal component `0.1`, the source operation retains `0.1` in 1.19.4 and multiplies by widened `0.4F` in 1.20+.

**Jump-factor fixture.** Keep honey at `(0,0,0)` and set `(0,1,0)` to flowing water with `LEVEL=7`; leave `(0,2,0)` non-water. On a normal post-first-tick with the same Y and an empty support optional, the player is not grounded on a block. Flowing water height is `amount / 9.0F` (`FlowingFluid.getOwnHeight()`); level 7 yields `7/9`, so its surface is `1 + 7/9`. `Entity.updateFluidHeightAndDoFluidPushing()` measures from the player AABB deflated by `0.001`; at this Y the water height is about `0.27678`, positive and below the normal `0.4` jump threshold. Thus `isInWater()` is true and `LivingEntity.aiStep()`’s `jumping && waterHeight <= threshold && noJumpDelay == 0` branch reaches `jumpFromGround()` despite `onGround == false` (1.19.4 lines 2521–2527; 1.20 lines 2540–2546; 1.20.2 lines 2569–2575). `blockPosition()` is the water block, whose jump factor defaults to `1.0`; old fallback reads that same water block, while the new fallback reads honey, whose vanilla jump factor is `0.5F` (1.19.4 `Blocks.java` lines 3879–3886; 1.20+ e.g. 1.20.2 lines 6660–6664). With no Jump Boost, the jump-power multiplier therefore changes from `1.0` to `0.5` before the Y velocity write. Honey’s collision top is Y=1, below the player’s feet at Y=1.5000005, so this fixture has no block support; flowing water is non-colliding.

These are source-level reachable fixtures with identical vanilla block states, player position and input on both sides. They establish that the tolerance difference alone can choose a different block Y and change both the horizontal speed factor and the water-jump block factor. They do not claim measured trajectories.

## Cutover and disposition

The old double literal occurs in 1.19.4; the float-literal call plus empty-support fallback first occurs in 1.20 and remains unchanged through 1.20.4. The expression is an eligible player movement dependency: it is reachable from ordinary `Entity.move()` speed damping and from the shallow-water `LivingEntity.aiStep()` jump path. This is a second concrete applicability witness for the already drafted `getBlockPosBelowThatAffectsMyMovement` support-selector finding, not an independent operation/finding; retain it as supplemental evidence within that finding rather than opening a duplicate finding.
