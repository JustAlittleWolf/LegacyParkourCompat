# Step-only entity candidate terminal

## Verdict

**Source-valid bounded witness found.** Under the same raw player, world, block, and entity snapshot, the old movement operation returns horizontal displacement `0.19999998807907104` with no vertical displacement, while the new operation returns horizontal displacement `0.7` and vertical displacement `0.5`. The candidate is an ordinary Boat collision shape which intersects only the old raised-step query, not the original movement query. The old step attempt is then rejected by its strict progress comparison; the new step attempt omits that Boat from its reused entity-candidate set and clears the slab.

This addresses the previously open step-only entity-candidate terminal. It proves an operation-level source difference for equal valid raw inputs; it makes no claim about how the Boat/player snapshot was produced.

## Raw input fixture

- Old-era local player bounding box: X/Z `[0.19999998807907104, 0.800000011920929]`, Y `[0, 1.7999999523162842]`; this follows `PlayerEntity` width `0.6F`, height `1.8F`, and `Entity.setPosition`'s float half-width and height arithmetic. Player position is `(0.5,0,0.5)`.
- Movement is ordinary self movement `(0.7, 0, 0)`. Set `onGround=true`, `stepHeight=0.6F`, `noClip=false`; no sneak/cobweb/piston adjustment, vehicle relation, world-border collision, or unloaded chunk. These are raw comparison inputs.
- The world has air except a bottom oak slab at block `(1,0,0)`, with collision shape `[1,2] × [0,0.5] × [0,1]`. Its fixed state/shape is the same in both endpoints.
- One raw, loaded, non-spectator, pushable Boat entity is not mounted to or otherwise in the player's vehicle chain. Its box is X `[0.9,2.275]`, Y `[1.9,2.4625]`, Z `[-0.1875,1.1875]`, realizable by Boat position `(1.5875,1.9,0.5)` and dimensions `1.375F × 0.5625F`. Its old/new collision-shape method returns its own entity box. All other entity collision candidates are absent.
- Border is distant/interior. No other block or entity shapes affect this fixture.

Entity-history/producer validity is outside this source comparison.

## Candidate membership and resolution

1.13.2 `WorldView.getCollisions(entity, box, dx,dy,dz)` makes the swept collision volume and calls the world's collision route. `World.getCollisions` appends `getEntityCollisions`; `EntityView.getEntityCollisions` retrieves entities around the query and accepts an entity shape only if it intersects the swept query bounds. On the original `(0.7,0,0)` request, the query's Y maximum is at most `1.8000001`, below Boat `minY=1.9`, so the Boat does not affect ordinary movement. The slab clips X at `1 - 0.800000011920929 = 0.19999998807907104`.

The step gate opens because `onGround` is true and ordinary X was clipped. The old step query is made with `(0.7, (double)0.6F, 0)`; its swept upper Y is approximately `2.399999976158142`, so the Boat shape is included. Old alternative 1 first checks upward motion against the horizontally expanded box. The Boat therefore caps that rise at `1.9 - 1.7999999523162842 = 0.10000004768371582`. After that rise the player top is at the Boat's bottom; the epsilon-adjusted orthogonal overlap in `calculateMaxDistance` means the Boat does not clip horizontal motion. The slab clips X to `1 - 0.800000011920929 = 0.19999998807907104`. The downward pass returns to Y `0`; at that X position the player maxX equals the slab minX, and the epsilon-adjusted orthogonal overlap means the slab does not clip the descent. Alternative 2 rises by the full `0.6000000238418579`, then the Boat clips its X to `0.099999988079071`; it also descends to Y `0` because it remains short of the slab. Alternative 1 wins (`~0.04 > ~0.01` horizontal progress squared), but ties ordinary movement at X `0.19999998807907104`. Old `Entity.move` accepts a step only when step progress is **strictly greater** than ordinary progress, so it restores ordinary movement: `(0.19999998807907104,0,0)`.

1.14.4 `Entity.m_72373519` queries entity/border shapes once, from the original swept box, and carries that candidate stream through its step vectors. `EntityView.getEntityCollisions` expands that original box by `1e-7`; its Y maximum remains below `1.9`, so the Boat is absent. Block candidates are rebuilt for movement vectors, so the slab remains present. The initial X movement is clipped to `0.19999998807907104`, opening the same step gate. On the raised horizontal movement, the slab is below the raised player and the absent Boat cannot clip X; X travels the full `0.7`. Downward movement clips at the slab's `0.5` top, producing `(0.7,0.5,0)`. This step has greater horizontal progress than ordinary movement and is returned.

The result includes a changed resolved position and collision flags: old horizontal collision true/vertical false; new horizontal false/vertical true. In both cases `onGround` is false after this request because the final `onGround` assignment requires a vertical collision and the original requested Y to be negative.

## Exact source anchors

- Old step query, alternatives, strict progress fallback and final flags: `1.13.2/Entity.java` lines 578–674.
- Old swept-volume construction and block/entity route: `1.13.2/WorldView.java` lines 154–171; `1.13.2/World.java` lines 1755–1757; `1.13.2/EntityView.java` lines 21–35.
- New one-time entity candidate query and reused step candidate stream: `1.14.4/Entity.java` lines 656–676. Fresh block collision concatenation in mixed-axis resolution is `Entity.java` lines 692–703.
- New entity query's `1e-7` box expansion and shape-intersection filter: `1.14.4/EntityView.java` lines 53–67.
- Player size and centered shape: `1.13.2/PlayerEntity.java` lines 450 and 1306; `1.13.2/Entity.java` lines 285–299 and 309–315.
- Boat size and own-box collision shape: `1.13.2/vehicle/BoatEntity.java` lines 76–78, 109–123; new equivalent `1.14.4/vehicle/BoatEntity.java` lines 111–118 and registered dimensions in `1.14.4/EntityType.java` lines 145–146.
- Bottom slab shape: `SlabBlock.java` both versions, old lines 26–53 and new lines 45–68.
- Voxel axis clipping uses orthogonal-axis overlap and clips to the first crossed shape boundary: `1.13.2/block/shape/VoxelShape.java` lines 188–240; `VoxelShapes.java` lines 194–204.

## Source identity

Every listed Java source hash below was recomputed from the read-only Feather publication and matched its version-root `ornithe-feather.sources.sha256` entry.

| Version | Source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.13.2 | `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` |
| 1.13.2 | `net/minecraft/entity/vehicle/BoatEntity.java` | `3d9c248c8cb5846ac157b7973e4c6f448fe12bdc63c8d33931dace98682c0f66` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 | `net/minecraft/block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` |
| 1.13.2 | `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/world/EntityView.java` | `3822844ced53882c52f0523a1bd714baa3cd9bb9dab38a5e2c53051c7b1590e3` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.14.4 | `net/minecraft/entity/vehicle/BoatEntity.java` | `2a33747d7d429ed58ef599de2eceddec5b377a78a1c3ddecd20def1d4907e3c9` |
| 1.14.4 | `net/minecraft/entity/EntityType.java` | `0b4bebd0cbe746bdc99b80fc173b9cff1ce69016012da2505638c600685273fe` |
| 1.14.4 | `net/minecraft/block/SlabBlock.java` | `91f2ebc592e5cb07d5ce8a6faa123ec0d4b7bf10aa6323d6aceb343bc0f73a53` |
| 1.14.4 | `net/minecraft/util/math/Box.java` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
