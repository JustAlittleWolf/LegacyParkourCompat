# Glass face predicate to falling-fluid player-current witness (1.13.2 → 1.14.4)

## Disposition

The exact same raw WATER/player/block snapshot yields a direct local-player vertical velocity-delta difference: 1.13.2 contributes `0`; 1.14.4 contributes `-0.014`. This is source-level and conditional on the stated query snapshot and default vanilla tags. There is no fluid/player producer history, ordinary trajectory, later movement-vector, or pair-freeze claim.

## Exact paired snapshot

- `P=(0,0,0)` contains flowing WATER with `LEVEL=8,FALLING=true`; it matches the default `FluidTags.WATER` recipe at both endpoints.
- `P+EAST` is the common `minecraft:glass` block; its fluid state is empty. The other horizontal neighbors are air with empty fluid. All four horizontal cells above and below those neighbors are air/empty; `P+UP`, `P+2UP`, and all scan cells above P are air/empty.
- The local standing player position is `(0.5,0.48,0.5)`, dimensions `0.6×1.8`, liquid collision enabled; the world area queried is loaded. The contracted box bounds are `[0.201,0.799]×[0.481,2.279]×[0.201,0.799]`, so the fluid-body loops scan x=0, y=0..2, z=0 and only P qualifies as WATER. The box does not overlap the glass block at x=1.

## Flow result

In both `FlowingFluid.getFlow` bodies, the first horizontal pass examines N/E/S/W. The neighbor fluid is empty in every direction. At E, glass material blocks movement, so the lower-fluid fallback is skipped; the other three neighbors are air, whose lower cells are also empty. Thus every gradient term stays zero and `vec3d` begins as `(0,0,0)` at both endpoints.

Because the state is falling, both methods then test each horizontal neighbor and its upper neighbor. For old glass at E, `Block.isExceptionForAttachment` returns true because old `isExceptionForPlacement` includes `Blocks.GLASS`; this short-circuits `isSolidFace` to false before old `Block.getFaceShape=SOLID` is read. No other queried horizontal or upper face is solid. Old `getFlow` returns `normalize((0,0,0))=(0,0,0)`.

In 1.14.4, `isSolidFace` keeps the same-fluid, UP and ICE gates, then asks `BlockState.m_87223014`. Its new face-sturdy path rejects default LEAVES and tests whether the collision shape fills the selected face. The common GLASS registration is full-cube and absent from the default LEAVES recipe, so the EAST face returns true. It is the first matching face in `Direction.Plane.HORIZONTAL`; the method evaluates `normalize((0,0,0))+(0,-6,0)=(0,-6,0)`, then returns `(0,-1,0)` after final normalization.

## Player-current and write arithmetic

The raw fluid state height is `8/9` in 1.13.2 (`LEVEL/9.0F`). In 1.14.4, the world-aware height returns the same level height because `FluidState` above P is empty, not the same fluid. The player body-current depth is:

```text
8/9 − contractedBox.minY
= 8/9 − 0.481
≈ 0.4078889
```

This is not less than `0.4`, so neither version scales the contributor. There is one qualifying cell. In 1.13.2 accumulated flow remains zero and the `vec3d.length()>0` writer gate does not run. In 1.14.4 the single `(0,-1,0)` contributor is retained for a player (player instances are not normalized a second time), and the entity writer adds `flow.scale(0.014)`, producing Y velocity delta `-0.014`. Existing velocity is a paired input; no absolute post-write velocity or next travel result is claimed.

## Exact source evidence and identity

Read-only primary sources are the published Ornithe Feather Gen2 build 2 endpoint trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Ready/provenance/source-manifest SHA-256 values are, respectively: 1.13.2 `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38`, `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383`, `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77`, `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9`, `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

| Relative source file | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0f0ef100c44fb8372d3e148ce` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/fluid/state/FluidState.java` | `05e2df9377a3bc1e91645ce4282bcaa4edebe93d7ef1907407961baaecff23a6` | `ee0bfe92723a768337bc8159aabb38aed187ac99d9d129fe994b099865b4db98` |
| `net/minecraft/data/tag/FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` |
| `net/minecraft/data/tag/BlockTagsProvider.java` | `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` | `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |

The endpoint source-manifest matches for these files were recomputed from the exact trees. `Block.java` shows old `GLASS` in `isExceptionForPlacement`/`isExceptionForAttachment` (lines 243–257), default old face `SOLID`, and a full collision cube when the block's default collision gate is enabled; 1.14.4 `isFaceSolid` (lines 402–403) checks `!LEAVES` and a full collision face. Old glass registration is `Block.java:892`; new registration is `Blocks.java:204`. `base-inherited-face-membership-closure/result.md` independently cross-references the `glass` registration as old false/new true for all states and confirms the default LEAVES recipes list only the six leaf IDs. The default `FluidTagsProvider` WATER recipe on both endpoints contains flowing and source water.

This report establishes only the direct conditional flow/current/velocity query under the enumerated vanilla snapshot. It does not establish any fluid/player history, ordinary trajectory, damage, runtime tag replacement or complete-pair coverage.
