# Independent shulker dynamic-shape recheck: 1.13.2 → 1.14.4

## Evidence and method

I independently read the exact Feather endpoint sources at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `.../1.14.4/ornithe-feather`, with no writes to either source tree. Their publication directories are both `ornithe-feather`; 1.14.4 also has Mojmap, which is not used here. The source manifests are `ornithe-feather.sources.sha256`; direct SHA-256 values below were recomputed from the named files. The supplied shulker report was used only to locate the bounded slice.

## Independently checked result

**Collision provider output closes as equal for common vanilla inputs.** Both registration sites enumerate the same 17 shulker variants (base plus 16 colors), and every constructor uses `.dynamicShape()`: 1.13.2 `Block.java:1615–1642`; 1.14.4 `Blocks.java:1458–1512`. `ShulkerBoxBlock` declares only `FACING` as a state property at each endpoint (`:39–46,117–119` old; `:45–53,118–120` new), with the six `Direction` values. The dye color is stored but is not read on the collision path.

Old `ShulkerBoxBlock.getShape(state, world, pos)` reads the block entity and returns `VoxelShapes.block(blockEntity.getShape(state))` for a `ShulkerBoxBlockEntity`, otherwise `VoxelShapes.block()` (`1.13.2 ShulkerBoxBlock.java:210–213`). New `getShape(state, world, pos, context)` does the same (`1.14.4 ShulkerBoxBlock.java:226–229`); it does not read `context`. Thus missing/non-shulker block entity fallback also pairs. The new `BlockState.getShape` and `getCollisionShape` forward context to the block provider; for a dynamic shape, `cacheShape()` intentionally leaves `cache` null and `getCollisionShape(world,pos)` dispatches through `CollisionContext.empty()` to the live provider (`BlockState.java:65–69,189–202`). This prevents an initialization-time dummy-world shape from replacing the block-entity-derived result. The old block state similarly calls its live provider (old `BlockState.java`, same source manifest; see endpoint source hash inventory).

The block-entity geometry formula is equal. Both `getShape(BlockState)` delegate to `getShape(state.get(FACING))` (old entity `:92–94`; new `:93–95`). Both expand the unit-block bounds in the facing offset by `0.5F * interpolatedProgress` and leave perpendicular axes unchanged (old `:96–104`; new `:97–100`). Old code calls `getProgress(1.0F)` per coordinate; new code stores its result once in a `float`. Both `getProgress(tickDelta)` interpolate `lastProgress` to `progress` (`MathHelper` lerp, coefficient `1.0F`) (old entity source near `:199–201`; new `:282–284`). For any equal pair of raw float fields, including stage-inconsistent/out-of-range values, the result at coefficient 1 is `progress`; it is pure, so repeated calls and one local call yield the same float. The multiplication order, `0.5F` literal, float operations and facing integer offsets are unchanged. Therefore the resulting box is equal for all six facings, all four enum stages, arbitrary equal raw progress fields, all 17 variants, and all collision contexts. Stages do not enter this collision formula.

**Face result has a separately verified difference.** Old `getFaceShape` reads facing and animation stage: CLOSED is SOLID on all sides, OPENING/CLOSING are UNDEFINED on all sides, OPENED is UNDEFINED on facing/opposite and SOLID on the four perpendicular sides (`1.13.2 ShulkerBoxBlock.java:311–318`). New has no matching provider; with no cache, `BlockState.m_87223014` calls `Block.isFaceSolid` (`BlockState.java:326–328`), which tests the live collision geometry and excludes only default-tag leaves (`Block.java:402–408`). For the paired geometry, at progress zero all six sides are full; for progress above zero the face in `FACING` is outside the unit boundary and not sturdy, while the opposite and four perpendicular boundary slices remain sturdy. This new direct predicate depends on progress, not stage, so arbitrary mismatched raw stage/progress pairs are covered by that description.

That direct predicate difference does not alone characterize the old fluid helper: old `FlowingFluid.isSolidFace` filters shulker blocks through `Block.isExceptionForAttachment` before consulting `FaceShape` (`1.13.2 FlowingFluid.java:105–123`, `Block.java:241–257`), whereas new flow helper has no equivalent shulker exclusion and consults the face-sturdy predicate (`1.14.4 FlowingFluid.java:106–115`). Under default vanilla leaf tags and equal raw inputs, this is a changed direct input to the falling-fluid flow calculation. No fluid/player trajectory or block-state producer claim is made.

## Residuals and scope

No raw collision `progress`, `lastProgress`, facing, animation stage, block-entity class/presence, color, or `CollisionContext` mismatch remains for this provider pair. This does not establish how those raw inputs are produced, synchronized, or how a resulting fluid vector affects a player. Custom block/tag replacements and intermediate releases remain outside this endpoint pairing. The face/sturdy consumer result is not an equality claim; its provider and old/new fluid-helper routes were checked above.

## Direct source SHA-256

Paths are relative to `decompiled_minecraft/`; hashes recomputed with `Get-FileHash -Algorithm SHA256`.

| Endpoint | File | SHA-256 |
|---|---|---|
| 1.13.2 | `ornithe-feather/net/minecraft/block/ShulkerBoxBlock.java` | `9d2652c2944cc8faf1a277349fbf2015170a4799ad882f876d24ee1d7f344fb8` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/ShulkerBoxBlock.java` | `016487146bc14aba8de02272e0bf5c76b4dff16c276abf30bf92cfa3061593df` |
| 1.13.2 | `ornithe-feather/net/minecraft/block/entity/ShulkerBoxBlockEntity.java` | `d123b08d4d3562ccb972a4433ec5a743cdd6877c59c5b6aa20d06af2063fa5ed` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/entity/ShulkerBoxBlockEntity.java` | `58b5e9f68831f6e3a3d293ae29c8c0c55628fc5a8d941e18286eb10ec7c0ba73` |
| 1.13.2 | `ornithe-feather/net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/shape/VoxelShapes.java` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| 1.13.2 | `ornithe-feather/net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` |
| 1.14.4 | `ornithe-feather/net/minecraft/fluid/FlowingFluid.java` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |
| 1.14.4 | `ornithe-feather/net/minecraft/util/math/MathHelper.java` | `e39d5dfc69c17a9032be086d7d4d14cc63525962a0ff83615b1befdcca599843` |
