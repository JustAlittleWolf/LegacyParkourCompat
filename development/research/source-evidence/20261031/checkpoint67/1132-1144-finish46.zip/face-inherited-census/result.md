# Inherited face-provider census: 1.13.2 → 1.14.4

## Scope and source identity

This read-only source pass closes the inherited-method portion of the falling-fluid face terminal against the existing exact inventories. Primary source family is Ornithe Feather Gen2 build 2 at both endpoints under `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Publication manifests and source identities are recorded in `../providers/inventory.md` (manifest hashes: 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`).

The old direct `getFaceShape` declaration inventory has 65 rows (`../providers/fluid-face-shape-providers.tsv`); the paired direct shape/collision declaration inventory has 93 old and 115 new rows (`../providers/shape-provider-overrides.tsv`, file SHA-256 `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad`). This pass does not repeat member-by-member raw-state shape work already in the result files listed below.

## Caller semantics relevant to inherited output

The paired `FlowingFluid.getFlow` caller samples only horizontal faces, at the horizontal neighbor and the cell above it, on the falling-fluid path. Old `isSolidFace` returns false for same-fluid, otherwise checks ICE, then the attachment-exception set and stairs, and finally asks whether `BlockState.getFaceShape(...) == SOLID`. New `isSolidFace` retains same-fluid, UP and ICE gates, then delegates to the state face-sturdy predicate; `Block.isFaceSolid` is `!state.is(BlockTags.LEAVES) && isFaceFull(state.getCollisionShape(...), face)`. Therefore an inherited old `Block.getFaceShape` default alone is not enough to infer a difference: the concrete registration's resolved old face implementation, old exception/material gates, collision shape, and generated vanilla LEAVES membership all matter.

## Inheritance resolution across declared old shape providers

For each of the 85 distinct old Java classes represented by the `getShape` / `getCollisionShape` declaration inventory, I resolved the class/ancestor chain against the 65 direct face-provider declarations. The declared shape providers do not reveal an unaccounted registered concrete class whose custom shape inherits `Block.getFaceShape`:

| Shape-provider classes with no direct `getFaceShape` declaration in that same class | Resolved inherited face implementation | Disposition |
|---|---|---|
| `AttachedPlantStem`, `DeadBushBlock`, `FlowerBlock`, `LilyPadBlock`, `MushroomPlantBlock`, `NetherWartBlock`, `SaplingBlock`, `SeaGrassBlock`, `StemBlock`, `TallPlantBlock`, `WheatBlock`, `BeetrootsBlock`, `CarrotsBlock`, `PotatoesBlock` | `PlantBlock` directly overrides old `getFaceShape`; crop subclasses route through `WheatBlock`/`PlantBlock` | No inherited-`Block` gap. The old provider's output still requires the exact old state/helper gate; collision/no-collision shape families are covered in `plant-crop-shapes-pairing` and `small-collider-shapes`. |
| `BaseCoralFanBlock`, `BaseCoralPlantBlock`, `CoralPlantBlock` | `BaseCoralPlantTypeBlock` directly overrides old `getFaceShape` | No inherited-`Block` gap; concrete coral provider domains are included in `plant-crop-shapes-pairing`. |
| `FloorSkullBlock`, `WallSkullBlock` | `SkullBlock` directly overrides old `getFaceShape` | No inherited-`Block` gap; floor/wall registration/shape crosswalk is in `sign-skull-banner-shapes`. |
| `StandingBannerBlock`, `WallBannerBlock` | `BannerBlock` directly overrides old `getFaceShape` | No inherited-`Block` gap; provider domains are in `sign-skull-banner-shapes`. |
| `WallSignBlock` | `SignBlock` directly overrides old `getFaceShape` | No inherited-`Block` gap; sign registration/provider split is in `sign-skull-banner-shapes`. |
| `RedstoneWallTorchBlock`, `WallTorchBlock` | `RedstoneTorchBlock` / `TorchBlock` directly override old `getFaceShape` | No inherited-`Block` gap; torch and redstone state classes are in existing climb/shape reports. |
| `BaseCoralWallFanBlock`, `SeaPickleBlock`, `SoulSandBlock` | The class itself has a direct old face override despite its shape-provider entry being inherited or located elsewhere | Direct rows remain under the existing 65-row face inventory and closure report. |
| `PaneBlock`, `PipeBlock` | Inherit old `Block.getFaceShape` at the abstract/helper layer | Neither is used as a concrete common registration without an intervening direct old face override: registered `glass_pane` / `iron_bars` use `IronBarsBlock`; fence/wall descendants use their own direct providers; registered `chorus_plant` uses `ChorusPlantBlock`. The common concrete outputs are covered by `pane-snow-fence-shape-pairing`, `wall-shape-pairing`, `fluid-face-unpaired-closure`, and the relevant direct rows. |
| `MovingBlockEntity` | Not a `Block` subclass; its dynamic terminal is supplied by `MovingBlock` | Excluded from a `Block.getFaceShape` inheritance chain; moving-piston fluid-face result remains covered by `fluid-face-masonry`. |

The remaining declared providers that directly define `getFaceShape` are already in the 65-row direct inventory; the old direct-provider reconciliation in `fluid-face-unpaired-closure/result.md` binds the residual common classes/state domains and the complete stair matrix. This hierarchy check prevents incorrectly treating helper/base declarations (notably `PaneBlock` and `PipeBlock`) as registered concrete old defaults.

## Base default and exception disposition

The old base `Block.getFaceShape` returns `FaceShape.SOLID`; base `Block.getShape` returns the unit block, and base collision dispatch returns empty only when `hasCollision` is false, otherwise dispatching to that same state shape. Thus ordinary base-`Block` registrations with collision enabled and the default unit shape produce old horizontal true and new horizontal full-face true (except active LEAVES membership). The registration's property-copy/`.noCollision()` configuration must not be assumed for unrelated subclasses.

Exact old attachment exceptions and the ICE material gate are enumerated and reconciled in `fluid-face-unpaired-closure/result.md`. Under the generated vanilla tag assumption, exceptions which create direct old/new face differences remain the already recorded families: glass, stained glass, beacon, glowstone, sea lantern, selected piston progress/states, and stairs. Leaves are rejected by the new predicate through generated `LEAVES`; trapdoors, cauldron, conduit, and paired shulker states have their source-state outcomes recorded in the cited shape/face reports. This census adds no new independent accepted difference and makes no trajectory claim.

## Result and remaining scope

This closes the **method-inheritance question for all declared old shape-provider classes** and shows that the two helper roots inheriting the old base face method (`PaneBlock`, `PipeBlock`) do not directly supply a common concrete registration without a more-specific old face provider. It does **not** close the full face terminal or pair freeze. A registration-by-registration common-ID/state/neighbor census of all remaining concrete inherited-base/default-shape registrations and generated tag membership is still required to substantiate the universal base-default clause across the complete registry; full ordinary movement collision/context/chunk/entity candidate closure also remains open as shown by independent audit v3. Runtime/custom tag payloads are excluded inputs. No bounded trajectory is inferred.

## Exact source file hashes

All hashes are full-file SHA-256 from the canonical Feather trees; they were checked against the manifests cited above.

| Relative source | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/PlantBlock.java` | `a1234ccec309bd8805fbe3bad48bce076e17c131e048d2a57d18cdb75f0f286e` | `6ede310fcb1e0163865dd4161b291cc02fe223bb56dfa1f89aa64b1cf72a1f75` |
| `net/minecraft/block/BaseCoralPlantTypeBlock.java` | `661b6d0f87c8a872acd945c0716aa396ac53932d773b17e31be95b224e531fc6` | `561ff00b85e21d4256ddc91250e0ee317b48dab946de3ac71cf47ead6514630e` |
| `net/minecraft/block/BannerBlock.java` | `21384a99f500bbedcac1e36e4639cb27bf7a7bdeb4c349661b13137facf18e07` | `dcdfec684cf0a929a1acfad2597f99f52f2cbe26415b2acd25309e215c2b127b` |
| `net/minecraft/block/SkullBlock.java` | `cb23466df16370da0f1e708210af9bca0f42e40270afa9d7eef21abc3254ac0c` | removed; floor/wall descendants use `BannerBlock` ancestry |
| `net/minecraft/block/SignBlock.java` | `64d61e8c4758d6f1d13d92e56a25f7599736e625fcfaa980fcb1f8bebfe5ad39` | `0094a15d80c84593ebff08e68f0f0d5b9983ead9e289940b1dbdde734929c51c` |
| `net/minecraft/block/RedstoneTorchBlock.java` | `d6be1c4a35b5112012e4b583310836bac3cac5e735e2671bb33c0cf9a8a7710f` | `dd5b2d30b0742609d6710c617013303e3d89db758f62043f454ea1dcd11f7612` |
| `net/minecraft/block/DoublePlantBlock.java` | `95e782d379a7e8fbbe24497bd25d840aab47ccc6fb2de8f50f5afa0cbd8080fa` | `44b9787e974632f4f9594d458388a3a84afdd3983012f809fb5b3d762fde7785` |
| `net/minecraft/block/TorchBlock.java` | `da11308e51f57ce95764f2ee645dde8d15607914a3a68bac9c0635ab3d1531e0` | `8430a1058184d9e87596d5ba961ce092e6c77469c642f50e5c901db1a0588aab` |
| `net/minecraft/block/IronBarsBlock.java` | `df6d956bb2745241e59294056f31513151b976dbd9ce3df5478fd72b66c68a0` | `10ccd6a2135cb05e74cdd4c440da29992dbc60655beedcb5f648f73bbc150541` |
| `net/minecraft/block/FenceBlock.java` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` | `4319ffb95ad81e969b11b39a8e6361d678b5fb5f3ad210d9834ce5e30d5f45d8` |
| `net/minecraft/block/FenceGateBlock.java` | `e251cbd1b5e06c42e856a1d537e4ba043f6760b8f54ea1388039428aa7c05164` | `c6c869ac12993e09f4684798e843778b2b63b7d9766f9cac0894dae0f312a151` |
| `net/minecraft/block/WallBlock.java` | `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf` | `033da2cef0973f5d380a81b53ee76e23324fffece72edc74e12fcee0d8764be7` |
| `net/minecraft/block/ChorusPlantBlock.java` | `299acaed9644e0837a29f282e830dc7582b8d8f14a1c904147c034518e474433` | `0c05da2c054d2912bd667aaa200c4428fcc8e4064874056907656376b6120189` |
| `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |
| `net/minecraft/block/PipeBlock.java` | `4c56867771e5848fec41d7ccbce5339af3dfefa7f98afb4712dfd0d5abd8f9a9` | `50974f5a929e70166c8edbac17dd22b295ceb50bacd345d2b89a25bb150740b6` |

No decompilation, build, test, gameplay launch, canonical source write, product/wiki/backlog read, or Git operation occurred.

