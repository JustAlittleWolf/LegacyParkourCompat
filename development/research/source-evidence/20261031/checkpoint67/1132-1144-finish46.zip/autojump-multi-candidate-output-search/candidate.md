# AutoJump multi-candidate output witness draft

**Conditional source-level candidate:** 1.13.2 → 1.14.4 changes the scheduled-jump write for identical raw AutoJump inputs and the same vanilla state assignment. The result depends on old aggregation of adjacent full-cube collision voxels versus the newer per-block candidate stream. This is not a trajectory or producer-history claim.

## Minimal raw callback fixture

Use both endpoints with the same LocalClientPlayerEntity callback inputs and effective player shape:

- Position and shape: `x = -0.4`, `z = 0.5`, `getShape().minY = 0.0`, `getShape().maxY = 1.8`, width `q = 0.6`, height `r = 1.8`.
- Callback displacement: `dx = 0.6F`, `dz = 0.0F`; movement speed `f = 0.1F`; yaw `0°` and pitch `0°`. The callback's computed displacement magnitude is above `0.001F`; the fallback vector is not used. Facing dot is `0`, so the `m < -0.15F` gate passes.
- State gates: AutoJump enabled; cooldown `<= 0`; on ground; not sneaking; not riding; nonzero input movement; no jump boost (`o = 1.2F`).
- Headroom positions are `(-1,1,0)` and `(-1,2,0)` under floor-to-block conversion; both are air.
- Interior loaded world, far from border, no entity collision candidates. All unspecified cells are air.
- Collision blocks: `STONE` at `(0,0,0)`, `(1,0,0)`, and `(1,1,0)`. No other blocks are needed.

With `g = (float)(dx² + dz²) = 0.36F`, the normalized callback direction is +X, `l ≈ 1/sqrt(0.36)`, and `p = max(f*7, 1/l) = max(0.7, about 0.6) = 0.7`. The callback query box extends from `x=-0.4` to `x=0.9` before its `0.6` horizontal growth, has Y extent `[0,1.8]`, and Z extent `[-0.1,1.1]`. The raised probe lines run from `(-0.4,0.51,0.2/0.8)` to `(0.9,0.51,0.2/0.8)`. They intersect the `(0,0,0)` stone, do not intersect the `(1,0,0)` stone, and do not intersect the upper stone at `(1,1,0)`.

## Query and callback result

In 1.13.2, `WorldView.getBlockCollisions` visits blocks in mutable region order, stores base full-cube `VoxelShapes.block()` results in a single `BitSetVoxelSet`, and appends one `IntVoxelShape` after ordinary shape outputs. For this L-shaped occupancy, `VoxelSet.forEachBox` starts at the bottom cell `(0,0,0)`, extends the lower run across X to `(2,1,1)`, and cannot extend it upward because `(0,1,0)` is air. Its first bounding box is therefore `[0,2] × [0,1] × [0,1]`; the upper cell is a separate box. The lower box intersects the raised probe, so old AutoJump sets initial `s=1`. Its center is `(1,0.5,0.5)`, which converts to `BlockPos(1,0,0)`. At the sole loop iteration `t=1`, clearance reads `(1,1,0)`, the upper stone. That provider returns a unit cube, so `s=2`, and `s - minY = 2 > o=1.2`; old AutoJump returns without writing `ticksToNextAutojump`.

In 1.14.4, `C_29205863` enumerates X fastest, then Y, then Z. The collision stream emits the overlapping stone shapes individually. Its first intersecting candidate is the block at `(0,0,0)`; `(1,0,0)` is after it and the upper `(1,1,0)` shape does not intersect the probe at Y `0.51`. The selected unit box has center `(0.5,0.5,0.5)`, converted to `BlockPos(0,0,0)`. At `t=1`, clearance reads `(0,1,0)`, which is air, so `s` remains `1`; `u=s-minY=1` satisfies `0.5 < u <= 1.2`. New AutoJump writes `ticksToNextAutojump = 1`.

**Terminal delta for identical callback inputs and identical raw block states:** old leaves the cooldown unscheduled; new schedules `1`. On the next `mobTick`, the new scheduled value is consumed by the paired forced-jump input path. No path to this raw fixture through prior ticks is asserted.

## Exact source evidence

Source family: Ornithe Feather Gen2 build 2, 1.13.2+build.2 and 1.14.4+build.2. Canonical source-manifest SHA-256: `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2), `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4). The callback source and manifest identities are also recorded in `autojump-callback-terminal/report.md`.

| Endpoint | Source file/member | Relevant lines | Whole-file SHA-256 |
|---|---|---:|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java`, `autoJump` | 882–980 | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java`, `autoJump` | 857–955 | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/world/WorldView.java`, `getBlockCollisions(VoxelShape,...)` | 108–151 | `9577360b1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java`, `getBlockCollisions(Entity,Box)` | 133–180 | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.13.2 | `net/minecraft/block/shape/VoxelSet.java`, `forEachBox` | 200–252 | `fe39ea60ac27e595280627a4d15ea93a69292da5870b5ef34a1d7d7283a267c6` |
| 1.14.4 | `net/minecraft/unmapped/C_29205863.java`, `m_97468855` | 25–54 | `d15373ef21f58ed67755269d32b2dd5ff65eb33dd4eea33e854b505b9ac9afdb` |
| 1.13.2 | `net/minecraft/block/Block.java`, `getShape` / `getCollisionShape` | 388–395 | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java`, contextual `getShape` / `getCollisionShape` | 371–378 | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |

All whole-file hashes above were recomputed read-only and agree with the paired reports where those files overlap. No canonical source was modified.

## Limits

This is a bounded callback/query output witness for adjacent base full cubes and air. It does not close all candidate orders, contextual providers, chunk behavior, border/entity candidates, callback input production, trajectory reachability, runtime parity, or intermediate patch boundaries. It is a draft for reconciliation and independent audit, not a permanent finding or implementation instruction.


