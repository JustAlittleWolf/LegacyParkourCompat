# AutoJump multi-candidate output search report

## Result

A concrete conditional scheduled-jump delta is found for identical raw callback inputs and a shared vanilla provider setup. Three `STONE` blocks at `(0,0,0)`, `(1,0,0)`, and `(1,1,0)` make an L-shaped occupied voxel set. In 1.13.2, the full-cube accumulation emits a merged lower bounding box whose center is `(1,0.5,0.5)`; its above-center lookup hits `(1,1,0)`, raises `s` to `2`, and returns before scheduling. In 1.14.4, per-block enumeration first yields the lower block at `(0,0,0)`; its above-center lookup at `(0,1,0)` sees air, leaving `s=1` and writing `ticksToNextAutojump=1`.

This directly answers the requested terminal for a multi-candidate setup. It needs no ordinary trajectory, producer history, test, or runtime launch. Candidate draft: `candidate.md`.

## Scope and method

Read-only comparison of the existing AutoJump callback reports/provider inventories and the exact 1.13.2+build.2 / 1.14.4+build.2 Ornithe Feather Gen2 source trees. I reused endpoint/manifests and paired scalar callback facts from `autojump-callback-terminal/report.md` and `autojump-query-terminal-expansion-v2/report.md`, then independently traced the block-query enumeration, old voxel box decomposition, provider outputs, and first-hit/clearance terminal for this fixture. No product, wiki, backlog, or Git data was consulted. No canonical source was changed.

## Reproduction inputs

See `candidate.md` for the full callback inputs and calculation. The core assignment is: player position `(-0.4,0,0.5)`, effective standing shape Y `[0,1.8]`, width/height `0.6/1.8`, callback displacement `(0.6F,0.0F)`, speed `0.1F`, yaw/pitch `0°/0°`, no jump boost, and the three listed stone blocks; all other blocks air. Set the ordinary eligibility gates to pass, keep the query interior/loaded, and provide no entity collision candidates. The callback's headroom lookups land in air at `(-1,1,0)` and `(-1,2,0)`.

The query box intersects all three stone collision shapes, but the raised probe at Y `0.51` intersects only the lower pair. The sole base-clearance loop iteration is `t=1` because `o=1.2F`.

## Paired control-flow calculation

| Step | 1.13.2 | 1.14.4 |
|---|---|---|
| Block candidate formation | Full-cube collision shapes are collected in `BitSetVoxelSet`; the final `IntVoxelShape` is appended after scanned ordinary shapes (`WorldView.java:108–151`). | Each overlapping translated collision shape is emitted as the mutable cursor advances (`WorldView.java:133–180`). |
| Candidate order/result | `VoxelSet.forEachBox` scans X/Y/Z; for the L occupancy it consumes the bottom `(x=0,y=0,z=0)` cell and merges the lower run across X to box `[0,2]×[0,1]×[0,1]`, then emits the upper unit cell separately (`VoxelSet.java:200–252`). The first lower box intersects the probe. | `C_29205863` increments X before Y before Z (`C_29205863.java:25–54`). Its first intersecting emitted box is the unit cube `[0,1]×[0,1]×[0,1]` at `(0,0,0)`. The upper cube at `(1,1,0)` is not probe-intersecting because it starts at Y 1. |
| Initial `s` and clearance position | `s=1`; merged box center floors to `(1,0,0)`; `t=1` reads `(1,1,0)` stone. | `s=1`; unit-box center floors to `(0,0,0)`; `t=1` reads `(0,1,0)` air. |
| Terminal | Stone's collision shape is the base unit cube, so `s=2`; `s-minY=2>1.2` returns without scheduling. | Air leaves `s=1`; `u=1` is strictly greater than `0.5` and at most `1.2`, so writes `ticksToNextAutojump=1`. |

Old box output ordering is supported by `VoxelSet.forEachBox`: the loop starts at X/Y/Z minimum, captures a contiguous Z run, expands it across X while the same Y run is occupied, then attempts Y expansion. Since the L lacks `(0,1,0)`, the lower run extends across X but not upward; the separate top unit remains after it. All three collision providers are shared base full cubes. The callback's downstream `mobTick` forced-input consumer is paired in the predecessor report (`LocalClientPlayerEntity.java:711–715` old, `:639–643` new).

## Evidence hashes

Whole-file hashes are SHA-256, recomputed read-only. Source manifest identity is Feather Gen2 build 2: 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

| Endpoint | Source file/member | Lines | SHA-256 |
|---|---|---:|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java`, `autoJump` | 882–980 | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java`, `autoJump` | 857–955 | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/world/WorldView.java`, block collision scan | 108–151 | `9577360b1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java`, collision candidate stream | 133–180 | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.13.2 | `net/minecraft/block/shape/VoxelSet.java`, `forEachBox` | 200–252 | `fe39ea60ac27e595280627a4d15ea93a69292da5870b5ef34a1d7d7283a267c6` |
| 1.13.2 | `net/minecraft/block/shape/IntVoxelShape.java` | full file | `e563f5530907a5cd0ecc07bd79473d378c8c1aeeaba1dbd7a4c6f703de7d7b3ca` |
| 1.14.4 | `net/minecraft/unmapped/C_29205863.java`, cursor | 1–76 | `d15373ef21f58ed67755269d32b2dd5ff65eb33dd4eea33e854b505b9ac9afdb` |
| 1.13.2 | `net/minecraft/block/Block.java`, base shape/collision shape | 388–395 | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java`, contextual base shape/collision shape | 371–378 | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |

Additional paired callback/query hashes, gates and the selected base-full-cube/air provider pairing are listed in `autojump-callback-terminal/report.md`, `autojump-query-terminal-expansion-v2/report.md`, and `providers/inventory.md` in the parent finish46 evidence set.

## Residual

This witness closes only the named interior, loaded, entity-free three-stone/air provider arrangement conditional on equal raw callback/player values. It does not generalize to arbitrary candidate shapes, contexts, first-hit order, missing chunks, border/entities, or prove that any prior tick produces this state/input. It makes no runtime-parity, pair-freeze, or intermediate-version boundary claim.
