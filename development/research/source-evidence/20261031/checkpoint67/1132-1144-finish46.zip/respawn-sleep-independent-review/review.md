# Independent review: copied sleeping state on local-player respawn

## Verdict

**CONDITIONAL — the tracked-state callback and first-tick branch are source-confirmed, but the exact post-reset position claim needs one fixture clarification and one input phrase should be corrected.** The candidate correctly identifies the old ordinary sleeping fields as not copied, the new optional sleeping-position tracker as copied, its client callback as a bed-center position write, and the subsequent `Pose.STANDING` reset as not clearing that tracker. After reset, new `isSleeping()` remains true; the ordinary old replacement's field is false. The `LivingEntity.mobTick` dead branch clears the local movement axes and skips `serverTickAi`, while the old awake replacement reaches the locally controlled AI input copy.

For the exact result “old spawn vs new bed center” after both `resetPos` calls, require that the collision-based reset loop exits immediately from **both** starting positions: the old constructor spawn and the new copied bed-centered position. The candidate says “paired collision-free spawn fixture” but later lists only “spawn position is collision-free,” which does not plainly exclude an obstruction at the new bed-centered position. Add the two-position fixture premise. Also replace “matching incoming respawn/sleep data” with “paired outgoing local-player sleeping state”; the sleep position is not a respawn packet field in this trace but the prior local player's tracked data copied into the replacement. No server producer evidence is needed.

These are narrow wording/input conditions, not a requirement for trajectory proof. The first-tick logical input-state difference is independently supported as stated, assuming the player is loaded and logical controls are paired.

## Source verification

I independently read the exact endpoint Feather sources. In 1.13.2 `handlePlayerRespawn` calls `Minecraft.respawnPlayer`; that method constructs a fresh local player, copies `oldPlayer.getSyncedData().getAll()` into the replacement, then sets dimension and calls `resetPos`. Old sleep boolean and sleeping position are ordinary `PlayerEntity` fields, not synced accessors, so this copy does not carry them.

In 1.14.4 `handlePlayerRespawn` constructs the replacement, copies `getSyncedData().getAll()`, and then calls `resetPos`. `LivingEntity` registers optional sleeping position as tracked data. The destination `SyncedData.update` writes each matching entry and calls `entity.onDataValueChanged`; the client `LivingEntity.onDataValueChanged` callback for that accessor invokes the helper which sets `(bedX+0.5, bedY+0.6875F, bedZ+0.5)`. `PlayerEntity.resetPos` sets the tracked pose to STANDING, then calls `super.resetPos`, restores health and clears death ticks. It does not clear optional sleeping position. `LivingEntity.isSleeping()` tests `getSleepingPos().isPresent()`, and `PlayerEntity.isDead()` returns `super.isDead() || isSleeping()`.

Both endpoint `LivingEntity.mobTick` implementations set `jumping=false`, sideways/forward speed to zero, and rotation speed to zero when `isDead()`; otherwise locally controlled entities call `serverTickAi()`. The local client subclass's `serverTickAi()` copies `input.movementSideways`, `input.movementForward` and `input.jumping` into the movement fields. Thus the first tick uses different movement fields under equal input; no resulting displacement is asserted.

## Hash-bound inputs (SHA-256)

| Input | SHA-256 |
|---|---|
| Candidate draft | `bb676c1e468a45ea37ca1fa6cea4061872d6da2ddc49c5ffede9c9393b33af0a` |
| 1.13.2 `ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.14.4 `ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.13.2 `SyncedData.java` | `93177865e23be0f8db5741bd505b952daee03d33761838ca782bd10bceb748e4` |
| 1.14.4 `SyncedData.java` | `4d0c0bee069994f64a31e1ff600ae59c3217eadb8678473e2256c2363e657e17` |
| 1.13.2 `Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 `LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.14.4 `LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.13.2 `PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 `PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.13.2 `LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 `LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |

No product implementation, wiki, backlog or Git history was consulted. No build, test, game, decompile or source-tree write was performed.
