# Independent review v4: cauldron collision-volume candidate

## Verdict

**ACCEPT** for the exact direct-operation candidate as written. The revised premise now fixes the movement vector after any cobweb/movement-multiplier handling, sets `noClip=false`, removes other clipping block/entity shapes, and excludes world-border intersection. Those conditions close the movement-query gates that control the claimed first clip. The arithmetic and source differences are correct under those paired inputs. This is an operation-level source finding; no prior ordinary history, producer parity, or trajectory is claimed.

## Independent source check

I reread the exact endpoint Feather source bodies. In 1.13.2, `CauldronBlock.getShape` returns the unit cube with only the interior cavity from `[2,4,2]` through `[14,16,14]` subtracted. The player's horizontal footprint `[0.2,0.8]²` lies entirely outside that cavity's lower bound in Y, so the cauldron has a solid bottom plate at Y=0 over the footprint. Starting with box top `-0.2`, an upward post-multiplier request of `0.5` is clipped to `0 - (-0.2) = +0.2`.

In 1.14.4, `CauldronBlock.getShape` subtracts the same cavity and three lower boxes. Their union removes the full centered footprint `[2/16,14/16]²` through Y=`3/16`; `[0.2,0.8]²` is contained in that footprint. A collision plate remains from `3/16` to `4/16`, so the same upward request clips to `3/16 - (-0.2) = +0.3875`.

Both source movement methods select collision resolution with `noClip=false`. The candidate's neutral pre-movement modifiers ensure the vector entering that resolution is `(0,0.5,0)`: old `inCobweb=false`, new pending movement multiplier zero. With no other clipping block/entity and no world-border intersection, the cauldron is the first Y collision. Zero horizontal components do not invoke or change the horizontal step alternatives. The 1.14.4 block collision path's entity context is irrelevant because this cauldron provider is constant and ignores its parameters.

## Recomputed input hashes

| Input | SHA-256 |
|---|---|
| Candidate `.native-source/20261031/1132-1144-finish46/candidates/cauldron-collision-volume.draft.md` | `dce1c18429f7c204da21689b12c41622d760c4d85818fa740d33c59d1b917bba` |
| `cauldron-storage-shapes/result.md` | `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360` |
| `cauldron-movement-relevance/result.md` | `a77f53dcbc21d9e9a4c1b3aff59394bfcff534ac219900a2e2606758f0ced591` |
| 1.13.2 `net/minecraft/block/CauldronBlock.java` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` |
| 1.14.4 `net/minecraft/block/CauldronBlock.java` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| 1.13.2 `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

No product implementation, wiki/backlog, product Git, build, test, game, or source generation was consulted or run.
