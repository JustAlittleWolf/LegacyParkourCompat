# Piston micro-request source boundary: 1.13.2 → 1.14.4

## Result

The revised direct piston-request finding is stable from **1.14.0 through 1.14.4**. The first new operation appears in 1.14.0: the piston helper returns the incoming vector before reading tick/accumulator state when `lengthSquared() <= 1.0E-7`. The same movement writer suppresses resolved vectors with squared length `<= 1.0E-7` in each intermediate. The candidate's direct `(2.0E-5,0,0)` input has squared length `4.0E-10`, so all these versions bypass accumulator reset/update and suppress the position write. The corresponding 1.13.2 path lacks this early guard and moves after its axis epsilon test (`2.0E-5 > 1.0E-5F`). This establishes stable endpoint applicability, not the full-pair cutoff for every movement operation.

## Exact intermediate check

The per-version Feather/Yarn method crosswalk follows `Entity.move(MovementType, Vec3d)` to the piston helper. In 1.14.0, 1.14.1, and 1.14.2 it is named `method_18794`; in 1.14.3 it is named `applyPistonMovement`. Each has the same operative order: squared-length early return; read world time and reset the accumulator only when it differs; choose the first nonzero axis; clamp accumulated axis to ±0.51; update that axis accumulator; return zero if accepted component magnitude is at most `1.0E-5F`. The new helper's early return precedes both tick and accumulator access. In each corresponding `move` body, the collision-resolved vector is written to the box/current coordinates only when its squared length is greater than `1.0E-7`.

| Release | Mapping/source member | Entity.java SHA-256 | Provenance binding |
|---|---|---|---|
| 1.14 | Entity.method_18794(Vec3d) | f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a | .decompile-provenance.json source map net/minecraft/entity/Entity.java: f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a |
| 1.14.1 | Entity.method_18794(Vec3d) | ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b | .decompile-provenance.json source map net/minecraft/entity/Entity.java: ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b |
| 1.14.2 | Entity.method_18794(Vec3d) | 7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc | .decompile-provenance.json source map net/minecraft/entity/Entity.java: 7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc |
| 1.14.3 | Entity.applyPistonMovement(Vec3d) | 9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14 | .decompile-provenance.json source map net/minecraft/entity/Entity.java: 9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14 |

The provenance files are the exact per-version `.decompile-provenance.json` files under the stated Yarn roots; the independent audit records their whole-file hashes. The source trees were read-only. No piston producer, runtime trajectory, or custom tag behavior was used.
