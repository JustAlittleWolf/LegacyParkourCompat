# Intermediate boundary: horizontal collision flag tolerance

## Boundary

The accepted horizontal-collision flag difference first applies in **1.14.0**. 1.13.2 sets `collidingHorizontally` from exact inequality of requested and resolved X/Z components. The first 1.14 implementation compares each component with `Math.abs(a-b) < 1.0E-5F` and negates that approximate-equality result. This predicate remains in 1.14.1–1.14.4. The accepted fixed full-cube witness therefore has the same flag result beginning with 1.14.0: an X request `5.0E-6` clipped to zero sets the old flag and leaves the new flag false. It changes only the flag in that fixture; both positions are unchanged.

## Exact source body crosscheck

In 1.14.0 Feather, `Entity.move` assigns `collidingHorizontally = !MathHelper.m_68886716(xIn,xResolved) || !MathHelper.m_68886716(zIn,zResolved)`. The helper body returns `Math.abs(e-d) < 1.0E-5F`. Yarn 1.14.1–1.14.3 use `Entity.horizontalCollision = !MathHelper.method_20390(xIn,xResolved) || !...z` and the helper body has the same strict `< 1.0E-5F`. The 1.14.4 endpoint uses the same Feather expression/helper. The 1.13.2 `Entity.move` exact `n != x || p != z` comparison is bound in the accepted candidate/review.

| Release | Mapping and `Entity.java` SHA-256 | `MathHelper.java` SHA-256 | Exact provenance identity |
|---|---|---|---|
| 1.14.0 | Feather `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` | Feather `E39D5DFC69C17A9032BE086D7D4D14CC63525962A0FF83615B1BEFDCCA599843` | Feather provenance `BFB011801A64E9AFAA4ACA43E8A8ED40BF2A02F136FFC02E65B32E79315764FA` |
| 1.14.1 | Yarn `1.14.1+build.10`, `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` | `21ED846AC48A5A2FBCDB2AC31FD5B74A461485EFFD881112C903C09D9297504A` | `.decompile-provenance.json` `308537C5ADEC3104C5CA243EB5010554F00978635ED74F0D7801C804DD4D4907` |
| 1.14.2 | Yarn `1.14.2+build.7`, `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` | `21ED846AC48A5A2FBCDB2AC31FD5B74A461485EFFD881112C903C09D9297504A` | `.decompile-provenance.json` `786546F99684423CC2563BE45C9C3334DFCC2C7DB58DDB74BA39CE403BD0869A` |
| 1.14.3 | Yarn `1.14.3+build.13`, `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` | `21ED846AC48A5A2FBCDB2AC31FD5B74A461485EFFD881112C903C09D9297504A` | `.decompile-provenance.json` `81EA0021EB122D4E3340E20D47D6ECB7079365BA767A038D26A8264CDDACC28A` |
| 1.14.4 | Feather `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` | Feather `E39D5DFC69C17A9032BE086D7D4D14CC63525962A0FF83615B1BEFDCCA599843` | Feather endpoint publication manifest |

Each Yarn provenance record contains the matching exact-release client, Intermediary and Yarn mapping artifacts and lists the `Entity.java` and `MathHelper.java` hashes above. The endpoint fixed-input candidate and independent acceptance are in `candidates/horizontal-collision-flag-tolerance.draft.md` and `horizontal-flag-independent-review/review.md`; they do not prove any trajectory or later climb/travel response. Pair-wide source coverage remains **NOT FROZEN**.
