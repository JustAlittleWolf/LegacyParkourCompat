# Intermediate boundary: multi-axis collision clipping order

## Boundary

The accepted fixed-list resolver-order difference first applies at **1.14.0**. 1.13.2 clips the supplied common shape list Y→X→Z. Beginning in 1.14.0, the new resolver clips Y first and processes the smaller-magnitude horizontal component first (`abs(dx) < abs(dz)` selects Z first; ties select X first). The exact source branch remains through 1.14.4. The existing fixed-list witness therefore remains applicable from 1.14.0 under its equal-shape-list assumptions; this report does not extend it to world-aware candidate generation.

## Exact source body and identities

The 1.14.0 one-axis/mixed clip helper `Entity.m_73670363` assigns `boolean bl = Math.abs(d) < Math.abs(f)`, clips Z before X when true, and otherwise clips X before Z. Its preceding Y clip and box translations preserve this order. Yarn 1.14.1–1.14.2 `Entity.method_17833` has the same branch and translations. In 1.14.3 the same selection is used by `method_20737` for multi-axis clips and `calculateTangentialMotionVector` for axis-only routes. The 1.14.4 Feather helpers `m_79801352`/`m_73670363` retain the same horizontal branch. These bodies match the accepted fixed-list report's comparator and per-axis arithmetic; only the operation order is the claimed delta.

| Release | Mapping and full `Entity.java` SHA-256 | Provenance SHA-256 |
|---|---|---|
| 1.14.0 | Feather `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` | Feather provenance `BFB011801A64E9AFAA4ACA43E8A8ED40BF2A02F136FFC02E65B32E79315764FA` |
| 1.14.1 | Yarn `1.14.1+build.10`, `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` | `.decompile-provenance.json`: `308537C5ADEC3104C5CA243EB5010554F00978635ED74F0D7801C804DD4D4907` |
| 1.14.2 | Yarn `1.14.2+build.7`, `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` | `.decompile-provenance.json`: `786546F99684423CC2563BE45C9C3334DFCC2C7DB58DDB74BA39CE403BD0869A` |
| 1.14.3 | Yarn `1.14.3+build.13`, `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` | `.decompile-provenance.json`: `81EA0021EB122D4E3340E20D47D6ECB7079365BA767A038D26A8264CDDACC28A` |
| 1.14.4 | Feather `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` | Feather endpoint publication manifest |

The 1.14.1–1.14.3 hidden Yarn provenance records contain the exact Minecraft client, Intermediary and mapping-build artifacts and list the `Entity.java` hash shown. 1.14.0 and 1.14.4 identities are already present in the accepted pair source inventory.

This establishes the operation-level source boundary for a fixed candidate list only. Query generation, entity/border/chunk/provider inputs, step-list reuse and full-pair coverage remain separate unresolved dependencies; pair status remains **NOT FROZEN**.
