# Horizontal collision-flag tolerance boundary: 1.13.2 → 1.14.4

## Result

The accepted horizontal collision-flag difference is stable from **1.14.0 through 1.14.4**. The first intermediate already compares requested and resolved X/Z movement with the shared `abs(e-d) < 1.0E-5F` helper, while 1.13.2 uses exact inequality. For the reviewed `5.0E-6` clipped request, all these new releases record `horizontalCollision=false`; old records true. The direct fixture and no-later-effect limits remain those in the accepted candidate/review.

## Exact intermediate check

In 1.14.0, 1.14.1, 1.14.2, and 1.14.3, Yarn `Entity.move(MovementType, Vec3d)` assigns `horizontalCollision` as the negation of approximate equality between post-preprocessing requested X/Z and resolved X/Z; `collided` is their horizontal/vertical OR. The called `MathHelper.method_20390(double,double)` returns `Math.abs(e-d) < 1.0E-5F` in each release. The accepted fixture's clipped difference `5.0E-6` is strictly within this tolerance, so it is classified equal at each intermediate. The 1.13.2 exact component inequality and 1.14.4 Feather helper use were verified by the independent candidate review.

| Version | Entity.java SHA-256 | MathHelper.java SHA-256 |
|---|---|---|
| 1.14 | `f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a` | `21ed846ac48a5a2fbcdb2ac31fd5b74a461485effd881112c903c09d9297504a` |
| 1.14.1 | `ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b` | `21ed846ac48a5a2fbcdb2ac31fd5b74a461485effd881112c903c09d9297504a` |
| 1.14.2 | `7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc` | `21ed846ac48a5a2fbcdb2ac31fd5b74a461485effd881112c903c09d9297504a` |
| 1.14.3 | `9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14` | `21ed846ac48a5a2fbcdb2ac31fd5b74a461485effd881112c903c09d9297504a` |

The source trees remained read-only; no producer, trajectory, build, test, game launch, or source regeneration is involved. This boundary is operation-specific, not a full-pair patch boundary.
