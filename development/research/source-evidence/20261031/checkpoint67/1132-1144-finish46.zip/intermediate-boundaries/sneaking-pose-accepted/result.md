# Intermediate boundary: player sneaking pose outputs and fit query

## Accepted endpoint finding

Candidate `synced-pose-response-pairing/result.md`, SHA-256 `62F3FDFAB1F83D3BFE24F4B9AEE8E30DD9716D26F581B96F7E0A495FC886F5F2`, was independently accepted by `synced-pose-independent-review/review.md`, SHA-256 `C7595F7306942E8529BDB941B1986E88AE7D85A1966435B084353A3F7B375A35`.

For equal raw local-player movement flags and a collision-free candidate pose box, the old sneaking resize is 0.6 × 1.65 with eye height 1.54; the new sneaking pose is 0.6 × 1.5 with eye height 1.27. This changes the next collision box and eye-position query. Separately, the new pose-fit check can reject standing when an entity shape intersects only the standing box, whereas the old null-entity resize query checks block shapes only; the review accepts this only under the stated fixed raw candidate membership. Broad entity-query parity is not established.

## Intermediate boundary

The new pose table and `Pose.SNEAKING` dimension/eye path are already present in the first inspected intermediate, **1.14.0**, and persist through 1.14.3 and endpoint 1.14.4. This is the operation-level boundary for both the sneaking size/eye result and the new entity-inclusive pose-fit path. The old 1.13.2 dimensions and eye-height formula are source-paired in the accepted candidate.

| Release | Exact mapped source evidence | `PlayerEntity.java` SHA-256 | `Entity.java` SHA-256 |
|---|---|---|---|
| 1.14.0 Feather | `PlayerEntity.updatePlayerPose` selects `Pose.SNEAKING`; dimensions table records 0.6×1.5 and eye callback returns 1.27. `Entity.m_87715359(Pose)` performs entity-aware pose fit. | `F73879BD42103FA45F39CFE178AC82C7574C6306F00555AF7F7E795976275DD7` | `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` |
| 1.14.1 Yarn | `PlayerEntity` pose/dimension table and pose eye method preserve 0.6×1.5/1.27; `Entity.wouldPoseNotCollide` includes entities. | `EBDA4AD25A265F8C85E88345EFCCE753B78E248A29A9B910C5CFD311A4A69319` | `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` |
| 1.14.2 Yarn | Same sneaking output and entity-inclusive pose-fit route. | `333BB39DB18AF4CEF320EB73B7ABE359D438FB2A6CA7D8798EE449DA6C684398` | `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` |
| 1.14.3 Yarn | Same sneaking output and entity-inclusive pose-fit route. | `E3F361AC4E369D01473F3D84044EE33F9685D182C4485E2E80B7F62756950963` | `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` |

The 1.14.0 source uses Feather names and paths; 1.14.1–1.14.3 use the supplied Yarn trees and call the pose-fit helper `wouldPoseNotCollide`. All four versions were inspected at the exact player pose-selection and dimension table lines, and at the entity pose-fit helper. The 1.14.0 Feather hash matches its local publication manifest. The 1.14.1–1.14.3 Yarn directories have no adjacent publication manifests; their file hashes above are direct hashes of the supplied read-only sources. The endpoint sources/manifests and exact input fixture are bound in the accepted candidate/review.

This report dates only the accepted sneaking size/eye and bounded fit-query operations; it does not close upstream pose state production, all pose collision contexts, or full-pair coverage.
