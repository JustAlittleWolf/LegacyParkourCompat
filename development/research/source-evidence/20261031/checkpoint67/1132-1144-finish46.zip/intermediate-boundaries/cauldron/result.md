# Cauldron collision-volume source boundary: 1.13.2 → 1.14.4

## Result

The lower cauldron collision-volume difference is stable from **1.14.0 through 1.14.4**. Each intermediate retains the three subtracted lower rails across Y=0..3/16 and the same `getCollisionShape` dispatch to the block state's outline shape. The candidate's standard centered 0.6-wide footprint therefore remains within the removed lower-center area at all four intermediates; equal source-query assumptions produce the new 3/16 plate clip rather than the old 0 bottom clip. This is an operation-specific boundary, not a full-pair cutoff.

## Exact intermediate check

For 1.14.0–1.14.3, Yarn `Block.getCollisionShape(state, world, pos, context)` returns `state.getOutlineShape(world, pos)` when collidable, otherwise empty. `CauldronBlock.getOutlineShape` returns one shared shape formed by subtracting (a) the central cavity from Y=4 through 16 and (b) the crossed lower rails and center box from Y=0 through 3. These coordinates are identical across all four releases. `LEVEL` is not read by the collision/outline provider. The source structure changes in 1.14.2–1.14.3 only in unrelated member/property naming within the class.

| Release | Relevant methods | Block.java SHA-256 | CauldronBlock.java SHA-256 |
|---|---|---|---|
| 1.14 | `Block.getCollisionShape` → `CauldronBlock.getOutlineShape` | `799e08e9631c0a6cdb74be2faeacb054f3c638e1b35c13863eeeba96417b2f2c` | `f5fe5b106283c7c150f7095079f1d6af4fa2a1a24a024c16971dfbf346d8ba44` |
| 1.14.1 | same | `f5ef3ec7cecd508d948ac5f4a09ce04a4882da000e70a518a1882a00946d56fe` | `f5fe5b106283c7c150f7095079f1d6af4fa2a1a24a024c16971dfbf346d8ba44` |
| 1.14.2 | same | `e90cdc7b0b78310c59eb5a96cfbfed0f0ec8aaf7156d20f0876e4a04711c2d1f` | `8912b33eb7a223d2d5660b9fbbbac8de1141eeed5340d6186f7c6e1faf953068` |
| 1.14.3 | same | `d8728c19555875aee8f47ea138bf836d02acf9076d69fce289baad93c60e715f` | `f00608a9ac3e804ea672f08a6d87f71aa949224496d79d6e26bd5f893919545a` |

The same raw cauldron/player state and empty-other-candidate query premises as the reviewed direct-operation candidate apply. No preceding ordinary tick, world/block producer, or runtime trajectory is inferred. The exact endpoint and intermediate source families are read-only; no build/test/game/decompile was run.
