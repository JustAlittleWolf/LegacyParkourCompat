# 1.13.2 → 1.14.4 ordinary candidate intermediate boundaries

## Scope and source identity

Read-only audit of six assigned source candidates across exact stable releases 1.13.2, 1.14, 1.14.1, 1.14.2, 1.14.3 and 1.14.4. Older and newer endpoints are Ornithe Feather Gen2 build 2; intermediate mappings are Yarn 1.14+build.21, 1.14.1+build.10, 1.14.2+build.7 and 1.14.3+build.13. The intermediate provenance records name the exact intermediary, Yarn, metadata and client inputs. Published endpoint ready/provenance records identify Feather and the pinned source/artifact manifests documented in the permitted source reviews.

I rehashed the examined endpoint and intermediate source files and checked each against its endpoint source manifest or the intermediate `.decompile-provenance.json` per-file source map. Every checked file matched. The inspected method identity was crosswalked by owning class, call site and operation/dataflow, not by method-name similarity; this is material across the 1.14 mapping transition. Intermediate source identities used here:

| Release/mapping | `Entity.java` | `LivingEntity.java` | local player source | `KeyboardInput.java` |
|---|---|---|---|---|
| 1.14 Yarn | `f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a` | `8889e22779b9124998931bc97ce8b0d183d335c32a9bcbb089e49de65882bae6` | `ClientPlayerEntity.java` `92d0f97a9293f7bd57d49af00b70f13d78fc8b2202e7ed67edcfed917e0071be` | `ade8c1b46b4b25888d326a963f645dd4fe82f53ef0797c2e499fe37e9bb47aa0` |
| 1.14.1 Yarn | `ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b` | `331e2d7dfa936a6f7197910ba374c4a60b479c8565ff7c64a4d6a9e1e8b52dda` | `ClientPlayerEntity.java` `6af7e75e80619ad77ce2c84692136b0a1d562a44d0e7910dcc3f6040b2dc9933` | `ade8c1b46b4b25888d326a963f645dd4fe82f53ef0797c2e499fe37e9bb47aa0` |
| 1.14.2 Yarn | `7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc` | `e8224e7df98ccf0986bb390f35e64293263d17b9ab1dbdfeb661c65d28b6ee78` | `ClientPlayerEntity.java` `90c96701849c9212ea7714f02e7bc9011d0a7d0aaf1f7b46464497ba3ca14947` | `ade8c1b46b4b25888d326a963f645dd4fe82f53ef0797c2e499fe37e9bb47aa0` |
| 1.14.3 Yarn | `9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14` | `e8aed9c63c0dfbe88e4b9e11c58881bc6e04b9cbaecbde5e3606e3afa406d72b` | `ClientPlayerEntity.java` `28b6b4031e02afd4a2e6b4a80e5a7ca06f16dac42ca0f92cab25e2c2dc9e14ae` | `ade8c1b46b4b25888d326a963f645dd4fe82f53ef0797c2e499fe37e9bb47aa0` |

The source-tree layout and endpoint file hashes are recorded in `.native-source/20261030/1132-1144-pool31/ordinary-tick/source-review.md` (SHA-256 `f9daef67079078add9ad621c6ef279e8275ae687b00a11184873fc6e00c1d128`) and `.native-source/20261031/1132-1144-finish46/ordinary-boundary-audit.md` (SHA-256 `e39ea6b1ba338d2ed6de0d50d844563b5e1b06a77908d1faf6ca0e09f3e3ca97`). The gate and camera dispositions below also use `.native-source/20261031/1132-1144-finish46/ordinary-gates/ordinary-gate-followup.md` (SHA-256 `21fee32838adb08830391399fc766c248a7164e997c03424d15af8c96fbf7585`), `.native-source/20261030/1132-1144-remaining34/ordinary-gates/ordinary-gate-closure.md` (SHA-256 `2c70c46506dddef309ae52dbff41bf9c1bc7ecc519486f71c7c5734dc08e436c`) and `.native-source/20261030/1132-1144-remaining34/camera-rounding/camera-rounding-closure.md` (SHA-256 `5ca5ab255a3ba0604eaab1e5c35ed6a38229c8707b835e2ca0f3e6fe0b887b6c`). The follow-up explicitly leaves the water-gravity trajectory unopened; this audit does not construct one.

## Boundary findings

### Eye height as a submersion dependency — 1.14.0

In 1.13.2, `Entity.isSubmergedIn(Tag)` forms its sample Y from `y + getEyeHeight()` and checks that the sampled fluid matches and that the eye point is below `blockY + fluidHeight + 0.11111111F` (`Entity.java:1042–1051`). The virtual player eye-height implementation selects `1.62F`, sleeping `0.2F`, swimming/fall-flying or height `0.6F` `0.4F`, and sneaking or height `1.65F` `1.54F` (`PlayerEntity.java:1859–1869`).

The 1.14.0 tree already has the pose/dimension model: its entity submersion predicate uses `getStandingEyeHeight()` and the same sampled-block/fluid-height comparison (`Entity.java:987–999`); entity dimensions refresh the cached standing eye height from the current pose/dimensions (`Entity.java:2189–2193`); `LivingEntity` supplies sleeping `0.2F` or calls the pose-specific active-eye-height path (`LivingEntity.java:2745–2751`); and `PlayerEntity.getActiveEyeHeight` returns `0.4F` for swimming/fall-flying/spin-attack, `1.27F` for sneaking, and `1.62F` otherwise (`PlayerEntity.java:1779–1790`). These pose-eye and submersion semantics persist through Yarn 1.14.1–1.14.3; 1.14.3 changes names/types while retaining the same formula (`Entity.java:1032–1045`, `LivingEntity.java:2759–2764`, `PlayerEntity.java:1781–1791`). Feather 1.14.4 retains them (`Entity.java:1035–1052`, `PlayerEntity.java:1802–1812`, with the mapped eye-height dispatch in `LivingEntity.java:2770–2775`).

**Boundary:** the eye-height/submersion dependency appears in 1.14.0 and remains through 1.14.4; no later 1.14.x cutover was found in the examined methods. A pose-dependent eye sample can move the strict submersion threshold, particularly for sneaking (1.54F → 1.27F). This is a dependency for underwater/sprint/swim gates, not a separately closed player trajectory. Fluid-height provider behavior and the precise state-update timing for a concrete water surface remain outside this audit.

### Dry swimming-pose keyboard slowdown — 1.14.0

Old 1.13.2 keyboard input scales both axes by `0.3` only when `sneaking` is true (`KeyboardInput.java:44–49`). In Yarn 1.14.0, local `ClientPlayerEntity.tick` passes `isInSneakingPose() || shouldLeaveSwimmingPose()` as the first argument to `input.tick`, and passes spectator status as the second (`ClientPlayerEntity.java:618–619`). The corresponding `KeyboardInput.tick(boolean, boolean)` scales axes when not spectator and either sneak input or the supplied first argument is true (`KeyboardInput.java:13–25`). This gate is present with the same operation in 1.14.1, 1.14.2 and 1.14.3, and in Feather 1.14.4 (`LocalClientPlayerEntity.java:625–631`, `KeyboardInput.java:13–25`).

**Boundary:** introduced by 1.14.0 and stable through 1.14.4. For a non-spectator in the swimming pose outside water, the new first argument enables keyboard slowdown without sneak input; 1.13.2 has no equivalent pose argument. Whether ordinary movement can enter that dry swimming pose depends on the constrained-pose fallback and its outer swimming-pose collision-fit gate, as recorded in the correction supplement (SHA-256 `679a5605972826dc3203717200f9c125e5834b83db8e9357177da0b8e1825481`). Pose-entry reachability is therefore still conditional on that separate collision/query dependency.

### Climb jump post-move gate — 1.14.0

The 1.13.2 grounded travel continuation assigns post-move Y velocity `0.2` only when `collidingHorizontally && isClimbing()` (`LivingEntity.java:1575–1578`). The 1.14.0 Yarn equivalent is already `(horizontalCollision || jumping) && isClimbing()` after `move`, then replaces Y with `0.2` (`LivingEntity.java:1821–1827`). The `jumping` alternative persists in 1.14.1–1.14.3 (same mapped operation at `:1825–1827`, `:1831–1833`, and `:1841–1843`) and 1.14.4 (`LivingEntity.java:1844–1849`).

**Boundary:** introduced by 1.14.0; no later stable patch change found. The endpoint ordinary ladder state that satisfies the new branch without horizontal collision is source-closed by the permitted gate follow-up; this audit only establishes that the branch remains present at every stable intermediate. It does not extend that witness to other climbables such as scaffolding.

### Water gravity sign cache — 1.14.0; witness remains open

Old 1.13.2 evaluates the water-gravity special-case sign test from the post-move, post-`0.8`-vertical-damping velocity (`LivingEntity.java:1617–1649`; the gate is `velocityY <= 0.0`). In 1.14.0 Yarn, the corresponding `moveRelative(Vec3d)` path caches `getVelocity().y <= 0.0` at entry (`LivingEntity.java:1766–1769`) and later uses that boolean in the water continuation after movement and damping (`:1850–1920`). The entry cache is present in 1.14.1–1.14.3 (`LivingEntity.java:1766–1769`, `:1772–1775`, `:1782–1785`) and 1.14.4 (`LivingEntity.java:1786–1793`, `:1882–1921`).

**Boundary:** introduced by 1.14.0 and retained through 1.14.4. The compared predicate reads different points in the operation sequence. Whether an ordinary player reaches a sign divergence together with the gravity special-case magnitude gates is still **open**; no water-gravity trajectory or arithmetic witness was constructed here.

### Camera flight jump+sneak cancellation/deadzone — 1.14.0

The 1.13.2 camera-flight branch divides horizontal input for sneak, then performs separate double `velocityY -= getFlySpeed() * 3.0F` and `velocityY += getFlySpeed() * 3.0F` assignments in sneak-then-jump order (`LocalClientPlayerEntity.java:797–806`). Yarn 1.14.0 instead decrements/increments an integer `j` and only adds a vertical vector when `j != 0` (`ClientPlayerEntity.java:717–731`). The cancellation/deadzone structure remains in 1.14.1–1.14.3 (same semantic sequence in `ClientPlayerEntity` around `:716–731`) and 1.14.4 (`LocalClientPlayerEntity.java:728–742`).

**Boundary:** introduced by 1.14.0, retained through 1.14.4. Existing source-only camera closure supplies a conditional binary64 deadzone witness but leaves ordinary production of its narrow incoming Y-velocity value open. This patch audit does not promote that conditional witness to an ordinary-reachability claim or claim a guaranteed camera-flight delta.

### Grounded acceleration formula — 1.14.0

In 1.13.2 `LivingEntity.travel`, grounded friction is first formed as `slipperiness * 0.91F`; the grounded acceleration multiplier is then `getSpeed() * (0.16277137F / (t * t * t))`, where `t` is that friction value (`LivingEntity.java:1538–1553`). Yarn 1.14.0 already passes raw block slipperiness into the extracted helper and computes `getMovementSpeed() * (0.21600002F / (f * f * f))` on ground (`LivingEntity.java:1818–1823`, `1938–1940`). This helper formula persists in 1.14.1–1.14.3 (`:1938–1940`, `:1944–1946`, `:1954–1956` respectively) and Feather 1.14.4 (`LivingEntity.java:1961–1963`). The airborne branch continues to select its air-speed value.

**Boundary:** formula rewrite present in 1.14.0 and stable through 1.14.4. The new expression folds the `0.91F` factor into the constant and changes the float operation grouping; the endpoint comparison is a source-level grounded acceleration candidate. Exact output equality/difference over reachable slipperiness and speed values was not exhaustively tested here, so this boundary does not by itself establish a concrete trajectory delta.

## Coverage limits

Examined: the six named candidate operations/dependencies at 1.13.2 and every stable 1.14 intermediate through 1.14.4, with source hashes verified against the published per-file identities. The previously reported exact eye/fluid gates, ordinary ladder gate, camera recurrence/deadzone condition and swimming-pose outer fit gate were consulted only within the assigned source-only materials.

Unexamined: any candidate outside this list; full tick/collision/provider dependency closure; numerical exhaustiveness for the grounded acceleration formula; ordinary reachability of the dry swimming-pose state and the camera deadzone incoming state; any water-gravity witness; full-pair independent audit or freeze; runtime parity. No product, wiki, backlog, or product Git history was consulted. No source generation, build, test, or launch was performed.
