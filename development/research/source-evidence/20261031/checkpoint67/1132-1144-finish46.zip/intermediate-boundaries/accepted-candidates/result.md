# Intermediate boundaries for accepted movement candidates

## Result

The accepted candidates below have method-level cutovers at **1.14.0**, stable through the 1.14.4 endpoint. The checks compare the exact intermediate Feather/Yarn sources for releases 1.14.0–1.14.3 against the endpoint Feather source. They establish only the listed operation-level formulas and fixed registration/tag inputs, not runtime histories or a pair-wide cutoff.

## Jump-boost float rounding

Candidate `callback-lifecycle-residual/candidates/jump-boost-float-rounding.draft.md`, SHA-256 `99f912c20cd59e13918182b289ce1e8681540940e73c1c4a3514fd6febfe02ba`, was independently accepted by `jump-boost-independent-review-v2/review.md`, SHA-256 `ec7a70dd28a7df0a25901b0fd6b6d2226f808acda789a3cf576bf509361bfa62`.

`LivingEntity.jump` in all four intermediates computes the jump strength in a `float` local, including `0.1F * (amplifier + 1)`, before passing it to the velocity setter. Thus the endpoint's binary32 addition is already present at the first intermediate, 1.14.0. The old 1.13.2 method adds after promoting the base float to double, as the accepted direct-write candidate describes. The operation boundary is therefore 1.14.0.

| Release | Method evidence | `LivingEntity.java` SHA-256 | Provenance SHA-256 |
|---|---|---|---|
| 1.14.0 | `LivingEntity.jump`, source line 1733; local `float f`, then `setVelocity(..., f, ...)` | `8889e22779b9124998931bc97ce8b0d183d335c32a9bcbb089e49de65882bae6` | `ea70a955a12f377cd3b9e8d5f346f4625b044d55da726b6bc472405ae91f4341` |
| 1.14.1 | same method/formula, source line 1733 | `331e2d7dfa936a6f7197910ba374c4a60b479c8565ff7c64a4d6a9e1e8b52dda` | `308537c5adec3104c5ca243eb5010554f00978635ed74f0d7801c804dd4d4907` |
| 1.14.2 | same method/formula, source line 1739 | `e8224e7df98ccf0986bb390f35e64293263d17b9ab1dbdfeb661c65d28b6ee78` | `786546f99684423cc2563be45c9c3334dfcc2c7db58ddb74ba39ce403bd0869a` |
| 1.14.3 | same method/formula, source line 1749 | `e8aed9c63c0dfbe88e4b9e11c58881bc6e04b9cbaecbde5e3606e3afa406d72b` | `81ea0021eb122d4e3340e20d47d6ecb7079365ba767a038d26a8264cddacc28a` |

The 1.14.4 endpoint method is included in the candidate's endpoint source evidence. No intermediate gate or jump trajectory is asserted.

## Chorus-flower falling-current face predicate

Candidate `candidates/chorus-flower-falling-current.draft.md`, SHA-256 `ee0bba652a75b741c177b0cbd7e667c7f7d0fa4d82f04e8b3cc7a6c71eee1b5b`, was independently accepted by `chorus-current-independent-review-v3/review.md`, SHA-256 `62fb8d61fe2012489416385b2f39b3f3a0977224ee7cbd295ca5834ccac4f97d`.

In each intermediate, `BaseFluid.getVelocity` retains the falling-flow full-face gate via `Block.isSolidFullSquare`; the latter rejects `BlockTags.LEAVES` and otherwise tests whether the selected collision face is full. `ChorusFlowerBlock` inherits the base full-cube collision face, is registered as a non-leaf plant, and the default leaves tag recipe excludes it. This exact path therefore already produces the endpoint sturdy east face in 1.14.0. The old 1.13.2 direct fluid-face helper returns `UNDEFINED` for the chorus flower face, as recorded in the accepted candidate and paired face closure. The current predicate's operation boundary is 1.14.0.

| Release | Relevant source path | `BaseFluid.java` SHA-256 | `Block.java` SHA-256 | `ChorusFlowerBlock.java` SHA-256 | `Blocks.java` SHA-256 | `BlockTagsProvider.java` SHA-256 | Provenance SHA-256 |
|---|---|---|---|---|---|---|---|
| 1.14.0 | `BaseFluid.getVelocity` → `Block.isSolidFullSquare` → inherited `ChorusFlowerBlock` collision face; default LEAVES recipe | `c596bd4fa6aaf4f176c4be18d9e3125ff8b3e47846cf5a99253cccc9ba7bf5b5` | `799e08e9631c0a6cdb74be2faeacb054f3c638e1b35c13863eeeba96417b2f2c` | `77eb10aaec383ae2786c0b5ccae7b2cb2368f424f1b2ff42c7980557001a3d99` | `62acdf407d1fa85095da0351d441b5ece10681b036505f7b9972bc21f77b0a0d` | `f389b69d9abfe6d001b3d357acbe2b7d5da1eeb4f4ee802a6d423ee4e78cce41` | `ea70a955a12f377cd3b9e8d5f346f4625b044d55da726b6bc472405ae91f4341` |
| 1.14.1 | same source path and default recipe | `c596bd4fa6aaf4f176c4be18d9e3125ff8b3e47846cf5a99253cccc9ba7bf5b5` | `f5ef3ec7cecd508d948ac5f4a09ce04a4882da000e70a518a1882a00946d56fe` | `77eb10aaec383ae2786c0b5ccae7b2cb2368f424f1b2ff42c7980557001a3d99` | `f5ba7169237468c68c085ecbf101e0e1c620013c00744a20dfae7c8af97c74dd` | `f389b69d9abfe6d001b3d357acbe2b7d5da1eeb4f4ee802a6d423ee4e78cce41` | `308537c5adec3104c5ca243eb5010554f00978635ed74f0d7801c804dd4d4907` |
| 1.14.2 | same source path and default recipe | `a2509164dc7d354fdef23957f96d2d05c0f6bff73446f8362c6acff8f5a81e1d` | `e90cdc7b0b78310c59eb5a96cfbfed0f0ec8aaf7156d20f0876e4a04711c2d1f` | `002c11100ee5dc7ed7e98bb139bc4e0be52eff70cddf72679337d3f0ecb288f7` | `f5ba7169237468c68c085ecbf101e0e1c620013c00744a20dfae7c8af97c74dd` | `b516b92cfe014d2da0a235eeb5cc93316dbb1c9ea65e14207442802f49aebc36` | `786546f99684423cc2563be45c9c3334dfcc2c7db58ddb74ba39ce403bd0869a` |
| 1.14.3 | same source path and default recipe | `7a178ec425b1103d1231387e4bb1c88ee67babeb288822fb0e9f7a2aa854776a` | `d8728c19555875aee8f47ea138bf836d02acf9076d69fce289baad93c60e715f` | `a36e7c7d029b2d0934e26e6f690be804dd3dd6f1e5f46eda96e4a3392835a562` | `d003f43e26e26190ed29b17cd3a0f16b0473b5b4b58d4dbd4a247974af8b0f71` | `84f89b86cd04ba46acb4944dfd71ffbe0b4d209da6a1de565d943ad1d954f54f` | `81ea0021eb122d4e3340e20d47d6ecb7079365ba767a038d26a8264cddacc28a` |

The endpoint source hashes and the fixed same-input witness are in the candidate draft. This is an operation-level source comparison; active tag payload, fluid/player production, and trajectory are outside the claim. Hashes are source files recomputed against the listed intermediate provenance records.

## Nested cauldron inside moving-piston collision shape

Candidate `candidates/moving-piston-cauldron-nested-collision.draft.md`, SHA-256 `0208f16284b4f04bf2ee0b8492aad2fb2b7347b703e165cbb5ce21e30089c1e3`, was independently accepted by `moving-piston-cauldron-independent-review/review.md`, SHA-256 `4dc7dce9fc8beaa4ab340b1e4dc647f41953c12432ec606fc9203a99b530e796`.

The intermediate Yarn `PistonBlockEntity.getCollisionShape(BlockView, BlockPos)` retains the same outer dispatch and composition at every inspected release: select the extending-source nested shape or empty seed; apply the thread-local facing/progress source-head gate; select piston head or moved state; compute the progress translation; translate and union the nested collision shape. `CauldronBlock` retains the paired lower-volume difference already dated to 1.14.0 in `intermediate-boundaries/cauldron/result.md`. Therefore the accepted same-input nested cauldron collision-shape witness is present from 1.14.0 through 1.14.4. This boundary applies to the shape output only; it does not assert a changed clipped vector or trajectory.

| Release | Method evidence | `PistonBlockEntity.java` SHA-256 |
|---|---|---|
| 1.14.0 | `PistonBlockEntity.getCollisionShape`, line 332; moved state shape offset and union at lines 345–359 | `782d5cb9e1b46d6c815f8c5d95eb75a601b069d446614072420ea075049dd192` |
| 1.14.1 | same body and line range | `782d5cb9e1b46d6c815f8c5d95eb75a601b069d446614072420ea075049dd192` |
| 1.14.2 | same body and line range | `782d5cb9e1b46d6c815f8c5d95eb75a601b069d446614072420ea075049dd192` |
| 1.14.3 | same body and line range; mapped piston-head registry field name differs | `fcc4bc9ca23af5387fc7d0ca8f50e51c08b9fa4b676d853c74a50603838af367` |

The endpoint wrapper and nested-state source evidence and full valid-input tuple are recorded in the candidate and `moving-piston-nested-shape-closure/report.md`. The shared intermediate `PistonBlockEntity.java` hash across 1.14.0–1.14.2 and the changed 1.14.3 hash were recomputed from the exact local Yarn trees; no intermediate publisher manifest was available beside 1.14.1–1.14.3 Yarn source trees. The formula was inspected directly at each listed method. Cauldron source hashes and the 1.14.0 geometry boundary remain in the linked cauldron report.

## Bed wake support and placement gates

Candidate `wake-partial-shape-provider-pairing/candidate.md`, SHA-256 `21dd0a25323e4cd225285f098ef02e21ff993170ef337218f33efd87b4b282cd`, was independently accepted by `wake-partial-shape-independent-review/review.md`, SHA-256 `3b45d2f311e6c4b18fc503ac5fb39a16af557046a19d54097d23a614c2b0fa0b`.

The 1.14.0 `BedBlock` wake-candidate search already uses collision-shape maximum-Y and emptiness tests to descend to support, then returns support-top plus `2.0E-7` after its player-sized clear-box check. These same movement-facing gates remain in the inspected 1.14.1–1.14.3 implementations (1.14.3 renames `getSpawnPoint` to `findWakeUpPosition`; the ordered candidate traversal and `canWakeUpAt` body are retained). Thus the accepted dandelion-over-stone direct wake-position delta has its new-side operation boundary at 1.14.0 and remains present through 1.14.4. The old 1.13.2 support/material gate and `Y+0.1` write are the other side of the pair; no bed-entry eligibility or trajectory is inferred.

| Release | Method evidence | `BedBlock.java` SHA-256 | Wake-search excerpt SHA-256 |
|---|---|---|---|
| 1.14.0 | `findWakeUpPosition`/`canWakeUpAt`, lines 195–255 | `473982558f0beb321ebe41828843c43a56f9e73196ec3996fd93aa256f63a788` | `93453d41175bf84426eb7b4d5f8be5b13236dc43aecce30a5f990d6c8e2ba5c8` |
| 1.14.1 | same | `473982558f0beb321ebe41828843c43a56f9e73196ec3996fd93aa256f63a788` | `93453d41175bf84426eb7b4d5f8be5b13236dc43aecce30a5f990d6c8e2ba5c8` |
| 1.14.2 | same | `b79d7c617e8f291135fbf3c1f9f82e8e6c75e0ec45b1bef62b16a9e648c9d26c` | `93453d41175bf84426eb7b4d5f8be5b13236dc43aecce30a5f990d6c8e2ba5c8` |
| 1.14.3 | `findWakeUpPosition`/`canWakeUpAt`, lines 195–255; first method mapping renamed | `99298ee0acbd9be8fcd9471a8b430a324edb159c2226ff4c8f6696b22a577097` | `fd1e5e531fd3b5b84c9e1cd812246ac3b41e34693d5a942885e6b68b0da26f5d` |

The wake-search excerpt hash is SHA-256 over source lines 195–256 (UTF-8, LF joined) in each exact Yarn file. Its 1.14.3 change includes the mapped method name; source inspection confirms the support, descent, clearance, and returned Y formula remain the same. These exact Yarn directories have no adjacent publisher manifest for 1.14.1–1.14.3; full-file hashes are recorded as source identities, and the endpoint Feather source hashes/manifest checks are in the candidate's paired report.

## Lava callback state consumed by local movement

Candidate `liquid-callback-movement-terminal/result.md`, SHA-256 `cef3485ccb54a5f83a8186631df3fe138245100c79ab70ae1d5367168b3ee003`, was independently accepted by `liquid-callback-independent-review/review.md`, SHA-256 `67987db5b6769181cf93209f78a456d6658b5a293790008057d11edd76526c3d`.

The operation-level transition begins in 1.14.0: `Entity.move` clears the stored lava bit before its block-collision callback scan; the scan reaches registered `FluidBlock.onEntityCollision`; that callback stores the lava bit for LAVA; and the next local-player `mobTick()` → `LivingEntity.moveRelative` consumes the same bit at its dry/lava gate. All four inspected Yarn intermediates retain this write/read order and default LAVA membership. This dates the bounded movement-route witness's new callback path to 1.14.0. It does not establish a preceding trajectory or a numeric movement-output difference.

| Release | Source evidence | `Entity.java` SHA-256 | `FluidBlock.java` SHA-256 | `LivingEntity.java` SHA-256 |
|---|---|---|---|---|
| 1.14.0 | clear at `Entity.move` line 529; callback scan invokes `onEntityCollision` at line 760; `FluidBlock.onEntityCollision` sets lava at 166–168; movement gate includes `isInLava` at `LivingEntity` line 1773 | `f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a` | `36fd9cd79c782357c2602917857bc2bdc05bb1d05fa6e1038f9a337028ca53b0` | `8889e22779b9124998931bc97ce8b0d183d335c32a9bcbb089e49de65882bae6` |
| 1.14.1 | same source locations and order | `ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b` | `36fd9cd79c782357c2602917857bc2bdc05bb1d05fa6e1038f9a337028ca53b0` | `331e2d7dfa936a6f7197910ba374c4a60b479c8565ff7c64a4d6a9e1e8b52dda` |
| 1.14.2 | clear at line 531; callback scan at 762; fluid callback at 166–168; gate at `LivingEntity` line 1779 | `7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc` | `04daaa27738790478fe5fe98398262e5c8799d2afae872f9483a0ca397ceca67` | `e8224e7df98ccf0986bb390f35e64293263d17b9ab1dbdfeb661c65d28b6ee78` |
| 1.14.3 | clear at line 538; callback scan at 806; fluid callback at 166–168; gate at `LivingEntity` line 1789 | `9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14` | `d238a66239b9b27df18a210feA47784ca0338f542241efc79b021e90cbd05424` | `e8aed9c63c0dfbe88e4b9e11c58881bc6e04b9cbaecbde5e3606e3afa406d72b` |

The intermediate `FluidBlock` class is the Yarn-named counterpart of the endpoint Feather `LiquidBlock` provider. Default `FluidTagsProvider` LAVA membership and endpoint file hashes are source-verified in `default-tag-provider-membership/result.md` and the accepted candidate. Intermediate full-file hashes above were recomputed from the exact Yarn trees; no adjacent publication manifest exists for 1.14.1–1.14.3. The candidate is restricted to the direct callback-written state and next movement gate under equal raw inputs.

## World-border hysteresis versus shape clipping

Candidate `border-shape-movement-query-pairing/candidate.md`, SHA-256 `8a1444ec798458d05d7ee374e755f09fe2035e57576460671b2763922af976bb`, was independently accepted by `border-shape-independent-review/review.md`, SHA-256 `8cdab3f87fa310d6061035d6c85cbb6f21a354109f576afaab47434e101757d3`.

The new entity mover includes the outside-border voxel shape as a collision candidate from 1.14.0. Its shape is the unbounded region minus the border interior snapped using floor/ceiling bounds; the player mover clips against its X=0 boundary in the accepted fixed snapshot. The same border-shape construction and shape-seeded clipping gate remain in 1.14.1–1.14.3, while 1.14.3 renames the entity method and changes entity-candidate routing. The accepted witness has no colliding entity candidates, so the border clip remains the same. The operation boundary is therefore 1.14.0. It is conditional on the old-only stored hysteresis bit and establishes no producer history or border-crossing trajectory.

| Release | Source evidence | `Entity.java` SHA-256 | `WorldBorder.java` SHA-256 |
|---|---|---|---|
| 1.14.0 | `Entity.method_17835`, line 647, seeds `WorldBorder.asVoxelShape()` when the contracted player box has no overlap; `WorldBorder.asVoxelShape`, line 49; snapped outside-region construction in area `method_17906`, lines 330–344 and 439+ | `f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a` | `e191b5b5fcfc43c4412b9da49e5146219906c9bc6995b40ac6cab25f62a7cd52` |
| 1.14.1 | same border path/formula | `ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b` | `e191b5b5fcfc43c4412b9da49e5146219906c9bc6995b40ac6cab25f62a7cd52` |
| 1.14.2 | `Entity.method_17835`, line 649; same border path/formula | `7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc` | `e191b5b5fcfc43c4412b9da49e5146219906c9bc6995b40ac6cab25f62a7cd52` |
| 1.14.3 | `Entity.handleCollisions`, line 656; same shape seed and border shape formula | `9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14` | `2da4c764b819fdc78b66eedf4cdfd71aadfcf9e7800b80515a88cd050c877506` |

The corrected fixture uses one square border, X `[0,10]`, Z `[-5,5]`, and `onGround=false` with zero Y request to bypass step alternatives. Border source file hashes were recomputed directly from each exact intermediate Yarn tree; the 1.14.1–1.14.3 Yarn folders do not include adjacent publisher manifests. Endpoint candidate and review files contain the exact conditional old-bit gate and clip arithmetic.

## Falling-current face query against common glass

Candidate `inherited-glass-face-current-witness/candidate.md`, SHA-256 `71347cb8388b31b7b4d085a8577acbde315fa1748c7d6997af26a7ba333419f6`, was independently accepted by `inherited-glass-face-current-independent-review/review.md`, SHA-256 `7df7a116d63adaaed69b149697cea3e63b89e9ef21ae9a7339550b0ba8485377`.

This candidate uses the same falling-fluid horizontal-face formula and new sturdy-face path dated above for chorus flower: old `FlowingFluid.isSolidFace` rejects glass through the attachment-exception gate before reading its old SOLID base face, while 1.14.0 `BaseFluid.getVelocity` reaches `Block.isSolidFullSquare` and its full collision face. Glass is a common full-cube collision registration and is absent from the default LEAVES recipe throughout the inspected 1.14 intermediates. The conditional glass current and resulting player velocity terminal therefore begins with the same formula at 1.14.0 and remains stable through 1.14.4. This adds the glass registration case only; it does not establish a trajectory or producer history.

| Release | Source path | `BaseFluid.java` SHA-256 | `Block.java` SHA-256 | `Blocks.java` SHA-256 | `BlockTagsProvider.java` SHA-256 |
|---|---|---|---|---|---|
| 1.14.0 | `BaseFluid.getVelocity` → `Block.isSolidFullSquare`; default GLASS registration and LEAVES recipe | `c596bd4fa6aaf4f176c4be18d9e3125ff8b3e47846cf5a99253cccc9ba7bf5b5` | `799e08e9631c0a6cdb74be2faeacb054f3c638e1b35c13863eeeba96417b2f2c` | `62acdf407d1fa85095da0351d441b5ece10681b036505f7b9972bc21f77b0a0d` | `f389b69d9abfe6d001b3d357acbe2b7d5da1eeb4f4ee802a6d423ee4e78cce41` |
| 1.14.1 | same source path and default memberships | `c596bd4fa6aaf4f176c4be18d9e3125ff8b3e47846cf5a99253cccc9ba7bf5b5` | `f5ef3ec7cecd508d948ac5f4a09ce04a4882da000e70a518a1882a00946d56fe` | `f5ba7169237468c68c085ecbf101e0e1c620013c00744a20dfae7c8af97c74dd` | `f389b69d9abfe6d001b3d357acbe2b7d5da1eeb4f4ee802a6d423ee4e78cce41` |
| 1.14.2 | same source path and default memberships | `a2509164dc7d354fdef23957f96d2d05c0f6bff73446f8362c6acff8f5a81e1d` | `e90cdc7b0b78310c59eb5a96cfbfed0f0ec8aaf7156d20f0876e4a04711c2d1f` | `f5ba7169237468c68c085ecbf101e0e1c620013c00744a20dfae7c8af97c74dd` | `b516b92cfe014d2da0a235eeb5cc93316dbb1c9ea65e14207442802f49aebc36` |
| 1.14.3 | same source path and default memberships | `7a178ec425b1103d1231387e4bb1c88ee67babeb288822fb0e9f7a2aa854776a` | `d8728c19555875aee8f47ea138bf836d02acf9076d69fce289baad93c60e715f` | `d003f43e26e26190ed29b17cd3a0f16b0473b5b4b58d4dbd4a247974af8b0f71` | `84f89b86cd04ba46acb4944dfd71ffbe0b4d209da6a1de565d943ad1d954f54f` |

Intermediate file identities above were recomputed from the exact local Yarn trees and their source hashes, matching the same source inputs and recipe described in the chorus-current section. Endpoint registration, candidate snapshot and velocity writer are bound in the accepted candidate/review.
