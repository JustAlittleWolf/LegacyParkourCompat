# Intermediate boundary: border-shape-seeded movement terminal

## Boundary

The independently accepted conditional border movement terminal first applies in **1.14.0**. The 1.13.2 old path uses the retained `outsideWorldBorder` bit to select whether enumerated outside-border cells are replaced with collision cubes. From 1.14.0 onward the movement resolver instead seeds the world-border shape when the contracted current entity box does not overlap that shape, then clips against it. The conditional fixed witness in `border-shape-movement-query-pairing/result.md` therefore applies starting 1.14.0 for its same current box/request/static bounds/air inputs and old-bit value; it does not establish the bit's producing history.

## Intermediate body check

The first 1.14 source (`Entity.m_72373519`) obtains `world.getWorldBorder().m_91823398()`, tests overlap with `box.contract(1.0E-7)`, and seeds either an empty stream or the border shape into the resolver candidate stream. In 1.14.1–1.14.3, `Entity.method_17835`/`Entity.handleCollisions` repeat that ordered test using `WorldBorder.asVoxelShape()` and `VoxelShapes.matchesAnywhere(..., contract(1.0E-7), AND)`. The same border candidate then reaches the normal clipper. 1.14.4 retains this operation in `Entity.m_72373519`. The old stored border-history bit does not gate this new shape-seeded path.

| Release | Mapping and full `Entity.java` SHA-256 | Provenance SHA-256 |
|---|---|---|
| 1.14.0 | Feather `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` | Feather provenance `BFB011801A64E9AFAA4ACA43E8A8ED40BF2A02F136FFC02E65B32E79315764FA` |
| 1.14.1 | Yarn `1.14.1+build.10`, `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` | `.decompile-provenance.json`: `308537C5ADEC3104C5CA243EB5010554F00978635ED74F0D7801C804DD4D4907` |
| 1.14.2 | Yarn `1.14.2+build.7`, `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` | `.decompile-provenance.json`: `786546F99684423CC2563BE45C9C3334DFCC2C7DB58DDB74BA39CE403BD0869A` |
| 1.14.3 | Yarn `1.14.3+build.13`, `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` | `.decompile-provenance.json`: `81EA0021EB122D4E3340E20D47D6ECB7079365BA767A038D26A8264CDDACC28A` |
| 1.14.4 | Feather `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` | Feather endpoint publication manifest |

For the three Yarn releases, the hidden provenance record contains the exact Minecraft client, Intermediary and Yarn artifact/build inputs and its source table includes the listed `Entity.java` hash. 1.14.0/1.14.4 endpoint source and publication identities are already bound in the accepted source report/review.

This establishes the operation boundary only; it does not establish producer history for the old hysteresis bit, a border-crossing trajectory, or pair-wide resolver/query closure. Pair status remains **NOT FROZEN**.
