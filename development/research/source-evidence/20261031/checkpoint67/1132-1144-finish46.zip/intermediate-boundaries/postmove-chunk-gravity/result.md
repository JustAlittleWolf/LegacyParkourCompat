# Intermediate boundary: post-move chunk-gated gravity write

## Accepted endpoint finding

Candidate `travel-postmove-chunk-closure/result.md`, SHA-256 `594DBC20B88F38C0EFF034677A79AF0E1564C834A335A0167C4D640684A6CA92`, was independently accepted by `travel-postmove-chunk-independent-review/review.md`, SHA-256 `27E3FD59E59ABB9EF2EBCE29E4CB68C1086EC546DBD66F60A3147F1C1A76F18D`.

The candidate compares 1.13.2 `LivingEntity.moveRelative(float,float,float)` to 1.14.4 `LivingEntity.moveRelative(Vec3d)`. For its raw standing local-player state at X=15.5, onGround=false, no climb correction, both pass X=0.6 to movement and end at X=16.1 in the no-collision input. The old post-move chunk query selects an absent destination chunk and its fallback `−0.1` Y velocity; the new pre-move `BlockPos` remains in cached FULL chunk `(0,0)` and selects gravity `−0.08`. Both apply the final `0.98F` factor. The effect is a conditional direct client velocity writer only. No producer history or trajectory is claimed.

## Intermediate cutover

The new source writes a `BlockPos` from the living entity's **pre-move** `(x, bounding-box minY−1, z)`, then tests that saved position after movement for the client fallback. This order is present at the first release, 1.14.0, and remains through 1.14.3. Thus the operation-level cutover is **1.14.0**. The 1.14.0 file is Feather-mapped; the 1.14.1–1.14.3 files are the locally supplied Yarn mappings.

| Release | Exact member/source evidence | `LivingEntity.java` SHA-256 |
|---|---|---|
| 1.14.0 | Feather `LivingEntity.moveRelative(Vec3d)`: saves `blockPos` before `move`, tests `isChunkLoaded(blockPos)` after it. | `8889E22779B9124998931BC97CE8B0D183D335C32A9BCBB089E49DE65882BAE6` |
| 1.14.1 | Yarn `LivingEntity.travel(Vec3d)`: saves `lv7` before `move`, tests `isBlockLoaded(lv7)` afterward. The local method is reached from the travel section. | `331E2D7DFA936A6F7197910BA374C4A60B479C8565FF7C64A4D6A9E1E8B52DDA` |
| 1.14.2 | Yarn `LivingEntity.travel(Vec3d)`: same pre-move `lv7` save and post-move client gate. | `E8224E7DF98CCF0986BB390F35E64293263D17B9AB1DBDFEB661C65D28B6EE78` |
| 1.14.3 | Yarn `LivingEntity.travel(Vec3d)`: same pre-move `lv7` save and post-move client gate. | `E8AED9C63C0DFBE88E4B9E11C58881BC6E04B9CBAECBBDE5E3606E3AFA406D72B` |

In 1.14.1–1.14.3 the helper name shown in Yarn is `travel`; the corresponding Feather endpoint calls the exact movement method `moveRelative`. The 1.14.0–1.14.3 local methods were inspected at 1.14.0 `LivingEntity.java:1838–1853`, 1.14.1 `:1818–1837`, 1.14.2 `:1824–1843`, and 1.14.3 `:1834–1853`. Their fallback values and order are unchanged: client/unloaded-position fallback writes `−0.1` when Y is positive (else 0), while the ordinary branch subtracts `d=0.08`; the result later receives `0.98F`.

The 1.14.0 Feather `LivingEntity.java` hash matches its local source manifest. The intermediate 1.14.1–1.14.3 Yarn trees have no adjacent publication manifests; their hashes above are direct hashes of the exact supplied read-only source files. The endpoint candidate binds the 1.13.2 and 1.14.4 sources and manifests. This boundary does not close any broader chunk-query/provider/context or pair-wide source audit.
