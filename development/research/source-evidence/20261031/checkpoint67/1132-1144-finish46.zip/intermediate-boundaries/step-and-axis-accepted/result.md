# Intermediate boundaries for step-only entity and resolver-axis findings

## Scope and verdict

This report dates two accepted, bounded source-operation findings across the exact local intermediate sources from 1.14.0 through 1.14.3. Both begin at **1.14.0**, remain present through 1.14.4, and are conditioned on equal fixed raw inputs. The intermediate 1.14.0 tree uses Ornithe Feather; the 1.14.1–1.14.3 trees use the locally supplied Yarn sources. Intermediate sources were read in place and hashed; they were not regenerated. No runtime history, world/provider enumeration, or trajectory is claimed.

## Step-only entity-candidate witness

The accepted source witness is `step-only-entity-candidate-terminal/result.md`, SHA-256 `0D35292EE9B72894B49181D3C7A9619FAD37B4A30AE143D01838B0FFABC7D43A`. Its independent review is `step-only-entity-independent-review/review.md`, SHA-256 `EBA52B43327F53A8C5483CBB0C8457F949AA2CB759ECE03DBC5257645FDA9770`.

At each inspected intermediate, the entity mover gathers entity collision shapes from the original requested sweep and reuses that candidate stream in both raised-step alternatives. The old alternatives query the movement shape at the raised vectors, so the fixed Boat box in the accepted witness is admitted by the old step-only query. The new path's initial swept entity envelope stays below the Boat's minY; reusing its candidate stream therefore omits the Boat from the step vectors. The same bottom-slab state and fixed Boat input from the accepted witness continue to produce old fallback `(0.19999998807907104, 0, 0)` and new `(0.7, 0.5, 0)`. The old strict greater-progress check is retained. This is a bounded fixed-input source witness and does not prove entity/player producer history.

| Release | Source path and relevant method | SHA-256 |
|---|---|---|
| 1.14.0 | Feather `net/minecraft/entity/Entity.java`; `m_72373519` materializes initial border/entity candidates and reuses `c_70593968` across step vectors. | `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` |
| 1.14.1 | Yarn `net/minecraft/entity/Entity.java`; `move` materializes initial border/entity candidates and reuses `LoopingStream` across step vectors. | `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` |
| 1.14.2 | Yarn `net/minecraft/entity/Entity.java`; same initial-envelope/reused-candidate step structure. | `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` |
| 1.14.3 | Yarn `net/minecraft/entity/Entity.java`; `handleCollisions` materializes the original-sweep entity stream and reuses it across step vectors. | `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` |

The 1.14.3 `EntityView.method_20743` helper hashes to `D5F906A1B0332F9FF978E9C0A92BB913CDFF68AC173A33AAD44AEDCCC9516EBB`; it expands the supplied original sweep by `1.0E-7`, gets the entities once, and admits only non-vehicle-chain entity collision boxes intersecting that expanded envelope. That envelope remains below the accepted Boat minY. In 1.14.0–1.14.2 the corresponding entity stream is constructed inline in the hashed `Entity.java` methods. The 1.14.4 endpoint's exact helper and fixed fixture are included in the accepted candidate.

## Fixed-candidate-list resolver-axis witness

The accepted bounded comparison is `resolver-axis-clip-core-pairing/report.md`, SHA-256 `9EDCD4D1A7F3EEDC18FCD2FAE51A4E0BE313988E20D280F772BFCE160A5CC3F4`, independently accepted by `resolver-axis-clip-independent-review/review.md`, SHA-256 `8C9A53DA184BC04D84A19B3A4FE6BE422788F5BAA5D0F7CD3FFBAD424E7219BD`.

For the same supplied full-cube candidate, box `[0,0.6] × [0.25,2.05] × [0,0.6]`, and request `(0.5,0.01,0.6)`, the intermediates retain Y-first clipping and choose the shorter horizontal axis first: because `abs(dx) < abs(dz)`, they resolve Z then X. The 1.13.2 endpoint resolves Y→X→Z. The paired axis clipper uses the same `1.0E-7` near-zero and face tolerances for the fixture. Thus the accepted same-list result remains old `(0.5,0.01,0.4)` versus new `(0.4,0.01,0.6)` throughout 1.14.0–1.14.4. This does not imply equal candidate-list construction; world-aware scans, border/entity inputs, and broader movement remain separate.

| Release | Entity resolver source SHA-256 | Shape distance source SHA-256 | Shape-stream source SHA-256 |
|---|---|---|---|
| 1.14.0 Feather | `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` | `45B5C03A644D4C80C1AF221C4E458D1CFFE68438229B727E4EAF724468F7DAB7` | `EA5E88613C93C6D15B11A9CE8AFCEF4681875CD4113D51282B2DC26BD8D4BE71` |
| 1.14.1 Yarn | `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` | `BDA272DD780777C5706351078B280A9775DDC40FCAA518A912841BE2CA6E047A` | `6B04957D569CA67C9A5EA74B901BAA870DB2490BA2097C7AD6FBBC360991D61A` |
| 1.14.2 Yarn | `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` | `BDA272DD780777C5706351078B280A9775DDC40FCAA518A912841BE2CA6E047A` | `6B04957D569CA67C9A5EA74B901BAA870DB2490BA2097C7AD6FBBC360991D61A` |
| 1.14.3 Yarn | `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` | `70A870FDEEA376E9936EA62287F96C3377AC319C9877C0E19CB857DBD1AC96D2` | `E485FA88440027DCD73D6BCD15A69438BE6EE3F70AC1BA9465CB69720A0BC47C` |

The 1.14.0 axis resolver is `Entity.m_73670363`; 1.14.1–1.14.2 use the Yarn `method_17833` resolver; 1.14.3 uses `calculateMotionVector`/`method_20737`. The axis selector at each source is Y followed by Z first when `abs(dx) < abs(dz)`, otherwise X first, then the other horizontal component. In 1.14.3 the mixed-axis branch composes a reusable stream of supplied shapes with freshly queried block collisions; the accepted witness is explicitly limited to the one supplied candidate shape and does not infer general world-list equivalence. The shape method names evolve (`calculateMaxDistance` to mapped/obfuscated `method_1108`), but the indexed occupancy scan and clipping tolerances needed by this fixture are retained.

## Provenance limits

1.14.0 has a local Feather source publication manifest. The 1.14.1–1.14.3 Yarn directories have no adjacent publication manifests; the hashes above are direct hashes of the supplied read-only files, and the reported method formulas were inspected at each release. The exact endpoint Feather source identities and candidate evidence are bound in the accepted candidate/review files cited above. Nothing here closes pair-wide provider/query coverage or the independent full-pair audit.
