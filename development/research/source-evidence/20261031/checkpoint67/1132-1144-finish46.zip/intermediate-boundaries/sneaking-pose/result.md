# Intermediate boundary: sneaking pose dimensions and eye height

## Boundary

The accepted endpoint source difference in `synced-pose-response-pairing/result.md` first applies at **1.14.0**. The new pose dimension table already gives sneaking `0.6F × 1.5F`, and the player eye-height method returns `1.27F`, in the 1.14.0 source. Both values remain unchanged in the supplied 1.14.1–1.14.3 Yarn sources and the 1.14.4 Feather source. The older 1.13.2 update path uses `0.6F × 1.65F` and eye height `1.54F` for the same logical sneaking state.

## Exact intermediate source files

The matched method is `PlayerEntity.updatePlayerPose()` plus the player's pose eye-height override in 1.14.0–1.14.4. In 1.14.0, `PlayerEntity.java` maps `Pose.SNEAKING` to `EntityDimensions.dynamic(0.6F, 1.5F)` and returns `1.27F` from its sneaking eye-height branch. In 1.14.1–1.14.2, Yarn gives the pose a different obfuscated enum name but retains `EntitySize.resizeable(0.6F, 1.5F)` and the same `1.27F` branch. In 1.14.3, `EntityPose.SNEAKING` is explicit and `EntityDimensions.changing(0.6F, 1.5F)` plus the same eye-height literal remain. The semantic method bodies were compared, not the identifiers alone.

| Release | Mapping tree / source | `PlayerEntity.java` SHA-256 | Provenance identity |
|---|---|---|---|
| 1.14.0 | Feather `net/minecraft/entity/living/player/PlayerEntity.java` | `F73879BD42103FA45F39CFE178AC82C7574C6306F00555AF7F7E795976275DD7` | Feather publication manifest |
| 1.14.1 | Yarn `1.14.1+build.10`, `net/minecraft/entity/player/PlayerEntity.java` | `EBDA4AD25A265F8C85E88345EFCCE753B78E248A29A9B910C5CFD311A4A69319` | `.decompile-provenance.json` SHA-256 `308537C5ADEC3104C5CA243EB5010554F00978635ED74F0D7801C804DD4D4907` |
| 1.14.2 | Yarn `1.14.2+build.7`, `net/minecraft/entity/player/PlayerEntity.java` | `333BB39DB18AF4CEF320EB73B7ABE359D438FB2A6CA7D8798EE449DA6C684398` | `.decompile-provenance.json` SHA-256 `786546F99684423CC2563BE45C9C3334DFCC2C7DB58DDB74BA39CE403BD0869A` |
| 1.14.3 | Yarn `1.14.3+build.13`, `net/minecraft/entity/player/PlayerEntity.java` | `E3F361AC4E369D01473F3D84044EE33F9685D182C4485E2E80B7F62756950963` | `.decompile-provenance.json` SHA-256 `81EA0021EB122D4E3340E20D47D6ECB7079365BA767A038D26A8264CDDACC28A` |

The 1.14.4 file hash is already bound to the accepted endpoint report (`2614DEB3B50D11F6CDF54D9E308703BF49CB53B72646B05253857E9557D657DF`). The 1.14.0 source has the locally supplied Feather publication. Each 1.14.1–1.14.3 Yarn provenance record contains the exact-release Minecraft client, Intermediary, and listed Yarn mapping build inputs, and its source table includes the matching `PlayerEntity.java` hash above.

This boundary covers the pose dimension/eye-height operation only. Collision-fit acceptance branches and synchronized pose inputs remain conditional inputs; no pose-producer history or trajectory is claimed. It does not change the pair-wide **NOT FROZEN** status.
