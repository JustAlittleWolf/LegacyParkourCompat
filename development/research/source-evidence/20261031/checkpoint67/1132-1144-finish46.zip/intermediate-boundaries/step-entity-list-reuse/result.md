# Intermediate boundary: step-only entity-candidate terminal

## Candidate and boundary

The bounded accepted endpoint candidate is `.native-source/20261031/1132-1144-finish46/step-only-entity-candidate-terminal/result.md` (candidate SHA-256 `0D35292EE9B72894B49181D3C7A9619FAD37B4A30AE143D01838B0FFABC7D43A`; independent review SHA-256 `EBA52B43327F53A8C5483CBB0C8457F949AA2CB759ECE03DBC5257645FDA9770`). This report checks the same source operation across the available 1.14 patch sources.

The accepted operation-level witness's first applicable release is **1.14.0**. Its distinguishing route is already present in the first 1.14 source: the resolver forms one entity-candidate stream from the original movement sweep, then carries that stream through both step alternatives and descent. The old 1.13.2 path builds a new collision list for the raised-step vector. This makes a Boat outside the original movement sweep but inside the raised-step sweep eligible to clip the old attempt and absent from the new candidate stream. Intermediate collision-query margins change later, but not this accepted fixture's membership result.

## Patch-member crosscheck

Each release's `Entity` movement body makes the ordinary resolver call with the initial movement vector, then calls the same clip helper for the raised `(x, stepHeight, z)` and vertically raised alternative, and reuses the captured candidate stream for the horizontal and descent subcalls. The `stepHeight > 0`, on-ground/descending, horizontal-clipping gates and strict progress comparisons remain in the same order. The enclosing member is `Entity.m_72373519(Vec3d)` in 1.14.0/1.14.4, `Entity.method_17835(Vec3d)` in 1.14.1–1.14.2 and `Entity.handleCollisions(Vec3d)` in 1.14.3. Clip-helper names change as shown by the individual source bodies; the flow is verified in those bodies, not inferred from name equality.

| Release | Mapping / exact source member | `Entity.java` SHA-256 | `EntityView.java` SHA-256 | Provenance SHA-256 |
|---|---|---|---|---|
| 1.14.0 | Feather; `m_72373519` seeds one `C_70593968` candidate stream from entity/border results, clips ordinary movement, then passes the same stream through both step candidates and descent. | `15E9D4CDE45D857CA3117CCFE2D5D9071C08E7EE4A67B4053F7B006FE7A4BFA9` | `B0ECBE77BB7A2504E86E5CADC6E8C32513E4F08D11264B4BAFF2245D10F91399` | Feather provenance SHA-256: `BFB011801A64E9AFAA4ACA43E8A8ED40BF2A02F136FFC02E65B32E79315764FA`. |
| 1.14.1 | Yarn `1.14.1+build.10`; `method_17835` passes the same seeded `LoopingStream` to ordinary and step resolver calls. Entity query filters shapes against the original swept bounds after the broader `0.25` entity lookup expansion. | `CE429699F2D8F0A54F4BE516783A474C6C7808572950164508CEED0BAF68ED5B` | `FEF34E5144D87F77A777E4DC1B62ACE7A92AF2EF9DBA7CEB25A80C7068170EEA` | `308537C5ADEC3104C5CA243EB5010554F00978635ED74F0D7801C804DD4D4907` |
| 1.14.2 | Yarn `1.14.2+build.7`; same candidate-stream reuse and entity query/filter behavior as 1.14.1. | `7C0E9CAB0842A45E42FA9F27C9661DE3FD0FD076C35FF989AA0477198EB38EDC` | `FEF34E5144D87F77A777E4DC1B62ACE7A92AF2EF9DBA7CEB25A80C7068170EEA` | `786546F99684423CC2563BE45C9C3334DFCC2C7DB58DDB74BA39CE403BD0869A` |
| 1.14.3 | Yarn `1.14.3+build.13`; `calculateMotionVector` reuses the stream. Entity query uses `1.0E-7` expansion and tiny-box cutoff. | `9B204A5F9AF6CA50C09DB4B6185FF37C39980C1A8CD1B5FD004713ECFFAE5C14` | `D5F906A1B0332F9FF978E9C0A92BB913CDFF68AC173A33AAD44AEDCCC9516EBB` | `81EA0021EB122D4E3340E20D47D6ECB7079365BA767A038D26A8264CDDACC28A` |
| 1.14.4 | `m_72373519`: same stream reuse and `1.0E-7` entity-query route. | `7315A496C195DA767DE9D4936D3ADB6EFc3C419DC0F0E95D6F32781B0DA1BA55` | `3822844CED53882C52F0523A1BD714BAA3CD9BB9DAB38A5E2C53051C7B1590E3` |

The older endpoint remains 1.13.2 `Entity.move(MoverType,double,double,double)`: its step branch issues a fresh `getCollisions(..., requestedX, stepHeight, requestedZ)` query after ordinary clipping and uses that step result for both alternatives and descent. The prior candidate report records the exact old/new witness geometry, query bounds and terminal outputs.

## Why the later query-margin edit does not move the witness boundary

For the candidate's old player swept box, the Boat starts above its maximum Y. The 1.14.0–1.14.2 entity query may gather a broad-phase list expanded by `0.25`, but filters each entity collision shape against the **unexpanded original swept box** before adding it. Thus the Boat is still absent from the initial new candidate stream, while it is included by the old raised-step query. Releases 1.14.3–1.14.4 use the narrow `1.0E-7` bounds and likewise omit it from the original stream. The already accepted candidate's changed terminal therefore applies beginning at 1.14.0; later query-margin changes are separate source changes and are not needed for this result.

For 1.14.1–1.14.3, each listed hidden Yarn `.decompile-provenance.json` contains the corresponding exact Minecraft client, Intermediary, and Yarn build inputs and a `sources` entry matching the listed Java file hashes. The 1.14.0 Feather source is tied to its local publication manifest. This report verifies exact release/mapping inputs and source bodies; it does not claim a runtime trajectory, complete resolver equivalence, or pair freeze.
