# 1.13.2 → 1.14.4 entity-query epsilon terminal check

## Verdict

No movement-terminal difference for the exact raw-input fixture below. 1.14.4 admits the Boat collision box through the new `1e-7` final query expansion, while 1.13.2 rejects it at the old unexpanded final filter. The admitted shape is still farther from the player's current X face than the requested positive X displacement. The exact one-axis clip therefore returns the unchanged request in both cases. This is a bounded no-effect witness, not a claim that every epsilon-only shape is harmless.

## Frozen inputs

- Same valid effective entity membership is assumed at both endpoints: the local player and one ordinary, non-ridden Boat; no other entity, block collision or nearby world border. These are raw movement-query inputs; no entity/world producer or trajectory is claimed.
- Player center `(0.5, 0, 0.5)`, standing dimensions `0.6F × 1.8F` (PlayerEntity source), and current box `[0.19999998807907104,0,0.19999998807907104]` to `[0.800000011920929,1.7999999523162842,0.800000011920929]`.
- Requested vector `(0.5,0,0)`, no preexisting piston displacement, `onGround=false`; entity collision query box is current box stretched by the request: X `[0.19999998807907104,1.300000011920929]`, same Y/Z extents.
- Boat collision box is `[1.30000005,0.5,0.3125]` to `[2.67500005,1.0625,1.6875]`. It is an achievable own bounding box for the 1.13.2 Boat dimensions (`1.375F × 0.5625F`) centered at x `1.98750005`, y `0.5`, z `1.0`. The fixture is specified by its effective box; no Boat motion or spawn proof is used.

## Query membership

- 1.13.2 `EntityView.getEntityCollisions`: broad candidate query expands the query bounds by `0.25`, so it can see this Boat; final collision-shape filter is `s.intersects(box)` against the unexpanded swept box. Since Boat minX `1.30000005` is greater than swept maxX `1.300000011920929`, strict intersection is false: the Boat shape is excluded.
- 1.14.4 `EntityView.getEntityCollisions`: query average side length is about `1.3667`, above the `1.0E-7` empty-query cutoff. It expands the swept box by `1.0E-7` and uses that same expanded box for candidate enumeration and final `box::intersects`. Expanded maxX is `1.300000111920929`; therefore the Boat shape is admitted. Its Y and Z intervals overlap the swept box.
- This difference follows the endpoint methods directly and does not depend on entity update timing.

## Exact clip arithmetic and terminal

The 1.14.4 movement path obtains entity collisions from the swept box, concatenates them into `m_64271959`, and for this one-axis vector routes through `m_73670363` to `VoxelShapes.m_10425781` / `VoxelShape.calculateMaxDistance`. Positive X clipping compares the Boat's first X face with the current player box maxX:

`f = 1.30000005 - 0.800000011920929 = 0.500000038079071`.

The shape's transverse Y/Z cells overlap the player's contracted-by-`1e-7` transverse interval. The clipper only applies `min(requested=0.5, f)`, so result is exactly X `0.5`, Y/Z `0`. The first-face tolerance (`f >= -1e-7`) permits near-contact candidates but does not expand the maximum requested distance. For 1.13.2 the Boat is absent after query filtering, so the same unobstructed request resolves to `(0.5,0,0)`.

In 1.14.4 `Entity.move` writes the resolved vector only when squared length is `>1.0E-7`; here it is `0.25`, so the player position becomes `(1.0,0,0.5)`. In 1.13.2 the same displacement is applied and position is the same. Neither horizontal nor vertical collision flag changes (`vec3d2 == vec3d`, vertical request is zero), `onGround` remains false, and there is no collision-induced velocity adjustment. Step-up is not entered because the ordinary clip did not reduce either horizontal component. Terminal differences for this fixture: none.

## Bound

This closes only the specified positive-X case with an epsilon-only entity box just beyond the swept extent. It does not establish safety for a box whose relevant face lies within the requested travel distance, a different axis/order, a step-up fallback, another collision shape, or query boxes near the average-side-length cutoff. Those require separate exact fixtures if operation applicability depends on them.

## Source identity

Publication markers: `1.13.2/ornithe-feather.ready.json` SHA-256 `1d1c644c1deB05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38`; `1.14.4/ornithe-feather.ready.json` SHA-256 `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77`.

Endpoint source hashes (SHA-256):

- 1.13.2 `net/minecraft/world/EntityView.java`: `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de`
- 1.13.2 `net/minecraft/entity/Entity.java`: `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`
- 1.13.2 `net/minecraft/entity/vehicle/BoatEntity.java`: `3d9c248c8cb5846ac157b7973e4c6f448fe12bdc63c8d33931dace98682c0f66`
- 1.14.4 `net/minecraft/world/EntityView.java`: `3822844ced53882c52f0523a1bd714baa3cd9bb9dab38a5e2c53051c7b1590e3`
- 1.14.4 `net/minecraft/entity/Entity.java`: `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55`
- 1.14.4 `net/minecraft/entity/vehicle/BoatEntity.java`: `2a33747d7d429ed58ef599de2eceddec5b377a78a1c3ddecd20def1d4907e3c9`
- 1.14.4 `net/minecraft/block/shape/VoxelShape.java` and `VoxelShapes.java` are Feather sources used above; clip arithmetic is from `calculateMaxDistance` and `calculateMaxOffset`.

No runtime, build, game, test, decompile, or canonical write was used.

- 1.13.2 
et/minecraft/entity/living/player/PlayerEntity.java: 4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633; 1.14.4 counterpart: 2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df.
- 1.14.4 
et/minecraft/block/shape/VoxelShape.java: 8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd; VoxelShapes.java: 51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9.
