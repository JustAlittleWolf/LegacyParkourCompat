# Block candidate query closure: 1.13.2 → 1.14.4

## Scope and paired inputs

This closes only the block-candidate enumeration path requested by the parent task, using exact Ornithe Feather sources. Movement caller context is from `.native-source/20261031/1132-1144-finish46/collision-candidate-route-pairing/report.md`. Paired inputs for comparison are identical query boxes/shapes, raw block states and loaded-chunk results; collision-context provider output is considered equal only where independently established for that raw state/context. This is not a producer/trajectory proof and does not close entity-candidate or complete border behavior.

Source manifests are Feather Gen2 build 2: 1.13.2+build.2 (`2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`) and 1.14.4+build.2 (`717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`).

## Query bounds and enumeration

Let the supplied query's per-axis bounds be `a=min`, `b=max`.

* 1.13.2 `WorldView.getBlockCollisions` enumerates integer coordinates `[floor(a)-1, ceil(b)]` inclusive. The `BlockPos.Mutable.iterateRegionMutable` arguments are the exclusive upper coordinate `ceil(b)+1`; it loops X fastest, then Y, then Z (`WorldView.java:112–151`; `BlockPos.java` region iterator).
* 1.14.4 computes `[floor(a-1e-7)-1, floor(b+1e-7)+1]` inclusive and the `C_29205863` cursor loops X fastest, then Y, then Z (`WorldView.java:133–181`; `C_29205863.java:15–48`).

For a non-integral bound, these integer ranges agree. If `a` is an exact integer, 1.14.4 includes one more low-side shell cell; if `b` is an exact integer, it includes one more high-side shell cell. These are real source-level differences even with the query box held equal. The added shell is at least one block beyond the query edge, so a local shape confined to its own unit cell cannot intersect the query; only a collision shape reaching out far enough can contribute there. Both endpoints subsequently require positive shape overlap against their respective supplied query shape (old final stream predicate; new `VoxelShapes.overlap` at `:174–176`).

Boundary pruning is not identical. Old code skips a cell lying on boundary faces of two or more dimensions (`WorldView.java:127–130`), while new code skips only 3-face corners (`lx==3`), then admits a 1-face shell cell only when `hasLargeCollisionShape()` and a 2-face shell cell only for `Blocks.MOVING_BLOCK` (`WorldView.java:163–175`). Therefore, with the same state and query shape, boundary cells can have different eligibility at exact integer-expanded bounds: 1.14.4 has special large-shape and moving-block routes where old omitted multi-face edges; conversely, old permits any state at a 1-face shell while new gates it on the large-collision flag. A changed candidate list/output is conditional on the selected state's exact collision shape positively overlapping the common query box. Generic ordinary shapes confined within their own cell do not witness a changed caller output from these shell cells. No such special boundary-state geometric witness was established in this task.

Within cells passing those filters, both translate the state's collision shape by integer cell coordinates and reject empty/non-overlapping results. Old additionally tests the translated *local* shape against `excludeBlock` and suppresses that cell when it overlaps the mover's original shape (`:138–140`); new enumeration has no equivalent per-cell exclusion (`:143–175`). This is an independent equal-query-input difference when a cell's state collision shape overlaps both the query and the old excluded shape. The top-level 1.13.2 movement query supplies a carved swept query plus original-box exclusion; 1.14.4 movement creates fresh queries from `box.expand(vector)` (see pairing report). Thus an identical *expanded box* alone does not equate the old carved query/exclusion inputs, and those inputs must remain explicit in any operation claim.

Old also aggregates every candidate whose provider returns the identity `VoxelShapes.block()` into one `IntVoxelShape` appended after the cell stream (`WorldView.java:121–122,141–151`); 1.14.4 emits overlapping translated shapes individually in cursor order (`:167–178`). Hence the emitted list's representation and order can differ even when the geometric union is the same. Do not infer a changed clipped position solely from this representation difference.

## Chunk availability and out-of-height cells

The old scan calls `isChunkLoaded(pos)` whose default is `allowEmpty=true`; client `ClientWorld.isChunkLoaded(...,allowEmpty)` therefore reports loaded even for a missing client chunk (`WorldView.java:274–279`; `ClientWorld.java:112–114`). It reads `World.getBlockState`, which returns `VOID_AIR` outside Y `[0,256)` and otherwise obtains a chunk with `load=true` (`World.java:178–180,519–525,187–198`). Old client `ClientChunkCache.getChunk(...,generate=true)` returns its `EmptyChunk` on a cache miss (`ClientChunkCache.java:47–50`); that chunk's `getBlockState` is `VOID_AIR` (`EmptyChunk.java:40–42`).

The new collision scan instead calls `getChunk(...,FULL_CHUNK,false)` and omits `null`; `World.getChunk` passes `load=false` through and returns null when absent (`WorldView.java:167–179`; `World.java:157–164,875–877`). New client cache also returns null on absent/unmatched chunk when `load=false` (`ClientChunkCache.java:67–77`). For a present new `WorldChunk`, direct section lookup returns AIR when Y is outside `[0,256)` or no section exists (`WorldChunk.java:191–223`). Both AIR and VOID_AIR have empty collision shape in these endpoint sources (AirBlock→empty shape; Block collision dispatch), so the absent-chunk and out-of-height cases produce no block collision candidate in either route **provided old world-border cell substitution is not active**. This closes the earlier report's unloaded/empty/out-of-height uncertainty for the block candidate route; the caller state providers are not needed to make these AIR/VOID_AIR outputs empty.

The 1.14.4 direct chunk-state read bypasses `World.getBlockState`'s `VOID_AIR` height guard, but its loaded `WorldChunk` gives AIR outside the range; this has the same empty collision result. `EmptyChunk` yields VOID_AIR and is likewise empty. Equal availability and equal raw state inputs therefore do not create a candidate difference just from missing chunks or build-height clipping. Old's `load=true` API may populate/return its empty sentinel, but this is source behavior, not an assertion about runtime chunk histories.

## World border, restricted to block route

Old block enumeration has a special collision candidate: when the passed `checkWorldBorder` is true and the enumerated position is outside the border (and the expanded scan box fails the all-inside test), it substitutes `VoxelShapes.block()` instead of consulting state (`WorldView.java:119–136`). Since the cell was first gated by `isChunkLoaded`, this can synthesize a full cube even over an old client empty-chunk `VOID_AIR` cell.

In 1.14.4 the block candidate loop never substitutes a border cube. `Entity.move` seeds its separate accumulated clipper candidates with `getWorldBorder().m_91823398()` only when contracted/expanded mover shapes straddle the border (`WorldView.java:150–156`, `Entity.java:657–665`); later block queries append ordinary block candidates. Thus the block-only candidate stream differs for outside-border cells: old may add synthetic cell cubes, new block scan omits/uses raw chunk state. This records only the route split. Whether the independent newer border shape and old synthetic cubes yield equal full movement output is left to the sibling border/hysteresis audit; do not treat the border as an ordinary block provider change.

## Closed outputs and remaining limitations

Closed for this exact source slice:

1. Both endpoints use one-cell swept-query margins, but exact integer query faces add one further shell cell in 1.14.4; conditional special collision shapes can therefore change candidate eligibility under equal boxes.
2. Boundary-cell filters differ, and old original-shape exclusion has no direct per-cell new counterpart; candidate streams can differ conditionally as detailed above.
3. Missing/empty client chunks and out-of-build-height positions resolve to no block collision in both versions when border substitution is inactive, despite their distinct lookup/loading routes.
4. Border handling is split: old can manufacture block-candidate cubes; new carries a separately generated border candidate.

No new concrete clipped-position witness is claimed from shell candidates, excluded-current-shape overlap, or the old/new border representations. Those require a specified raw state/provider result and exact query shape/caller history; the parent assignment treats those as paired inputs, and this task intentionally did not synthesize a trajectory. The existing independent full-cube diagonal witness remains the prior report's clip-order result, not evidence for the conditional shell differences here. No full movement inventory/freeze follows from this bounded source closure.

## Exact source file SHA-256

Hashes below identify the files read for this comparison (SHA-256 over file bytes):

| File | SHA-256 |
|---|---|
| 1.13.2 `world/WorldView.java` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.13.2 `world/World.java` | `0023DE30DA608DB73C6C6188334D2BB19039D86FE4D6F5E4AD79D732A5D2CD1A` |
| 1.13.2 `entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.13.2 `world/chunk/WorldChunk.java` | `D800FAC11AA2672A4DD69CB5A599E5F84BB6E2C71CFC8080FA972ACDABFB4914` |
| 1.13.2 `world/chunk/EmptyChunk.java` | `42EF83DD4325EAA9589F243E0034E86CD76CF357FB33EE82C515D043E336C2A1` |
| 1.13.2 `client/world/chunk/ClientChunkCache.java` | `D416574E48CF414145B2C8CB8C1B7EF9E39D44AAF876972D724316FD01957F88` |
| 1.13.2 `client/world/ClientWorld.java` | `BAE1D6D653260E42D735B9652E5C89711F1BD78EACBA7993E2460F2F2528640A` |
| 1.13.2 `util/math/BlockPos.java` | `EE71CFDEDCAA27458F48168AB761B435CF9C878B04F21E971DDBAFB6254AA3FD` |
| 1.13.2 `block/Block.java` | `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` |
| 1.13.2 `block/AirBlock.java` | `DC80BCD262BC9E8E84BFD66971BFAF8ED621F02899AE8802C9CB2B2FEF8A93C4` |
| 1.14.4 `world/WorldView.java` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.14.4 `world/World.java` | `498A72CDD4BD035CD731D2C49FCE401BEF439D6F92F498501577D9CFC59AB487` |
| 1.14.4 `entity/Entity.java` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |
| 1.14.4 `world/chunk/WorldChunk.java` | `42541D52FD708A689ED15E408B327D011FCEA73CFA45AF4C3C8DD9355AEEBCF7` |
| 1.14.4 `world/chunk/EmptyChunk.java` | `6D0CD2FC6514B639B6AD863F2C42F0E8A9F55402BEF1FC01666A82E52F0278BB` |
| 1.14.4 `client/world/chunk/ClientChunkCache.java` | `612082958CF2C54CD26822B653B84FA8A3F93CA2808DDED55F3C5AA86CF1409C` |
| 1.14.4 `unmapped/C_29205863.java` | `D15373EF21F58ED67755269D32B2DD5FF65EB33DD4EEA33E854B505B9AC9AFDB` |
| 1.14.4 `block/Block.java` | `1F8EC3628F08E196C2793E91CA0B94FEACEA6BC3939E7FB770F0682A6E66F2C5` |
| 1.14.4 `block/AirBlock.java` | `5F39EAC1EC12B6E5C37E07A6C153A3A539C10C26ACCB016E8384C801B6083D04` |

This report is source-only. No game, build, test, decompile, product source or canonical research state was written.
