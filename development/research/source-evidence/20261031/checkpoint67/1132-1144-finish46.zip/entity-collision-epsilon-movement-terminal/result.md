# Entity collision-query boundary: no changed player terminal in the bounded no-step case

## Result

For an ordinary positive-volume local-player box, the old and new entity-collision queries produce the same accepted Boat/Shulker collision shapes for a fixed requested movement and fixed entity population in the bounded no-step case below. The old broad phase expands by `0.25`, while the newer final query expands by `1.0E-7`; neither difference changes the candidate shape stream that reaches the player clipper under this fixture. The new `1.0E-7` average-side cutoff is not reached by the stated player box.

This closes only the EntityView candidate-query epsilon boundary for the fixed request with no block, border, or step candidates. It does not close old/new step candidate-list rebuilding, border hysteresis, vector/order differences, entity histories, or full-pair coverage. No candidate-stream difference or movement finding is claimed.

## Fixed query input and exact swept bounds

Use a standing player box `B=[0.41,0,0.20]–[1.01,1.80,0.80]`, requested vector `(0.10,0,0)`, with `onGround=false`. Hold one eligible non-spectator Boat or live Shulker shape equal to its entity AABB fixed at both endpoints; all other entity/block candidates are empty and the world border is distant. The ordinary player dimensions remain positive, and no step retry is admitted in this input (`onGround=false`, no downward clipped motion).

Both routes form the same outer swept envelope after the `1.0E-7` tolerance:

```text
A = [0.4099999, -0.0000001, 0.1999999] – [1.1100001, 1.8000001, 0.8000001]
```

In 1.13.2 `WorldView.getCollisions(entity, box, dx,dy,dz)` creates `A` as the expanded sweep and computes `S = A \ B'`, where `B'` is the original box shifted by `(-1.0E-7,+1.0E-7,+1.0E-7)` for this positive-X request (`WorldView.java:154–163`). Here `B'` has `maxX=1.0099999`; therefore the part of `S` with `x` in `(1.0099999,1.1100001)` spans the full Y/Z ranges of `A`. `S.bounds()` is exactly `A`, which is the box used by old `EntityView.getEntityCollisions` for its final `candidate.intersects(box)` filter (`EntityView.java:26–35`).

In 1.14.4 `Entity.move` passes `B.expanded(0.10,0,0)` to `EntityView.getEntityCollisions` (`Entity.java:657–665`; `Box.m_78709828` delegates to `expanded`, `Box.java:113–114`). That method expands by `1.0E-7` and uses the resulting same `A` for both its entity query and final shape filter (`EntityView.java:53–67`). Thus both sides accept exactly those candidate collision boxes that strictly intersect `A`.

The old broad-phase box is `A.expand(0.25)`; the new query box is `A`. For the eligible entity methods checked here, `BoatEntity.getCollisionShape()` and live `ShulkerEntity.getCollisionShape()` both return their own `getShape()` bounding box. If such a candidate shape intersects `A`, its entity bounding box also intersects `A`, so the new entity query includes it; the broader old query includes it as well and its final filter keeps it. An old broad-phase-only entity whose shape misses `A` is discarded by the old final filter. With the single fixed candidate, both movement calls therefore pass the same entity-shape stream onward.

The ordinary standing box makes the new query average side length `(0.7000002 + 1.8000002 + 0.6000002)/3`, about `1.0333335`, far above the `<1.0E-7` early-return gate. The later resolver receives the same entity candidates on both endpoints; with equal empty block/border inputs and no step alternative, the queried entity-list boundary cannot change the movement result.

## Exact source identity

Read-only sources are Ornithe Feather Gen2 build 2 at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Ready records identify the exact endpoint versions and Feather mapping. I recomputed each cited Java file hash and verified it equals its path/hash row in the source manifest.

| Relative source file | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` | `3822844ced53882c52f0523a1bd714baa3cd9bb9dab38a5e2c53051c7b1590e3` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` |
| `net/minecraft/world/WorldAccess.java` | `fc75177d629ef8d0d491821fe557e21606e4cb381164f1ca41b2763073f854be` | `f57639756acdedbd0e5a598f7740a8e17f0dc3b2ba710aa4690d05f4f3bcd746` |
| `net/minecraft/world/chunk/WorldChunk.java` | `d800fac11aa2672a4dd69cb5a599e5f84bb6e2c71cfc8080fa972acdabfb4914` | `42541d52fd708a689ed15e408b327d011fcea73cfa45af4c3c8dd9355aeebcf7` |
| `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/entity/vehicle/BoatEntity.java` | `3d9c248c8cb5846ac157b7973e4c6f448fe12bdc63c8d33931dace98682c0f66` | `2a33747d7d429ed58ef599de2eceddec5b377a78a1c3ddecd20def1d4907e3c9` |
| `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `35d3f858f7e06c035ee66b74b08420b678665dcdff9e4cf0619d68570966afa5` | `cea369aa7057a6adf8ec84e238458a83fe4762fa0b3ad8b230bdf5531bd1b8c` |

Source-manifest SHA-256 values: 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. All 11 file hashes per endpoint matched their manifest rows.

No product, wiki, backlog or Git evidence was read. No source was modified; no build, test, decompilation, game launch or runtime trajectory was run.
