# Bounded step candidate-list rebuild comparison: 1.13.2 → 1.14.4

## Result

For the fixed one-block oak bottom-slab step below, every clip that can be affected by the slab obtains its same shape from the old reusable list or the corresponding new vector query. The raised horizontal clip is the one exception in list membership: the old reused list still contains the slab, while the new scan omits it because it no longer overlaps the raised sweep; the old clip also sees no vertical overlap and is unaffected. The two implementations return the same position delta and collision flags for this fixture even though the new resolver builds separate candidate streams and the alternative-selection tie disposition differs. This closes only this state/query slice; it does not establish candidate-list equivalence for other providers, contexts, borders, chunks, or step vectors.

This report does not re-evaluate the previously recorded downward-component difference for nonzero requested Y or any other accepted step candidate. It uses requested Y=0 so that both downward vectors are the same and compares query rebuilding only.

## Fixed raw input

- Local player box from position `(0.5,0,0.5)`, standing dimensions `0.6F × 1.8F`: X/Z `[0.19999998807907104,0.800000011920929]`, Y `[0,1.8]`.
- `onGround=true`, positive step height `0.6F`, no sneak-edge or piston preprocessing, no entities, and an interior world border.
- Movement request `(0.7,0,0)`. The only colliding block in every relevant swept neighborhood is `minecraft:oak_slab` at `(1,0,0)`, with the bottom-slab shape `[1,2] × [0,0.5] × [0,1]`; neighboring cells are air. Its six raw states are already paired, and the bottom state is collidable in both endpoints. It ignores context/world/position and has the same shape in each release.
- Assume every cell/chunk scanned by the old and new calls is available with those same states. This is a fixed source-query fixture, not a claim that ordinary history produces it.

## Paired candidate queries

### 1.13.2

`Entity.move` first makes one vector-specific world collision query for `(0.7,0,0)` and clips the normal move; the slab stops X at `1 - 0.800000011920929 = 0.19999998807907104`, so the step gate opens from `onGround=true` plus X clipping. The method then restores the starting box and makes one collision query for the step vector `(0.7,0.6,0)`. That returned list contains the single oak slab and is reused for both step alternatives and the downward clip (`Entity.java:578–618` and `:619–680`).

Both alternatives rise by `0.6`: the upward clip is not blocked by the slab beneath the starting box. Once raised, the horizontal `0.7` sweep has its lower face at `0.6`, above the slab top `0.5`, so it is not horizontally clipped. Both alternatives therefore have horizontal progress `0.7`; the old strict-`>` selector chooses its second alternative on equality. The subsequent downward `-0.6` clip reaches the slab top and resolves to `-0.1`. The final step delta is `(0.7,0.5,0)`.

### 1.14.4

`Entity.m_72373519` begins with entity and border candidates; both streams are empty for this fixture. Its normal single-axis X query obtains the same slab shape through the context-aware block scan and resolves X to `0.19999998807907104`. The step gate opens from `onGround=true` and X clipping. The first step alternative uses `m_64271959(0.7,0.6,0)`; its fresh swept block query includes the slab, then Y-before-X clipping yields `(0.7,0.6,0)`. The second alternative's upward query uses the horizontally expanded original box and also includes the slab; its subsequent raised horizontal query cannot be clipped by the slab because the raised box begins at Y=0.6. It likewise yields `(0.7,0.6,0)`. Since its rise equals `stepHeight`, the `vec3d4.y < stepHeight` gate does not replace the first alternative. The final downward query covers the slab again and resolves to `-0.1` (`Entity.java:656–685`, `:692–772`; `VoxelShapes.m_10425781`). The new selected result is also `(0.7,0.5,0)`.

In this witness, the step alternative choice differs on equality (old selects alternative two; new retains alternative one), but both candidate vectors and the subsequent descent are equal. Both position writers apply the same delta because its squared length is `0.74`, above the new `1.0E-7` position cutoff. Both movement calls finish with horizontal collision false, vertical collision true, and `onGround=false` from requested Y being zero. There is no terminal movement difference in this bounded fixture.

## Query and dependency boundary

The old step vector query materializes one block-shape list and reuses it; the new `m_64271959` multi-axis path performs a fresh `WorldView.getBlockCollisions` query per vector, while its axis-only path uses contextual shape scans in `VoxelShapes.m_10425781`. Here, every query that can clip the selected rise/descent sees the same oak-slab shape. For the raised second-alternative horizontal clip, the old list still carries the slab but it has no vertical overlap; the new axis scan omits it, also yielding the full horizontal request. The one horizontal axis avoids the X/Z ordering branch. These fixed facts explain why query reconstruction does not change this output.

Still open outside the fixed fixture: other state/context/neighbor-dependent providers, entity and border candidates, empty/unloaded chunk differences, boundary cells and epsilon extents, multiple competing shapes and their ordering, diagonal/X-Z clipping, and step vectors where a fresh per-axis query adds or drops a collision shape. Same state histories and effective vanilla memberships are inputs; producer/runtime history remains excluded. This slice makes no pair-freeze or trajectory claim.

## Exact source identities

Endpoint publication identities are Ornithe Feather Gen2 build 2. Source-manifest SHA-256 values: `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4). Full-file source SHA-256 values:

| Relative source file | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` | `91f2ebc592e5cb07d5ce8a6faa123ec0d4b7bf10aa6323d6aceb343bc0f73a53` |
| `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |

The slab state/provider closure and `SlabBlock.java` hash pair are cross-checked in `../common-block-shape-pairing/result.md`. No canonical sources were modified. No build, test, game, or runtime check was run.
