# Fixed overlap/excludeBlock clip fixture: 1.13.2 → 1.14.4

## Scope and conclusion

This source-only fixture addresses the bounded residual in `../resolver-context-terminals-followup/report.md`: old 1.13.2 `excludeBlock` removes a common provider shape that the 1.14.4 vector-expanded query emits. The paired provider is the common `minecraft:oak_fence` collision shape at block position `(0,0,0)`, raw state `NORTH=true; EAST=true; SOUTH=false; WEST=false; WATERLOGGED=false`. The shape has the same output at both endpoints. For the fixed player box and vector below, the candidate is eligible in the old cell scan, intersects the old movement-only shell, positively overlaps the original box, and positively overlaps the new query box. Old excludes it and new emits it. With no other collision candidates and an interior loaded chunk/world border, that membership difference changes the fixed clip result from `(0.2,0,0.1)` to `(0.135,0,0)`.

This is a geometric fixed-input clip witness. It does not establish an ordinary player trajectory, how this raw fence state or overlapping player box is produced, a state producer, or an implementation applicability boundary. Other entity/border candidates, step alternatives, chunks outside the stated loaded cell, and context-dependent providers are not part of this fixture.

## Paired provider output

The existing oak-fence raw-state pairing covers the selected state at both endpoints. The `PaneBlock` constructor used by `FenceBlock` has `(f=2,g=2,h=16,i=16,j=24)`. Its collision provider returns the `shapes` table built by `makeShapes(f,g,j,0,j)`. With NORTH and EAST connected, the union is an L shape made from the north and east arms (the center post is contained by their overlap). In local coordinates the arms are:

- North arm: `x=[6/16,10/16]`, `y=[0/16,24/16]`, `z=[0/16,10/16]`.
- East arm: `x=[6/16,16/16]`, `y=[0/16,24/16]`, `z=[6/16,10/16]`.

The old `PaneBlock.getCollisionShape(BlockState,BlockView,BlockPos)` and new `PaneBlock.getCollisionShape(BlockState,BlockView,BlockPos,CollisionContext)` select this same state-indexed shape. The new method ignores context. The paired registration enables collision and does not enable dynamic shape, so the new entity-context path yields the same output as its cached shape.

## Fixed inputs and candidate-membership checks

- Provider cell: `(0,0,0)`, loaded; no nearby world-border crossing.
- State: registered `minecraft:oak_fence`, NORTH+EAST mask `12`, `WATERLOGGED=false`.
- Player box `B`: `x=[-0.11,0.49]`, `y=[0,1.8]`, `z=[-0.22,0.38]` (width `0.6`, height `1.8`).
- Requested vector: `(dx,dy,dz)=(0.2,0,0.1)`, a mixed horizontal vector; no step alternative is evaluated for this fixed resolver call.
- New query box `B.expand(vector)`: `x=[-0.11,0.69]`, `y=[0,1.8]`, `z=[-0.22,0.48]`.

The translated fence shape intersects `B` with positive volume through both arms: the overlap includes `x=[0.375,0.49]`, `y=[0,1.5]`, `z=[0.375,0.38]`. The positive EAST request also extends the old swept query past the original box's positive-X face. The movement shell includes `x` strictly above the old directionally shifted carve edge `0.49-1.0E-7` and below `0.69+1.0E-7`, while the east arm occupies that interval and overlaps the player box's Y/Z footprint. Thus this cell's shape positively intersects the old movement shell. Its scan cell `(0,0,0)` is interior to the enumerated shell bounds, not a filtered multi-face boundary cell.

Old `WorldView.getBlockCollisions(shape,excludeBlock,checkWorldBorder)` translates the original box locally for cell `(0,0,0)`, finds positive `AND` overlap with the fence shape, and returns an empty shape for that cell before its final shell-overlap filter. The old candidate is therefore excluded. The new `WorldView.getBlockCollisions(entity,box.expand(vector))` has no `excludeBlock` test; it dispatches the same NORTH+EAST collision shape and emits it because it positively overlaps the expanded query box. This cell is an interior scan cell under the new expanded-query bounds, so the large-shape/moving-block shell conditions do not gate it.

## Clipper handoff and result

Assume the accumulated old entity/border/block stream is empty apart from the queried fence cell, and that the new carried entity/border stream is empty apart from this fresh block candidate. These are explicit fixed candidate-list inputs; no world history is inferred.

Old 1.13.2 clips Y→X→Z using the materialized candidate list. Since `excludeBlock` removed the fence, the X request remains `0.2`; the unobstructed Z request remains `0.1`. Result: `(0.2,0,0.1)`.

New 1.14.4 `Entity.m_64271959` routes this two-axis vector through its mixed-vector query and `m_79801352`. Because `abs(0.2) < abs(0.1)` is false, it clips X before Z. For X clipping, the box's Z interval positively includes the east arm's `[6/16,10/16]` band. In the paired L-shape grid, the box maximum `0.49` is inside the occupied X interval `[6/16,10/16]`; the next X face at `10/16=0.625` is also occupied through the east arm. The limiting gap is `0.625-0.49=0.135`, so X becomes `0.135`. After that move, the box still overlaps the east arm in X and Y, and its Z maximum `0.38` is within the east-arm interval `[6/16,10/16]`; there is no later occupied Z face, so Z remains `0.1`. Result: `(0.135,0,0.1)`.

The per-axis arithmetic itself is the paired algorithm already recorded in `../resolver-axis-clip-core-pairing/report.md`; this fixture's delta comes from the old/new candidate membership. It does not claim a later entity-position write or complete movement tick result.

## Exact source identity and member hashes

Source roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Ornithe Feather Gen2 build 2. Source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`, respectively. Full Java file SHA-256 values below were recomputed from those source trees.

| Endpoint | Exact file/member used | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/world/WorldView.java`, `getBlockCollisions(VoxelShape,VoxelShape,boolean)` and `getCollisions(Entity,Box,Set<Entity>,double,double,double)` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.14.4 | `net/minecraft/world/WorldView.java`, `getBlockCollisions(Entity,Box)` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.13.2 | `net/minecraft/block/PaneBlock.java`, `PaneBlock(float,float,float,float,float,Block.Properties)`, `makeShapes`, `getCollisionShape` | `9422E3F2AA9843ECD041F5CED13D05A4C7472D697F7DFD838450E49969E5326C` |
| 1.14.4 | `net/minecraft/block/PaneBlock.java`, corresponding constructor, `makeShapes`, and context `getCollisionShape` | `7150E89268A84113453CD5416FFE25E1CA7D42A39F264F7AE989878A10EE2158` |
| 1.13.2 | `net/minecraft/block/FenceBlock.java`, `FenceBlock(Block.Properties)` and state definition | `ABEFBEDEA10306ABF602D4E379A4793B415CA7635231752CD9F18A80ACED5FC2` |
| 1.14.4 | `net/minecraft/block/FenceBlock.java`, corresponding constructor and state definition | `4319FFB95AD81E969B11B39A8E6361D678B5FB5F3AD210D9834CE5E30D5F45D8` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java`, `getCollisionShape(BlockView,BlockPos)`; `net/minecraft/block/Block.java`, oak-fence registration | BlockState `0496FDA381628E90B3B3FF8AE376A5BAE24CBD662366F34D70991252FAB2FE70`; Block `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java`, context collision dispatch/cache; `net/minecraft/block/Blocks.java`, oak-fence registration | BlockState `6C6703C7C2F7203A7507D8A621BC83E1DAD613B32089394F5AF4FBD8636B165F`; Blocks `9C0323497B31F8A284456E5692898897B92B6F0817D0371FAE9A8AFB54C638F8` |
| 1.14.4 | `net/minecraft/util/math/Box.java`, `m_78709828(Vec3d)` expanded-query helper | `B68667118BA729FC18FEFA3B9DE9060184F9D71F53A4BF10A8B7215863FF8B6E` |
| 1.14.4 | `net/minecraft/unmapped/C_29205863.java`, `m_97468855` scan and `m_87302669` boundary count | `D15373EF21F58ED67755269D32B2DD5FF65EB33DD4EEA33E854B505B9AC9AFDB` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java`, `getCoordIndex` and `calculateMaxDistance` | `D95B0607647DA11595E24E1E26E9615CB7DA7705EA7885908544362DF62275C1` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java`, corresponding `getCoordIndex` and `calculateMaxDistance` | `8EFB68BF9D5EFDB0EC48E401D1852E90458C7094F8FA0C8E9AE418F268C40FDD` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java`, `overlap` and `calculateMaxOffset` | `313968D4E5855B5EC380272B6ABABCC5849D478AB771926355912A8CB6AA9C95` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java`, corresponding `overlap`, `calculateMaxOffset`, and world-aware query wrapper | `51A09C297C7F01C8BAD9B66AF2A80900E95F33C6E3A250CE599F4817433587D9` |
| 1.13.2 | `net/minecraft/entity/Entity.java`, `move` axis-resolution path | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.14.4 | `net/minecraft/entity/Entity.java`, `m_64271959` and `m_79801352` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |

The paired raw-state/provider reference is `../pane-snow-fence-shape-pairing/result.md` (SHA-256 `31F7E2E5FA169557469327D68F14E6D3732E8CA3D5C86C69EAEBD29E44FC0B46`); its endpoint file hashes and the two `PaneBlock.java` hashes above identify the exact paired geometry. The canonical provider inventory is `../providers/inventory.md` (SHA-256 `97631F9563A94CD08D470F5D4483D3960498B2D0EE9BFCDE9A977DE54E949480`).

No product, wiki, backlog, or Git data was read or changed. No source tree was written or regenerated. No build, test, game, decompile, or network activity was performed.

## Erratum after independent candidate review

The opening conclusion's new clip vector `(0.135,0,0)` is a typo. The exact clip calculation later in this report gives `(0.135,0,0.1)`, which is the intended result and matches the reviewed fixed-input fixture. The candidate draft now explicitly supplies vector `(0.2,0,0.1)` and the no-step SELF movement gates. This remains a conditional clip-vector witness; it does not assert ordinary trajectory reachability or a complete tick outcome.
