# Corner-shell clip candidate: two-boundary moving-block admission changes the resolved X vector

## Verdict

**Conditional exact terminal found.** For one fixed, initially nonoverlapping player box and one requested vector, the old two-boundary cell filter omits a shared vanilla `moving_piston` collision shape while the 1.14.4 one-axis `MOVING_BLOCK` gate admits that same shape. Exact `Entity.move` clipping gives `(-0.5, 0, 0)` at 1.13.2 and `(-0.1, 0, 0)` at 1.14.4 under the bounded assumptions below.

This is a source-only movement-query/clip terminal. It does not claim piston production or an ordinary trajectory reaches the raw moving-block entity inputs. The new geometry uses a paired `cobblestone_wall` moved-state output rather than the previously checked oak-fence fixture. The prior provider census and reports were inputs; provider rosters/tables and the closed moving-piston fixture were not redone.

## Frozen source basis

Exact read-only endpoints are Ornithe Feather Gen2 build 2 at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`; source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` respectively.

The frozen provider inventory is `providers/shape-provider-overrides.tsv` (SHA-256 `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad`). The relevant already-paired vanilla state report is `wall-shape-pairing/result.md`: its `minecraft:cobblestone_wall` collision tables match for all 64 raw property tuples. The relevant prior route report is `large-shape-boundary-candidate-closure/result.md`; it closed candidate membership and a different clip fixture, while leaving the final movement vector open for its overlapping initial box. The route descriptions in `collision-candidate-route-pairing/report.md` and `resolver-query-branch-closure/report.md` were used as instructed.

## Reproducible matched input

Use the same inputs at each endpoint:

- Player collision box `B = [0.6,1.2] × [0.2,2.0] × [0.2,0.8]`.
- Requested movement `v = (-0.5, 0, 0)`; `MoverType.SELF`, `noClip=false`, `onGround=false`, not sneaking, not in cobweb, and no piston movement adjustment.
- The only relevant block candidate is at `p=(-1,-1,0)`, in a loaded interior chunk with border inactive. Its state is `minecraft:moving_piston`; its `MovingBlockEntity` has `movedState=minecraft:cobblestone_wall[UP=true,NORTH=false,EAST=true,SOUTH=false,WEST=false,WATERLOGGED=false]`, `facing=EAST`, `extending=false`, `source=false`, `progress=0.5F`, and `NOCLIP_DIR=null`.
- No other block, entity, or border candidate blocks this motion.

The paired wall collision output for `UP=true` and east-only mask is the union of the center post `[4,0,4]–[12,24,12]` and east arm `[5,0,5]–[16,24,11]`, in sixteenths. The matched moving-entity wrapper translates it east by `1.0F - 0.5F = 0.5F`. At `p`, the resulting world bounds include the east arm `[-0.1875,0.5] × [-1,0.5] × [0.3125,0.6875]` and post `[-0.25,0.25] × [-1,0.5] × [0.25,0.75]`. `B` is disjoint in X from the complete union (its min X is `0.6`, beyond the shape's max X `0.5`), so the old `excludeBlock` overlap check would not suppress the shape if that cell reached it. Y and Z positively overlap the east arm.

## Old 1.13.2 route and result

`Entity.move` requests the collision stream for the box and vector. Its `WorldView.getCollisions` forms the movement-only shell from `B.expanded(-0.5,0,0).expand(1e-7)` minus the sign-shifted original box. The shell bounds on X are approximately `[0.1,0.6000001]`; its Y minimum is just below `0.2`. In `getBlockCollisions`, the enumerated cell range gives `p=(-1,-1,0)` as a boundary position on both X-min and Y-min, while Z is interior. The old predicate rejects cells on two or more boundary dimensions before it reads the state or asks for its collision shape. Thus this moving shape is absent from the old clipper list. With other collision candidates absent, Y/X/Z clipping leaves the request at `(-0.5,0,0)`.

The initial box is outside the moving shape, so this result does not depend on the old `excludeBlock` guard. The requested negative X travel reaches the wall shape, but the old route never supplies it to `calculateMaxOffset` because of the two-boundary prune.

## New 1.14.4 one-axis route and result

The one-axis vector routes through `VoxelShapes.m_10425781` / `m_84822986`, scanning the X travel range while using the original box's Y/Z cross ranges. At cell `(-1,-1,0)`, two boundary coordinates are counted (`s=2`). `BlockState.getBlock()` is `Blocks.MOVING_BLOCK`, so the explicit `(s != 2 || block == MOVING_BLOCK)` gate admits it. `MOVING_BLOCK` is dynamically shaped, and the outer `MovingBlock` provider delegates to the same `MovingBlockEntity`; its context argument is unused. The moved-state wall provider is context-insensitive and has the same collision shape as at 1.13.2.

For negative X movement, the box's local X interval relative to `p` is `[1.6,2.2]`; the wall's translated local maximum X is `1.5`. The exact axis gap is `1.5 - 1.6 = -0.1`, so the requested `-0.5` clips to `-0.1`. The subsequent nonzero-distance position write applies this resolved vector. With `onGround=false` and requested Y zero, the step-up gate is false. The new resolved vector is therefore `(-0.1,0,0)`.

The candidate's collision shape is not itself different across versions. The movement-vector delta comes from old two-boundary rejection versus the newer one-axis special admission for `MOVING_BLOCK`.

## Exact source hashes (SHA-256)

| Endpoint | Relative file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.13.2 | `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` |
| 1.13.2 | `net/minecraft/block/WallBlock.java` | `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf` |
| 1.13.2 | `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` |
| 1.13.2 | `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.13.2 | `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| 1.14.4 | `net/minecraft/util/math/Box.java` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |
| 1.14.4 | `net/minecraft/block/WallBlock.java` | `033da2cef0973f5d380a81b53ee76e23324fffece72edc74e12fcee0d8764be7` |
| 1.14.4 | `net/minecraft/block/MovingBlock.java` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |
| 1.14.4 | `net/minecraft/block/entity/MovingBlockEntity.java` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |

## Limits

This witness fixes the box, request, collision state and provider inputs. It does not prove the player can ordinarily acquire that box or that a piston creates these exact `MovingBlockEntity` fields. Candidate populations other than the single specified shape are excluded by assumption. No tests, builds, game runs, trajectory reconstruction, product changes, wiki/backlog/Git access, or canonical source writes were performed.



