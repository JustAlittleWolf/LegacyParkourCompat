# Pose-fit entity-collision response: fixed-input witness

## Scope and verdict

Exact endpoint pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2 build.2. This source-only witness closes the specific conditional path where clearing sneak after a prior crouched pose leaves the old client standing but the new client retaining `Pose.SNEAKING`, solely because the new desired-pose fit query includes another entity's collision shape. It establishes a fixed-input response difference, not entity history, motion, trajectory, or runtime parity. The source interval is bounded to these endpoints; no intermediate introduction version is asserted.

## Exact fixed snapshot

- Player position: `(x,y,z) = (0,0,0)` on both sides; player is not spectator or riding, `abilities.flying=false`, and `isFallFlying`, `isSleeping`, `isSwimming`, and `isDoingSpinAttack` are false.
- Logical sneak has just been cleared: `isSneaking=false`.
- Prior crouched dimensions: 1.13.2 has width `0.6`, height `1.65`; 1.14.4 has current synchronized `Pose.SNEAKING`, width `0.6`, height `1.5`.
- All blocks in the fit-query area have empty collision shapes.
- The same non-spectator, non-ridden BoatEntity is a fixed world input at `(0,1.7,0)`. Its collision shape is its box in both endpoints (`BoatEntity.java:116–118`). 1.13.2 sets it to width `1.375F`, height `0.5625F` in the constructor (`BoatEntity.java:75–79`); 1.14.4 declares those dimensions for `EntityType.BOAT` (`EntityType.java:145–147`). The resulting bounds are `x,z=[-0.6875,0.6875]`, `y=[1.7,2.2625]`. Treat this box as supplied snapshot data; no boat physics or placement/trajectory history is claimed.

With open intersection boundaries, the boat box misses the previous 1.13.2 crouched box (`maxY=1.65`), the 1.14.4 current/fallback sneaking box (`maxY=1.5`), and the 1.14.4 preliminary swimming fit box (`maxY=0.6`). It intersects each standing candidate (`maxY=1.8`) over `1.7 < y < 1.8`. It is in the new entity-query broad-phase area and has a non-null collision shape. Thus all fixture gates have a defined result without relying on an entity being simulated.

## Paired update gates and outcomes

1.13.2 `PlayerEntity.tick` calls `updatePlayerPose` at its end (`PlayerEntity.java:252–255`). With the stated flags, the method chooses `0.6F × 1.8F`; because current dimensions are `0.6F × 1.65F`, it builds a standing candidate from the current box minimum corner and calls `world.hasNoCollisions(null, box)` (`PlayerEntity.java:334–360`). `WorldView.hasNoCollisions` tests `getCollisions` (`WorldView.java:201–206`), while `World.getCollisions` appends entity collision shapes only if the passed entity is non-null (`World.java:1755–1757`). The null fit call therefore sees only block shapes. The empty-block fixture passes and `Entity.setSize(0.6F,1.8F)` installs the standing box (`Entity.java:285–300`). There is no event or cancellation gate on this direct invocation/setter path.

1.14.4 `PlayerEntity.tick` also calls `updatePlayerPose` at its end (`PlayerEntity.java:279–282`). First it requires `m_87715359(Pose.SWIMMING)` to pass (`PlayerEntity.java:343–344`). It does in this fixture. The raw flags then choose desired `Pose.STANDING` (`:346–358`). The spectator/riding bypasses are false. `m_87715359(Pose.STANDING)` calls `world.hasNoCollisions(this, poseBox)` (`Entity.java:1628–1629`), and `WorldView.getCollisions` concatenates block and entity collisions (`WorldView.java:121–130`). Its `EntityView.getEntityCollisions` queries nearby non-spectators, excludes the player and excluded entities, drops null collision shapes, then intersects returned shapes with the candidate (`EntityView.java:32–34, 53–66`). The boat shape therefore rejects standing. The next ordered test, `m_87715359(Pose.SNEAKING)`, passes because the boat starts above `1.5`; `updatePlayerPose` selects `Pose.SNEAKING` (`PlayerEntity.java:360–370`). This is a direct vanilla method path with no callback cancellation. The call to `m_59065105(Pose.SNEAKING)` writes the already-current pose; `SyncedData.set` only calls `onDataValueChanged` when the value differs (`Entity.java:295–300`; `SyncedData.java:120–127`).

## Resulting geometry, eye height, and next movement input

The old updater installs dimensions `0.6 × 1.8`. Since width is unchanged, `Entity.setSize` keeps the prior minimum X/Y/Z corner and sets the new maximum Y to `1.8` (`1.13.2 Entity.java:285–300`). The old eye-height accessor observes `isSneaking=false` and height other than `0.6`/`1.65`, so it returns `1.62F` (`PlayerEntity.java:1859–1869`).

The new pose remains `SNEAKING`; the player's pose-dimension table maps it to `0.6 × 1.5` (`PlayerEntity.java:110–118, 1964–1966`). `Entity.m_84943753` is the dimension/eye/shape writer reached when a pose data value changes: it updates dimensions, stores `m_42089492` as eye height, and rewrites the shape; the equal-width branch preserves the shape minimum corner (`Entity.java:2239–2266`). Here the selected pose is already `SNEAKING`, so the equality-gated data write does not invoke that callback and the existing dimensions, eye height, and box stay at `0.6 × 1.5`, `1.27F`, and `maxY=1.5`. New player eye height for `Pose.SNEAKING` is `1.27F` (`LivingEntity.java:2770–2775`; `PlayerEntity.java:1802–1812`).

On the next ordinary player movement call, the current shape is the input to collision collection: old `Entity.move` requests `world.getCollisions(this, this.getShape(), x, y, z)` (`1.13.2 Entity.java:578–586`); new `Entity.move` starts with `this.getShape()` and queries entity collisions from the moved query box (`1.14.4 Entity.java:657–665`). The starting vertical extent is therefore `1.8` old versus `1.5` new for this fixed snapshot. Ordinary movement remains entity-aware on both endpoints; the difference demonstrated here is the *pose-fit* query. Eye-position block/fluid logic also reads `y + getEyeHeight()` when its existing gates are active (`1.13.2 LivingEntity.java:264–269`; `1.14.4 LivingEntity.java:299–304`). No resulting trajectory or fluid state is predicted.

## Conditional limits

- The result requires all listed flags and fit-query inputs; a blocked preliminary swimming candidate, spectator/riding bypass, or blocked fallback fit follows other branches.
- The boat's collision box is a fixed common query input. The report makes no claim about how it reached that position, boat motion, vehicle behavior, or non-player physics.
- This does not establish the full prior-pose lifecycle, synchronization producer, intermediate patch boundary, or runtime parity. It also does not say old movement collision queries ignore entities; old `Entity.move` passes `this`, so the paired ordinary movement query can include entities.

## Exact source identity and hashes

Sources are the published `ornithe-feather` trees. Mapping artifacts in the source provenance are `feather-gen2-1.13.2+build.2` and `feather-gen2-1.14.4+build.2`. Ready-record source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4). The hashes below were recomputed from the read-only trees and match their source manifests.

| Release | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ED22F6C5A3C55D67EED782070AC722201DF4D624ADBC90779F1FD29C2876633` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C` |
| 1.13.2 | `net/minecraft/entity/EntityType.java` | `60DC820909860135CE1439E8836F1CE56600EC9C71BDA3B0968466FF4E5FAC03` |
| 1.13.2 | `net/minecraft/entity/vehicle/BoatEntity.java` | `3D9C248C8CB5846AC157B7973E4C6F448FE12BDC63C8D33931DACE98682C0F66` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023DE30DA608DB73C6C6188334D2BB19039D86FE4D6F5E4AD79D732A5D2CD1A` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614DEB3B50D11F6CDF54D9E308703BF49CB53B72646B05253857E9557D657DF` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2CCCF4331CE9E62013EEB8E96163E5E146E1291619EB998CE9867DAA87C02B61` |
| 1.14.4 | `net/minecraft/entity/data/SyncedData.java` | `4D0C0BEE069994F64A31E1FF600AE59C3217EADB8678473E2256C2363E657E17` |
| 1.14.4 | `net/minecraft/entity/EntityType.java` | `0B4BEBD0CBE746BDC99B80FC173B9CFF1CE69016012DA2505638C600685273FE` |
| 1.14.4 | `net/minecraft/entity/vehicle/BoatEntity.java` | `2A33747D7D429ED58EF599DE2ECEDDEC5B377A78A1C3DDECD20DEF1D4907E3C9` |
| 1.14.4 | `net/minecraft/world/World.java` | `498A72CDD4BD035CD731D2C49FCE401BEF439D6F92F498501577D9CFC59AB487` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.14.4 | `net/minecraft/world/EntityView.java` | `3822844CED53882C52F0523A1BD714BAA3CD9BB9DAB38A5E2C53051C7B1590E3` |

No product, wiki, backlog, Git, build, test, game runtime, or decompiler operation was used. No source tree was written.

