# Independent review: post-move dry-gravity chunk gate

## Verdict

**Accepted as a conditional direct local-player movement-velocity writer difference**, bound to candidate `travel-postmove-chunk-closure/result.md`, SHA-256 `594DBC20B88F38C0EFF034677A79AF0E1564C834A335A0167C4D640684A6CA92`.

The corrected candidate names the exact Feather members (`LivingEntity.moveRelative(float,float,float)` at 1.13.2:1478 and `LivingEntity.moveRelative(Vec3d)` at 1.14.4:1786), includes `onGround=false`, gives a standing local-player size, and records the local-player `isLocallyControlled()` gates. I inspected those bodies and the cited chunk-query/position helpers directly. All 19 listed source-file SHA-256 values match their exact endpoint Feather source manifests.

## Independent source check

Both local-player classes return true from `isLocallyControlled()`, so the movement method's outer client-control gate is satisfied. With the stated dry, no-effect, no-gravity-disabled, nonclimbing inputs, old `moveRelative` moves using the current X velocity and only later multiplies that velocity by `0.91F`. The new `m_19439509` helper returns its input unchanged when not climbing; its `move` likewise sees X `0.6` and applies `w=0.91F` only after movement. With `onGround=false`, both horizontal factors are exactly the same airborne constant and don't depend on the slipperiness lookup. Thus both reach X `16.1` from X `15.5` under the supplied unobstructed raw collision result.

Old `WorldView.isChunkLoaded(BlockPos)` defaults to `allowEmpty=true`; `ClientWorld` consequently returns true, then the post-move lookup retrieves the absent chunk's `EmptyChunk`, whose inherited `WorldChunk.loaded` flag is false. Old travel takes the client fallback and sets Y velocity to `-0.1`, then multiplies it by `0.98F`, approximately `-0.0980000019`.

New constructs its immutable `BlockPos` from pre-move `(15.5, 0, 0.5)`. `Vec3i` floors the coordinates, so it remains in cached FULL chunk `(0,0)` when tested after movement. The new chunk source returns the loaded cached chunk for that key, avoiding the unloaded fallback. With zero prior Y velocity, gravity then writes `-0.08` before the same `0.98F` multiplier, approximately `-0.0784000015`. These are distinct next-Y-velocity outputs under the stated same chunk snapshot.

## Scope limits

This is conditional on the stated raw client chunk availability, unobstructed move result, local logical movement, and effect/pose gates. It does not establish chunk streaming or input histories, server behavior, general movement trajectories, or patch-intermediate boundaries. The candidate keeps those producer and trajectory claims out of scope. No build, test, runtime, decompile, product/wiki/backlog, or Git use was involved.
