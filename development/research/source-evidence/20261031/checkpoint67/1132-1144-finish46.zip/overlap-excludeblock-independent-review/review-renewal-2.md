# Second review renewal: overlap / `excludeBlock` fixture

## Binding and source identity

This separate addendum reviews candidate revision SHA-256 `1174ac51022d5c4658d6961ebdbeb049e39e8bd14a56bd543c2af37c1f18781b` at `.native-source/20261031/1132-1144-finish46/overlap-excludeblock-fixture/candidate.md`. Endpoint identity and relevant source-file hashes are unchanged from `review.md`: exact 1.13.2 and 1.14.4 Ornithe Feather sources, Feather Gen2 build 2 mappings, with the hashes and source-publication verification identities recorded there.

## Recheck

The revised fixture now explicitly sets old `inCobweb=false` and the 1.14.4 pending movement multiplier vector to zero. This closes the remaining input-vector ambiguity: 1.13.2 `Entity.move` otherwise changes the requested components when `inCobweb` is true, while 1.14.4 `Entity.move` otherwise adds `f_74350999` to the supplied vector and clears the pending vector before calling its movement resolver. The supplied values therefore reach collision resolution unchanged under the stated SELF/no-sneak assumptions.

The route and clip remain correct against the endpoints. With `noClip=false`, both versions take their collision branches. In 1.13.2, SELF and `onGround=false` skip sneak-edge reduction; Y=0 is unchanged, so the ground/step gate remains closed. In 1.14.4, SELF avoids the piston-type clamp, the zero pending vector causes no vector addition, and the unchanged Y=0 plus `onGround=false` leaves `bl4=false`, so the step attempt is skipped. The new multi-axis resolver enters its X/Z path, tests Y first, then X before Z for `abs(0.2) > abs(0.1)`. The old resolver likewise tests Y, X, then Z. With the specified empty other block/entity/border candidates and the same fence geometry, old filtering suppresses the intersecting fence candidate; new expanded-query membership includes it. The fence shape's next occupied X coordinate beyond the box maximum `0.49` is `0.625`, so X becomes `0.625 - 0.49 = 0.135`; Z remains `0.1`.

## Renewed verdict

**Source-verified conditional fixed-input witness.** The revised candidate now states the inputs needed for the isolated resolver result, including both versions' web-related preprocessing state. The prior limitation is unchanged: the box begins intersecting the oak-fence collision shape, and no source-backed path is provided showing how this box/state pair arises or that an in-scope trajectory reaches it. Thus the conditional calculation is verified; ordinary reachability and generally applicable movement behavior remain unestablished.
