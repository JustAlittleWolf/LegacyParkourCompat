# Review renewal: revised overlap / `excludeBlock` fixture

## Binding

This is a separate renewal for candidate revision SHA-256 `ecc22b135ca1f5b640be717f185ed679ed77b30990c6d09d8b71b30777ea8ecb` at `.native-source/20261031/1132-1144-finish46/overlap-excludeblock-fixture/candidate.md`. The exact endpoint source identity remains the 1.13.2 and 1.14.4 Ornithe Feather publication and mapping identity recorded in `review.md`; the relevant `Entity.java`, `WorldView.java`, fence provider, and shape sources retain the hashes listed there.

## Renewal checks

- The explicit vector `(0.2,0,0.1)` exercises the 1.14.4 multi-axis clipping path. `m_79801352` clips Y, compares absolute X/Z magnitudes, clips X before Z for these values, and keeps Z at `0.1` after the X clip.
- The old `Entity.move` path clips Y, X, then Z. With `onGround=false` and unchanged Y input/result of zero, its step condition is false; the stated positive step height therefore does not trigger the alternate step attempt. The newer `m_72373519` likewise has `bl4=false` (`onGround` false and no downward Y collision), so its step branch does not run.
- `noClip=false` selects the collision path in both versions. `MoverType.SELF`, with the stated non-sneaking/no-sneak-edge and no web adjustment, does not alter the requested vector in the cited branches. Empty other block/entity/border candidates make the old/new fence membership the only blocker affecting the clip vector. The assumed air and queried chunks also avoid the candidate scans encountering additional collision shapes.
- Given those fixed inputs, the box's positive-Z overlap strip `[0.375,0.38]` intersects the oak fence's occupied voxels; its X maximum is `0.49`, and the next occupied X coordinate used by `VoxelShape.calculateMaxDistance` is `0.625`, yielding `0.625 - 0.49 = 0.135`. The old original-box exclusion suppresses that fence candidate; the new expanded-box query emits it. The resulting conditional clip vectors remain old `(0.2,0,0.1)` and new `(0.135,0,0.1)`.

One reproducibility detail remains implicit: 1.14.4 applies the retained `f_74350999` vector before collision resolution, regardless of `MoverType`. `Entity.onCobwebCollision` assigns that vector, and `Entity.move` consumes and clears it. The stated absence of web adjustment implies the fixture intends this to be zero, but the fixed-input setup should explicitly set/assume `f_74350999 = Vec3d.ZERO` (or state that no prior cobweb impulse is pending). `SELF` already makes the piston-type input clamp irrelevant; “no piston preprocessing” does not itself specify the retained cobweb vector.

## Renewed verdict

**Renewed as source-verified conditional fixed-input witness, subject to stating the retained cobweb vector is zero for reproducibility.** The added vector, `noClip`, on-ground, step, movement-type, and other-candidate assumptions close the earlier numeric and step-gate gaps. The review remains strictly conditional: the candidate explicitly does not show how the intersecting player box and NORTH+EAST oak-fence state arise or that any in-scope trajectory reaches them. The source witness is not an ordinary-reachability claim and does not close the discovery workflow's reachability/applicability gate for a generally applicable movement finding.
