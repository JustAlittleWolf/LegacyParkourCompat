# Independent source review: overlap / `excludeBlock` fixture

## Inputs and source identity

- Candidate reviewed: `.native-source/20261031/1132-1144-finish46/overlap-excludeblock-fixture/candidate.md`, SHA-256 `b8c5d1df3b3859f06d604451926c8756190f6d61476740168202b6877bc9f353`.
- 1.13.2 Ornithe Feather, Feather Gen2 `1.13.2+build.2` (`feather-gen2-1.13.2+build.2-mergedv2.jar` and `.tiny`); published source manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`. Provenance records an exact 1.13.2 Feather decompile; source verification reports 2,711 files, zero source differences, and zero missing files.
- 1.14.4 Ornithe Feather, Feather Gen2 `1.14.4+build.2` (`feather-gen2-1.14.4+build.2-mergedv2.jar` and `.tiny`); published source manifest SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. Provenance records an exact 1.14.4 Feather decompile; source verification reports 3,250 files, zero source differences, and zero missing files.

Relevant published source hashes (SHA-256):

| Release | Source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `net/minecraft/block/FenceBlock.java` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` |
| 1.13.2 | `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `net/minecraft/block/FenceBlock.java` | `4319ffb95ad81e969b11b39a8e6361d678b5fb5f3ad210d9834ce5e30d5f45d8` |
| 1.14.4 | `net/minecraft/block/PaneBlock.java` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |

## Findings

1. **Oak fence is a valid common provider.** 1.13.2 registers `oak_fence` as a `FenceBlock` in `Block`'s registry initialization; 1.14.4 registers it as a `FenceBlock` in `Blocks`. `FenceBlock` inherits `PaneBlock`'s collision-shape construction in both endpoints. The supplied state with NORTH and EAST true selects a shape containing the central post and both arms. For collision shape construction, the post spans X/Z `[6/16,10/16]`; the north arm spans X `[6/16,10/16]`, Z `[0,10/16]`; the east arm spans X `[6/16,1]`, Z `[6/16,10/16]`. The collision shape reaches the player’s Y range. This collision geometry is the same at both endpoints; it is a witness provider, not a changed fence shape.

2. **Old candidate membership is as described.** In 1.13.2 `Entity.move` passes the player shape and requested components to `WorldView.getCollisions`. That method forms an expanded movement shell (`shape.expanded(dx,dy,dz)` minus the slightly shifted original shape), then calls `getBlockCollisions(shape, excludeBlock, ...)` with the original box as `excludeBlock`. The latter translates each candidate block shape into local coordinates and returns empty whenever `VoxelShapes.overlap(excludeBlock, voxelShape3, AND)` is true. The stated box overlaps the fence post/arms in X, Z `[0.375,0.38]`, and Y, so this whole block candidate is suppressed.

3. **New membership and numeric clip are consistent for the stated fixed input.** 1.14.4's `Entity.m_64271959` takes the multi-axis path when X and Z are nonzero and concatenates the cached shapes with `world.getBlockCollisions(entity, box.m_78709828(vec3d))`. That `WorldView` collector emits translated block collision shapes with positive overlap against the directed expanded query box; it has no original-box suppression. For requested vector `(0.2,0,0.1)`, the query expands to positive X/Z and overlaps the same oak-fence shape. `m_79801352` clips Y first, then X before Z because `abs(0.2) < abs(0.1)` is false. During positive-X offset calculation, the box's X max is `0.49`; its Z interval overlaps the occupied fence voxels. The next occupied X coordinate is `10/16 = 0.625`, so `calculateMaxOffset` reduces X to `0.625 - 0.49 = 0.135`. Thus the old/new candidate membership difference and the reported component result hold when the remaining collision stream is equal and contains no other blocker that changes the result.

4. **Interpretation and scope.** This is a valid *conditional fixed-input source witness*: an already-intersecting player box is a legal argument/state for the collision methods, and neither source path asserts or repairs a non-overlap invariant before collecting/clipping shapes. The intersection does not by itself put the calculation outside player-movement scope. It does mean this witness is not evidence of ordinary trajectory reachability. The candidate correctly disclaims proving how the state/box pair arises or that a trajectory reaches it. The discovery procedure asks for a concrete reachable precondition, so the fixture alone cannot close that reachability/applicability gate or support an unconditional claim about normal movement. Keep the claim explicitly conditional unless a source-backed in-scope path to the intersecting box is established.

The candidate also omits the requested input vector from its setup; `(0.2,0,0.1)` is inferable from the outputs but should be stated explicitly for a reproducible fixture. The stated old/new resolver outputs concern the clip calculation under equal collision inputs. To claim the complete `Entity.move` outcome, the fixture would also need its step/on-ground and other movement gates specified; no such whole-tick claim is established here.

## Verdict

**Source mechanics: verified. Conditional fixed-input witness: verified with the explicit vector and equal-stream caveat above. Ordinary reachable player movement: not established.** The intersecting player/provider box does not invalidate the conditional collision-source claim, but the current fixture does not satisfy the discovery workflow's reachability requirement for a generally applicable movement finding.
