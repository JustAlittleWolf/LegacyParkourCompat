# Sign, banner, skull, and daylight-detector shape pairing: 1.13.2 → 1.14.4

## Scope and source identity

This source-only pass compares the published Ornithe Feather Gen2 build 2 trees at both endpoints, using the exact class sources and registry declarations. Provider inventory and endpoint manifests are verified in `../providers/inventory.md`; I recomputed hashes listed below from the canonical source trees. No Mojmap or staging mapping tree was used. Existing `climb-trigger-shapes/comparison.md` already records the wall-sign direction table and raw outputs; I independently rechecked the wall-sign class/provider and include it here to close the assigned family. Existing `fluid-face-remaining-static/result.md` checks banner face predicates and no-collision registration; this pass pairs banner geometry and registration only. No state-production history or trajectory was examined.

Compared registrations: two old generic sign IDs to their six 1.14.4 wood-specific ID families; 32 old / 240 new sign states. All 32 banner IDs are common (16 colors × standing/wall); 320 provider states total. All twelve skull/head IDs are common (six floor and six wall); 120 states total. `daylight_detector` is one common ID with 32 states. Totals are registration/property tuples, not claims about reachability.

## Dispatch and effective player-collision gate

The parent provider inventory records the endpoint dispatch: old `BlockState.getCollisionShape(world,pos)` calls the base `Block.getCollisionShape`, which checks `hasCollision` before invoking the state shape. In 1.14.4 the entity collision path supplies `CollisionContext.of(entity)` to the context overload; base collision dispatch still checks `hasCollision` before calling `getShape(..., context)`. For non-dynamic states, cache construction uses empty context. The providers below ignore world, position, and new context, so context and cache paths agree.

`Block.Properties.hasCollision` defaults true in both `Block.java` sources. Sign and banner registrations explicitly call `.noCollision()`, making their effective collision shape empty despite their nonempty outline-shape provider outputs. Skull/head registrations and daylight detector registrations do not call `.noCollision()` or enable `dynamicShape`; their default collision gate is true, so their listed shapes are effective collision outputs. Thus provider equality is movement-collision relevant for skulls and daylight detector; signs and banners are shape-provider parity only because the movement collision gate suppresses them in both releases.

## Registration and complete state domains

| Family | 1.13.2 IDs/classes | 1.14.4 IDs/classes | Complete domains at each endpoint |
|---|---|---|---|
| Standing sign | `sign` → `StandingSignBlock` | `oak_sign`, `spruce_sign`, `birch_sign`, `acacia_sign`, `jungle_sign`, `dark_oak_sign` → `StandingSignBlock` | `ROTATION=0..15` × `WATERLOGGED=false/true` = 32 per registration. Old/new `buildStateDefinition` adds the same two properties. The new six wood IDs split the old generic ID; there is no ID-preserving match. |
| Wall sign | `wall_sign` → `WallSignBlock` | six `*_wall_sign` wood IDs → `WallSignBlock` | horizontal `FACING={NORTH,EAST,SOUTH,WEST}` × `WATERLOGGED=false/true` = 8 per registration. Old/new `buildStateDefinition` adds the same properties. The new six IDs split the old generic ID; no ID-preserving match. |
| Standing banner | 16 color `*_banner` IDs → `StandingBannerBlock` | same 16 color IDs/classes | `ROTATION=0..15` = 16 per ID. |
| Wall banner | 16 color `*_wall_banner` IDs → `WallBannerBlock` | same 16 color IDs/classes | horizontal `FACING` four directions = 4 per ID. |
| Floor skull/head | `skeleton_skull`, `wither_skeleton_skull`, `zombie_head`, `player_head`, `creeper_head`, `dragon_head` → floor variants | same six IDs → floor variants | `ROTATION=0..15` = 16 per ID. Ordinary and special player/wither subclasses inherit the floor provider; the state definition adds only `ROTATION`. |
| Wall skull/head | matching six `*_wall_skull` / `*_wall_head` IDs → wall variants | same six IDs → wall variants | horizontal `FACING` four directions = 4 per ID. Player/wither subclasses inherit the wall provider; the state definition adds only `FACING`. |
| Daylight detector | `daylight_detector` → `DaylightDetectorBlock` | same ID/class | `POWER=0..15` × `INVERTED=false/true` = 32. |

Registration ranges are old `Block.java:1003,1008` (signs), `:1272–1283` (heads), `:1297` (detector), and `:1444–1540` (banners); new `Blocks.java:429–488` (wood signs), `:887–920` (heads), `:945` (detector), and `:1179–1295` (banners). In all registration families above, the constructor class and registration identifier were checked on each side. Property domains follow each class's `buildStateDefinition`, defaults, and `Properties.ROTATION`, `POWER`, `INVERTED`, and horizontal facing declarations. For signs, the six new wood registrations have the same provider class/state formula as the old generic registration.

## Paired shape outputs

All coordinates below are in sixteenths of a block; fractions are exact source literals such as 4.5/16.

| Provider | 1.13.2 → 1.14.4 paired output | State use and dependencies | Collision result |
|---|---|---|---|
| `SignBlock` / `StandingSignBlock` | Constant box `(4,0,4)–(12,16,12)` | Neither method reads rotation, waterlogged state, world, position, or (new) context. Standing state changes leave the box constant. | Empty at both endpoints because each registration uses `.noCollision()`. |
| `WallSignBlock` | `NORTH (0,4.5,14)–(16,12.5,16)`; `SOUTH (0,4.5,0)–(16,12.5,2)`; `EAST (0,4.5,0)–(2,12.5,16)`; `WEST (14,4.5,0)–(16,12.5,16)` | Only `FACING` indexes the same four-entry map. `WATERLOGGED`, world, position, and (new) context are ignored. The four outputs agree with the already inventoried climb-trigger shape table. | Empty at both endpoints due to `.noCollision()`. |
| `StandingBannerBlock` | Constant box `(4,0,4)–(12,16,12)` | `ROTATION` is ignored; no world/position/context access. | Empty at both endpoints due to `.noCollision()` for all 16 colors. |
| `WallBannerBlock` | `NORTH (0,0,14)–(16,12.5,16)`; `SOUTH (0,0,0)–(16,12.5,2)`; `WEST (14,0,0)–(16,12.5,16)`; `EAST (0,0,0)–(2,12.5,16)` | Only `FACING` indexes the same four-entry map; world/position/context are ignored. | Empty at both endpoints due to `.noCollision()` for all 16 colors. |
| `FloorSkullBlock` and subclasses | Constant box `(4,0,4)–(12,8,12)` | `ROTATION` is ignored; world/position/context are ignored. Player and wither floor variants inherit this provider in both source trees. | Effective, nonempty collision at both endpoints; skull registrations retain default `hasCollision=true`. |
| `WallSkullBlock` and subclasses | `NORTH (4,4,8)–(12,12,16)`; `SOUTH (4,4,0)–(12,12,8)`; `EAST (0,4,4)–(8,12,12)`; `WEST (8,4,4)–(16,12,12)` | Only horizontal `FACING` indexes the same map; world/position/context are ignored. Player and wither wall variants inherit this provider in both source trees. | Effective, nonempty collision at both endpoints; registrations retain default `hasCollision=true`. |
| `DaylightDetectorBlock` | Constant box `(0,0,0)–(16,6,16)` | `POWER` and `INVERTED` are ignored by `getShape`; no world/position/context access. | Effective, nonempty collision at both endpoints; registration retains default `hasCollision=true`. |

The output function agrees across all enumerated tuples: 40 sign outputs old versus 240 wood-specific sign outputs new, 320 banner outputs on each side, 120 skull outputs on each side, and 32 detector outputs on each side. No provider reads neighboring state, block entity contents, fluid state, entity identity, or any other contextual input. Placement and support methods do read neighbors, but they produce/change state and are not part of this fixed-state provider comparison. Waterlogged signs' fluid behavior is intentionally not analyzed; there is no fluid trajectory or waterlogged-sign trajectory claim.

## Movement relevance and limits

For `Entity.move` collision collection, only the effective skull/head and detector shapes contribute under the vanilla registrations. The same formulas and state dependencies mean this assigned batch yields no provider-level collision-shape delta under equal raw block IDs/state tuples and the listed vanilla collision gates. The sign ID split is a name/crosswalk change, but its empty collision gate means the provider itself does not affect movement collision. Banners also remain empty-collision blocks. This is not a claim about block-state history, player paths, non-collision interactions, every collision provider, or release boundaries between these endpoints.

## Exact source hashes (SHA-256)

Relative to each endpoint's `ornithe-feather` tree:

| File | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/SignBlock.java` | `64d61e8c4758d6f1d13d92e56a25f7599736e625fcfaa980fcb1f8bebfe5ad39` | `0094a15d80c84593ebff08e68f0f0d5b9983ead9e289940b1dbdde734929c51c` |
| `net/minecraft/block/StandingSignBlock.java` | `b05236bb5ce89e48cfaede3b20c6a71b21c8a00eae5fd975d98962455b0446a8` | `b05236bb5ce89e48cfaede3b20c6a71b21c8a00eae5fd975d98962455b0446a8` |
| `net/minecraft/block/WallSignBlock.java` | `d2040a687cb404d5c8679f79f65491ff829d3d83ef0c555155c0b41748d97b9b` | `627ac5d3b3eff0ce9bce86ea8e0df288ade8b1b95348d6a8c746b8d59359d566` |
| `net/minecraft/block/BannerBlock.java` | `21384a99f500bbedcac1e36e4639cb27bf7a7bdeb4c349661b13137facf18e07` | `dcdfec684cf0a929a1acfad2597f99f52f2cbe26415b2acd25309e215c2b127b` |
| `net/minecraft/block/StandingBannerBlock.java` | `bc8a64d47d7ed894288c7923f7e6feb1c9c1a0b58ad961c194fc04dbf7793c6d` | `b5631687ac64a18de1973d56a8f67c6446718b38674966b68f8ef74323d1ca31` |
| `net/minecraft/block/WallBannerBlock.java` | `70d1fb6b45df1bd86b6a7276cab817472c2c974cad31cb7ac041da3224f04296` | `78ab22665aaf9c4700d20b885cc2a640915bf8e59fe98ee58fba7d2d5d0b6930` |
| `net/minecraft/block/FloorSkullBlock.java` | `a23ac417451ead612e2a34185700c0631bdf75f7c6b6f7e1639b4624b8b12fc7` | `017f758d85d37d7d4bc86506e2c3e03fd7ff4f2027e9e8fa3d1b8abe8e9060a8` |
| `net/minecraft/block/WallSkullBlock.java` | `d7ab74c4f259b2a6c742580a381f1f87a49862512d9324562f4b01679ef988dd` | `e5cedfc3f01dac16915c82f88bb620da894562f9994c25a6f84aae223975f179` |
| `net/minecraft/block/DaylightDetectorBlock.java` | `9abc985cb0fd300cc26edf1a0ec0343911354e3ba4b59d0e823531274e23c49a` | `e7be527301144649bfb10929304e624d9cf9697af521a5fd8e416f15078c94a5` |
| Registry source (`Block.java` → `Blocks.java`) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

No source-tree write, build, test, game launch, or decompile was performed. No product, wiki, backlog, or shared-root Git data was read or changed. This bounded provider slice makes no independent full-pair audit or pair-freeze claim.
