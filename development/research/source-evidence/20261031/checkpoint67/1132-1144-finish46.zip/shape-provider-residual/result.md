# Remaining fence and wall registration shape pairing: 1.13.2 → 1.14.4

## Scope and result

This closes the common fence registrations beyond the already-paired `oak_fence`, plus `mossy_cobblestone_wall` beyond the already-paired `cobblestone_wall`. It pairs all outline and collision outputs for 256 additional raw registration/state tuples. These providers are movement collision inputs: registrations retain collision enabled. This report is based on exact Feather Gen2 build 2 endpoint source and the existing same-class provider formulas, not on block-state production or a player trajectory. It does not freeze the whole provider inventory.

The complete row expansion is in [`states.tsv`](states.tsv), SHA-256 `0fe3f19ad3a14b578ca7131c06fa1c70793e798ba1eddc051cd99f3ee96a3b7c`. Each row compares identical raw property values and records the exact old/new outline and collision table selectors.

## Registration and raw-state crosswalk

The exact common fence IDs in this tranche are `spruce_fence`, `birch_fence`, `jungle_fence`, `acacia_fence`, `dark_oak_fence`, and `nether_brick_fence`; each endpoint registers each as `FenceBlock`. Together with the previously closed `oak_fence`, this covers all seven common vanilla `FenceBlock` IDs. Every ID's definition adds the same `NORTH`, `EAST`, `SOUTH`, `WEST`, and `WATERLOGGED` boolean properties, for 32 raw tuples per ID. This tranche therefore closes 6 × 32 = 192 additional fence tuples.

The additional wall ID is `mossy_cobblestone_wall`; each endpoint registers it as `WallBlock` with copied cobblestone properties. Its state definition has `UP`, `NORTH`, `EAST`, `SOUTH`, `WEST`, and `WATERLOGGED`, each boolean: 64 raw tuples. Together with `cobblestone_wall`, already paired in `../wall-shape-pairing/result.md`, this closes both common 1.13.2 `WallBlock` registrations. The full raw domains are Cartesian state-definition inputs, not claims that neighbor placement/growth produces every tuple.

Fence arm bits are `N=4, E=8, S=1, W=2`, with mask the OR of present directions; `WATERLOGGED` is ignored by both geometry providers. Wall uses the same directional mask; `UP` chooses between the wall table and the inherited pane table; `WATERLOGGED` is ignored. This property-to-mask convention matches the already-paired oak-fence and cobblestone-wall report tables.

## Provider output pairing and collision route

For every fence state row, old and new `FenceBlock.getShape` select the same `FENCE_OUTLINE[mask]` output. Old and new inherited `PaneBlock.getCollisionShape` select the same `FENCE_COLLISION[mask]` output. The source constructors use the same `FenceBlock` shape arguments as `oak_fence`, whose exact output formula is already recorded in `../pane-snow-fence-shape-pairing/result.md`: a mask-selected center post plus its connected arms; outline arms stop at block height and collision arms extend to 24/16. Each added ID instantiates the same `FenceBlock` constructor at both endpoints. The provider reads only the state connection booleans; it has no world, neighbor, block-entity, or collision-context read. Identical registered material/map-color/sound data do not enter its shape result.

For every mossy-wall state row, the paired old/new `WallBlock` provider selects the same table: when `UP=true`, `WALL_OUTLINE[mask]` and `WALL_COLLISION[mask]`; otherwise inherited `PANE_OUTLINE[mask]` and `PANE_COLLISION[mask]`. The full table construction, pane fallback and explicit mask-to-box recipe are in `../wall-shape-pairing/result.md`; `mossy_cobblestone_wall` invokes the same `WallBlock` constructor as `cobblestone_wall` at both endpoints, so the paired table recipe applies to every added row. The method reads only those six state booleans and does not query world, position, block entity, or context.

These registrations all leave collision enabled. Old base collision dispatch and inherited pane/wall collision overrides therefore feed the selected boxes to movement collision queries. New entity-context collision routing or static caching cannot alter these outputs: the state-selected providers ignore context, and the added registration classes do not enable dynamic shapes. No shape difference was found among any of the 256 rows.

## Exact source identities

Source roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Endpoint publication/manifest identities and provenance are recorded in `../providers/inventory.md` (SHA-256 `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480`). All file hashes below were recomputed from the read-only endpoint trees and are included in the recorded source manifests.

| Relative source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/block/Block.java` (old registry and base dispatch) / `net/minecraft/block/Blocks.java` (new registry) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/Block.java` (new base dispatch) | — | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/FenceBlock.java` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` | `4319ffb95ad81e969b11b39a8e6361d678b5fb5f3ad210d9834ce5e30d5f45d8` |
| `net/minecraft/block/WallBlock.java` | `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf` | `033da2cef0973f5d380a81b53ee76e23324fffece72edc74e12fcee0d8764be7` |
| `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |
| `net/minecraft/block/PipeBlock.java` | `4c56867771e5848fec41d7ccbce5339af3dfefa7f98afb4712dfd0d5abd8f9a9` | `50974f5a929e70166c8edbac17dd22b295ceb50bacd345d2b89a25bb150740b6` |
| `net/minecraft/state/StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |
| `net/minecraft/state/property/BooleanProperty.java` | `7a414a5c7a8110a97b32fce9ad0bfa9df0212f286bfbe5b777962205cc9dcf11` | `7a414a5c7a8110a97b32fce9ad0bfa9df0212f286bfbe5b777962205cc9dcf11` |
| `net/minecraft/util/math/Direction.java` | `6d5c496ff65377fee9f00c826e48c7be14d3889e5ae5191e110a464007549082` | `121f8b78eda07640eccbe369f40acc7ccbdcb275dcb6aca87c4495cd193b01c0` |

## Remaining scope

Closed here: six common fence registrations (192 tuples) and the mossy wall registration (64 tuples), with collision/outline dispatch and same-state output pairing. The already-paired oak fence, cobblestone wall, and oak gate remain in their cited reports. Still open outside this tranche: other provider classes/states/context inputs listed in `../providers/shape-provider-overrides.tsv`, candidate membership/border/chunk sources, and all state/neighbor producers. This report claims no implementation applicability boundary and no endpoint pair freeze. No product/wiki/backlog, shared Git, builds, tests, game, decompile, or source-tree writes were involved.
