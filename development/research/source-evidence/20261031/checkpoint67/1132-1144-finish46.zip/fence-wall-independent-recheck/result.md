# Independent fence/wall collision-shape recheck (1.13.2 → 1.14.4)

## Finding

I independently checked the 256 rows in `../shape-provider-residual/states.tsv`: six fence IDs × 32 raw connection/waterlogged tuples, plus `mossy_cobblestone_wall` × 64 `UP`/connection/waterlogged tuples. The existing table has 256 rows and 256 unique `(id,state_tuple)` keys: 192 fence rows and 64 wall rows. Recomputing the directional mask, endpoint provider selector and paired selector from the frozen raw tuple found zero mismatches. `derived-states.tsv` expands every row into its selected outline and collision box descriptor, also with zero mismatches.

This closes this exact fixed-state collision output slice only. It does not claim every eligible provider/member is covered, prove state production or world trajectories, or establish a new movement behavior claim.

## Independent formula and dependency audit

Both endpoint `FenceBlock` classes extend `PaneBlock`, initialize identical default state properties (`NORTH`, `EAST`, `SOUTH`, `WEST`, `WATERLOGGED`), and invoke the same constructor parameters `(2,2,16,16,24)`. They create a separate occlusion shape with `(2,1,16,6,15)`, but `getOcclusionShape` is not the collision provider and must not be substituted for it. The inherited pane provider is the relevant fence geometry.

Both `PaneBlock.makeShapes` implementations construct a center box and OR direction-selected arms. `PipeBlock` maps horizontal directions to bits via `1 << direction.getIdHorizontal()`: north=4, east=8, south=1, west=2. The mask is exactly the OR of those enabled raw state properties; `WATERLOGGED` is not read by the shape-index method. Fence semantic outline routes to the pane `collisionShapes` table made with `(2,2,16,0,16)`; semantic collision routes to `shapes` made with `(2,2,24,0,24)`. Both endpoint methods select these arrays from the same mask, with no world, position, neighbor, block-entity, or `CollisionContext` read.

Both endpoint `WallBlock` classes add `UP` and use the same arrays and branches. For `UP=true`, semantic outline selects `makeShapes(4,3,16,0,14)` and semantic collision selects `makeShapes(4,3,24,0,24)`. For `UP=false`, dispatch falls through to its `PaneBlock` superclass constructed with `(0,3,0,14,24)`: outline selects inherited `makeShapes(0,3,0,0,14)` and collision selects inherited `makeShapes(0,3,24,0,24)`. These are functions only of the raw state tuple; neither override reads world, position, neighbor, block entity, or context. The `WATERLOGGED` property is absent from those calculations.

`derived-states.tsv` records, for every input row, the chosen selector and component-box descriptor as `core[minX,minY,minZ;maxX,maxY,maxZ]` plus the selected `N/E/S/W` arm boxes. Each descriptor was expanded from the exact `PaneBlock.makeShapes` coordinates and the class-specific parameters above, then checked against the independent property-bit mask and the old/new selectors in `states.tsv`. The entries are un-unioned component boxes; `+` means the exact `VoxelShapes.or` composition in the source table. Thus the file compares all 256 state-to-shape selections and all generated component coordinates without claiming a runtime execution.

`Block.getCollisionShape` routes to the state shape only when `hasCollision` is true. Both endpoint registrations use ordinary properties without `.noCollision()`; the 1.14.4 property default is `hasCollision=true`, and old/new `Block` collision dispatch agrees. The new `CollisionContext` argument is passed through the route but ignored by these providers. This supports fixed-state closure for this slice.

## Registration and tuple coverage

Old `Block.java` registers all six added fence IDs and `mossy_cobblestone_wall`; new `Blocks.java` registers the same IDs with `FenceBlock` / `WallBlock`. Fence state declarations are the four directional booleans and `WATERLOGGED`; wall has those plus `UP`. The state tuple audit found each Cartesian input exactly once per registered ID and each wall selector correctly uses `PANE_*` when `UP=false`, `WALL_*` when true. The common registrations are:

- `spruce_fence`, `birch_fence`, `jungle_fence`, `acacia_fence`, `dark_oak_fence`, and `nether_brick_fence`: 32 tuples each.
- `mossy_cobblestone_wall`: 64 tuples.

## Exact source identities

Only published `ornithe-feather` trees were read. 1.14.4 also has a Mojmap publication and a Yarn staging directory; neither was used. Each listed Java source hash matches its endpoint `ornithe-feather.sources.sha256` entry. Hashes are SHA-256.

| Endpoint source | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/FenceBlock.java` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` | `4319ffb95ad81e969b11b39a8e6361d678b5fb5f3ad210d9834ce5e30d5f45d8` |
| `net/minecraft/block/WallBlock.java` | `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf` | `033da2cef0973f5d380a81b53ee76e23324fffece72edc74e12fcee0d8764be7` |
| `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |
| `net/minecraft/block/PipeBlock.java` | `4c56867771e5848fec41d7ccbce5339af3dfefa7f98afb4712dfd0d5abd8f9a9` | `50974f5a929e70166c8edbac17dd22b295ceb50bacd345d2b89a25bb150740b6` |
| `net/minecraft/util/math/Direction.java` | `6d5c496ff65377fee9f00c826e48c7be14d3889e5ae5191e110a464007549082` | `121f8b78eda07640eccbe369f40acc7ccbdcb275dcb6aca87c4495cd193b01c0` |

Publication identities: 1.13.2 `ornithe-feather.sources.sha256` SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; provenance `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383`; ready marker `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38`. 1.14.4 `ornithe-feather.sources.sha256` SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; provenance `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9`; ready marker `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77`.

Input table SHA-256: `0fe3f19ad3a14b578ca7131c06fa1c70793e798ba1eddc051cd99f3ee96a3b7c`. Derived full-row expansion SHA-256: `1de38dbd5e9c4a271413b6c0ca49b03d4ddf9ee150229ff720cf9a5383ba45f3`.
