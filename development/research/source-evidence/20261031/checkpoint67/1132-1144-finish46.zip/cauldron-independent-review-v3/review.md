# Independent review v3: cauldron collision-volume candidate

## Verdict

**CONDITIONAL — the provider difference and clip arithmetic are correct under the named local inputs, but the fixture still needs to exclude world-border clipping.** I independently checked the exact Feather provider and movement sources. With `noClip=false`, neutral cobweb/movement multipliers, the stated standing AABB and upward vector entering collision resolution, no other clipping block or entity, and a world border that does not intersect the swept AABB, the cauldron clips old upward motion at `+0.2` and new motion at `+0.3875`.

The candidate currently excludes other clipping blocks/entities but does not say that the world-border collision shape is absent from the swept query. Both collision paths include a world-border terminal under their applicable conditions, so a close/moved border could replace the cauldron as the first clip and invalidate those exact displacement values. Add an explicit no-border-intersection premise (or say the paired query has no other collision shape, including the border); no ordinary trajectory or producer evidence is needed for this direct query claim.

## Independent source and arithmetic check

- 1.13.2 `CauldronBlock.getShape` returns the unit cube with only the inside cavity `[2,4,2]–[14,16,14]` removed. The footprint therefore has a bottom plate through Y=`4/16`.
- 1.14.4 `CauldronBlock.getShape` removes the same cavity plus the crossed rails and centered square through Y=`3/16`. The player footprint X/Z `[0.2,0.8]²` lies wholly inside the removed central square `[2/16,14/16]²`. The remaining plate begins at `3/16`.
- Given initial box top `-0.2`, an upward post-multiplier displacement of `0.5`, and no other clipping shape, old vertical max-offset is `0 - (-0.2) = 0.2`; new max-offset is `3/16 - (-0.2) = 0.3875`. Zero X/Z means the horizontal step alternatives do not alter this vertical clip.
- Old `Entity.move` applies its cobweb transform only when `inCobweb` is true; new `Entity.move` applies the pending vector multiplier only when its squared length is greater than `1.0E-7`. The candidate's explicit neutral state makes its vector entering collision resolution `(0,0.5,0)` at both endpoints. `noClip=false` selects the collision path. A standing player width is `0.6` at both endpoints.

## Recomputed input hashes

| Input | SHA-256 |
|---|---|
| Candidate `.native-source/20261031/1132-1144-finish46/candidates/cauldron-collision-volume.draft.md` | `d80e442d187dd943b28495c713b3fed419f6fecb505f71183ae95b858691489f` |
| `cauldron-storage-shapes/result.md` | `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360` |
| `cauldron-movement-relevance/result.md` | `a77f53dcbc21d9e9a4c1b3aff59394bfcff534ac219900a2e2606758f0ced591` |
| 1.13.2 `net/minecraft/block/CauldronBlock.java` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` |
| 1.14.4 `net/minecraft/block/CauldronBlock.java` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| 1.13.2 `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

The previously listed source/report inputs were used only as source-location cross references; endpoint source bodies and hashes were independently rechecked. No product implementation, wiki/backlog, product Git, build, test, game, or source generation was used.
