# Independent door and fence-gate shape recheck

## Scope and result

I independently evaluated the old and new shape selectors against every raw state tuple listed in `../wood-door-gate-shape-tranche/states.tsv`. That table was used only as the enumeration ledger; expected outputs were derived from the paired Feather source formulas. The ledger SHA-256 is `8fe0eb2067d66967a80eea940bb4613b3d94be297d81f37cbd4311b667334898`.

Coverage: 480 unique tuples across 10 registered IDs: 320 tuples for the five non-oak wooden doors (spruce, birch, jungle, acacia, dark oak) and 160 tuples for five fence gates. State-domain checks confirmed the expected declared properties and full Cartesian products: doors use HALF, FACING, OPEN, HINGE, POWERED; gates use FACING, OPEN, POWERED, IN_WALL. Result: 0 selector/output mismatches, 0 old/new hash mismatches in the ledger, and no missing registrations among these IDs.

## Source-derived behavior

- Door outline and collision selectors use FACING, OPEN, and HINGE to choose a 3/16-thick slab. HALF and POWERED do not affect the selected shape.
- Gate outline selection uses FACING and IN_WALL (the in-wall shape is shorter). Gate collision selection additionally uses OPEN: open gates have an empty collision shape; closed gates use the fixed-height slab along the FACING axis. POWERED does not affect either output.
- In both versions, the generic block collision provider checks the state's collision flag and returns that state's outline shape when collision is enabled. The relevant constructors retain collision; no per-instance no-collision override was found.
- The outline and collision getters select shapes solely from the supplied block state; they do not read world, position, neighbors, or collision context. Newer getter signatures accept a collision context but do not use it. Door/gate `updateShape` methods read neighboring/world state to produce synchronized door-half values or gate `IN_WALL`; those producer paths are outside this provider-output comparison.

The selectors and box constants match across the two endpoints for these members. This result establishes provider output for the enumerated valid states only; it does not establish state reachability, world/neighbor producer equivalence, fluid behavior, trajectories, or pair-wide source freeze.

## Endpoint manifest and primary source hashes

Manifest SHA-256: 1.13.2 Feather `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 Feather `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `DoorBlock.java` | `e01782f96a2214be2bc48dffad8b062db9eda12c04aa4d7747f01575d0df019b` | `5c40e94e04427c8a16a301aad12f7d2efdef866f70b21acd830fc683099dcbcd` |
| `FenceGateBlock.java` | `e251cbd1b5e06c42e856a1d537e4ba043f6760b8f54ea1388039428aa7c05164` | `c6c869ac12993e09f4684798e843778b2b63b7d9766f9cac0894dae0f312a151` |
| `Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |
| `Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |

## Reproduction notes

The comparison covered each row's old and new door outline/collision descriptors and gate outline/collision descriptors, applying the source selectors and fixed box constants. Domain and registration checks were performed separately from the output comparison. No game launch, runtime trajectory, build, test, or decompilation was used.
