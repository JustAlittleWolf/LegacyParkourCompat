# Climb and trigger block shape comparison: 1.13.2 → 1.14.4

## Result and scope

Compared the exact Ornithe Feather Gen2 build 2 decompilations identified in the frozen provider inventory: 1.13.2 and 1.14.4. This bounded pass covers `LadderBlock`, `VineBlock`, `TripwireBlock`, `TripwireHookBlock`, `WallSignBlock`, `WallTorchBlock`, `RedstoneWallTorchBlock`, and `EndRodBlock`, their state-property definitions/defaults, registrations, each direct `getShape` formula, and the collision-shape dispatch/cache gate. It does not infer how block states are produced or establish an ordinary player trajectory.

**No shape-output difference was found for any common registered block ID or any paired raw property state.** The 1.14.4 contextual `getShape(..., CollisionContext)` overloads do not inspect the context for these providers. The same box coordinates, selection by state, and (for Vine) ordered OR operations appear in both endpoints. The exhaustive 250-row table is `raw-state-shape-outputs.tsv`; all rows have equal old/new shape descriptors and a SHA-256 digest of that canonical descriptor. Full source-file hashes are in `source-hashes.tsv`.

## State and registration coverage

The raw table enumerates the full Cartesian state domain declared by each class, without claiming that each assignment is normally placeable or naturally produced:

| Provider | 1.13.2 ID → 1.14.4 ID(s) | Raw states enumerated | Shape selector |
|---|---|---:|---|
| LadderBlock | `ladder` → `ladder` | 8 | FACING; WATERLOGGED ignored |
| VineBlock | `vine` → `vine` | 32 | UP/NORTH/EAST/SOUTH/WEST; union accumulated in that order |
| TripwireBlock | `tripwire` → `tripwire` | 128 | ATTACHED; all six other booleans ignored |
| TripwireHookBlock | `tripwire_hook` → `tripwire_hook` | 16 | FACING; POWERED and ATTACHED ignored |
| WallSignBlock | `wall_sign` → no common ID; class is registered as `oak_wall_sign`, `spruce_wall_sign`, `birch_wall_sign`, `acacia_wall_sign`, `jungle_wall_sign`, `dark_oak_wall_sign` | 8 each × six IDs | FACING; WATERLOGGED ignored |
| WallTorchBlock | `wall_torch` → `wall_torch` | 4 | FACING |
| RedstoneWallTorchBlock | `redstone_wall_torch` → `redstone_wall_torch` | 8 | FACING; LIT ignored |
| EndRodBlock | `end_rod` → `end_rod` | 6 | FACING axis |

The common IDs for seven of the eight families are explicit in the paired `Block.java` registrations on the older side (1.13.2 `Block.java`, including the relevant lines 987, 1005, 1062–1065, 1203, 1231–1233, 1584) and `Blocks.java` on the newer side (1.14.4 lines 397–400, 450, 457–489, 549–553, 728–730, 782–785, 1407–1409). The changed sign IDs are a registration rename/split; no same-ID WallSignBlock comparison exists. The 1.13.2 single `wall_sign` state's eight outputs were compared against each 1.14.4 WallSignBlock property's same eight outputs as a class-level crosswalk only, not treated as common IDs.

## Direct provider formulas

`LadderBlock.getShape` switches on the four horizontal `FACING` values. NORTH returns box `(0,0,13)-(16,16,16)`; SOUTH `(0,0,0)-(16,16,3)`; WEST `(13,0,0)-(16,16,16)`; EAST `(0,0,0)-(3,16,16)`. `WATERLOGGED` does not affect the result.

`VineBlock.getShape` starts empty, then ORs `CEILING_SHAPE`, `NORTH_SHAPE`, `EAST_SHAPE`, `SOUTH_SHAPE`, `WEST_SHAPE` when the corresponding UP/NORTH/EAST/SOUTH/WEST booleans are true. The component boxes are respectively `(0,15,0)-(16,16,16)`, `(0,0,0)-(16,16,1)`, `(15,0,0)-(16,16,16)`, `(0,0,15)-(16,16,16)`, `(0,0,0)-(1,16,16)`. The table records all 32 ordered component recipes including the empty state.

`TripwireBlock.getShape` returns `ATTACHED_SHAPE` `(0,1,0)-(16,2.5,16)` iff ATTACHED, otherwise `FREE_SHAPE` `(0,0,0)-(16,8,16)`. POWERED, DISARMED, NORTH, EAST, WEST and SOUTH do not affect shape.

`TripwireHookBlock.getShape` selects NORTH `(5,0,10)-(11,10,16)`, SOUTH `(5,0,0)-(11,10,6)`, WEST `(10,0,5)-(16,10,11)`, EAST `(0,0,5)-(6,10,11)`. POWERED and ATTACHED do not affect shape.

`WallSignBlock.getShape` returns the facing-map box: NORTH `(0,4.5,14)-(16,12.5,16)`, SOUTH `(0,4.5,0)-(16,12.5,2)`, EAST `(0,4.5,0)-(2,12.5,16)`, WEST `(14,4.5,0)-(16,12.5,16)`. WATERLOGGED does not affect shape.

`WallTorchBlock.getShape` returns the facing-map box: NORTH `(5.5,3,11)-(10.5,13,16)`, SOUTH `(5.5,3,0)-(10.5,13,5)`, WEST `(11,3,5.5)-(16,13,10.5)`, EAST `(0,3,5.5)-(5,13,10.5)`. `RedstoneWallTorchBlock.getShape` forwards to the exact same shape selector; LIT does not affect shape.

`EndRodBlock.getShape` selects by FACING axis: X `(0,6,6)-(16,10,10)`, Z `(6,6,0)-(10,10,16)`, Y `(6,0,6)-(10,16,10)`.

The source line locations for these formulas/state domains are 1.13.2 / 1.14.4 respectively: LadderBlock `23–46 / 23–46`; VineBlock `29–48, 51–74, 345–347 / 23–42, 45–68, 304–306`; TripwireBlock `31–54, 201–203 / 32–55, 197–199`; TripwireHookBlock `28–51, 250–252 / 29–52, 242–244`; WallSignBlock `22–48, 95–97 / 22–49, 96–98`; WallTorchBlock `23–49, 109–111 / 23–54, 114–116`; RedstoneWallTorchBlock `22–44, 89–91 / 20–37, 90–92`; EndRodBlock `17–47, 89–91 / 18–48, 85–87`.

## Collision and dispatch qualification

The 1.13.2 `BlockState` shape accessor dispatches to `Block.getShape(state,world,pos)`; the base collision provider returns empty when `hasCollision` is false and otherwise returns the state's shape. In 1.14.4 `BlockState.getShape(world,pos,context)` dispatches to `Block.getShape(state,world,pos,context)`; `getCollisionShape` uses the cached value when present or dispatches with the supplied context. `BlockState` creates a static `Cache` when `!block.hasDynamicShape()` (line 66); cache construction calls `block.getCollisionShape(..., CollisionContext.empty())` (line 410). Base `Block.getCollisionShape` still gates on `hasCollision` and reads the no-context `state.getSHape(world,pos)` (lines 376–377). Every targeted provider ignores the new context, and none overrides the default dynamic-shape flag, so the cache's empty context cannot change these outputs.

Registration properties distinguish raw visual/outline shapes from player collision shapes. Ladder and EndRod registrations retain collision (`noCollision()` is absent). Vine, Tripwire, TripwireHook, WallSign, WallTorch and RedstoneWallTorch registrations use `noCollision()` at both endpoints. Their shape-provider outputs are not player collision shapes under the base gate and are marked `player_collision_gate=false` in the TSV. This does not claim those blocks have no other movement-facing callback or predicate; it only classifies this collision-shape route. Tripwire's `onEntityCollision` remains a separate callback surface and was not audited as a state-producer or movement delta here.

## Exact source identities

The paired inventory identifies Feather Gen2 build 2 source publications. Its endpoint ready-marker source-manifest SHA-256 values are 2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211 (1.13.2) and 717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc (1.14.4). Provider Java file hashes were recomputed and recorded in `source-hashes.tsv`.

## Boundaries

- Closed for this assignment: direct raw shape outputs and state-property dependencies for these eight class families; same-ID inventory and sign ID crosswalk; registration collision flag; shape context/cache dispatch.
- Not established: valid placement/update state histories, tripwire collision callback effects, ladder/vine ordinary tick reachability, other provider families, intermediate release cutovers, or end-to-end player trajectory.
- No movement finding is supported by these shape outputs: all common-ID raw shape results match, and sign IDs do not overlap. The broader pair is not frozen by this slice.

