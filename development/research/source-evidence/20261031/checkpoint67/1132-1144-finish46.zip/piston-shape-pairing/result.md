# Piston base, head, and moving-block collision shapes: 1.13.2 → 1.14.4

## Source identity and scope

Exact endpoint pair: Minecraft 1.13.2 and 1.14.4, both Ornithe Feather Gen2 build 2, read from `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. The permitted prior inventory identifies source-manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4); its endpoint provenance, ready-marker, mapping, and source-publication identities are retained in `../providers/inventory.md`. This bounded pairing covers static PistonBaseBlock and PistonHeadBlock collision shapes, the MovingBlock dispatch, MovingBlockEntity's dynamic collision shape, vanilla registrations, state-to-provider dispatch, and the involved shape construction/translation. It does not audit piston movement responses, world collision aggregation, arbitrary moved-block providers as a complete family, piston state producers, or server behavior.

## Static same-state outputs

**Piston bases.** `PistonBaseBlock.getShape` is at `net/minecraft/block/PistonBaseBlock.java:51–71` (1.13.2) and `:52–72` (1.14.4). Both return the full unit cube for `EXTENDED=false`. For `EXTENDED=true`, both select the same direction-specific shape: east `[0,0,0]–[12,16,16]`, west `[4,0,0]–[16,16,16]`, south `[0,0,0]–[16,16,12]`, north `[0,0,4]–[16,16,16]`, up `[0,0,0]–[16,12,16]`, down `[0,4,0]–[16,16,16]` in the 16-unit block coordinate system. All six constant declarations have identical coordinates in both files (`:31–36`). `sticky` and all other properties do not enter this provider. Thus all 12 same-class `(EXTENDED, FACING)` combinations have equal shape output for normal and sticky registered blocks.

**Piston heads.** `PistonHeadBlock.getShape` is at `net/minecraft/block/PistonHeadBlock.java:67–69` (1.13.2) and `:72–74` (1.14.4); the 1.14.4 signature adds `CollisionContext`, which the body ignores. Both union the same facing-specific head slab with the same facing/SHORT-specific arm box. The six head boxes and twelve long/short arm boxes are numerically identical (`:24–41` in both endpoints); `getHeadShape` has the same direction switch (`:48–64`); `getArmShape` has the same direction and `SHORT` switch (`1.13.2 :71–88`, `1.14.4 :76–93`). `TYPE` (normal/sticky) is unused by the shape calculation. All 24 same-state `(FACING, SHORT, TYPE)` combinations therefore return equal shape geometry.

Piston base/head collision dispatch is inherited from `Block.getCollisionShape`: the common collision-enabled gate leads to the block state's shape. The 1.14.4 state API adds context overloads; the base/head providers ignore context, and the no-context state wrapper uses the empty context for static cached collision shape. Therefore the added context/cache dispatch does not alter these static same-state collision outputs. The 1.14.4 collision-context path likewise reaches the same context-ignoring provider.

## Dynamic MovingBlockEntity output

`MovingBlock.getCollisionShape` is `net/minecraft/block/MovingBlock.java:108–111` in 1.13.2 and `:104–107` in 1.14.4. Both retrieve a `MovingBlockEntity` at the queried position and delegate to `getCollisionShape(world,pos)`, otherwise return the empty shape. The new overload accepts a collision context but does not read it. The registered `moving_piston` block is marked `dynamicShape()` on both sides, so the 1.14.4 contextless cached-static shortcut does not replace this per-query entity dispatch.

`MovingBlockEntity.getCollisionShape` is `net/minecraft/block/entity/MovingBlockEntity.java:324–352` (1.13.2) and `:332–360` (1.14.4). The bodies are identical after the 8-line offset. For matched values of `movedState`, `facing`, raw float `progress`, `extending`, `source`, world/position and thread-local `NOCLIP_DIR`, both perform the same operations in the same order:

1. Seed the first shape from `movedState` forced to `PistonBaseBlock.EXTENDED=true` only when `!extending && source`; otherwise use empty.
2. Read `NOCLIP_DIR`; when `progress < 1.0F` and it equals `getMoveDirection()` (facing when extending, opposite-facing otherwise), return that first shape immediately.
3. Otherwise use a synthetic `PISTON_HEAD` state with the same facing and the same computed `SHORT` value when `source`; otherwise use `movedState`.
4. Compute `facingOffset * getAmountExtended(progress)` on each axis, where amount is `progress - 1.0F` if extending and `1.0F - progress` otherwise; translate the selected collision shape by those offsets and OR it with the first shape.

The short expression, operation order, primitive types and constants are identical: `.set(PistonHeadBlock.SHORT, this.extending != 1.0F - this.progress < 4.0F)`, followed by `float f = this.getAmountExtended(this.progress)` and three `double` offset products. `getMoveDirection` (`MovingBlockEntity.java:155–157` old, `:163–165` new) and `getAmountExtended` (`:87–89` old, `:95–97` new) also have equal bodies. There is no piston-body change that introduces a different progress threshold or progress interval. At a fixed raw input tuple, the early-return branch and translated-union branch are selected identically, including at the exact comparisons `progress < 1.0F` and `1.0F - progress < 4.0F`.

This is a conditional compositional equality: for arbitrary moved states, equality of the resulting dynamic shape additionally requires their nested collision-shape provider outputs to match in the two endpoints. The dynamic wrapper itself has no difference. The static piston base/head families just paired above satisfy that nested condition. This report does not claim all movable blocks' nested providers were independently paired.

## Registrations and state/provider construction

Both endpoints register `piston` and `sticky_piston` as `PistonBaseBlock(false/true, ...)`, `piston_head` as `PistonHeadBlock(...)`, and `moving_piston` as `MovingBlock(...dynamicShape()...)`. Registration rows are `net/minecraft/block/Block.java:919,933–934,951` old and `net/minecraft/block/Blocks.java:266,283–284,333–335` new; old `Blocks.java` exposes the aliases and points to the corresponding `Block` static registrations. The registrations use the same shape class and piston material/strength values. `PistonBaseBlock` state properties are `FACING, EXTENDED`; `PistonHeadBlock` properties are `FACING, TYPE, SHORT` and have the same defaults in both versions. The MovingBlock state (`FACING, TYPE`) does not participate in the dynamic collision body; the entity fields do.

`Block.block(min...,max...)` divides each coordinate by `16.0` in both endpoints (`Block.java:171` old, `:167` new). `VoxelShape.move(dx,dy,dz)` has the same empty-shape branch and builds the same `ArrayVoxelShape` with per-axis `OffsetDoubleList` (`VoxelShape.java:60–68` both). `VoxelShapes.or(a,b)` delegates to `join(a,b,BooleanOp.OR)` in each (`VoxelShapes.java:91–93` old, `:111–113` new). These constructors/translations preserve the paired same-state geometric result.

## Hashes of complete examined Java files

SHA-256; paths are relative to each endpoint's `ornithe-feather` source root:

| File | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/PistonBaseBlock.java` | `1722edaf96c15af587b4e169b62c5af1d352800e82a2070e1f4af86bdde4cb31` | `37409c9f2390642103155dcec3e922e0d387e9d0bbca069fb334277d5d84a058` |
| `net/minecraft/block/PistonHeadBlock.java` | `d0de8ab39c2d350054d7ee9ed66f0e1695f2b7d1d78324b9eabd955361b58e5f` | `348885e6949b4aa754496af1e641ba07de9dcc1402ce0b88b4cde8f57febfd5b` |
| `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |
| `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
`r`n
## Result and limits

Paired static piston base/head collision geometry is identical for all same vanilla state properties. `MovingBlock` dispatch and the complete `MovingBlockEntity` dynamic formula are identical under the same raw inputs; no progress-specific output difference is found in this wrapper. Dynamic equality for every piston-movable block remains conditional on the nested moved state's own provider output, which was not exhaustively inventoried here. Direct player piston pushes are already covered by the allowed prior contact report and were not reexamined. No product, wiki, backlog, Git, server producer, source output, build, test, or game launch was consulted or changed.



