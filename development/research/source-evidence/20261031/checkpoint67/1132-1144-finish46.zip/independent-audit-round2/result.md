# Independent source-pair coverage audit — round 2

## Verdict

**NOT FROZEN.** The independent source-derived roster is frozen, but the pair still has unresolved terminal dependencies in collision candidate routing, border handling, and local-player response consumers. This verdict is about endpoint source coverage only; no implementation acceptance or runtime-parity claim is made.

## Frozen roster and exact source identity

Roster: `roster.md`, SHA-256 `766e599b2fde62a6945afb2649af40ad6fc059ef8b3882408548e837e9a9ea0`.

Primary read-only source roots: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.13.2\ornithe-feather` and `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.14.4\ornithe-feather`; exact releases 1.13.2 and 1.14.4, Ornithe Feather Gen2 build 2 on both sides.

| Release | ready marker SHA-256 | provenance SHA-256 | source manifest SHA-256 | pinned mapping input |
|---|---|---|---|---|
| 1.13.2 | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `feather-gen2-1.13.2+build.2-mergedv2.jar` and `.tiny` |
| 1.14.4 | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | `feather-gen2-1.14.4+build.2-mergedv2.jar` and `.tiny` |

I independently recomputed each ready/provenance/manifest hash above. Each ready marker's version, namespace, and source-manifest digest agrees with its source directory. I also recomputed and matched the source-manifest rows for both versions' `Entity.java`, `WorldView.java`, `EntityView.java`, `LivingEntity.java`, `PlayerEntity.java`, `LocalClientPlayerEntity.java`, `BlockState.java`, `Block.java`, and `MovingBlockEntity.java`. These exact files were read directly for this audit; no generated source was written.

## Coverage disposition

The frozen roster traces the local client tick through `PlayerEntity.tick`, `LivingEntity.tick/mobTick/moveRelative`, `Entity.move`, world collision/block-state dispatch, pose/state writers, callbacks, and movement-facing consumers. The current source-only tranches provide useful coverage for ordinary tick staging, travel branches, pose updates, provider registrations, chunk state, external responses, and step/entity terminals. I crosschecked their stated member scopes against the exact Feather endpoint methods and manifests above.

Several findings are already source-closed as individual conditional witnesses: the resolver's diagonal-axis output and small-vector position-writer cutoff; the downward step-component terminal; the step-only Boat/entity candidate witness; common ladder jump correction; paired old-era provider-state families including the 23-ID/551-state residual census; and the copied sleeping-position respawn response plus its first-tick input consumer. Those bounded witnesses do not establish whole-pair coverage. Missing server, device, block/fluid producer history or runtime trajectories do not block this source audit under the assigned equal-input rule.

The following exact slices still lack paired evidence sufficient to close all eligible terminals and dependencies:

1. **Block candidate/query boundary and step reuse.** Old `Entity.move` (`Entity.java:578–680`) calls the signed-epsilon `WorldView.getCollisions` route (`WorldView.java:112–177`), which subtracts the original `excludeBlock`, can substitute border cubes, and reuses one candidate list across each old step attempt. New `Entity.move`/`m_72373519` (`Entity.java:456–468, 656–685`) builds an accumulated candidate list and asks `m_64271959`/`m_79801352` or `m_73670363` to resolve per-vector block queries (`WorldView.java:133–178`; contextual `VoxelShapes.m_10425781`). The concrete old `excludeBlock` overlap case, exact-integer expanded bounds, shell-cell category filters (`hasLargeCollisionShape`/moving-block exception), representation/order of unit cubes versus individual shapes, and remaining multi-shape axis/step interactions have no exhaustive matched candidate-to-clip terminal table. Step-alternative tie choice and query rebuilding are individually identified; oak bottom-slab rebuilding is a no-effect fixture and the Boat step-only witness closes only its stated setup.
2. **Border history and edge candidate.** Old `Entity.outsideWorldBorder` plus `WorldView.collidesWithBorder/getCollisions` (`WorldView.java:170–199`) is hysteresis-sensitive and can synthesize outside-border block cubes. New `Entity.m_72373519` seeds a border shape from `WorldBorder` against contracted/expanded mover shapes (`WorldView.java:150–156`; `Entity.java:659–665`) and has no corresponding entity history bit. The exact transition/edge cases have not been paired through resolved vector, collision flags, and downstream movement consumer. Deep-interior exclusion fixtures do not close this boundary.
3. **Entity-query epsilon terminals and pose-fit response.** Old/new `EntityView.getEntityCollisions` use different broad-phase/final expansions and the new `1.0E-7` average-side cutoff (`EntityView.java:21–35` versus `:53–67`). The accepted Boat/Shulker producer inventory and the bounded no-step epsilon no-effect fixture do not cover near-face candidates that actually clip, degenerate inputs, or the entity stream carried through each step vector. Separately, old `PlayerEntity.updatePlayerPose` checks `hasNoCollisions(null, box)` while new `Entity.m_87715359(Pose)` checks with `this`, admitting entity candidates before the next movement tick. That pose-fit writer's entity-only intersection outcome and following box/eye-height consumers remain conditional and unclosed.
4. **Remaining dynamic nested terminal.** `MovingBlockEntity.getCollisionShape(BlockView,BlockPos)` calls the nested `movedState.getCollisionShape(world,pos)` through `MovingBlock.getCollisionShape`. The wrapper/formula and finite registered common provider families are paired, and shared collision-context reads reduce to the reported new-only scaffolding provider. However, the exact raw `movedState == Blocks.MOVING_BLOCK` with nonmatching `NOCLIP_DIR` recursively re-enters itself at the same position with no state mutation; the terminal-closure report leaves this raw input unresolved. No finite nested shape output is established for that input, so the provider dependency is not closed for the full candidate domain. This is not claimed as an endpoint delta.
5. **Local response callbacks and their next-tick consumers.** `LocalClientPlayerEntity.pushAwayFrom`/`wouldCollideAt` differs: old tests one sampled block with a swimming-dependent `shouldSuffocate`/`doesNotSuffocate` decision (`LocalClientPlayerEntity.java:401–455`); new scans the player-box vertical block range with `shouldSuffocate` (`:389–447`). Both can directly write a horizontal `±0.1` velocity which the subsequent travel reads; the changed block predicate/sample domain has not been closed for a valid shared local-player snapshot. `LocalClientPlayerEntity.autoJump` retains its scalar gates/scheduling write, but shape queries use different context and candidate routes and have no exhaustive callback-output pairing. The collision result in `PlayerEntity.updatePlayerPose` above also writes the pose/dimensions and affects the next tick's collision and eye-height queries.
6. **Climbing predicate coordinate dependency.** `LivingEntity.isClimbing` samples `floor(getShape().minY)` on 1.13.2 but constructs a position from `(x,y,z)` on 1.14.4. The ladder/wall jump correction gate has an individual witness, but the equality of these sample coordinates across all local-player dimension/position writers has not been closed as a paired invariant.

### Chunk boundary correction

I did not retain unloaded/empty chunks or out-of-build-height AIR/VOID_AIR as an independent open residual. `block-chunk-collision-closure/result.md` closes those no-border block-candidate cases: old missing-client fallback yields VOID_AIR and new nonloading null/loaded out-of-range state yields no collision, with empty AIR/VOID_AIR shapes. The border substitution route remains open as listed above. Exact-integer query shell/boundary filtering remains open independently of the missing-chunk case.

## Source-only materials consulted after roster freeze

Allowed author source reports/inventories consulted included:

- `.native-source/20261030/1132-1144-pool31/ordinary-tick/` and `pose-query-closure/` reports;
- `.native-source/20261030/1132-1144-remaining34/ordinary-gates/`, `collision-query/`, `fluid-contact/`, `fluid-geometry-witness/`, `fluid-water-tag/`, and `camera-rounding/` reports;
- `.native-source/20261031/1132-1144-finish46/ordinary-tick-staging-full-pair/`, `ordinary-gates/`, `travel-terminal-pairing/`, `step-resolution-pairing/`, `collision-candidate-route-pairing/`, `collision-border-entity-closure/`, `collision-query`/chunk closure, `entity-collision-epsilon-movement-terminal/`, `step-candidate-rebuild-terminal/`, `step-only-entity-candidate-terminal/`, `resolver-query-branch-closure/`, and `resolver-context-terminals-followup/`;
- finish46 provider inventory/census and paired outputs, including `base-shape-registration-census/`, `providers/`, `provider-state-pairing/`, `residual-23-provider-state-closure/`, `dynamic-provider-movement-gap/`, `moving-piston-nested-shape-closure/`, and `moving-piston-nested-terminal-closure/`;
- finish46 callback/response reports `callback-lifecycle-residual/`, `callback-consumer-closure-followup/`, `client-response-pairing/`, `client-response-modifier-residual/`, `external-responses/`, `tracked-state-pairing/`, `synced-pose-response-pairing/`, `local-player-pose-lifecycle-closure/`, `prev-position-consumer-pairing/`, `sleep-position-boundary/`, and `respawn-first-tick-followup/`.

I did not inspect product code, wiki/backlog materials, product Git, prior `independent-audit*` reports, or modify canonical source. No build, test, launch, decompilation, network request, or trajectory check was run. Writes are limited to this audit directory.

## Exact source members to close before pair freeze

- Resolver/query: 1.13.2 `Entity.move`, `WorldView.getCollisions` and `getBlockCollisions`; 1.14.4 `Entity.move`, `m_72373519`, `m_64271959`, `m_79801352`, `m_73670363`, `WorldView.getBlockCollisions`, `VoxelShapes.m_10425781`.
- Border/entity: 1.13.2 `Entity.outsideWorldBorder` accessors and `WorldView.collidesWithBorder/getCollisions`; 1.14.4 `Entity.m_72373519`, `WorldView.getBlockCollisions`, `WorldBorder` shape query, `EntityView.getEntityCollisions`.
- Shape dynamic terminal: both `MovingBlock.getCollisionShape`, `MovingBlockEntity.getCollisionShape`, `BlockState.getCollisionShape`; resolve recursive self-nesting as an equal/nonapplicable terminal under the permitted raw-state scope.
- Local callback and writer: both `LocalClientPlayerEntity.pushAwayFrom`, `wouldCollideAt`, `autoJump`; both `PlayerEntity.updatePlayerPose`; paired `WorldView.hasNoCollisions`/entity collision stream and the next `LivingEntity` travel/pose/submersion consumers.
- Coordinate invariant: both `LivingEntity.isClimbing`, plus `Entity.setPosition`, size/dimension/pose writers and `PlayerEntity.updatePlayerPose`/response paths that maintain or break `y == shape.minY`.

Pair freeze remains **not granted** until these exact terminals and dependencies are closed or explicitly dispositioned within the assigned scope.
