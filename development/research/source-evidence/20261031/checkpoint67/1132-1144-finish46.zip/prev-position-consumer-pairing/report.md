# Previous-position consumer pairing: 1.13.2 → 1.14.4

## Scope and result

I followed every exact-source Java occurrence of `prevX`, `prevY`, and `prevZ` at both endpoints, starting from the correction-handler assignments. Under equal finite correction targets and equal later movement inputs, the 1.14.4 writes to these fields do not feed local-player movement physics, collision, pose, velocity, or another position update. Before the next local-player physics tick at each endpoint, the world ticker snapshots the current position into all three previous-position fields. The only non-rendering read in the 1.13.2 tree is the world ticker's non-finite-position fallback; its snapshot assignment precedes that fallback, so the correction-handler difference cannot change that fallback's value on a later tick under the stated assumptions.

The other reads are interpolation/presentation consumers (entity renderers, camera/world/debug rendering, and the pickup particle) or a server-only berry-bush contact calculation in 1.14.4. No trajectory claim is made. This result is limited to these fields and the correction-to-next-tick path; it does not close other packet-response state or pair coverage.

## Correction and tick ordering

- 1.13.2 `ClientPlayNetworkHandler.handlePlayerMove(PlayerMoveS2CPacket)`, lines 621–670, resolves relative axes and calls the local player's `updatePositionAndAngles`, but does not write `prevX/Y/Z`. File SHA-256: `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11`.
- 1.14.4 `ClientPlayNetworkHandler.handlePlayerMove(PlayerMoveS2CPacket)`, lines 652–712, resolves relative axes and additionally adjusts or assigns each corresponding `prevX/Y/Z` from the same resolved correction target before applying the resolved position. File SHA-256: `6c840580285c7c7d4617e895edac82d4eeBF8289dd4994e7b593cebeb49b43ef`.
- 1.13.2 `World.tickEntities` calls `tickEntity` for world entities (lines 958 onward; player entities pass the loaded-area gate), and `World.tickEntity(Entity, boolean)` first copies `x/y/z` into `prevX/Y/Z` at lines 1135–1154, then invokes `entity.tick()`. Its NaN/infinity recovery at lines 1166–1175 copies the corresponding `prev` value back to `x/y/z`. `World.java` SHA-256: `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a`.
- 1.14.4 `ClientWorld.tickEntities` calls `m_07416577(Entity)` for regular entities; that method copies `x/y/z` to `prevX/Y/Z` at lines 150–154 before invoking `entity.tick()` at lines 155 onward. The local player is registered in `entitiesById`, and the player branch is included by this method. `ClientWorld.java` SHA-256: `c4674cc7c6b322bef6a5a951aa73be2b405de4bc64804fb9b6bb96c1832b1768`.

Thus, after correction and before the next entity physics call, the differing historical interpolation baseline can affect presentation. At the start of that call both tickers replace the baseline with the same current position, before movement physics. The 1.13.2 invalid-coordinate fallback remains a consumer of `prevX/Y/Z`, but not of the stale value from before a finite correction: the pre-physics snapshot overwrites it first. The same ordering also applies if later movement creates a non-finite current coordinate during that tick. This argument assumes paired ordinary finite inputs/targets; malformed values and asynchronous timing outside the serialized client tick boundary were not independently tested.

## Full occurrence inventory and exclusions

The recursive exact-tree search was limited to Java files under the two assigned Ornithe Feather roots. It found no player-physics/collision/pose/velocity reader of these fields beyond the 1.13.2 world fallback described above.

- **1.13.2 non-rendering reader:** `net/minecraft/world/World.java`, `tickEntity(Entity, boolean)`, lines 1149 and 1166–1175. As above, the read is guarded by current-position NaN/infinity and restores coordinates; previous values are refreshed before `entity.tick()`.
- **1.14.4 server-only reader:** `net/minecraft/block/BerryBushBlock.java`, `onEntityCollision`, lines 62–64, is guarded by `!world.isClient`; it measures entity horizontal displacement for server-side berry-bush damage behavior. It is not a local-client movement consumer.
- **Particle interpolation:** both endpoint `net/minecraft/client/entity/particle/EntityPickupParticle.java`, method `buildGeometry`, interpolate the collector's old/current coordinates for particle placement. 1.13.2 hash `241b77538a144c3d1cb88c6a7e9b72905dc738f4f9a46ebc935b4e954de54cd1`; 1.14.4 hash `10b163c8d17344058f9ad8a0913c5369b15a9e9df259e4663dd153fa72558ac7`.
- **Presentation interpolation:** remaining exact-tree reads are in client rendering/camera/debug presentation code, including `client/render/{GameRenderer,FogRenderer,WorldRenderer}`, `client/render/debug/*Renderer`, `client/render/entity/{DefaultRenderer,EntityRenderer,EntityRenderDispatcher,GuardianRenderer,MinecartRenderer}`, `client/render/block/entity/BlockEntityRenderDispatcher`, and 1.13.2 `client/ParticleManager`. Their reads interpolate coordinates or derive render-relative positions; no values are written back to the local player's physical position, box, velocity, or pose by these reads.

The `Entity.java` field declarations and other `prevX/Y/Z` occurrences in movement-related entity sources are assignments/snapshots, not reads. Both endpoint entity field declarations and `setPositionAndAngles` initialize/copy the fields; 1.13.2 `World.tickEntity` and 1.14.4 `ClientWorld.m_07416577` provide the per-tick copy described above. 1.13.2 `Entity.java` SHA-256: `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`; 1.14.4 `Entity.java` SHA-256: `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55`.

## Evidence identity and uncertainty

The endpoint source roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Hashes for handler and ClientWorld files match the exact-source identity in the permitted client-response pairing report. The searches covered all `.java` files under both roots; no source was generated or modified.

Residual uncertainty: this is static source tracing, not a runtime observation. It establishes the next normal world entity-tick ordering and classifies every direct field occurrence, but does not establish client packet-thread scheduling beyond the ordinary serialized tick assumption, test malformed correction values, or make claims about changes to other synchronized movement state.
