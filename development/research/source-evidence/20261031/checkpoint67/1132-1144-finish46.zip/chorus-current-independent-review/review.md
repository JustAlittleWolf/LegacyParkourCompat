# Independent blind review: chorus-flower falling-water current

## Verdict

**Reject the reviewed draft revision as written.** The principal same-state flow/current/velocity witness is supported, but one caller-gate explanation is false and must be corrected before accepting the claim. Reviewed claim revision SHA-256: `ccac5ed60c102ab11d6a69fa156aa04fa0e43ea533bb38e8819449f6848ff15d`.

## Required claim correction

The draft says the chorus flower “blocks movement so its lower check is skipped” during the first `getFlow` gradient pass. In both endpoints the flower is registered with `Material.PLANT`, and `PLANT` is configured with `.notBlocksMotion()`. Therefore `blocksMovement()` is false and the gradient pass **does query** the fluid state one block below the flower. The fixture already specifies that below-cell as empty fluid, so the gradient remains zero; the result survives, but the stated gate/order explanation does not. Revise to say that the lower query runs and returns empty fluid, leaving that neighbor's gradient at zero.

## Independent source reasoning

- Both `FlowingFluid.getFlow` bodies first scan `Direction.Plane.HORIZONTAL`, accept empty fluid via `canFlowInto`, and only compute a nonzero gradient from nonzero sampled height. For an empty-fluid neighbor, the material gate decides whether to query below. With the stated lower cells empty, every gradient remains zero, including the chorus-flower east neighbor after correcting the gate explanation.
- Both bodies then enter the face pass only when `FALLING` is true. It queries horizontal directions and, for each, the adjacent block face followed by the face one block above. Old `isSolidFace` applies the same-fluid, UP and ICE gates, then excludes attachment exceptions/stairs and compares the old face shape with `SOLID`. Chorus flower is not one of those old exceptions; its override returns `UNDEFINED`, so the EAST face does not match. In 1.14.4 the helper keeps the same-fluid, UP and ICE gates and asks `BlockState.isFaceSturdy`. Chorus flower inherits the base full-block collision shape, has collision enabled by its registration, and is absent from the generated vanilla `LEAVES` set. Its EAST face is therefore sturdy for every AGE state. With all other sampled neighbor and upper cells air, old `getFlow` returns normalized zero; new `getFlow` applies `(0,-6,0)` to zero and returns `(0,-1,0)`.
- The six raw chorus-flower states (`AGE=0..5`) share the old face override and have no new shape override or age-dependent collision provider. The specified flowing WATER state (`LEVEL=8,FALLING=true`) is within the declared fluid properties. Its old height is `8/9`; the new contextual height also uses `level/9` for level 8. With the player's contracted box minimum Y `0.481`, one qualifying water cell contributes depth `8/9 - 0.481 ≈ 0.40789`, which is not below `0.4`. Other scanned cells are empty fluid by fixture assumption.
- In `Entity`'s body-fluid query, one contributor means the accumulated current remains `(0,-1,0)` for a player (player instances are not normalized again). The old current length is zero, so its velocity writer gate does not run. The new writer adds `current * 0.014`, giving a `-0.014` Y-velocity delta. This supports a direct paired query/velocity-write difference under the stipulated snapshot; it does not establish that the snapshot is produced or reachable in a trajectory.

## Exact source identity and hash audit

Canonical roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather`. The permitted `providers/inventory.md` identifies these as Ornithe Feather Gen2 build 2. I re-read the ready markers and recomputed their source-manifest and ready-marker hashes; both agree with that report. The hashes below were also recomputed from the canonical files and match the corresponding entries in each source manifest.

| Identity item | 1.13.2 | 1.14.4 |
|---|---|---|
| `ornithe-feather.sources.sha256` SHA-256 | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` |
| `ornithe-feather.ready.json` SHA-256 | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` |
| Client artifact SHA-256 in ready marker | `3410887ba652f25792c7675bfaf9140e73b60e93cfbf113a803f8a98cb05c0f9` | `b3b2a798e2d67b566008fe4a03767ae2c7ff3f8c7ba6751e7b71fc7299672d0a` |

| Relative source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |
| `net/minecraft/block/ChorusFlowerBlock.java` | `cacbbd84e9be8912d8e79d6d90cafd72a70b81d3e96518b8f0eb2aef65fe19c4` | `5f8de15e04efd8f98a1dcc82628550cfcfe2d65c00bfbae6f56586b9e11adda4` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/block/material/Material.java` | `9bf4fc6893e07f15b7db2b03cba7cba7850370a2499870c621f422c356cf3b4f` | `b976f0011b0cf0f05831a799f40632f2824a4c09019f75d29ef7d88f33f72acf` |
| `net/minecraft/data/tag/BlockTagsProvider.java` | `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` | `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |

The pair-lane reports provide the generated vanilla block-tag evidence; active/runtime tag replacement remains excluded. The draft's assumed loaded area, player box/position, `hasLiquidCollision()==true`, default tag membership, and identical raw source snapshots are fixture assumptions. I treated these as assumptions, not producer or trajectory facts. No product, wiki, backlog, or Git data was used. No canonical source was changed.
