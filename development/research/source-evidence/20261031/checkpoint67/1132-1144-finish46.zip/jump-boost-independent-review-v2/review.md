# Independent review: jump boost float rounding candidate v2

Reviewed draft: `callback-lifecycle-residual/candidates/jump-boost-float-rounding.draft.md`  
Reviewed draft SHA-256: `99F912C20CD59E13918182B289CE1E8681540940E73C1C4A3514FD6FEBFE02BA`  
Evidence: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2 build 2, canonical sources under `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/ornithe-feather/`.

## Verdict

**Accept the bounded source claim.** The correction that `LivingEntity.jump()` supplies the final Y component and `PlayerEntity.jump()` updates statistics/exhaustion afterward is accurate. No trajectory or downstream displacement claim is needed or supported.

## Source audit

The exact `LivingEntity.java`, `PlayerEntity.java`, and `LocalClientPlayerEntity.java` files at both endpoints match their entries in `decompiled_minecraft/<version>/ornithe-feather.sources.sha256`. The relevant source hashes are:

| File | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |

At both endpoints `LivingEntity.getJumpStrength()` returns `0.42F`. In 1.13.2, `LivingEntity.jump()` writes this float to double `velocityY`, then adds `(amplifier + 1) * 0.1F`; the multiplication is float arithmetic and the resulting float is promoted for the double addition. For amplifier 0, the resulting double is `0.5199999883770943`. In 1.14.4, the same effect branch computes `getJumpStrength() + 0.1F * (amplifier + 1)` into local `float f`, rounding the sum to binary32 (`0.5199999809265137`) before passing it to `m_32166403(vec3d.x, f, vec3d.z)`. That entity velocity setter receives doubles and constructs the new velocity vector, so `f` is promoted after its float rounding. The difference is `-7.450580596923828E-9` (new minus old).

The surrounding jump gate matches in the inspected methods: the jumping flag; the fall-distance/on-ground relation; lava exclusion; and zero cooldown before `jump()` followed by cooldown assignment. `LocalClientPlayerEntity.serverTickAi()` copies `input.jumping` to `jumping` in both versions, and `LivingEntity.mobTick()` invokes that AI before the jump gate for locally controlled entities. This supports the draft’s bounded local-client call-path statement without establishing the history that produced the gate state.

`PlayerEntity.jump()` in both versions calls `super.jump()` first, then increments jump statistics and adds sprint-dependent exhaustion. Those later operations do not write Y. The base `LivingEntity.jump()` setter is therefore the final Y write within this jump call; its subsequent sprint impulse changes horizontal velocity only. The player source contains no `getJumpStrength()` override in either endpoint’s player tree, so the paired `0.42F` base value applies to this player call.

The finding is limited to the conditional jump-boost velocity-write difference under paired effect/amplifier and direct-call gate inputs. It does not establish ordinary input history, effect production/timing, an ensuing tick’s velocity, or trajectory.
