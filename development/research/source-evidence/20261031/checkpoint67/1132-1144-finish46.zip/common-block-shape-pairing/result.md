# Common block shape pairing: oak stairs, slab, and trapdoor

## Scope and evidence

Source-only comparison of 1.13.2 → 1.14.4 Ornithe Feather Gen2 build 2. Sources are the canonical trees `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `.../1.14.4/ornithe-feather`. Publication identities and verified manifest/ready-marker/provenance hashes are recorded in `../providers/inventory.md`; this pass used the exact Feather trees and did not use Mojmap. Each source-file hash below was recomputed from the compared tree.

Compared vanilla IDs: `minecraft:oak_stairs`, `minecraft:oak_slab`, and `minecraft:oak_trapdoor`. This covers 80 stair states (4 FACING × 2 HALF × 5 SHAPE × 2 WATERLOGGED), 6 slab states (3 slab-type values × 2 WATERLOGGED; Feather names this property HALF), and 64 trapdoor states (4 FACING × 2 HALF × 2 OPEN × 2 POWERED × 2 WATERLOGGED). The same properties and enumerated values are present at each endpoint. This report pairs output functions for all those raw logical combinations. It does not audit how block-state producers reach them.

## Dispatch and cache closure

- 1.13.2 `BlockState.getShape(world,pos)` dispatches to `Block.getShape(state,world,pos)`; `BlockState.getCollisionShape(world,pos)` dispatches to `Block.getCollisionShape`. The base `Block.getCollisionShape` applies `hasCollision`, then returns `state.getShape(world,pos)`; thus these three classes inherit collision output from their `getShape` implementation.
- 1.14.4 `BlockState.getShape(world,pos,context)` dispatches to `Block.getShape(state,world,pos,context)`. Base `Block.getCollisionShape` applies the same `hasCollision` gate and calls `state.getSHape`, which supplies `CollisionContext.empty()`. `BlockState.getCollisionShape(world,pos)` can instead return the per-state cached collision shape; cache construction calls the same base collision method with `DummyBlockView`, origin, and empty context. The player collision query may use an entity context, but the three provider methods below do not read their context, world, or position.
- These vanilla oak registrations are static-shape blocks. 1.14.4 cache creation is conditional on `!hasDynamicShape`; `Block.Properties.dynamicShape` initializes false, oak slab/trapdoor registrations do not enable it, and oak stairs copy oak-planks properties whose `dynamicShape` likewise remains false. The cache route and direct entity-context route therefore select the same provider result for every enumerated state. The 1.13.2 base collision gate and 1.14.4 base collision gate are both true for these ordinary solid block registrations.
- The `getShape` providers are also the collision fallback/outline-shape provider for these blocks. There is no direct `getCollisionShape` override on any of the three classes at either endpoint.

## State-by-state results

| Family | 1.13.2 provider | 1.14.4 provider | Closure over every listed state | Result |
|---|---|---|---|---|
| Oak stairs, 80 states | `StairsBlock.getShape(state,world,pos)` lines 99–101; index helper lines 103–105 | `StairsBlock.getShape(state,world,pos,context)` lines 99–101; index helper lines 103–105 | Both select TOP/BOTTOM table from HALF, then `SHAPE.ordinal()*4 + FACING.getIdHorizontal()`, then the same `SHAPE_INDICES` table. Both tables use the same base and four 8×8×8 quarter boxes; `makeShape` unions the same bit-selected pieces in NW, NE, SW, SE order. WATERLOGGED is not read. `StairShape.java` and `StairHalf.java` hashes match across endpoints; Direction horizontal IDs are identical (N=2, S=0, W=1, E=3). The VoxelShapes box grid/`or`/`join` path retains the same math for these 1/2-grid boxes. | Same voxel region and collision/outline output for all 80 states. Context/world/position independent. |
| Oak slab, 6 states | `SlabBlock.getShape(state,world,pos)` lines 51–60 | `SlabBlock.getShape(state,world,pos,context)` lines 52–61 | DOUBLE returns full cube; TOP returns the 8/16-to-16/16 box; BOTTOM/default returns 0/16-to-8/16 box. The enum members/order and shape constants match exactly (`SlabType.java` hashes match). WATERLOGGED is not read. Context/world/position are not read. | Same output for all 6 states. |
| Oak trapdoor, 64 states | `TrapdoorBlock.getShape(state,world,pos)` lines 45–64 | `TrapdoorBlock.getShape(state,world,pos,context)` lines 47–65 | CLOSED ignores FACING and selects the identical top/bottom 3/16-thick horizontal box by HALF. OPEN ignores HALF and selects the identical 3/16-thick vertical edge box by FACING. POWERED and WATERLOGGED are not read. Context/world/position are not read. | Same output for all 64 states. |

The requested provider bodies, stair union recipe and all eight stair quarter boxes plus both base boxes match across endpoint source apart from the added unused context parameter and small line offsets. Slab and trapdoor shape constants and decision branches match. The state enumeration is explicit in each class's `buildStateDefinition`; enum hashes for `StairShape`, `StairHalf`, and `SlabType` are identical. The `Direction` source hash differs because the newer file adds unrelated members, but the six enum constructors and horizontal-id values used by stairs are the same.

## Registration cross-check

- 1.13.2 `Block.java:993` registers `oak_stairs` as `StairsBlock` over oak planks; `Blocks.java:790` resolves `OAK_STAIRS` from that registry ID. 1.14.4 `Blocks.java:410` directly registers `oak_stairs` as the same class over oak planks.
- 1.13.2 `Block.java:1549` registers `oak_slab` as `SlabBlock`; `Blocks.java:758` resolves `OAK_SLAB`. 1.14.4 `Blocks.java:1305–1306` registers the same ID/class.
- 1.13.2 `Block.java:1156` registers `oak_trapdoor` as `TrapdoorBlock`; `Blocks.java:845` resolves `OAK_TRAPDOOR`. 1.14.4 `Blocks.java:656–658` registers the same ID/class.

No provider output difference was found in these families. This closes only their paired raw-state collision/outline provider results under the default vanilla registrations. It does not establish state-production histories, player trajectories, all block providers, or intermediate release boundaries.

## Exact file hashes (SHA-256)

| File relative to endpoint tree | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/StairsBlock.java` | `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` | `b49cbd43a9be5e848623f25769dede5795f50435ba0e82bbdbbf571527396b9f` |
| `net/minecraft/block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` | `91f2ebc592e5cb07d5ce8a6faa123ec0d4b7bf10aa6323d6aceb343bc0f73a53` |
| `net/minecraft/block/TrapdoorBlock.java` | `26dd6911517029daef779cef046e943953356644a76372f1d47b1323054629da` | `129b1c0eda5e1431fe3845ef129524dd96c4eb018b686e6d0e38b093e198b3a5` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `net/minecraft/util/math/Direction.java` | `6d5c496ff65377fee9f00c826e48c7be14d3889e5ae5191e110a464007549082` | `121f8b78eda07640eccbe369f40acc7ccbdcb275dcb6aca87c4495cd193b01c0` |
| `net/minecraft/block/state/property/StairShape.java` | `1f67c3ff79edc82d93be6ad553fd198cdd031277571fb7342a926c979f4236b3` | `1f67c3ff79edc82d93be6ad553fd198cdd031277571fb7342a926c979f4236b3` |
| `net/minecraft/block/state/property/StairHalf.java` | `ef1627ddd414bdf6ceeebe634b56799b9a7203ca4d61f943a794f1aa1e4c7381` | `ef1627ddd414bdf6ceeebe634b56799b9a7203ca4d61f943a794f1aa1e4c7381` |
| `net/minecraft/block/state/property/SlabType.java` | `20ef3591cf5f5cf83886d7ab5034fd8402418f68e517180cbba2fe0c7535f697` | `20ef3591cf5f5cf83886d7ab5034fd8402418f68e517180cbba2fe0c7535f697` |

No product/wiki/backlog/Git data was read or changed. Neither canonical source tree was written. No build, tests, game launch, or decompile was run. This is a bounded source pairing; it makes no trajectory or full-pair-freeze claim.

