# Independent review: partial-shape wake position

## Verdict

**ACCEPT**, limited to the direct wake-position response under the candidate's paired raw state snapshot. I verified candidate SHA-256 `21dd0a25323e4cd225285f098ef02e21ff993170ef337218f33efd87b4b282cd` and source report SHA-256 `05d0e73e1dc96961472dbae3685f5cd3875b87cce892ce440d1f8a8e72b7ffe9` before retracing the stated source path. I make no bed-entry, producer, or preceding-trajectory claim.

## Independent source check

In 1.13.2, the ordered `BedBlock.getSpawnPoint` scan begins at the northwest candidate for a north-facing bed, so `(-1,2,-1)` is examined first. The old validity predicate checks only full-block support below and non-solid materials in the candidate and above (`BedBlock.java:220–253`). The candidate's dandelion at that position is registered as a `FlowerBlock` with `Material.PLANT` and `noCollision` (`Block.java:952–962`); `Material.PLANT` is non-solid. Stone below is a full cube, and air above is non-solid. The first candidate is accepted. The old `PlayerEntity.wakeUp` then calls `getSpawnPoint(..., 0)` and writes `(blockX+0.5F, blockY+0.1F, blockZ+0.5F)` (`PlayerEntity.java:1305–1330`), giving `(-0.5,2.1,-0.5)`.

In 1.14.4, `BedBlock.getSpawnPoint` has the same first-candidate order (`BedBlock.java:200–228`), but `isValidSpawnPos` queries collision shapes, descends through empty shapes to a support shape, and then checks the centered type-sized AABB (`:230–255`). The dandelion registration uses `Material.PLANT` and `noCollision` (`Blocks.java:336–338`; `Block.Properties.noCollision` clears `hasCollision` at `Block.java:853–855`; base collision returns empty at `:376–378`). The empty shape is below the `7/16` rejection and is skipped by the support descent. That descent reaches the stone cube at Y=1 and computes `d = 1 + 1 + 2e-7 = 2.0000002`.

The new centered player box is X/Z `[-0.8,-0.2]` and Y `[2.0000002,3.8000002]`. It is disjoint from the bed footprint `[0,1]×[0,1]` and starts `2e-7` above the stone top at Y=2, so the stated clear-world collision test accepts. The new `LivingEntity.stopSleeping` writes that returned vector (`:2742–2756`), yielding `(-0.5,2.0000002,-0.5)`. Subtracting the old direct Y write gives `-0.0999998`. The same stone/dandelion/air state inputs satisfy both algorithms' first-candidate gates; the differing placement formulas are in the reported terminal path.

## Integrity

I recomputed the candidate and report hashes above. I also recomputed each listed Java file SHA in the report and matched it to the corresponding endpoint `ornithe-feather.sources.sha256` row: old `BedBlock`, `PlayerEntity`, `Block`, `Material`; new `BedBlock`, `LivingEntity`, `PlayerEntity`, `Block`, `Blocks`, `Material`, `VoxelShape`, and `EntityType`. All matched. Ready/provenance/source-manifest record hashes and exact endpoint identity are documented in the source report.

This is an endpoint source-level direct-response finding. It does not imply that a prior sleeping trajectory can produce the candidate state or that subsequent movement differs by a specific amount.
