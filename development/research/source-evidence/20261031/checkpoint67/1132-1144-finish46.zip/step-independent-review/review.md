# Independent source review: step-downward component

Candidate reviewed: `.native-source/20261031/1132-1144-finish46/candidates/step-downward-component.draft.md`

Renewed candidate SHA-256: `1D9DF5AB2CD76BBF0C0A8DEA8667308D4799A67E13C86A2BCB137E1E1A1C2DD4`

Prior review identity: `F0CB4FA360320D78E99BBB4E40A8839BB580383D3B00DAD813DDB07253931407`.

Renewed verdict: **the source formula difference and the fixed fixture's final-position contrast are verified under the direct equal-input/state assumption. The candidate now corrects the prior wording and alternative-rise issues and properly limits applicability to conditional operation-level evidence.** This verdict applies only to the renewed candidate bytes identified above.

## Evidence retraced

- 1.13.2 Ornithe Feather `net/minecraft/entity/Entity.java`, `move(MoverType,double,double,double)` (full-file SHA-256 `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`). When the step alternative wins, it assigns `y = -u` or `y = -aa`, where `u`/`aa` is that candidate's upward offset. It then collision-clips that descent. The original requested `o`/Y is not included in the descent request. This method is `void`; it does not return a movement vector. It updates the entity's shape and then calls `setPositionFromShape()` unconditionally in the non-noClip path.
- 1.14.4 Ornithe Feather `net/minecraft/entity/Entity.java`, `m_72373519(Vec3d)` (full-file SHA-256 `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55`). Its selected-step descent request is `-vec3d3.y + vec3d.y`, retaining the original requested Y. The caller applies the returned vector and calls `setPositionFromShape()` only when its squared length is greater than `1.0E-7`; the fixture's horizontal component makes this gate pass.
- Both `SlabBlock.java` files match the candidate hashes. Bottom slab shape is the lower half of the block (Y 0 through 0.5). The stated default oak slab state is bottom and not waterlogged. Both `Block.java` files match the candidate hashes; their base shape is a full unit cube.

## Fixture arithmetic

With the slab at `(1,0,0)`, the starting player box is horizontally disjoint from the slab, so the selected first step alternative can rise by the full `0.6` before moving X. At the raised height it clears the slab. After moving X by `1.8`, the box spans X `1.5..2.1`; it no longer overlaps the sole floor cube at X `0..1`. Thus the later descent is unobstructed. Normal movement, by contrast, overlaps the slab while grounded and clips X at `0.2`; its requested downward component clips against the initial floor. Horizontal progress makes the step alternative win in both implementations.

The revised candidate correctly says that the second 1.14.4 candidate rises only `0.5`: its vertical-only move is evaluated over `box.expanded(vec3d.x, 0, vec3d.z)`, which overlaps the half-height slab. The first candidate rises `0.6`, progresses X by `1.8`, and wins the strict horizontal-progress comparison, so this second candidate does not change the result.

The selected descent is `-0.6` in 1.13.2, yielding a net position Y change of `0`; it is `-0.7` in 1.14.4, yielding net position Y `-0.1`. Neither descent is clipped at the destination. The 1.14.4 result has squared length `1.8² + 0.1² = 3.25`, so the outer position-writer gate passes. The candidate now distinguishes the old final position displacement from the new resolver output and does not claim the old void method returns a vector.

## Applicability judgment

`SELF` is a valid movement mode and the historical `Entity.move`/resolver operation is used for players. Under the assignment's equal-raw-input/state assumption, this fixture demonstrates a real operation-level difference for the specified direct input. The exact source does not establish that a player tick naturally supplies `(1.8,-0.1,0)`: `1.8` is an unusually large one-call displacement, and no ordinary input/travel path or external player-response producer is supplied. The revised candidate explicitly limits the claim accordingly. Do not infer ordinary parkour reachability, spawn reachability, or general player-tick impact.

Renewal confirms the requested corrections only; it does not broaden the source coverage or establish a patch boundary within 1.13.2–1.14.4. No tests, builds, launches, implementations, wiki/product history, or other reports were consulted.
