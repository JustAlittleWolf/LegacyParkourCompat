# Independent review v2: copied sleeping state on local-player respawn

## Verdict

**ACCEPT under the candidate's explicit paired outgoing sleeping-state, reset-loop, loaded-player, and equal logical-control assumptions.** The revised draft corrects both issues from the first review: its paired state is taken from the outgoing local player (the new sleep position is copied tracked data, not a respawn packet field), and it requires the shared reset loop to exit from both the old spawn and new bed-centered start. No eligible server producer or bed-entry claim is included.

## Independent source verification

I reread the exact Feather endpoint source bodies and recomputed their complete file hashes. In 1.13.2, `Minecraft.respawnPlayer` creates a new local player and copies the outgoing player's `SyncedData`; sleeping boolean and position are ordinary `PlayerEntity` fields, so that copy does not transfer them. The new entity's `PlayerEntity.isSleeping()` reads the ordinary false default. `resetPos` runs after the copy; the shared collision search leaves the constructor spawn unchanged under the candidate's two-position fixture and then zeros velocity.

In 1.14.4, `handlePlayerRespawn` creates a replacement and copies tracked data before calling `resetPos`. The optional sleeping-position accessor is registered on `LivingEntity`. `SyncedData.update` stores each matching entry and calls `onDataValueChanged`; the client callback for sleeping position moves the replacement to the bed center. `PlayerEntity.resetPos` writes `Pose.STANDING`, then calls the shared reset, but does not clear the optional sleeping-position accessor. Therefore `LivingEntity.isSleeping()` remains true because it tests optional-position presence. The two-position reset fixture is sufficient to preserve the old-spawn/new-bed-center position difference.

On the first tick, `LivingEntity.mobTick` tests `isDead()` before its locally controlled AI input-copy branch. New `PlayerEntity.isDead()` adds `isSleeping()` to the health test; after reset, the sleeping optional makes the predicate true. The dead branch clears jumping and the movement axes. The old replacement's ordinary sleeping field is false and its reset restores health, so it reaches `LocalClientPlayerEntity.serverTickAi` when camera-controlled; the response sets the local player as camera, and that method copies its input axes/jump. The tick proceeds to travel on both sides. This supports a different first-tick movement-field state; it does not prove a specific displacement or trajectory.

The assumptions pair the outgoing old sleep boolean/bed position to the new tracked sleeping position and sleeping pose. This is an accepted source-state comparison assumption. The candidate correctly leaves producer timing and bed-entry eligibility out of scope.

## Hash-bound reviewed inputs (SHA-256)

| Input | SHA-256 |
|---|---|
| Revised candidate draft | `c158bb3d829c1e345d3e06d9cb0e5be6c75f31c13511af92283dd1100fc4d3b7` |
| 1.13.2 `ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.14.4 `ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.13.2 `SyncedData.java` | `93177865e23be0f8db5741bd505b952daee03d33761838ca782bd10bceb748e4` |
| 1.14.4 `SyncedData.java` | `4d0c0bee069994f64a31e1ff600ae59c3217eadb8678473e2256c2363e657e17` |
| 1.13.2 `Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 `LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.14.4 `LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.13.2 `PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 `PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.13.2 `LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 `LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |

No product implementation, wiki, backlog, Git history, or server producer was inspected. No build, test, game launch, decompile, or canonical source modification was performed.
