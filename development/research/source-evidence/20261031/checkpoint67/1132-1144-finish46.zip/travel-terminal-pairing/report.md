# Travel-to-move terminal pairing: 1.13.2 → 1.14.4

## Assignment and limits

Exact pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2 build 2. This source-only slice independently pairs ordinary `LivingEntity` and `PlayerEntity` travel continuations, their four `Entity.move` calls per living travel method, and the move terminal position/flag/velocity writes. Raw input, movement state, block/fluid state, and collision results are comparison assumptions; their producers are not proven by assuming them. This is not full pair coverage, a freeze, or runtime parity. No product source/history, wiki inventory, tests, builds, launches, decompilation, or source writes were used.

The assigned prior source-only reports were read as leads. In particular, the ladder-jump climb case is re-traced below; prior friction-sampling claims were checked against the exact method order and narrowed. The narrow camera-flight incoming-velocity producer remains a separate open input question and is not inferred from the complete `moveRelative` comparison.

## Exact source identity

Canonical read-only roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.

| Endpoint | Ready source manifest SHA-256 | Ready artifact manifest SHA-256 | Source count | Relevant source hashes (all matched manifests) |
|---|---|---|---:|---|
| 1.13.2 Feather Gen2 build 2 | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `fdcacd9150f98ea70acafc5cab754027ab1a09828ff0eaa8e542dd7890d9ce1e` | 2,711 | `LivingEntity.java` `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c`; `PlayerEntity.java` `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633`; `Entity.java` `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 Feather Gen2 build 2 | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | `308cc33ef6dffc047432ade6affc88eccc9de94a736ee9a98571fd92915c2970` | 3,250 | `LivingEntity.java` `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61`; `PlayerEntity.java` `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df`; `Entity.java` `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |

Each on-disk ready source/artifact manifest digest matched its ready marker. Selected source file digests above were recomputed and matched their manifest entries.

## Paired members and compact fingerprints

Hashes below are SHA-256 of the exact extracted decompiled method text, including its signature and braces; full-file hashes are above.

| Member | 1.13.2 Feather | 1.14.4 Feather |
|---|---|---|
| `LivingEntity.moveRelative` | `LivingEntity.java:1478–1669`, `78de2dc443a97a6d6d08a3e430b0a5dbcb967ad73a5dddd14d9f7169cec56e82` | `LivingEntity.java:1786–1942`, `951b235d5145569b71860d49595f4069560a0892ad5d11d76ded1a6a38a8c4b5` |
| `PlayerEntity.moveRelative` | `PlayerEntity.java:1442–1468`, `e2bec35ade0d77ec03898370e7466fc6f7504eb9629e2e9590c85804742093ae` | `PlayerEntity.java:1381–1409`, `a70272e72266f8750569959ab011e1c43c15f6daf1c948b9c41430576d28029c` |
| `Entity.updateVelocity` | `Entity.java:1057–1075`, `ce5c24df63c34a398c66f03759c8cf9b403cc2d9f50b28baf204037d75e48f3f` | `Entity.java:1062–1065`, `ea338da925943254cc9d8ebf1ca579c653c5cb421d78244b58dfb1793cad0a53` |
| `Entity.move` | `Entity.java:473–776`, `4a2270fbb434f7bde4f2f15062993063560bcda5c372723ee5cdf081fc63cff8` | `Entity.java:444–571`, `81d5cd437e39b4eaa7b3af2d7de998bce53493e4f7e0a40a4b5ee03b5998b907` |
| New dry travel helpers, no old separate helper | inline in `LivingEntity.moveRelative` | `m_19439509(Vec3d)`: `LivingEntity.java:1944–1959`, `33b94ec37b2a8bef95516938a84f7c6573c8369037494017f0c4aa78e3d33c8b`; `m_70235197(float)`: `:1961–1963`, `a34edbc78fa332e26b230e371f039e04a66a6131ca31ef6d0511bb7cb3507a44` |

The methods use changed vector APIs, so their body hashes are not expected to match. The walking-animation terminal in both living methods retains the same position-delta magnitude, clamp-to-1, `0.4F` interpolation, and progress addition. The local-player wrapper retains the same swim look-Y gates (`-0.2`, `0.0`), interpolation factors (`0.085`, `0.06`), flying-speed selection, post-super vertical damping by `0.6`, fall-distance reset/flag clear, and movement-stat call, expressed through vector getters/setters in 1.14.4. Elytra uses the same horizontal-speed magnitude: new `Entity.m_23572928(Vec3d)` is exactly `x*x + z*z`, matching the old `sqrt(velocityX² + velocityZ²)` measure. No other dry/lava/water/elytra branch was found structurally absent from the paired method bodies.

## Travel continuation inventory

`LivingEntity.mobTick()` preserves the relevant local order on both sides: local AI/input copy, jump handling, `sidewaysSpeed` and `forwardSpeed` scaling by `0.98F`, `flyingTick()`, then `moveRelative`, followed by push handling (`1.13.2 LivingEntity.java:1890–1935`; `1.14.4 :2191–2237`). The local camera AI copies `input.jumping` to `jumping` on both endpoints (`LocalClientPlayerEntity.java:635–646` / `:601–612`).

| Route | 1.13.2 continuation | 1.14.4 continuation | Terminal comparison |
|---|---|---|---|
| Elytra / fall-flying | Mutates XYZ velocity by glide lift, pitch dive, look alignment and `(0.99F,0.98F,0.99F)` drag; calls `Entity.move`; server-only wall damage and landing flag handling follow. `LivingEntity.java:1488–1536`. | Same glide terms/order through `Vec3d` additions and `m_17023014(0.99F,0.98F,0.99F)`; calls vector `move`; same damage/landing gates. `:1797–1839`. | Same branch terms identified. Post-move travel does not further change velocity on this route. `Entity.move` still controls resolved position, collision flags and axis-stop writes. |
| Dry / ground / climbing / gravity / levitation | Samples support friction, computes acceleration, clamps climbing velocity, calls move, then applies horizontal-collision climb Y=`0.2`, levitation or client-unloaded/gravity handling, Y drag and XZ friction. `:1537–1601`. | Samples support block once, calls acceleration and climb helper, moves, then applies `(collidingHorizontally || jumping) && climbing` Y=`0.2`, levitation or client-chunk/gravity handling, and XZ/Y drag. `:1840–1867`. | Climb gate, gravity chunk query and acceleration/friction procedure differ as detailed below. |
| Lava | `updateVelocity(...,0.02F)`, move, halve XYZ, apply `d/4` gravity, then wall step-up `0.3F` correction. `:1602–1616`. | Same branch order through vector update, move, half-scale, gravity addition and `0.3F` correction. `:1868–1881`. | Branch and terminal correction order match; acceleration arithmetic is shared with the changed `Entity.updateVelocity`. |
| Water | Depth Strider/Dolphins Grace select controls; move; apply XZ `f` and Y `0.8F` drag; threshold gravity correction; wall step-up `0.3F` correction. `:1617–1655`. | Same control terms; move; vector drag; threshold correction guarded using pre-move `bl`; wall step-up correction. `:1882–1928`. | Pre/post-move Y guard differs under the narrow slow-falling state below; acceleration arithmetic also differs. |
| Player swimming/flying overlay | Swim look correction before `super.moveRelative`; if flying, temporarily changes air speed and restores Y as saved Y `*0.6`; resets fall distance/flag. `PlayerEntity.java:1442–1468`. | Same ordering through immutable vector updates and scalar Y restore. `:1381–1409`. | No separate position correction; post-super Y/XZ values are explicitly reinstalled with the same operands. Input/look state remains assumed. |

All four `LivingEntity.moveRelative` call sites on each side reach `Entity.move(MoverType.SELF, ...)`: fall-flying, dry, lava, and water. Dry post-move velocity writes occur before the next travel tick; `Entity.move` is the position/shape writer in this continuation.

## Source-confirmed terminal differences and conditional effects

### 1. Acceleration helper changed from float normalization to a vector/double procedure

Old `Entity.updateVelocity(float,float,float,float)` accumulates a float squared norm, returns when it is `<1.0E-4F`, takes a float square root, clamps that length to at least `1.0F`, divides the float scale by it, rotates with float yaw sine/cosine, then adds float component products into the double velocity fields (`1.13.2 Entity.java:1057–1075`). New `updateVelocity(float,Vec3d)` delegates to `m_51093791`; that helper uses a double squared norm, returns only below `1.0E-7`, normalizes the vector when the norm exceeds `1.0`, scales it as a `Vec3d`, rotates in double component arithmetic using float sine/cosine, then adds the resulting vector (`1.14.4 Entity.java:1062–1076`).

The same input tuple maps to the same x/y/z axes, but the threshold and intermediate precision differ. For fixed raw movement vectors with squared magnitude in `[1.0E-7,1.0E-4)`, the new helper applies acceleration where old returns; above those thresholds, normalization/rotation rounding also differs. This helper feeds ordinary dry, lava and water acceleration through `LivingEntity.moveRelative`. Which small raw vectors a live input producer supplies is not established here.

### 2. Ground acceleration/friction expression changed

Old dry travel derives ground acceleration from `u = 0.16277137F / (t*t*t)` with `t = slipperiness * 0.91F`; it samples `t` before `updateVelocity`, then reads the same support location again before `Entity.move` for drag (`1.13.2 LivingEntity.java:1538–1558`). New passes raw slipperiness `v` to `m_70235197`, which returns `getSpeed() * (0.21600002F / (v*v*v))` on ground, and uses `w = v * 0.91F` for later drag (`1.14.4 LivingEntity.java:1841–1846, 1961–1963`). The constants and binary32 operation placement differ, so exact acceleration rounding is not established as equal.

The old second support read is after `updateVelocity` but still before `Entity.move`; no position write occurs between reads. Under stable vanilla state at the same block coordinates both old reads address the same support. I found no source basis for a “support transition during this move” effect from that resample alone. In air, new reads the block state to obtain `v`, but the helper returns `speedInAir` and `w` stays `0.91F`, so that read does not feed the acceleration/drag result.

### 3. Dry climb correction now also accepts a jump

Old post-move dry climb correction requires `collidingHorizontally && isClimbing()` and assigns `velocityY=0.2` (`1.13.2 LivingEntity.java:1575–1578`). New tests `(collidingHorizontally || jumping) && isClimbing()` and puts Y=`0.2` into the post-move vector before levitation/gravity and drag (`1.14.4 LivingEntity.java:1846–1866`). Thus the new terminal Y is subsequently gravity/levitation and `0.98F` adjusted; `0.2` is an intermediate correction, not the final dry velocity.

The exclusive new gate is source-reachable for the shared ladder state: local `serverTickAi()` copies `input.jumping` to `jumping` on both endpoints (`1.13.2 LocalClientPlayerEntity.java:635–646`; `1.14.4 :601–612`); `mobTick` calls it before travel on both (`LivingEntity.java:1896–1926` / `:2197–2227`). Both climbing predicates accept LADDER and reject a spectator (`1.13.2 LivingEntity.java:1046–1057`; `1.14.4 :1239–1249`). With that ladder state, jump held and no horizontal displacement, new enters the post-move correction while old does not. Horizontal collision remains a separate resolver output; its production is not needed for this zero-XZ witness. This closes the common ladder/jump gate and its conditional post-move delta only; it does not prove arbitrary ladder histories. New scaffolding climbing is modern-only and excluded from the old-era pair comparison.

### 4. Dry client unloaded-chunk gravity samples a different location/gate

Old, after moving, resets the pooled query to current `x`, `y=0`, current `z` and applies normal gravity if server-side or if both `isChunkLoaded(query)` and `getChunk(query).isLoaded()`; otherwise it applies the `y>0 ? -0.1 : 0` fallback (`1.13.2 LivingEntity.java:1584–1594`). New computes `blockPos` before movement, then uses `world.isClient && !world.isChunkLoaded(blockPos)` as its fallback gate (`1.14.4 LivingEntity.java:1841–1842, 1856–1864`). A raw client state that crosses an x/z chunk boundary or differs in the additional `Chunk.isLoaded()` result can select different post-move Y values. Chunk availability semantics and an ordinary unloaded-boundary history remain open.

### 5. Water gravity deadzone uses initial Y state in the new branch

Old water travel checks `velocityY <= 0.0` after movement and after Y drag before deciding whether to set `-0.003` or subtract `d/16` (`1.13.2 LivingEntity.java:1640–1649`). New captures `bl = velocity.y <= 0.0` at method entry, uses it to select slow-fall `d=0.01`, and later uses that captured boolean instead of a post-move sign test (`1.14.4 LivingEntity.java:1787–1793, 1912–1921`). For ordinary `d=0.08`, the tolerance comparisons around `d/16 == 0.005` make the special correction unreachable; with slow-falling `d=0.01`, a fixed state whose Y changes sign during movement can make the guards disagree. The source delta and exact consumer are closed; a producer/reachable crossing witness is not.

### 6. Entity.move terminal position/flags/velocity clearing

Both endpoint methods translate the resolved shape and then derive `x/y/z` through `setPositionFromShape`; that helper has the same assignments (`1.13.2 Entity.java:782–787`; `1.14.4 :778–783`). Both `Entity.move` methods derive vertical collision/on-ground, call `checkFallDamage`, clear X/Z velocity when that axis was clipped, invoke `beforeCollision` on a vertical clip, and run post-move step/contact callbacks (`1.13.2 Entity.java:674–776`; `1.14.4 :471–571`). New X/Z zeroing uses vector setter calls; old directly assigns the corresponding fields while preserving the other components.

Cobweb motion remains a paired pre-move modifier: old `onCobwebCollision()` sets `inCobweb`, then `Entity.move` scales requested `(x,y,z)` by `(0.25,0.05F,0.25)` and clears velocity; new `onCobwebCollision(state, vec)` stores that multiplier vector and clears velocity when `Entity.move` consumes it (`1.13.2 Entity.java:520–528, 1949–1952`; `1.14.4 :457–463, 1964–1967`). The prior collision-contact report's cobweb pairing is consistent with these source sites; the multiplier's world/block callback producer remains outside this travel-terminal slice.

The horizontal flag comparison is not the same: old uses exact `n != x || p != z`; new uses `!MathHelper.m_68886716(inputX,resolvedX)` / Z, whose helper is `abs(a-b) < 1.0E-5F` (`1.14.4 MathHelper.java:155–157`; `Entity.java:472`). Therefore clipping below `1.0E-5` can change `collidingHorizontally`, which is consumed by the dry climb and water/lava step-up corrections. This depends on resolver output. More broadly, old collision/step clipping is inline in `Entity.move`, while new delegates preprocessing and resolution to `m_91740517`/`m_72373519`; the prior collision lane records changed diagonal axis order and open collision-provider/query closure. I did not claim identical resolved vectors or close the position trajectory. Position setter arithmetic itself showed no separate difference in this slice.

There is also a resolved-motion cutoff at the position writer: old enters shape translation when any post-preprocess request component is nonzero (`1.13.2 Entity.java:578–599`), whereas new only calls `setShape`/`setPositionFromShape` when the resolved vector's squared length is `>1.0E-7` (`1.14.4 Entity.java:463–468`). A nonzero resolved vector at or below that norm can therefore update the old position while leaving the new position unchanged. The exact collision-free/tiny-input route and subsequent input history remain open; this is a conditional source terminal, not a demonstrated ordinary trajectory.

### 7. Lava mode branch input depends on a changed move-produced contact signal

The travel branch structure remains `!isInWater` then `!isInLava` then fall-flying/dry versus lava; these checks are before the four calls to `Entity.move`. However, the old `Entity.isInLava()` scans a contracted entity shape for lava material (`1.13.2 Entity.java:1053–1055`), while new reads a stored flag reset during `Entity.move` before block-collision callbacks and set by the new LiquidBlock lava contact path (`1.14.4 Entity.java:541–543, 1058–1059`; see permitted collision-contact report). This makes the state producer/timing a dependency for which branch a later tick takes. This report compares each branch assuming the same branch-input state; it does not close lava-state production or fluid callbacks. Water contact/height producers are likewise not assumed identical.

## Unresolved inputs and dependencies

- Collision resolver output, axis order/cutoff, world-border/entity collision candidates, block/contextual shapes, and callbacks. These feed resolved position and exact horizontal flags; this slice does not close their dependencies.
- Water contact and height, lava contact-state production/timing, flow/contact callbacks, support block/state, and fluid tag/resource state. Branch outputs above assume the stated raw water/lava state.
- Ordinary producers for small acceleration vectors, slow-fall water sign crossing, chunk-boundary fallback state, and camera-flight incoming velocity. These are not inferred from fixed raw inputs.
- Fall-flying equipment/state and look-vector producers are assumed; the paired formulas do not prove their upstream state histories.
- No intermediate 1.14.0–1.14.3 patch boundary was audited here.

This report is limited to `.native-source/20261031/1132-1144-finish46/travel-terminal-pairing/`; it makes no full-pair freeze claim.
