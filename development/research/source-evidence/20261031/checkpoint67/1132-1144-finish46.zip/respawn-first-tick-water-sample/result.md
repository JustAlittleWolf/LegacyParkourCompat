# First-tick water-submersion sample around sleeping-position relocation

## Result

The ordinary collision-free respawn case is a no-effect closure: 1.14.4 copies the sleeping-position tracked value before `resetPos`; its accessor callback positions the replacement at the bed center. On the first player tick, `PlayerEntity.tick()` samples water at that already-established bed-center position, then `LivingEntity.baseTick()` applies the same bed-center position again. With equal position and effective fluid membership, the cached `PlayerEntity.isSubmergedInWater` value does not change during the relocation. 1.13.2 has no `firstTick` sleeping-position relocation and samples at its replacement position before `super.tick()`. The already-accepted respawn-copy difference means these positions are not generally equal across releases, so this no-effect statement is conditional on equal effective sample inputs.

A narrower conditional stale-cache case exists when 1.14.4 `resetPos()` raises the new player from the copied bed center because of a collision, and the first-tick helper later returns it to the bed center. `PlayerEntity.tick()` samples at the raised position before `LivingEntity.baseTick()` relocates it. `Entity.baseTick()` recomputes the base `Entity.submergedInWater` after relocation, but `LocalClientPlayerEntity.isSubmergedInWater()` overrides the getter to return the separate cached `PlayerEntity.isSubmergedInWater` field, which that recomputation does not update. If water-tag membership at the pre-relocation eye query differs from membership at the bed-center eye query, the first tick therefore leaves the local-player getter stale relative to the post-relocation position. The differing cached boolean is consumed by local sprint/input predicates and by `Entity.updateSwimming()` through the virtual getter. This is a conditional direct movement-state input, not a claimed trajectory or a fluid/respawn producer finding.

This case requires the exact raised-reset-position / subsequent bed-center-relocation ordering and different effective water predicate results at those two eye queries. If reset is collision-free (or the two query results agree), there is no water-cache delta from the helper. No waterlogged-sign or collision-free trajectory is used. The separate new-version unloaded-chunk early return in the fluid helper does not create an additional local-player case: the local-player tick's loaded-chunk gate covers the same horizontal chunk as the eye query.

## Exact ordered source evidence

- 1.13.2 `PlayerEntity.tick()` runs `updateWaterSubmersion()` immediately before `super.tick()`. Its method assigns `isSubmergedInWater = isSubmergedIn(FluidTags.WATER)`. `Entity.isSubmergedIn(Tag)` tests the eye-height block's fluid state and `eyeY < blockY + (fluidHeight + 0.11111111F)`.
- 1.14.4 has the same `PlayerEntity.tick()` call order. Its assignment is `isSubmergedInWater = m_69330161(FluidTags.WATER, true)`. That method has the same boat exclusion, eye position, tag predicate and height comparison; it additionally returns false if the eye block's horizontal chunk is unloaded.
- 1.14.4 `LivingEntity.baseTick()` checks `firstTick` and applies `getSleepingPos().ifPresent(this::m_57357409)` before `super.baseTick()`. `m_57357409` sets `(bedX + 0.5, bedY + 0.6875F, bedZ + 0.5)`.
- The prior accepted `respawn-first-tick-followup` source report records the replacement's copied sleeping-position callback and collision-sensitive `resetPos` ordering: the callback first sets bed-center coordinates; `resetPos` can raise Y if collision is found. Thus the first-tick relocation is normally idempotent, but can undo that raise.
- 1.14.4 `Entity.baseTick()` then runs its water-state update after the living relocation. It updates the base `Entity.submergedInWater` field with the tagged eye query. `LocalClientPlayerEntity.isSubmergedInWater()` returns the separate inherited `PlayerEntity.isSubmergedInWater` cache, so this later base-field write does not refresh the player cache. The local-player tick's loaded-chunk guard makes the helper's added eye-query chunk guard redundant for this tick.
- The local-player sprint predicates call `isSubmergedInWater()`; `Entity.updateSwimming()` also calls it when deciding whether to enter swimming. These are direct state consumers; their operation bodies otherwise remain paired for this scoped query.

## Exact source identity

Both sides use the published `ornithe-feather` source set (Feather Gen2 build 2), consistent with the primary endpoint pair. Read-only roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather`. Full Java-file SHA-256 values were recomputed from the canonical source trees:

| Release | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |

## Scope limits

Raw effective fluid memberships and the already-established respawn copied-state assumptions are abstract inputs here. I did not prove fluid/tag payload producers, respawn packet/producer behavior, server decisions, or a trajectory. The result does not establish the exact intermediate patch boundary. No source was generated or changed. No product/wiki/backlog/Git data, build, test, game or runtime was consulted.
