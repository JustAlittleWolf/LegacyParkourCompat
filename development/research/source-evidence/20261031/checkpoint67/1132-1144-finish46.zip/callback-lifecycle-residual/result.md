# Callback/lifecycle residual closure: slipperiness, jump, climb

## Bounds and method

Exact source pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2 build 2 at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/ornithe-feather/`. This source-only tranche closes the local-player slipperiness getter/registration inventory and traces the direct jump terminal and the remaining climb predicate context. It does not claim pair freeze, runtime parity, or any general movement trajectory. Sources were read only; no product code, wiki, backlog, generation, decompilation, build, test, or launch was used.

## Local-player jump terminal

The local client copies `input.jumping` into the living `jumping` field in `LocalClientPlayerEntity.serverTickAi()` (1.13.2 `client/entity/living/player/LocalClientPlayerEntity.java:638–640`; 1.14.4 `:604–606`). The inherited `LivingEntity.mobTick()` runs that locally controlled AI before the jump gate (old `LivingEntity.java:1896–1899, 1903–1911`; new `:2197–2200, 2204–2212`). A direct jump call is gated by `jumping`, the existing fall-distance/on-ground condition, not being in lava, and zero jump cooldown. This establishes a local-player call path; it does not establish input history or how the gate's world/state values were produced.

`PlayerEntity.jump()` is the only override on the player chain at both endpoints and calls `super.jump()` first, then increments the jump statistic and adds the same exhaustion (`1.13.2 PlayerEntity.java:1430–1439`; 1.14.4 `:1369–1378`). The base `LivingEntity.getJumpStrength()` returns `0.42F` on both endpoints (`1.13.2 LivingEntity.java:1447–1449`; 1.14.4 `:1752–1754`). No `getJumpStrength()` override exists in either PlayerEntity tree, so this is the direct local-player base value.

The jump-boost arithmetic changes precision. Old `LivingEntity.jump()` first assigns `getJumpStrength()` to the double Y-velocity field, then adds `(amplifier + 1) * 0.1F` to that double (`1.13.2 LivingEntity.java:1451–1455`). New computes `getJumpStrength() + 0.1F * (amplifier + 1)` into a `float f`, then passes that rounded float as Y to the vector velocity setter (`1.14.4 LivingEntity.java:1756–1765`). For the same direct call with JUMP_BOOST amplifier 0 and the base strength, binary32 operands are `0.42F` and `0.1F`: old Y is `0.5199999883770943` after promotion and double addition; new Y is `0.5199999809265137` after float addition and promotion (new minus old `-7.450580596923828E-9`). The distinct bounded finding draft is `candidates/jump-boost-float-rounding.draft.md` (SHA-256 `a3ca165c35a8081be6623096f41948d14c714562f620461305c4bfc42df4ff12`). This callback/lifecycle report records the method and reachability coverage; the draft is the candidate claim. The no-effect branch uses the unchanged base float value. Active effect presence/amplifier are paired inputs; effect production/timing is outside this slice.

## Friction getter and registration domain

`Block.getSlipperiness()` is a parameterless read of the instance's final `slipperiness` field in both versions (`1.13.2 Block.java:683–685`; 1.14.4 `:703–705`). A full exact-source search of each endpoint's `net/minecraft/block` tree found no override and no other `.slipperiness(...)` customization site beyond the five registry entries below. Thus the callback is not state-, neighbor-, or world-context-dependent; its value comes from block instance construction. The `Block.Properties` defaults are `0.6F` on both sides (`Block.java:1907` old; `:817` new).

| Common block registration | 1.13.2 declaration | 1.14.4 declaration | Value verdict |
|---|---|---|---|
| `ice` | `Block.java:1068` | `Blocks.java:562` | `.98F` both |
| `slime_block` | `Block.java:1380` | `Blocks.java:1070` | `.8F` both |
| `packed_ice` | `Block.java:1432` | `Blocks.java:1158` | `.98F` both; concrete class changed from `PackedIceBlock` to `Block`, but both use the same property value |
| `frosted_ice` | `Block.java:1607` | `Blocks.java:1442` | `.98F` both |
| `blue_ice` | `Block.java:1870` | `Blocks.java:1832` | `.989F` both |

Every other common block registration inherits the same `0.6F` default, absent a listed customization. These checks close the getter/registration callback inventory for the paired vanilla block instances; they do not close the movement use of the value. Dry travel consumes slipperiness for acceleration and post-move drag: old `LivingEntity.moveRelative(float,float,float)` samples the support block and derives ground acceleration using `t = slipperiness * 0.91F` then `0.16277137F / (t*t*t)` (`1.13.2 LivingEntity.java:1538–1558`); new `moveRelative(Vec3d)` supplies raw slipperiness to `m_70235197`, which derives `0.21600002F / (v*v*v)`, while drag uses `v * 0.91F` (`1.14.4 LivingEntity.java:1841–1846, 1961–1963`). The existing travel-terminal report already records the changed expression and unexhausted float input domain. This tranche confirms the full common registration input set and does not promote that existing operation difference to a trajectory finding.

## Climbing predicate context and residual

For a local player, the base `LivingEntity.isClimbing()` method is the relevant predicate. Old reads the block at `floor(x), floor(getShape().minY), floor(z)`, rejects spectator players, and accepts ladder, vine, or an open trapdoor backed by a facing-matched ladder (`1.13.2 LivingEntity.java:1046–1060`). New obtains the state through `m_83221421()` at `new BlockPos(this)` (entity x/y/z), rejects spectator entities, and accepts ladder, vine, new scaffolding, or the same open/matched trapdoor condition (`1.14.4 LivingEntity.java:1239–1264`). The helper's trapdoor facing/state tests are equivalent for the same queried position/state. Scaffolding is new-only and excluded from the old-era comparison.

The prior `travel-terminal-pairing/report.md` and `ordinary-gates/ordinary-gate-followup.md` already close the separate old `collidingHorizontally` vs new `(collidingHorizontally || jumping)` post-move climb-correction gate for a jump-held common-ladder state. This report does not duplicate that gate finding. Residual: old's vertical query coordinate comes from the box minimum while new uses entity Y. Equality depends on the position/box invariant through pose and dimension updates; this tranche has not closed that history/provider dependency for all local-player states. No generalized climbing equivalence or trajectory follows.

## Previously closed callback families and remaining inventory

The exact block/entity contact and support callback inventory is already paired in `../block-callback-terminal-pairing/review.md`: complete `onEntityCollision` overrides and call dispatch; `beforeCollision`; `onSteppedOn`; and `onFallenOn` dispositions. It already handles bubble-column, cobweb, soul-sand, bed/slime bounce and step effects, lava contact, damage-only/server-only terminals, and modern-only berry bush. I did not reopen or duplicate those members. That report identifies the added lava-contact writer's interaction with the later `isInLava` travel branch as an open contact timing/state-history dependency; fluid height/flow/current and contact domains remain with the separate fluid audit. No evidence here closes those residuals.

## Selected source identities

SHA-256 values were recomputed from the canonical endpoint files and match `ornithe-feather.sources.sha256` entries. Hashes are for the files containing the inspected terminal, call path, and registry declarations:

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

### Exact remaining work from this tranche

- The direct jump boost velocity rounding delta is source-closed under equal effect amplifier and direct jump-call conditions; its gameplay history/applicability is not claimed here.
- The slipperiness getter and customization inventory is closed for the paired registrations; the changed grounded acceleration expression remains the already-recorded conditional operation candidate, and binary32 equality across continuous speed inputs is not exhaustively resolved.
- The common ladder climb-correction gate is already source-closed elsewhere; climb predicate coordinate equivalence across position/box history remains open.
- Contact/lava state timing and broad fluid query/contact dependencies remain open to the corresponding fluid/collision closure. No pair freeze or trajectory claim is made.