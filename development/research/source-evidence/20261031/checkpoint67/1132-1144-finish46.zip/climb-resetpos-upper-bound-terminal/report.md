# `Entity.resetPos` upper-bound terminal and climb predicate

## Result

**The upper-bound terminal can leave a live raw entity/player snapshot with different climb lookup Y coordinates, and the difference can reach movement-facing behavior.** This is a conditional source-level witness, not a claim about ordinary response history, a particular respawn producer, or runtime parity.

## Paired reset loop: exact order

Both Feather endpoints have the same loop gate and placement/increment order (`Entity.java`, old 260–274; new 275–288):

1. Enter only when `world != null` and stored `y > 0.0 && y < 256.0`.
2. Call `setPosition(x, y, z)`, rebuilding the box with its minimum Y at the current stored Y.
3. Query collisions on that box: 1.13.2 calls `world.hasNoCollisions(this, this.getShape())`; 1.14.4 calls `world.hasNoCollisions(this)` (which delegates using `entity.getShape()`).
4. If collision-free, `break` immediately; otherwise increment only `this.y++`.
5. Re-evaluate the strict loop gate. If the increment made Y `>= 256`, exit without another `setPosition` or collision query. Both endpoints then zero velocity and pitch; the newer endpoint uses its vector setter `m_28162558(Vec3d.ZERO)`, the older writes three components.

Thus an iteration at Y=255.x whose box collides leaves the terminal raw fields at Y=256.x and box-minY 255.x. No endpoint source clamps that Y or synchronizes the box after the terminal increment. The bound is on entity Y, while the collision query uses the box; the world block-height gate (`World.isOutsideWorldHeight`) treats block Y `>= 256` as outside, not entity Y itself.

## Conditional raw snapshot witness

The source gates permit this setup without relying on how it was produced:

- A non-null world, non-spectator player, and X/Z with a valid loaded block neighborhood.
- Reset begins at Y=254.0. At both candidate placements Y=254 and Y=255, a colliding block shape overlaps the player's box, so both `hasNoCollisions` checks return false. A raw example is a solid block adjacent to the player's center cell, with the center cell holding a ladder at Y=255; the player's horizontal box overlaps the adjacent solid. The ladder itself need not provide the collision.
- The next increment sets entity Y to 256.0 and the strict `< 256.0` loop test exits, preserving box-minY 255.0.
- World block lookup at Y=255 can return the ladder. Lookup at Y=256 returns `VOID_AIR` in both endpoints because `World.getBlockState` checks `isOutsideWorldHeight` first.

This is an admissible conditional raw world/player state under the source gates. No claim is made that a paired client response or normal respawn commonly creates the required two colliding placements; producer history is outside this follow-up.

## Predicate and movement-facing consequence

The old predicate (`LivingEntity.isClimbing`, 1.13.2 lines 1046–1058) floors `getShape().minY`, then has the player spectator guard and tests the block for ladder/vine or matching open ladder trapdoor. In the terminal snapshot it reads block `(floor(x), 255, floor(z))`, so the witness ladder returns true.

The new predicate (1.14.4 lines 1239–1263) first rejects spectators, then `m_83221421()` looks up `new BlockPos(this)`, whose Y is the entity's stored Y. In the witness it reads `(floor(x), 256, floor(z))`; world height handling returns `VOID_AIR`, so it returns false. (Scaffolding is an additional new climbable block but does not affect this witness.)

That boolean difference can affect player movement when the corresponding code paths are reached:

- 1.13.2's grounded, non-water travel path checks `isClimbing()` before `move` (lines 1560–1575). A true result clamps horizontal velocity components to ±0.15, clears `fallDistance`, caps downward Y velocity at −0.15, and for a sneaking player clamps negative Y to zero. After movement, `collidingHorizontally && isClimbing()` sets `velocityY = 0.2` (1576–1578).
- 1.14.4's land path applies `m_19439509` immediately before `move` (1844–1846); that helper (1944–1958) performs corresponding horizontal clamps, fall-distance reset, and downward-Y handling only when its `isClimbing()` gate is true. The false result in this witness skips them. After movement, `(collidingHorizontally || jumping) && isClimbing()` selects Y=0.2 in the movement vector (1904–1911); with a false climb result, it does not select that value. This follow-up does not claim other unrelated travel branches differ.
- Neither endpoint sets a dedicated climbing flag in these predicate consumers. The identified output is the direct predicate and its velocity/fall-distance handling, subject to the stated branch and post-move gates.

## Bounded assumptions

- Conditions above describe a conditional, valid block/player snapshot and source-reachable reset loop terminal; they do not assert normal producer reachability, commonness, or that the paired clients receive identical world snapshots.
- The movement consequences are conditional on non-spectator status and execution reaching the cited travel gates. No trajectory, subsequent resynchronizing setter, server behavior, profile switch, or runtime result is asserted.
- Block collision setup is specified only to satisfy the exact loop collision gates; this is not a separate collision-provider audit.

## Exact source roots and SHA-256

Read-only Feather Gen2 source roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather`.

| Version | Source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/world/World.java` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8da8a238edf834f3963e401e6eeef6cb475c4909` |

No source tree was written or regenerated. No product, wiki, backlog, Git history, build, test, game, or decompile action was used.
