# Bed shape pairing: 1.13.2 → 1.14.4

## Scope and exact sources

Source-only pairing of the vanilla colored bed block family, mapped as `BedBlock`, in Ornithe Feather Gen2 build 2 for Minecraft 1.13.2 and 1.14.4. Exact read-only roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather`. Their endpoint publication, mapping and provenance identities are those verified in `../providers/inventory.md`; the bed source hashes below were recomputed from the exact trees. No other mappings were used.

This pairs bed outline and collision shape outputs over each endpoint's registered raw states and checks the directly exposed movement-facing face query. It does not infer entry eligibility, block-state producers or trajectory outcomes. The existing neighboring wake-position comparison is only a consumer dependency where it asks candidate positions for collision shapes.

## Registration and state-space closure

Both endpoints register 16 separate color IDs with `BedBlock`: `white_bed`, `orange_bed`, `magenta_bed`, `light_blue_bed`, `yellow_bed`, `lime_bed`, `pink_bed`, `gray_bed`, `light_gray_bed`, `cyan_bed`, `purple_bed`, `blue_bed`, `brown_bed`, `green_bed`, `red_bed`, and `black_bed`. 1.13.2 `Block.java:901–916` registers those IDs and `Blocks.java:700–715` obtains the corresponding aliases; 1.14.4 `Blocks.java:212–258` directly registers the same IDs as `new BedBlock(...)`. There is no single `minecraft:bed` registry ID in these endpoint source trees; the family is the sixteen color IDs.

For each registered block, both `BedBlock.buildStateDefinition` methods add the same properties in the same order: `FACING`, `PART`, `OCCUPIED` (old lines 276–278; new lines 275–277). `FACING` is the horizontal direction property (north, south, west, east); `PART` has `FOOT` and `HEAD`; `OCCUPIED` is Boolean. Thus each endpoint has 16 raw states per color block (4 × 2 × 2), 256 across the 16 IDs. The enum/property declarations and values match across the pair. The default is FOOT and unoccupied, but all raw combinations were considered independently of normal placement consistency.

## Outline and collision providers

- **1.13.2:** `BedBlock.getShape(BlockState, BlockView, BlockPos)`, lines 210–212, always returns `SHAPE = Block.block(0, 0, 0, 16, 9, 16)` (lines 39–47). The result is independent of FACING, PART, OCCUPIED, world and position. `BlockState.getShape` dispatches to this method; base `Block.getCollisionShape` first applies `hasCollision`, then returns `state.getShape` (old `BlockState.java:205–210`, `Block.java:387–395`). The vanilla bed registrations use colliding wool properties, so that gate passes.
- **1.14.4:** `BedBlock.getShape(BlockState, BlockView, BlockPos, CollisionContext)`, lines 180–192, uses `direction2 = FACING` for HEAD and `FACING.getOpposite()` for FOOT. It returns one of four composites. Each composite includes the full-footprint mattress `Block.block(0, 3, 0, 16, 9, 16)` and two corner legs of height 3/16 on the selected end/side: north uses x=[0,3] and [13,16], z=[0,3]; south uses the same x ranges at z=[13,16]; west uses x=[0,3] at both z ends; east uses x=[13,16] at both z ends. The state selector is the only input read; OCCUPIED, context, world and position do not affect output.
- There is no BedBlock `getCollisionShape` override on either side. The 1.14.4 base collision provider calls `state.getSHape`, which supplies `CollisionContext.empty()`, and its ordinary static state path can return `BlockState.Cache.collisionShape` instead (`Block.java:371–378`; `BlockState.java:189–203, 393–416`). Bed registrations do not request dynamic shapes, so the cached empty-context result equals direct entity-context dispatch because the BedBlock provider ignores context. Outline queries dispatch to the same `getShape` provider. Cache population therefore does not mask a context-specific result.

**Difference and movement meaning:** across all 16 raw states of every color ID, the old outline/collision region is a continuous 9/16-high rectangular bed volume. The new region preserves the same 9/16 maximum height and full mattress footprint above 3/16, but removes most of the lower 3/16 volume and leaves two corner posts for each bed part. This is a source-confirmed collision and outline geometry change reachable by ordinary player block collision. It can alter lower-body collision/clearance around beds; no trajectory or final tick result is claimed. Facing/part select which pair of legs is present; OCCUPIED remains geometry-neutral.

## Movement-facing face query

- 1.13.2 `BedBlock.getFaceShape(BlockView, BlockState, BlockPos, Direction)`, lines 271–273, returns `FaceShape.UNDEFINED` for every face and raw state.
- 1.14.4 has no BedBlock override. `BlockState.m_87223014(BlockView, BlockPos, Direction)` uses the cached face-solid bit or `Block.isFaceSolid`; that helper rejects leaves then calls `isFaceFull(collisionShape, face)`, which requires the selected unit-block boundary slice to be a full block (`BlockState.java:326–328`; `Block.java:402–409`; `VoxelShape.java:170–200`). Bed collision shape never forms a full unit boundary face: its Y extent ends at 9/16 and its boundary slices on X/Z are partial. Therefore this predicate is false for all six directions, all eight facing/part combinations and either occupied value. This matches the old bed's non-solid FaceShape result. `FlowingFluid.isSolidFace` reaches these respective face terminals in the already inventoried falling-fluid path; bed face-query output itself does not change.

The 1.14.4 wake-position candidate scan also reads collision shapes for tested positions (`BedBlock.isValidSpawnPos`, lines 230–256). The paired provider above supplies its bed-state input if such a candidate is examined. This report does not claim any candidate is selected or make a bed-entry eligibility finding.

## Exact source file SHA-256

| Relative file | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/BedBlock.java` | `a274ed3d3dd8e4f4895fe1f3d1444425a9248e9cd41bc6e1f2677af7dacbec18` | `aab431c7d85bc654b74215d2b2be5fbe6de81643f5e2be466658d918f272abe1` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/block/state/property/BedPart.java` | `1a83310e470e355b0c67622b0ebcd26b38a04f97cb5a23a0885727ab16fd445d` | `1a83310e470e355b0c67622b0ebcd26b38a04f97cb5a23a0885727ab16fd445d` |
| `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |

This bounded provider pairing is complete for the registered vanilla bed raw state spaces. It does not close other block providers, state production, wake candidate histories, trajectories, or intermediate release boundaries, and makes no full-pair freeze claim. No canonical decompiled source was written or regenerated; no product, wiki, backlog or Git history was read or changed; no build, test or game was run.
