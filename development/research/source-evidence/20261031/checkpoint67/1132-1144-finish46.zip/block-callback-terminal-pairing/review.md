# 1.13.2 → 1.14.4 block-callback terminal pairing

## Bounds and evidence

This is a bounded source-only terminal audit of block/entity contact callbacks reached from player movement, plus the immediately adjacent landing, ladder, piston and entity-push routes requested for closure. Exact pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2 build 2 on both endpoints. Sources are read-only at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/ornithe-feather/`. The prior permitted source review identifies the pinned provenance, ready and verification records; this audit rehashed every selected source against the endpoint source manifest. All actual hashes matched. No product sources/history, wiki, backlog, source generation, decompilation, build, test or launch was used. No movement trajectory, complete pair coverage or freeze is claimed.

The same raw block/entity inputs are assumed at the two compared callback sites. Block-state, packet and other external state producers are not audited here; a callback that only triggers those producers is therefore disposed by its direct local-player movement effect, not by downstream world evolution.

## Dispatch terminal

`BlockState.onEntityCollision` dispatches to `Block.onEntityCollision` in both endpoints (1.13.2 `block/state/BlockState.java:261–263`; 1.14.4 `:253–255`). The dispatcher body is the same `this.getBlock().onEntityCollision(this, world, pos, entity)` forwarding operation. `Entity.move` calls `checkBlockCollisions` after the move, fall/step work and step-sound work (1.13.2 `entity/Entity.java:746–753`; 1.14.4 `:540–548`). Both `checkBlockCollisions` bodies use the same shape inset of 0.001, `isAreaLoaded` gate, ascending x→y→z cell loops, then call `blockState.onEntityCollision(...)` followed by `this.onBlockCollision(blockState)` for each cell (1.13.2 `Entity.java:801–830`; 1.14.4 `:797–826`). The terminal source is unchanged for local-player dispatch: the protected `Entity.onBlockCollision` method is empty on both sides (`1.13.2 Entity.java:832–833`; `1.14.4 :828–829`). The only override found by an exact-source search is `ServerPlayerEntity.onBlockCollision`, which runs `CriterionTriggers.ENTER_BLOCK` (old `server/entity/living/player/ServerPlayerEntity.java:298–300`; new `:313–315`). `LocalClientPlayerEntity` instead extends the client-player class in both endpoints (`client/entity/living/player/LocalClientPlayerEntity.java:89` / `:79`), so that server-only criterion override cannot be the local-player terminal.

## Complete block callback inventory

Exact-source `rg` inventory over both endpoint `net/minecraft/block` trees found the following concrete overrides. `Block` is the unchanged no-op base. The common override set is AbstractPressurePlate, BubbleColumn, Button, Cactus, Cauldron, Cobweb, DetectorRail, EndPortal, Hopper, LilyPad, Portal, SoulSand and Tripwire. Each is paired below. Old-only is TNT. New-only is BerryBush, Campfire, LiquidBlock, WitherFlower and Wheat. The two non-block `onEntityCollision` names are the expected `HopperBlockEntity` delegate and unrelated projectile/entity callsites; they are not extra `Block` overrides.

| Terminal | Local-player effect and endpoint verdict |
| --- | --- |
| `Block` base; `BlockState` dispatch | Both delegate/no-op bodies are unchanged. |
| `AbstractPressurePlateBlock.onEntityCollision` (old `:69–76`, new `:65–72`) | Server-only block-state/redstone update. No local-client player movement write; excluded downstream state producer. |
| `BubbleColumnBlock.onEntityCollision` (old `:38–78`, new `:36–76`) | Same surface-vs-body gate (`pos.up().isAir()`), same calls to `Entity.onBubbleColumnSurfaceCollision` / `onBubbleColumnCollision`; direct local-player velocity-Y caps/additions and body fall-distance reset pair unchanged (`Entity.java:1873–1889`; new `:1905–1928`). |
| `ButtonBlock.onEntityCollision` (old `:154–158`, new `:149–153`) | Same server-only wooden-button gate; powered/block/neighbour changes only. |
| `CactusBlock.onEntityCollision` (old `:103–105`, new `:99–101`) | Same unconditional `takeDamage(CACTUS, 1)`; health/damage excluded. |
| `CauldronBlock.onEntityCollision` (old `:63–70`, new `:65–72`) | Same server-only burning/level/height gate, extinguish and level decrement; no local-client movement write. |
| `CobwebBlock.onEntityCollision` (old `:24–26`, new `:16–18`) | The call shape changed: old sets `inCobweb` and clears fall distance; new records `f_74350999 = (0.25, 0.05F, 0.25)` and clears fall distance (`Entity.java:1949–1952`; new `:1964–1967`). Old `Entity.move` consumes the bit to multiply requested movement by those same factors and zero velocity (`:520–528`); new consumes the stored vector at move entry and clears the pending/current velocity (`:457–461`). For this common cobweb callback's local-player movement result, factor and reset agree. The callback/helper API itself is changed but no behavior difference is established for cobweb. |
| `DetectorRailBlock.onEntityCollision` (old/new `:46–53`) | Same server-only powered/output update. No local-player movement write. |
| `EndPortalBlock.onEntityCollision` (old `:47–57`, new `:37–47`) | The destination expression changes from always THE_END to toggle END/OVERWORLD. Both callback bodies require `!world.isClient`, no riding/passengers, portal eligibility and shape overlap. Thus the changed destination is server-only, not a local-player movement delta. |
| `HopperBlock.onEntityCollision` (old `:210–215`, new `:195–200`) | Same block-entity delegation. The callee requires `entity instanceof ItemEntity` before testing suck-area overlap and picking up that item (old `HopperBlockEntity.java:490–499`; new `:414–423`); local player cannot enter the writer. |
| `LilyPadBlock.onEntityCollision` (old `:22–27`, new `:23–28`) | Same base call and boat-only break. No player movement write. |
| `PortalBlock.onEntityCollision` (old `:112–116`, new `:102–106`) | Same no-riding/no-passenger/portal-eligibility gate and `entity.onPortalCollision(pos)` call. `onPortalCollision` has matching local write `inPortal = true` after cooldown check (old `Entity.java:1703–1724`; new `:1696–1719`); its portal-time/dimension processing is under server-world gating (old `Entity.java:356–389`; new `:1721–1745`). For a local client player, only the contact marker is written and it is not consumed as a client movement response. No callback terminal delta. |
| `SoulSandBlock.onEntityCollision` (old `:26–29`, new `:28–31`) | Old multiplies x/z velocity by 0.4; new scales vector x/z by 0.4 and y by 1.0. Same direct local-player velocity effect. |
| `TripwireBlock.onEntityCollision` (old `:127–133`, new `:123–129`) | Same server-only powered/trap-state update; it queries nearby entities and writes tripwire state, not player movement. |
| Old-only `TntBlock.onEntityCollision` (old `:108–117`) | Requires `!world.isClient` and `entity instanceof AbstractArrowEntity`; this is neither a common terminal nor a local-player path. |
| New-only `BerryBushBlock.onEntityCollision` (new `:59–70`) | For `LivingEntity` except fox, calls `entity.onCobwebCollision(state, (0.8,0.75,0.8))` on either logical side. This writes fall distance and the next requested-movement multiplier, so it can directly target a local player. It has no old endpoint block/callback counterpart; berry bushes are a new block feature at this endpoint, not a 1.13.2-era block to emulate. Server-only berry-bush damage is excluded. |
| New-only `LiquidBlock.onEntityCollision` (new `:168–172`) | For LAVA-tagged fluid calls the entity setter that raises the lava-contact flag; it is not server-gated, so the local player is a target. Old `Block.onEntityCollision` is a no-op for liquid blocks. This is a changed travel-contact terminal: new `Entity.move` resets the flag immediately before the callback scan (`:540–543`), the callback sets it (`Entity.java:1054–1060`), and `isInLava` consumes it; old `isInLava` scans the contracted entity box for LAVA material (`:1053–1055`). This confirms the writer/gate difference only; timing/region effects and trajectory witness remain open as in the prior draft. |
| New-only `CampfireBlock.onEntityCollision` (new `:79–88`) | Lit/fire-immunity/living-entity/Frost-Walker gates lead to `takeDamage(FIRE, 1)` then the no-op base callback. Direct effect is damage only; excluded. |
| New-only `WitherFlowerBlock.onEntityCollision` (new `:48–57`) | Server-only difficulty/living/invulnerability gates add WITHER effect; no local-client write, and health/damage effects are excluded. |
| New-only `WheatBlock.onEntityCollision` (new `:147–153`) | Only ravager (`C_22685453 extends RaiderEntity`, `:44`) with mob-griefing enabled breaks the block; player cannot satisfy the entity-type gate. Base callback is no-op. |

The `onEntityCollision` callsites outside this player-move terminal are also disposed: 1.13.2 `AbstractArrowEntity` invokes the callback for its own projectile contact (`:335`), and 1.14.4 `FireworksEntity` does so for its own projectile (`:212`). Those callers do not pass the local player as the colliding entity. Vehicle, projectile, Vex and other `checkBlockCollisions` callers likewise are non-player physics and out of scope.

## Adjacent movement routes requested for terminal disposition

- **Ladder/climbing:** `LivingEntity.isClimbing` keeps the ladder, vine and open-trapdoor predicate for old-era blocks (old `LivingEntity.java:1046–1057`; new `:1239–1249`, plus same trapdoor helper). New scaffolding is a new block/feature and has no old counterpart. A separate travel gate is not unchanged: old post-move climb boost requires `collidingHorizontally && isClimbing()` (old `LivingEntity.java:1575–1578`); new dry travel uses `(collidingHorizontally || jumping) && isClimbing()` (`1.14.4 LivingEntity.java:1846–1850`). The local player can satisfy the new added jumping arm. This is an adjacent source-confirmed movement candidate, not a block-callback difference; witness/dependency disposition remains open.
- **Fall/landing/support block:** `Entity.move` selects the below-block support state and calls `checkFallDamage`, which dispatches `Block.onFallenOn` only on landing and then clears or accumulates `fallDistance` (old `Entity.java:682–696`, `882–891`; new `:477–491`, `877–886`). Base damage, Bed half damage, Hay reduced damage and Slime non-sneak zero damage are health/damage only. Farmland and TurtleEgg callbacks can change block state only under server gates. There is no common `onLandedUpon` override in this inventory. These landing terminals do not write local-player movement state under scope. The relevant movement responses are instead `Block.beforeCollision` and `onSteppedOn`, below.
- **Below-block/bounce and step:** On a vertical clipped move, `Entity.move` invokes the selected support block's `beforeCollision` (old `:705–708`, new `:501–504`); on ground, it invokes `onSteppedOn` (`:710–720`, new `:506–518`). Exact block search finds direct movement writers in Bed/Slime `beforeCollision` and Slime `onSteppedOn`; both endpoint formulas/gates match for players. Bed upward bounce is `-velocityY * 0.66F` for a nonsneaking LivingEntity; Slime reverses downward LivingEntity y velocity with factor 1.0, and Slime step damping multiplies x/z by `0.4 + abs(velocityY)*0.2` when `abs(velocityY)<0.1` and not sneaking. Component setter refactors in 1.14.4 preserve these results. Other stepped-on overrides are Magma/Redstone (damage/redstone), Stairs forwarding to its base block, and TurtleEgg (server-side block state); no additional direct player movement writer was found. |
- **Piston:** Old `Entity.move(MoverType.PISTON, x,y,z)` accumulates/clamps the first nonzero axis to ±0.51, records per-tick deltas, and returns when the accepted component magnitude is ≤1.0E-5F (`Entity.java:478–514`). New `move(..., Vec3d)` delegates to `m_19881916` (`:449–454`), whose helper has an added squared-length early return at `<= 1.0E-7` before that same per-axis clamp/±0.51 accumulator (`:623–654`). Therefore tiny nonzero piston requests can bypass the old clamp/epsilon path on the new endpoint. This is a source-confirmed adjacent candidate; producer/witness closure is open. Piston vector producers are outside this bounded terminal audit.
- **Entity push:** Common `Entity.push(Entity)` has the same vehicle/no-clip/separation gates, arithmetic, passenger gates and two velocity additions (old `Entity.java:1186–1223`; new `:1170–1205`). The player sleeping gate is old `PlayerEntity.push` (`PlayerEntity.java:2016–2020`) and new `LivingEntity.push` (`LivingEntity.java:1667–1671`); it remains the same `!isSleeping()` gate for local players. `pushAwayCollidingEntities` still calls `entity.push(this)` (old `LivingEntity.java:1962–2013`; new `:2263–2312`). The collision recoil helper's three component multiplications by −0.2 are replaced with vector `scale(-0.2)` (`:1987–2009`; new `:2288–2308`), same gate and local-player result. No source difference was found in these paired player velocity routes; entity candidate enumeration/producer closure is not claimed.
- **Water/bubble/fall contact:** Bubble-column block callback and helper math pair unchanged above. The lava contact callback is the only endpoint callback difference here that directly changes the local player's travel-contact state. Full fluid-height/flow and travel response dependencies are still open and are not reclosed by this audit.

## Exact source hashes rechecked against Feather source manifests

The endpoint roots and source/manifests are the ones identified in the permitted 1.13.2→1.14.4 source review. Hashes below are actual local SHA-256 values and each matches the corresponding `ornithe-feather.sources.sha256` entry. For compactness, callback block-class hashes are grouped by endpoint; absent endpoint files/overrides are called out above.

**1.13.2**

| File | SHA-256 |
| --- | --- |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| `AbstractPressurePlateBlock` | `c920500d5b908f6f516e04b6c312ba7c848c3cfa97b24d3427ccf10d2b0de701` |
| `BubbleColumnBlock` | `0320e1b70b215dfff209f8e5003b97cac3a247fd3d642597f2db8ab46d251b2e` |
| `ButtonBlock` | `0cdd88bf4f0ee6b2d935a59867c1ba6df68c098d97701e800f499f83dc7a9578` |
| `CactusBlock` | `d337d776966b6a50070a5ed79ec8cbabb064e15b7b2d6b8e4992a66ccea5e8c9` |
| `CauldronBlock` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` |
| `CobwebBlock` | `a0848fddd8d8c526e99241f6f6fab74df108d0f8861a4f04cc331fd6fd058875` |
| `DetectorRailBlock` | `39c3cc54bd8ccc7c4d99669884e8dea9c3248d911815064ee049eda0872cae1b` |
| `EndPortalBlock` | `9541e703d04bf9148cb324741de73c4f3ce76021bc358f22308c946bccb72ad3` |
| `HopperBlock` | `c43588fd0bdf0c17ec7356090e67af8101335b5ee2a565088837d6d75a3a73ae` |
| `LilyPadBlock` | `741784cff408619ec5f262366b481c92bd5892d329fc2f77393e3faeae6397eb` |
| `PortalBlock` | `075976960fdb4518ec5ee70443d8bfd175981aeb01b71aec9bc8ad5d957ccee9` |
| `SoulSandBlock` | `259645f4b6dbc7b71481756c8fcd804d7bd3dadb679d09f06284ffb9d145b5be` |
| `TripwireBlock` | `708a553f53db6ff187e93e02e0e7ffc8e34fc0c9abd38a0ffe7c18a488534d59` |
| `TntBlock` | `2acf48c3575f434324af23053816855e8e34e21119653c304b438af0ae03a305` |
| `SlimeBlock` | `8a97ba1ed4b65141b6623c7a5b13162767a54bc5666a4d99e8518ba0113cfae4` |
| `BedBlock` | `a274ed3d3dd8e4f4895fe1f3d1444425a9248e9cd41bc6e1f2677af7dacbec18` |
| `FarmlandBlock` | `581dae15cc29abe90f9cf20232a3cd1b7ab6c868808bc5e4f05816952b61eef9` |
| `HayBlock` | `a69ddb3554c2453c8d04ddeec14a1e0feed001592e49384a710f630bac0c7a64` |
| `TurtleEggBlock` | `555e7263053f773dfce7d13c94c6dc1d043e26eea929a5b7cafddc6aa3189cf8` |

**1.14.4**

| File | SHA-256 |
| --- | --- |
| `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `AbstractPressurePlateBlock` | `23fa38e232fd91a736ae79c8d038c317707b72a2f312467efbacca42b903b1c3` |
| `BerryBushBlock` | `8c8bc4a4fb2bdfcdfb16267d796b6541accc44b0f04d1570c2d4a0236a7deb3e` |
| `BubbleColumnBlock` | `d5b9bdcf81349e96920134d6519629479787203d59ea2bd1683080c0b5223ef2` |
| `ButtonBlock` | `9153636ceafd3c93882d8b9603a7813ff99695b955d17f45507e87860408ba63` |
| `CactusBlock` | `3e5d6d42cef91cd8bab1b2a96589f80f6d164fea8f0b286a0589cbf211d2f67b` |
| `CampfireBlock` | `09629643b1775d243c8c559fd1e4de11e0044a45317f6bcc1a00e65fe6550ef7` |
| `CauldronBlock` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| `CobwebBlock` | `ec068b2ead79f4986dad8afdbbf442dafb0725c39f1bbde286f670631324d704` |
| `DetectorRailBlock` | `0a8c54c7d650f7283281e49f04872b15069893c04deaf8466b6be799e300a3ad` |
| `EndPortalBlock` | `02c5ed627568172fc2dcb0a6b2f3263bebf7a975ff71bcbebe6067124bb6a050` |
| `HopperBlock` | `179c954e0c484ec1c613c9273b679725f5f352081a141540c31d8b20d6b03859` |
| `LilyPadBlock` | `044fb0551c40490da3507e21ebcc2af81b82f6f5477df324681b07635f9875e5` |
| `LiquidBlock` | `bfbbe2997ce6c03224b5833176d6b19b4b4b4cbc3337960fb3d867de77519ca1` |
| `PortalBlock` | `4e350efb356a684dfb554a83c06c1d138ac075e67cb6a9f9afa72881e17996f5` |
| `SoulSandBlock` | `fd8afe4294317c439f7a8c90143aea1a59491c746d9fe1645db6094e7c53f21f` |
| `TripwireBlock` | `fea6cdd16b28ab7008ef4429fb50aeb4f2c3ec4c6f7de9ae54959ae5cfca9efd` |
| `WitherFlowerBlock` | `80440b992b4bbe7588f723832c87551d5e129a8d8ea8d46f046e7ec8ddc561ed` |
| `WheatBlock` | `32c765a4e19506214f5450b025d1476da6d8a947143262de633f51c36120e562` |
| `SlimeBlock` | `9c5cf3602653fd5699064364906cd1f08ae445cba74674a1c9d8026aeafd24ca` |
| `BedBlock` | `aab431c7d85bc654b74215d2b2be5fbe6de81643f5e2be466658d918f272abe1` |
| `FarmlandBlock` | `27227a174fa9d51ab3b618e52d1ec6226fcd0610d4c89ed5648e113731eb66c3` |
| `HayBlock` | `a69ddb3554c2453c8d04ddeec14a1e0feed001592e49384a710f630bac0c7a64` |
| `TurtleEggBlock` | `164fae7dc599eaf0ca63217178a755d15006e2ed6def947a28cd495868f3cb66` |

**Additional dispatch/applicability files**

| File | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
| --- | --- | --- |
| `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| `net/minecraft/client/entity/living/player/ClientPlayerEntity.java` | `99b57acea68323125d859313ef5dd2c55d0703c08c5cce475c0227da0d12d1ee` | `b1ac72bad8c09f5e68e4d0682d431e3b54471e854810b94d91f830a95ae408dd` |
| `net/minecraft/server/entity/living/player/ServerPlayerEntity.java` | `82b02af5dcf3ad9ff6ab2db89fa6a48a7723913cbdb306f14e17a9b384d17728` | `77967c842ca17fc63347aecb17dfd7db2741f85998e3d99b4f959fef1f71eef4` |
| `net/minecraft/block/entity/HopperBlockEntity.java` | `1f9864f6a442307c3d55755040b47f509c466b09293bfbad65ae65be1cfabc66` | `c8db47256ef058ff2456bee676202d6b6743ac8dd8b33db2381d554004ccfd0f` |
| `net/minecraft/unmapped/C_22685453.java` (Ravager) | absent | `72e61f858ab1f124096d19c11e557e9ecfdd162ac3e7c2c26fa47829b3d23c1e` |

## Disposition and remaining boundary

For the asked post-`Entity.move` callback terminal, the common movement-writing callbacks pair with no direct result difference for local players. The source-confirmed local-player movement-contact delta in this block callback inventory is 1.14.4 `LiquidBlock` setting lava-contact state; new BerryBush is a new-feature callback and has no old-era counterpart. EndPortal has a real source change, but is server-gated. Damage/health, presentation, world-state, projectile-only, vehicle-only, server-only and mob-only callbacks are disposed above with their gates. Adjacent source-confirmed candidates are the already surfaced climb-boost gate widening and the newly documented tiny-vector piston early-return gate; neither has a trajectory claim here. Source coverage outside these exact terminal slices remains open.
