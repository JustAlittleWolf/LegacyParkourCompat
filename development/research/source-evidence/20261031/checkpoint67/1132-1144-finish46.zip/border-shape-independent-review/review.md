# Independent review: border hysteresis movement witness

## Verdict

**ACCEPT, narrowly and conditionally**, for corrected candidate SHA-256 `8a1444ec798458d05d7ee374e755f09fe2035e57576460671b2763922af976bb` and paired source report SHA-256 `7f309011405bf87acc8ab02e3c3b9ed696cfd8a135ce3b43c26d04f0f2106a2e`. The exact fixed inputs and clip arithmetic check out after the report corrected the border to a realizable square (X `[0,10]`, Z `[-5,5]`) and fixed `onGround=false` so neither endpoint takes the step alternative.

For that same current player box/request/border and full-load air snapshot, old movement with its conditional historical `outsideWorldBorder=true` bit does not border-substitute the swept exterior cells and retains X `-0.5`; new movement seeds the outside-border shape, clips at X `0`, and resolves X `-0.19999998807907104`. The movement-vector difference is `+0.30000001192092896` X. This is a conditional resolver/position terminal, not a claim that the prior bit was produced by a particular trajectory or border producer.

## Independent source check

I recomputed the listed file hashes and confirmed the relevant entries in each exact endpoint source manifest. The local player half-width is computed from `0.6F / 2.0F`, yielding binary32 `0.30000001192092896`; subtracting/adding that from center `0.5` gives X/Z bounds `[0.19999998807907104, 0.800000011920929]`. Y is `[1,2.7999999523162842]` from the same binary32 height arithmetic. With request Y zero and `onGround=false`, the old step gate (`onGround || requestedY differs from clippedY and requestY < 0`) and the new equivalent gate are false.

In 1.13.2 `WorldView.getCollisions` reads the old bit and calls `collidesWithBorder`. A true old bit contracts X bounds to `(1,9)` and Z to `(-4,4)`. Center X `0.5` fails the strict `>1` containment test. Because the prior bit `true` and query result `false` differ, the source does not update the bit. `checkWorldBorder` is false, so the block collision stream does not replace exterior cells with a full cube. With loaded air cells and no entities, the swept candidate list contains no obstacle; the old X clip remains `-0.5`.

In 1.14.4 `Entity.m_72373519` seeds the outside-border shape when it does not overlap the contracted current box. The current box lies strictly within the snapped interior rectangle X `[0,10]`, Z `[-5,5]`, so the shape is added. Its outside portion includes the player’s Y/Z slice at X `<0`; clipping a negative X request limits it to `0 - minX = -0.19999998807907104`. Since `onGround=false` and requested Y is zero, the step retry does not run. The final center is `0.5 - 0.19999998807907104 = 0.30000001192092896`, while the old center is `0.5 - 0.5 = 0`.

The old state is a valid conditional historical input: the source preserves `outsideWorldBorder=true` when the next containment result is false, so it can remain set in this one-block hysteresis band. This review does not infer how the bit became true. A bit-false old entity is outside this witness.

## Source identity

Primary roots are the exact read-only Ornithe Feather Gen2 build 2 publications at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Recomputed hashes match manifest entries; source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

| File | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `WorldBorder.java` | `7593d7a8df153f2a039a5b38cca684e1e15529b80ffde743151419e125590718` | `dc01d59f1d8ad15fdf0cc33dc4280f871ce7d62f68a1822fe7233e28f606345f` |
| `VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |

No source trees were modified. No builds, tests, runtime, game, decompilation, product/wiki/backlog, or Git history were consulted.
