# Entity and world-border collision closure: 1.13.2 → 1.14.4

## Scope and verdict

This closes the entity-shape producer inventory and compares border/entity candidate handling for the already paired collision-query route. Inputs are the exact Feather endpoint sources and the existing `.native-source/20261031/1132-1144-finish46/collision-candidate-route-pairing/report.md`. No product, wiki, backlog, or Git evidence was consulted. No source files, generated sources, builds, tests, games, or runtime trajectories were used.

**Entity candidates:** for a local-player movement query with the same swept box, same entity population and shapes, and ordinary local-player mover, I found no source-level semantic difference in the non-epsilon candidate producer outputs. Both endpoint queries exclude the mover, explicit excludes, and same-vehicle entities; both test candidate collision shapes and mover collision-against shapes. The expansion/filter boundaries differ by `0.25` versus `1.0E-7` plus a new tiny-query cutoff, so equality is not proven at tangency or degenerate-query boundaries. The only concrete built-in non-null collision-shape overrides found in either endpoint are Boat and Shulker; Boat also supplies collision-against shape, while Minecart supplies only collision-against shape. For a player mover those vehicle collision-against methods are not called (the mover's base `getCollisionAgainstShape` returns null); Boat's own collision shape and a live Shulker's shape can be candidates. Entity-shape methods themselves are equivalent at the inspected override bodies (`BoatEntity` returns `getShape`, Boat/Minecart collision-against return the other entity's shape iff it is pushable, Shulker returns its shape iff alive). Their exact method bodies are unchanged, though surrounding class files differ.

**World border:** candidate construction is not equivalent. 1.13.2 has persistent `outsideWorldBorder` hysteresis on `Entity`; each `WorldView.getCollisions` query reads the prior bit, uses it to shrink/expand the border bounds by one block, evaluates strict containment of the entity center, conditionally updates the bit, and passes that query's result to block-cell border substitution. Thus for an identical position/box/world border, a different prior `outsideWorldBorder` value can change whether outside enumerated cells become full-cube candidates. The new endpoint has no such entity field/accessors. Instead, movement seeds the clip candidate list with the border's outside-region shape when the mover's contracted current box does not overlap that shape; the shape is built as the infinite region minus the border interior snapped to `floor(min)` / `ceil(max)` block coordinates. This is a real history-sensitive candidate/gate difference and can affect a border-adjacent move; no concrete resolved-vector or collision-flag numeric witness is claimed here.

The old history bit is also reached by position/occupancy calls (`hasNoCollisions(entity, box)` delegates to old `getCollisions(entity, shape, ...)`) and can therefore be read/updated outside a movement query. New `hasNoCollisions` uses position-shaped block/entity streams and has no old-style border state mutation. Keep this position query distinct from `Entity.move`: it is not evidence of a player-move output by itself. Conversely, new `Entity.move` seeds one border shape for its normal and step resolution, while 1.13.2's vector-specific movement query re-evaluates the hysteresis gate for each query, including its distinct step query. This report does not claim a full border-transition trajectory.

## Exact path and exclusions

1.13.2 `Entity.move` calls the vector overload `WorldView.getCollisions(entity, box, dx,dy,dz)`, which constructs the signed epsilon swept candidate box and then calls the shape overload. The shape overload evaluates and mutates the hysteresis described above; `World.getCollisions` appends `EntityView.getEntityCollisions` after block candidates. The non-vector overload is a position query and does not synthesize a motion sweep.

1.14.4 `Entity.move`'s `m_72373519` forms the border stream from its current box and `WorldBorder` shape, queries entity collisions with `box.m_78709828(vec3d)` (the swept box), then seeds the clipper with entity shapes followed by the border candidate. Each resolver call reuses that list and adds only its vector-specific block candidates. `WorldView.getCollisions(entity, box, excludes)` is a separate position query that concatenates position-shaped block and entity streams.

At both endpoints, `getEntities(exclude, bounds)` forwards the excluded mover through `World.getEntities` to `WorldChunk.getEntities`, whose collector tests `entity != exclude` before adding it. The entity-collision stream additionally applies explicit exclusions and `!mover.hasSameVehicle(candidate)`. These rules close the local-player self/same-vehicle routing. The client movement candidate list is therefore not populated by the local player's own shape. In 1.14.4 the chunk collector additionally enumerates Ender Dragon parts, but those parts use the base null collision-shape methods; no local-player clipping candidate arises from that list expansion in the inspected path.

## Entity candidate boundary

The complete endpoint declaration search for `getCollisionShape` / `getCollisionAgainstShape` found only these overrides relevant to candidate emission:

| Producer | 1.13.2 | 1.14.4 | Local-player movement relevance |
|---|---|---|---|
| Base `Entity.getCollisionShape` | null | null | No candidate |
| Base `Entity.getCollisionAgainstShape(other)` | null | null | No mover-provided shape |
| `BoatEntity.getCollisionShape` | own `getShape()` | same | Can be emitted as an entity candidate |
| `BoatEntity.getCollisionAgainstShape(other)` | other `getShape()` iff `other.isPushable()` | same | Not called for the local player mover; can apply when a Boat is the mover, outside this local-player movement scope |
| `MinecartEntity.getCollisionAgainstShape(other)` | other `getShape()` iff pushable | same | Not called for the local player mover; Minecart has no `getCollisionShape` override |
| `ShulkerEntity.getCollisionShape` | own `getShape()` iff alive | same | Can be emitted as an entity candidate |

All other entity classes inherit null from base for these two methods. Candidate entities are first collected by their entity bounding boxes, with the default non-spectator filter; the collision stream then applies the candidate-shape non-null/intersection filter. Same-vehicle and explicit-set exclusions are the same operations at both endpoints. These conclusions concern the candidates' collision-shape methods, not all entity bounding-box, life-state, or world-history producers.

The collision query itself has a boundary difference: old `EntityView.getEntityCollisions` returns empty only for an empty shape, gathers entities in `shape.bounds().expand(0.25)`, then tests returned shapes against the unexpanded bounds. New `EntityView.getEntityCollisions` returns empty when average side length is below `1.0E-7`, gathers with `shape.expand(1.0E-7)`, and tests shapes against that expanded box. The old broad-phase margin alone cannot change a result when every candidate's collision shape is fully contained within its own entity bounds and the final shape intersection is false; the new epsilon final test can admit near-contact shapes and the cutoff can remove tiny queries. Neither boundary was promoted to a changed resolved clipping result without a specific exact query witness. The supplied collision-route report remains the source for broad candidate enumeration and clipper-order evidence; this report does not repeat its chunk/unloaded-state analysis.

## Hash-bound source set

All hashes are SHA-256 of full files at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{version}/ornithe-feather/`.

| File | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` | `3822844ced53882c52f0523a1bd714baa3cd9bb9dab38a5e2c53051c7b1590e3` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` | `World.java` not needed for the 1.14.4 entity-collision implementation; `WorldAccess` delegates to `EntityView` |
| `net/minecraft/world/WorldAccess.java` | not needed for the old `World.getCollisions` override | `f57639756acdedbd0e5a598f7740a8e17f0dc3b2ba710aa4690d05f4f3bcd746` |
| `net/minecraft/world/chunk/WorldChunk.java` | `d800fac11aa2672a4dd69cb5a599e5f84bb6e2c71cfc8080fa972acdabfb4914` | `42541d52fd708a689ed15e408b327d011fcea73cfa45af4c3c8dd9355aeebcf7` |
| `net/minecraft/world/border/WorldBorder.java` | `7593d7a8df153f2a039a5b38cca684e1e15529b80ffde743151419e125590718` | `dc01d59f1d8ad15fdf0cc33dc4280f871ce7d62f68a1822fe7233e28f606345f` |
| `net/minecraft/entity/vehicle/BoatEntity.java` | `3d9c248c8cb5846ac157b7973e4c6f448fe12bdc63c8d33931dace98682c0f66` | `2a33747d7d429ed58ef599de2eceddec5b377a78a1c3ddecd20def1d4907e3c9` |
| `net/minecraft/entity/vehicle/MinecartEntity.java` | `0f7039a8f22a8b0bb4e2da8c16c1c161a162214fc2ef139b245e7f059f17d13b` | `b428814058197a9ede9437816ae8fe6ec63ab72acc58cdbd302657a53e37ded6` |
| `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `35d3f858f7e06c035ee66b74b08420b678665dcdff9e4cf0619d68570966afa5` | `cea369aa7057a6adf8ec84e238458a83fe4762fa0b3ad8b230bdf5531bd1b8c` |

Line anchors: old `EntityView.java:21–35`, new `EntityView.java:53–67`; old `World.java:1754–1757`; new `WorldAccess.java:75–76`; old `WorldView.java:112–199`; new `WorldView.java:125–178`; old `Entity.java:895,1571,2262–2268`; new `Entity.java:658–665,890,1567`; old/new Boat methods around `:108–123`; old/new Minecart method around `:120–128` / `:111–120`; old/new Shulker method around `:435–439` / `:414–418`; old/new `WorldChunk.getEntities` around `:727–750` / `:482–505`; new `WorldBorder.java:46–48,~290–310` for border-shape construction.

**State:** This closes the declared entity override inventory and confirms an old history-sensitive versus new shape-derived world-border candidate path. It does not provide a concrete border vector/collision-flag witness, close epsilon/degenerate entity-query outcomes, or freeze the pair. It does not revisit chunk/unloaded-state or provider inventories.
