# Independent review: first-tick water-submersion sample

## Verdict

**Do not accept this as a separate 1.13.2-to-1.14.4 movement-cache finding.** The reported 1.14.4 cache can be stale relative to its post-relocation position in the narrow raised-reset case, but the source does not establish an old-versus-new cached-boolean delta under equal tick-entry position and effective fluid-query inputs. Accept the collision-free/equal-sample case only as a no-effect closure. Retain the relocation as context or a dependency of the separately accepted position/reset finding.

This verdict is bound to `.native-source/20261031/1132-1144-finish46/respawn-first-tick-water-sample/result.md`, SHA-256 `71ca3217064cdd3c8074ec23a751cad556d8f99cf228226b91a85715b9bd3d9e` (recomputed during review).

## Source verification

The candidate’s source identity table names the published `ornithe-feather` roots for both endpoints. I independently checked the eight named source files against their publication manifests; all eight file hashes match. The stated first-tick order is supported:

- In 1.14.4, `PlayerEntity.tick()` updates the inherited player cache before `super.tick()`. `LivingEntity.baseTick()` then applies the sleeping-position helper on `firstTick`, before delegating to `Entity.baseTick()`. The helper unconditionally calls `setPosition(bedX + 0.5, bedY + 0.6875F, bedZ + 0.5)`.
- `Entity.baseTick()` subsequently refreshes its own `Entity.submergedInWater` field and calls `updateSwimming()`. `LocalClientPlayerEntity.isSubmergedInWater()` dispatches to the separate inherited `PlayerEntity.isSubmergedInWater` cache, so that base-field refresh does not update the client-player getter’s value.
- Both endpoint `PlayerEntity.tick()` implementations sample the player cache before `super.tick()`. Both `LocalClientPlayerEntity` implementations read the player cache for `isSubmergedInWater()`; this is not a new cache separation introduced only in 1.14.4.
- New-version virtual getter use by `Entity.updateSwimming()` is verified. Movement/input reads are downstream consumers, but do not by themselves prove a cross-version delta.

The exact Java file hashes are those listed in the bound candidate report. The candidate’s claim about the collision-sensitive reset producing a raised initial position relies on its cited prior respawn/reset source review; this review treats that as a conditional input and does not claim the reset producer anew.

## Why the narrow cache claim is not independently accepted

Let `p0` be the tick-entry position and let `W(p)` be the player water-submersion query at that position. With equal raw logical position and effective fluid inputs, the old player cache is set to `W(p0)` before its base tick. The new player cache is also set to `W(p0)` before its first-tick sleeping-position relocation. The new base tick later moves to `p1` and refreshes only the base `Entity` field; its client-player getter continues returning `W(p0)`. Thus the new getter may be stale with respect to `p1`, but the old getter at its unchanged `p0` is also `W(p0)`. The cached getter output remains equal across the pair under the stated equal-input comparison.

Any downstream difference in this narrow setup must be attributed to the changed player position and position-dependent queries or other consequences of the already-identified relocation. It cannot be isolated as a newly differing cached water boolean from the evidence here. If the two releases begin at different positions because of the accepted respawn/reset behavior, their samples may differ, but that is inherited from that position delta and does not establish this cache write/refresh as a distinct operation difference.

For the ordinary collision-free case, where the first-tick bed-center placement is idempotent and both compared samples have equal effective inputs, the relocation does not change the player cache. This is a valid no-effect closure. No trajectory, collision-free waterlogged-sign fixture, active-tag producer, server behavior, or fluid producer is inferred.

## Scope and handling

Source-only review of the listed endpoint Feather Java files and their publication manifests. No product implementation, wiki, backlog, Git operation, build, test, game/runtime, or decompile workflow was consulted or run. Keep water producer/history and trajectory proof excluded. Record the narrow stale-relative-to-new-position behavior as an interaction of the accepted relocation context, not as an independent accepted movement finding.
