# Plant, crop, and aquatic plant shape-provider pairing: 1.13.2 → 1.14.4

## Scope and verdict

This source-only slice pairs all 66 common registered block IDs in the assigned provider families and all 257 raw block-state combinations they declare. Both endpoints are Ornithe Feather Gen2 build 2. The primary sources are the canonical `1.13.2/ornithe-feather` and `1.14.4/ornithe-feather` trees identified by `../providers/inventory.md`; the older registry is `net/minecraft/block/Block.java`, and the newer registry is `net/minecraft/block/Blocks.java`. IDs and state/property domains match across endpoints. For every same-ID, same-property tuple, the outline provider's normalized box formula is the same. New shape overloads accept `CollisionContext`, but these providers ignore it.

The effective base collision gate makes 65 of the 66 IDs return an empty player collision shape in every state because their registrations set `.noCollision()`. `sea_pickle` is the exception: it leaves the default `hasCollision=true` and its state-selected outline is also its effective player collision box. Its four PICKLES-dependent boxes are identical across versions. Consequently, this batch identifies no paired collision geometry difference eligible for player movement emulation. All provider formulas and state counts below are exhaustive by the registered property domains; state producers and trajectories are not evaluated.

## Registration and exhaustive per-state results

All dimensions use sixteenths of a block. Ranges include both endpoints. `empty` means the base collision provider returns an empty shape due to `hasCollision=false`; otherwise the listed outline is also the collision output.

| Registered common ID(s) | Provider(s); full raw state domain in both endpoints | Outline output for every raw state | Effective player collision |
|---|---|---|---|
| `attached_pumpkin_stem`, `attached_melon_stem` (2 IDs, 8 states) | `AttachedPlantStem`; `FACING=NORTH/EAST/SOUTH/WEST` | Direction map: N `(6,0,0)–(10,10,10)`; E `(6,0,6)–(16,10,10)`; S `(6,0,6)–(10,10,16)`; W `(0,0,6)–(10,10,10)` | Empty; both registrations use `.noCollision()` |
| `dead_tube_coral`, `dead_brain_coral`, `dead_bubble_coral`, `dead_fire_coral`, `dead_horn_coral`; `tube_coral`, `brain_coral`, `bubble_coral`, `fire_coral`, `horn_coral` (10 IDs, 20 states) | Dead IDs use `BaseCoralPlantBlock`; live IDs use `CoralPlantBlock`; both inherit `WATERLOGGED={false,true}` from `BaseCoralPlantTypeBlock` | All states `(2,0,2)–(14,15,14)` | Empty; all registrations use `.noCollision()` |
| `dead_tube_coral_fan`, `dead_brain_coral_fan`, `dead_bubble_coral_fan`, `dead_fire_coral_fan`, `dead_horn_coral_fan`; `tube_coral_fan`, `brain_coral_fan`, `bubble_coral_fan`, `fire_coral_fan`, `horn_coral_fan` (10 IDs, 20 states) | Dead IDs use `BaseCoralFanBlock`; live IDs use `CoralFanBlock`; both inherit `WATERLOGGED={false,true}` | All states `(2,0,2)–(14,4,14)` | Empty; all registrations use `.noCollision()` |
| `dead_tube_coral_wall_fan`, `dead_brain_coral_wall_fan`, `dead_bubble_coral_wall_fan`, `dead_fire_coral_wall_fan`, `dead_horn_coral_wall_fan`; live `tube/brain/bubble/fire/horn_coral_wall_fan` (10 IDs, 80 states) | Dead IDs use `BaseCoralWallFanBlock`; live IDs use `CoralWallFanBlock`; `FACING=NORTH/EAST/SOUTH/WEST × WATERLOGGED={false,true}` | For each facing regardless of waterlogged: N `(0,4,5)–(16,12,16)`; E `(0,4,0)–(11,12,16)`; S `(0,4,0)–(16,12,11)`; W `(5,4,0)–(16,12,16)` | Empty; all registrations use `.noCollision()` |
| `wheat` (1 ID, 8 states) | `WheatBlock`; `AGE=0..7` | `(0,0,0)–(16,2+2×AGE,16)` | Empty; `.noCollision()` |
| `beetroots` (1 ID, 4 states) | `BeetrootsBlock` overrides inherited wheat age with `AGE=0..3` | `(0,0,0)–(16,2+2×AGE,16)` | Empty; `.noCollision()` |
| `carrots`, `potatoes` (2 IDs, 16 states) | `CarrotsBlock` / `PotatoesBlock`; inherited `AGE=0..7` | `(0,0,0)–(16,2+AGE,16)` | Empty; `.noCollision()` |
| `nether_wart` (1 ID, 4 states) | `NetherWartBlock`; `AGE=0..3` | `(0,0,0)–(16,H,16)`, `H=[5,8,11,14]` in age order | Empty; `.noCollision()` |
| `pumpkin_stem`, `melon_stem` (2 IDs, 16 states) | `StemBlock`; `AGE=0..7` | `(7,0,7)–(9,2+2×AGE,9)` | Empty; `.noCollision()` |
| `sugar_cane` (1 ID, 16 states) | `SugarCaneBlock`; `AGE=0..15` | All ages `(2,0,2)–(14,16,14)` | Empty; `.noCollision()` |
| `grass`, `fern` (2 IDs, 2 states) | `TallPlantBlock`; no properties | `(2,0,2)–(14,13,14)` | Empty; `.noCollision()` |
| `dead_bush` (1 ID, 1 state) | `DeadBushBlock`; no properties | `(2,0,2)–(14,13,14)` | Empty; `.noCollision()` |
| `dandelion`, `poppy`, `blue_orchid`, `allium`, `azure_bluet`, `red_tulip`, `orange_tulip`, `white_tulip`, `pink_tulip`, `oxeye_daisy` (10 IDs, 10 states) | `FlowerBlock`; no block-state properties | Base `(5,0,5)–(11,10,11)` moved by the exact positional XZ offset below | Empty; all common flower registrations use `.noCollision()` |
| `brown_mushroom`, `red_mushroom` (2 IDs, 2 states) | `MushroomPlantBlock`; no properties | `(5,0,5)–(11,6,11)` | Empty; `.noCollision()` |
| `oak/spruce/birch/jungle/acacia/dark_oak_sapling` (6 IDs, 12 states) | `SaplingBlock`; `STAGE=0..1` | All stages `(2,0,2)–(14,12,14)` | Empty; `.noCollision()` |
| `kelp` (1 ID, 26 states) | `KelpBlock`; `AGE=0..25` | All ages `(0,0,0)–(16,9,16)` | Empty; `.noCollision()` |
| `kelp_plant` (1 ID, 1 state) | `KelpPlantBlock`; no properties, no `getShape` override; inherited base Block outline is a unit cube | `(0,0,0)–(16,16,16)` | Empty; `.noCollision()` |
| `seagrass` (1 ID, 1 state) | `SeaGrassBlock`; no properties | `(2,0,2)–(14,12,14)` | Empty; `.noCollision()` |
| `tall_seagrass` (1 ID, 2 states) | `TallSeaGrassBlock`; `HALF={LOWER,UPPER}` | Both halves `(2,0,2)–(14,16,14)` | Empty; `.noCollision()` |
| `sea_pickle` (1 ID, 8 states) | `SeaPickleBlock`; `PICKLES=1..4 × WATERLOGGED={false,true}` | Pickles 1: `(6,0,6)–(10,6,10)`; 2: `(3,0,3)–(13,6,13)`; 3: `(2,0,2)–(14,6,14)`; 4: `(2,0,2)–(14,7,14)`; WATERLOGGED does not affect shape | **Collision-enabled:** default properties leave `hasCollision=true`; all eight states collide with the corresponding listed box |

The 30 coral IDs are not 30 unrelated providers: the live `CoralPlantBlock`, `CoralFanBlock`, and `CoralWallFanBlock` classes inherit their relevant shape/state declarations from the paired base classes. Their common dead variants instantiate the corresponding base class directly. The `WATERLOGGED` property is inherited by the coral plant and fan families; wall fans add `FACING`. Class/property domains and formula outputs are equal for all raw states. `BaseCoralPlantTypeBlock` itself has a direct `(2,0,2)–(14,4,14)` `getShape` provider and the shared `WATERLOGGED` property, but it has no standalone registration among these IDs; every registered subclass in this family overrides that provider with the formulas shown in the table.

`FlowerBlock` is the only provider here that uses position in its outline result. Both endpoints call `state.getOffset(world,pos)` and move the same base box by the result. Both `BlockState.getOffset` implementations delegate to `Block.getOffset`; both `Block.getOffset` bodies use `hashCode(pos.x,0,pos.z)`, return X/Z jitter `((bits/15)-0.5)*0.5`, and return Y=0 for `OffsetType.XZ`. `FlowerBlock.getOffsetType()` is XZ. The method does not query a neighbor or otherwise read the world. This result is geometrically paired at the same position, and flower collision is gated empty regardless.

## Collision path, movement relevance, and dependency boundary

The old `Block.getCollisionShape(state,world,pos)` returns `state.getShape(world,pos)` only when `hasCollision`; otherwise empty (`Block.java:393–395`). In 1.14.4 the corresponding context overload applies the same gate and uses the context shape (`Block.java:376–378`); the no-context `BlockState` route may use its static cache (`BlockState.java:197–203, 410`). The assigned block registrations are static and the default cache uses empty context. All direct shape providers here ignore world, neighbors, and (new endpoint) collision context except FlowerBlock's positional offset described above. For all no-collision IDs, `hasCollision=false` dominates the outline output on the movement collision route. Sea pickle keeps the default true flag and so its per-PICKLES formula is a real local-player collision input.

The registered outputs were paired by raw property tuple. This does not claim how crops grow, waterlogging is assigned, kelp height is produced, flower positions become established, coral survives/dies, or a player trajectory reaches any particular tuple. Placement/update/growth callbacks can inspect neighbors, tags, fluid state, or supporting collision faces; those are state-producer/support behaviors outside this outline-provider pairing. The non-collision outlines do not become player collision geometry through the base collision dispatch. No waterlogged-sign trajectory, producer proof, or runtime game evidence is asserted.

## Source references and SHA-256

Paths are relative to each endpoint's `ornithe-feather` source root. Hashes are SHA-256 of the complete file; this independently recomputes the class hashes in the supplied provider inventory.

| File(s) | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | not present (old registry is `Block.java`) | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/state/StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |
| `AttachedPlantStem.java` | `9b5c6b3dad10cd26b18492c52cf715d738cf9f9ee9153e81b9495c345863bdbf` | `2870e74dca87b0ca7f6ff615d2450626c4d2e4b70190d8dbed4d2e24d065bb15` |
| `BaseCoralFanBlock.java` | `a330d4276a97b14c5038ddd817f11f976b7061d4ef004f608fa4e7c53d285516` | `7c90eb5d706a2a5471d14fd5b6637268d2d322c09e4f31d1ab13b4440198cbd0` |
| `BaseCoralPlantBlock.java` | `7c0d90ff98b063a0e97641c5c58afc1d019f3e2c8e0c6e0227b869689e179a04` | `958566defbe1f67224964e7afc58c149713b81bd3519d355fa0e8a87469bf087` |
| `BaseCoralPlantTypeBlock.java` | `661b6d0f87c8a872acd945c0716aa396ac53932d773b17e31be95b224e531fc6` | `561ff00b85e21d4256ddc91250e0ee317b48dab946de3ac71cf47ead6514630e` |
| `BaseCoralWallFanBlock.java` | `12326ecd456026b98d1b4471f54cf5f399763e33833bb4224c3e88592a4ecef0` | `91ed215892e79082363b375cae70225abe5f4b545296f13cab4c3a2418c36f03` |
| `BeetrootsBlock.java` | `9102e147211d5767e1fcb642553491414579c2ee7908a77c836bd92bdfa46497` | `83ab558b214807a1c1be064971587477a092b7d09bd3c01768f31807d976aed1` |
| `CarrotsBlock.java` | `bdff4737ca9912f6e76f6460ac7d8ccb1253861b3544238b1fce5ccc618bb307` | `3a72c65249925c2b4b98e77796505eabc3347255b6ed160a5d7bc026eadabe7a` |
| `CoralPlantBlock.java` | `1d4599b6c1e43ade173cba46cbbc17f5bc0c42a4996ac5fa8a11a9cd1c988956` | `378e4139703495c115aa30cdb046f01d16ed1e28d86d395c4681d62e2ac97f0f` |
| `DeadBushBlock.java` | `101b68c9595addc9bcedb6c49cd9908eb6bf3d9a093abc6f4584f7b94a5aa4f9` | `0615386766594e7d7fcf9a929cf1deff3cc3eb90f9a6395ab5d3febef0063732` |
| `FlowerBlock.java` | `72cc99f3abf2679c1589f2fe22c55f2850abebdf747b9ad08bb48af96d9fb1d1` | `02ed99801d9b665313b0efec6ef04fd29e0464a2fd676d5e41878ccb09462e09` |
| `KelpBlock.java` | `57330c0ac1cd00000f2e0c0f78ec98d2ec48024045b65d24f506408ea3cb8952` | `1e26cc67f68c836963a09582b24605856f9f99f08959cfab6f0b464d8b0c4707` |
| `KelpPlantBlock.java` | `dba4dffada2a7baae6a0f06e973b5af7dd175b71b9387581497087f76378751f` | `0178baad268c0ccc7ff9da8bda721f933cb3cce81736b2dcc968c8d626edd345` |
| `MushroomPlantBlock.java` | `2da1fde703c9c6a529fbc92af884927da0af631e2b4b01a28bffffc0a3bb53a8` | `72abb19d5276aa91ddd2ad3a50f25c5946225666367aab1bfc373b97a4f738cf` |
| `NetherWartBlock.java` | `dc403d65587fedcb5b72b3e9ebc44369cb8f4fa1df0855d48318195e4aa9c4f9` | `3a6ece5a35f898d2e00411156162f3ca53bd003a18de3721736be9eecbce2178` |
| `PotatoesBlock.java` | `5ec0aa93d727c7eece5232d88f71933dfc3b1228c38e22bc48ede2679c75c573` | `f831104d5ab09dfedf53372d001a76f332ce827ec869ef659a7a75080a2a9cca` |
| `SaplingBlock.java` | `8d1e15a7f20f78b68dc1a5e8560d0c84f03b9cd685e151075ae7062e0144bf26` | `0a820ff91d7f08099f9b5519c3de5dafe19f53004f3ffc6154336206fef72484` |
| `SeaGrassBlock.java` | `a3019943a0a5a61055f4731566446e662b532b75e950d8f8676ada28ff4f5b10` | `26307e005f90a8930afba830d5f928b7a178cd081280420bb5384fc4f3f3c3d3` |
| `SeaPickleBlock.java` | `1b232549de646d46b2f986d78802b0f7208978e103f00bd98fe64e4fe47d76a4` | `8adcb2c2bf60478e41ca2542ac9e661172e8c3d1bac9674fb293eca4d164e12f` |
| `StemBlock.java` | `c247cd56d97ff7d39a8436fe9a0396480158b2ead6aa3ee0870953c2ad30e35e` | `b9035f20363564a7d529864b94e4fe4c255fe0a84f721abad2a847930aeb63aa` |
| `SugarCaneBlock.java` | `09e578a7ac2442448c72b640ffb5afb94354fc4bd0188fa2a3e59e021ac0138e` | `f1b06a1613e6c0058aa666c6bd3689521627bab82f59b17055c225298820271b` |
| `TallPlantBlock.java` | `630b21b2de31c7261371da9f03f4f1dd108c65c670776ce42f72e4fcf36976f6` | `2af49d0bdc8e250dcb3484c1945766b6e0d60cae2760271e3108474b2529ea50` |
| `TallSeaGrassBlock.java` | `0876535db8acade7e4295c6044355452b936d8af99845dea71145553af35fe52` | `51230c1b8da12187b0296ee55a459a3656df3647ce817d8f1ccf104ed522f9a0` |
| `WheatBlock.java` | `f8b50a11a50f546f2b474fa20cc272a0534d4276adf94ef5c936e83edfef2d62` | `32c765a4e19506214f5450b025d1476da6d8a947143262de633f51c36120e562` |
| `CoralFanBlock.java` (inherited provider registration) | `26570c87d6bde252c8c126181fd80e64f25ac8d56f0726bfd1a09080e7ef9a22` | `d019c3615b51076dec48d238621fe6c8c7031ed65dfddb275b34c630188318b2` |
| `CoralWallFanBlock.java` (inherited provider registration) | `f85288a635e27c9222ccde668b8580f0ec715b9f8f661e3fe3aef34f7f02bd12` | `29f213cca08e66d999aac9ce555ead0aa217a2c738c81124be8a738d97359a89` |

The smaller prior shape slices contain no direct overlap for these providers: `terrain-small-shapes` covers farmland/path/carpets/cake/dragon egg/brewing stand; `small-collider-shapes` covers lily pad/turtle egg/flowerpot/cactus. The general provider inventory remains the discovery index, not a substitute for this per-state pairing.

## Limits

This closes the assigned same-ID outline and effective base collision-provider slice only. It does not close every block-shape provider in the pair, intermediate-version boundaries, active tag contents, support/face predicates, provider state production, callbacks, interactions, or movement trajectories. New-only flower IDs such as `cornflower` and `lily_of_the_valley` have no 1.13.2 counterpart and are excluded. No product implementation, wiki/backlog, or Git history was read; no canonical source was written; no build, test, decompile, game, or server was run.
