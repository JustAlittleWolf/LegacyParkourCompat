# Auto-jump callback terminal follow-up: 1.13.2 → 1.14.4

## Scope and result

Source-only follow-up for the local client player's post-move auto-jump callback and its next-tick forced-jump terminal. The exact inputs are Ornithe Feather Gen2 build 2, 1.13.2+build.2 → 1.14.4+build.2, with the source manifests identified in the permitted callback-consumer report (`2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`). Sources are read-only at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. The paired callback and collision-candidate reports were used only for the explicitly recorded source identity and previously paired collision-route context. No product, wiki, backlog, or Git information was used.

**Result:** no source-level scheduled-jump difference is demonstrated for the bounded common-provider case below. Both versions produce the same candidate box, clearance answers, height, and `ticksToNextAutojump = 1`, conditional on equal callback inputs that pass the paired scalar gates. The callback/query dependency is **not closed generally**: provider contexts outside the base full-cube/air case, entity and border candidates, candidate ordering, and empty-chunk behavior remain outside this bounded equivalence.

This is a direct callback terminal comparison, not a claim that an input or block-state history is reached by an ordinary movement trajectory. Raw movement, state, and query histories are inputs here; their producers are not analyzed.

## Paired callback and forced-input route

1. `LocalClientPlayerEntity.move` snapshots X/Z, calls `super.move`, then invokes `autoJump((float)(x - oldX), (float)(z - oldZ))` in both versions (1.13.2 `:871–876`; 1.14.4 `:846–851`). The superclass movement query is the paired `Entity.move` route recorded in `collision-candidate-route-pairing/report.md` (1.13.2 `Entity.move` collision query at `:578–580`; 1.14.4 `Entity.move` delegates through `:463–468` to `m_72373519` at `:656–685`). The exact resolved `dx`/`dz` remain callback inputs; this report does not establish their production history.
2. `autoJump` has the same enabling and state gates: enabled; cooldown `<= 0`; grounded; not sneaking; not riding; nonzero input vector; fallback movement vector squared length above `0.001F`; and facing dot product not below `-0.15F` (old `:882–908`, new `:857–883`). Both then require empty collision shapes at the block at `getShape().maxY` and the block above it (old `:909–915`, new `:884–890`).
3. Both set the unboosted clearance limit to `1.2F`; jump boost adds `(amplifier + 1) * 0.75F`. They calculate `p = max(speed * 7.0F, 1.0F / l)`, construct the same swept `Box` from the pre/post horizontal points and player height, grow X/Z by player width, then build the two raised probe segments at `+0.51F` (old `:915–934`, new `:890–909`). 1.14.4 uses `getWidth()`/`getHeight()` where 1.13.2 reads the fields; 1.14.4's getters return `dimensions.width`/`dimensions.height` (`Entity.java:2628–2633`). This comparison conditions on equal effective dimensions, as the paired callback does not independently close dimension production.
4. Old code iterates `world.getCollisions(this, box)` (old callback `:935`) and new code iterates `world.getCollisions(this, box, Collections.emptySet())` (new callback `:910–914`). In either version, the first returned bounding box intersecting either raised probe supplies `s = box.maxY`; the code samples collision shapes above the intersecting box center and may reject a too-high obstruction (old `:938–963`, new `:917–942`). Without jump boost, `o == 1.2F`, so the integer loop visits only `t == 1`. If the final rise `u = s - getShape().minY` satisfies `u > 0.5F && u <= o`, both write `ticksToNextAutojump = 1` (old `:968–972`; new `:947–951`).
5. On the next `mobTick`, both decrement a positive cooldown, set the corresponding suppression flag, and set `input.jumping = true` (old `:711–715`; new `:639–643`). This is the callback's forced-input terminal; the following ordinary jump dispatch is downstream of this same staged input.

The listed scalar gates, projected probe construction, terminal interval, and scheduled-input write are paired source facts. The old/new differences relevant to this bounded query are the 1.14.4 `CollisionContext.of(this)` argument at every callback shape lookup, the `Set` argument on `getCollisions`, and the underlying world-query implementation. They do not change the result for the provider setup defined next.

## Bounded common-provider/query closure

Use equal callback/player inputs passing the paired gates, no jump-boost effect (`o == 1.2F`), matching effective width/height and `getShape`, a loaded interior query away from the world border, no entity candidates, and a query candidate set with exactly one intersecting base full-cube block. The cube is an interior cell actually overlapping the callback query/probe; all queried head-clearance cells and the single unboosted overhead-clearance cell are ordinary air. No movement/state producer is asserted.

- In 1.13.2 the callback's `Box` overload converts the box to a voxel shape and invokes the world collision stream. `WorldView.getCollisions(entity, Box)` is at `:166–167`; `World.getCollisions` appends entity candidates at `:1754–1757`; the base block scan is `WorldView.getBlockCollisions(VoxelShape, ...)` at `:108–151`. The base full-cube provider returns the unit cube when `hasCollision` is true (`Block.getCollisionShape`, `:393–395`; `BlockState.getCollisionShape`, `:209–210`).
- In 1.14.4 the callback calls `WorldView.getCollisions(entity, Box, Set)` (`:129–131`), which concatenates block and entity streams. Its block scan is `getBlockCollisions(entity, Box)` (`:133–180`), computes `CollisionContext.of(entity)`, and emits translated shapes that overlap the query. The base `Block.getCollisionShape(..., context)` has the same `hasCollision` gate and uses the state's shape (`:376–378`); `BlockState.getCollisionShape(..., context)` dispatches to that provider (`:201–203`). This base full-cube output is already paired as the same unit cube in `provider-state-pairing/result.md`.
- For this setup, the old full-cube aggregation yields the single same unit-box candidate, while the newer stream yields that same translated unit box. Empty entity and border candidate sets add nothing. The callback therefore sees the same sole intersecting `box2`, sets the same `s`, and queries the same empty air shapes for its head and overhead clearance. The same `u` enters the same final interval test, so scheduling `ticksToNextAutojump = 1` is identical.

This closes only this one-candidate base-full-cube/air setup, conditional on the stated equal raw callback inputs. It does not infer that the query candidate set has this form in any particular trajectory.

## Paired query/gate roster and open terminal members

| Route | Paired source call/gate | Status for this follow-up |
|---|---|---|
| Post-move callback entry | `LocalClientPlayerEntity.move` → `super.move` → `autoJump(float,float)` | Same callback call shape; `dx`/`dz` are raw paired inputs. The full movement query's candidate/clipper differences remain in the permitted collision-route report. |
| Callback eligibility | enabled, cooldown, grounded, sneak, ride, movement-vector and facing tests | Paired. Equal input/state values make the gates equal. |
| Headroom and obstacle geometry | two initial shape-is-empty checks; same swept box and two probe segments; first intersecting candidate; above-center clearance loop; final `0.5F < u <= o` test | Paired control flow. Same answers and candidate in the bounded case. |
| Block provider dispatch | old context-free shape route vs 1.14.4 contextual shape route | Closed for base full cube and queried air only. Other contextual/state/neighbor-sensitive providers remain open. |
| Collision query candidates | old box-to-voxel route and world entity append vs new block/entity concatenation, contextual scan, and candidate filtering | Closed only for one interior overlapping full cube, loaded cells, no entities and deep-interior border. Broad candidate equivalence/order is open. |
| Callback terminal and next tick | `ticksToNextAutojump = 1`; next `mobTick` decrements and forces `input.jumping = true` | Paired. No scheduled-jump delta in the bounded setup. |

**Open member residual:** `LocalClientPlayerEntity.autoJump` is not generally closed at the branch that selects the first intersecting collision box and at the subsequent contextual clearance lookups. The exact paired members are old `autoJump` `:882–980` and new `autoJump` `:857–955`; residual dependencies are the `WorldView.getCollisions`/`getBlockCollisions` routes and state `getCollisionShape` providers listed above. In particular, the older block scan can read through its `allowEmpty=true` route where the newer scan omits a null non-loading full chunk; candidate populations/order and contextual provider outputs are not established for those cases. The permitted collision-route report records the broader query limits. No auto-jump-specific output witness or reachability claim is made for those open branches.

## Evidence identity and hashes

Canonical trees: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`; both are the permitted Feather Gen2 build 2 source sets. The source-manifest identities are given above. Source-file SHA-256 values were recomputed read-only and agree with the callback follow-up where overlap exists.

| Version | Source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.14.4 | `net/minecraft/world/World.java` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

Exact member-excerpt SHA-256 values below hash the listed 1-based source lines joined with LF, UTF-8 encoded, with no terminal LF. File hashes above remain the canonical whole-file identities.

| Version | Member excerpt (exact line interval) | SHA-256 |
|---|---|---|
| 1.13.2 | `LocalClientPlayerEntity.move` `871–876` | `470de74594581ac10848b9e010ad124baa99b6ef2e20c9150989d764a4e0f653` |
| 1.14.4 | `LocalClientPlayerEntity.move` `846–851` | `017d89aac16cd165fdc729816f15d0cc40f32fc547e235f032e110bbf5693bfd` |
| 1.13.2 | `LocalClientPlayerEntity.autoJump` `882–980` | `b6e4c904937d60167272aa8cb500c0656ed92a7cccd79545597154c3f20998a6` |
| 1.14.4 | `LocalClientPlayerEntity.autoJump` `857–955` | `be38812c94537a5a66f8436965550de085619ba303aa285b7b06884f19d4a281` |
| 1.13.2 | forced input in `mobTick` `711–715` | `bfa1ec0ad4e7f62c6eb71445364125f2489c2e6fa94ac8e1f42f07ad9c97e283` |
| 1.14.4 | forced input in `mobTick` `639–643` | `48fa8d37b69563250847fc4475b205990f31cd2d342f5fe4f7ef3aa50d848294` |
| 1.13.2 | `Entity.move` collision-query call `578–580` | `d7641458d8859e4d2d4744733cfaf92e245d73d9eb1561d4ca26dc4d7d39311c` |
| 1.14.4 | `Entity.move` delegate `463–468` | `74ec402cbf7ec9a012de842ccf8c4c0e61c2c31f097f1f044a09469ee92c28bd` |
| 1.14.4 | `Entity.m_72373519` query/seed route `656–685` | `e90725b58861a33a9f23d9aa3434b6e6a37b21e829a98688c3297a6344b73c8c` |
| 1.13.2 | `WorldView.getBlockCollisions` `108–151` | `26eff2f2a46e08a6378b4f8821a4667a93b4d51e1d71149d924a23b658f9801d` |
| 1.13.2 | `WorldView.getCollisions(entity, Box)` `166–167` | `7edaeef53c8c11b62a3aff44e156b9392fc67420ffb9c26decac14924d139bd3` |
| 1.13.2 | `World.getCollisions` override `1754–1757` | `d8772dd82f54f85a3c344ed05fc3195dd5f55563da9d1bdf82228aa1ff95c997` |
| 1.14.4 | `WorldView.getCollisions` and block scan `129–180` | `4014023d08e30c0dd61164e8555a4ef609a602b68e1965d777b622b603e13afa` |
| 1.13.2 | `Block.getCollisionShape` `393–395` | `bf8df9877780458d0dcda1de4d71c8de2081ae9c0d4e262ae3840ecbc51a8a84` |
| 1.13.2 | `BlockState.getCollisionShape` `209–210` | `83a66ec33a4ee15fceb2aaf739f597422aea8d36d71fb544d9d7074b6c035821` |
| 1.14.4 | `Block.getCollisionShape` `376–378` | `bde10a15f02e1ac143a97f57478a534426037112c9cc0ea0582180e5082754c6` |
| 1.14.4 | `BlockState.getCollisionShape` `197–203` | `940389f6224bf8f5fdece0769dc61ed64c26cfcc14753882e21adc186ed30fcc` |

No source tree was written. No build, tests, game launch, decompile, network, implementation, or trajectory analysis was performed. This report does not freeze the pair or claim runtime parity.
