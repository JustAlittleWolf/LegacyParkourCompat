# Old border hysteresis can allow an outward clip through the new border shape

Assume an identical fully loaded vanilla movement snapshot at both endpoints: square world border bounds X `[0,10]`, Z `[-5,5]` (center `(5,0)`, size `10`); local player position `(0.5,1,0.5)` with standing dimensions `0.6F × 1.8F`; `onGround=false`; and movement request `(-0.5,0,0)`. The source's `setPosition` arithmetic yields X/Z box bounds `[0.19999998807907104,0.800000011920929]` and Y `[1,2.7999999523162842]`. All block cells visited by the swept query are air and no entities collide. The old endpoint's stored `outsideWorldBorder` bit is true. The same current box, border, block states, on-ground flag, and movement request are used on the new endpoint; the old-only stored bit is a conditional input, not a claim about its producer history. Zero requested Y and `onGround=false` exclude the step alternative in both move paths.

**1.13.2, Ornithe Feather:** `Entity.move` requests the vector-specific `WorldView.getCollisions` stream. `WorldView.collidesWithBorder` sees the stored outside bit and contracts the border bounds by one block, so it checks the player's center against X `(1,9)` and Z `(-4,4)`. Since X `0.5` is not greater than 1, the result is false. The query then passes `checkWorldBorder=false` into `getBlockCollisions`. Its outside-border cell substitution is guarded by `checkWorldBorder`, so the exterior cells in the swept query resolve to the assumed air states, and X clipping retains the requested `-0.5` displacement.

**1.14.4, Ornithe Feather:** there is no entity `outsideWorldBorder` field. `Entity.m_72373519` obtains the outside-region `WorldBorder` shape, tests it against the contracted current player box, and seeds that shape as a clipping candidate because the current box is interior. The border shape is the infinite region with the snapped interior rectangle removed, so it includes X `<0` at the player's Y/Z coordinates. The current minimum X is `0.19999998807907104`; clipping request `-0.5` against the shape yields resolved X `-0.19999998807907104`, placing the box at X=0. The old resolved X remains `-0.5`. The final movement vectors differ by `+0.30000001192092896` X, and the resulting player centers are X=0 versus X=`0.30000001192092896`.

The old `outsideWorldBorder=true` state can persist while the player center lies within one block of the border: the old comparison does not update the bit when the prior and current booleans differ. This report conditions on that stored input but does not assert how a prior tick or position query produced it. A freshly initialized old entity with the bit false is not covered by this witness.

This is a conditional movement-resolver result for the stated loaded world, border, raw box and old hysteresis bit. It does not establish a border transition trajectory or server/client border production. The source operation difference is reviewed separately; endpoint source evidence is below.

## Exact source evidence

Primary source roots are read-only Ornithe Feather Gen2 build 2 at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.

| Release | Source file | Relevant member/range | SHA-256 |
|---|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `outsideWorldBorder` field and accessors; `Entity.move` collision query | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `getCollisions` / `collidesWithBorder` / border cell substitution, lines 130–199 | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.13.2 | `net/minecraft/world/border/WorldBorder.java` | min/max border bounds | `7593d7a8df153f2a039a5b38cca684e1e15529b80ffde743151419e125590718` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java` | axis clipping and overlap | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` |
| 1.13.2 | `net/minecraft/util/math/Box.java` | player box and vector expansion | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | selected air collision result | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `m_72373519`, lines 656–665 | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | contextual block stream and entity collision stream, lines 129–178 | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.14.4 | `net/minecraft/world/border/WorldBorder.java` | `m_91823398` and static outside-region shape construction | `dc01d59f1d8ad15fdf0cc33dc4280f871ce7d62f68a1822fe7233e28f606345f` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java` | axis clipping and overlap | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| 1.14.4 | `net/minecraft/util/math/Box.java` | player box and vector expansion | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | selected air collision result | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

The endpoint source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; these source rows are also listed in the existing `collision-border-entity-closure/result.md` manifest cross-check. No source tree was changed or regenerated.
