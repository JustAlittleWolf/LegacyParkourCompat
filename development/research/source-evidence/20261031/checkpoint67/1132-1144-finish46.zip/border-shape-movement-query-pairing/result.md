# Border hysteresis versus shape-seeded clipping: conditional movement witness

## Result

The old stored `outsideWorldBorder` input can suppress old border-cell substitution while the new entity mover seeds and clips against the outside-border shape. For one fixed full-load snapshot, the old resolver retains X request `-0.5` and the new resolver clips to `-0.19999998807907104`. This proves a conditional movement-terminal difference for the same current player box, movement request, border bounds and ordinary air states, conditional on the old-only `outsideWorldBorder=true` value. It does not establish how that prior bit was produced or a border-crossing trajectory.

## Fixed raw inputs and arithmetic

- World border: square static bounds X `[0,10]`, Z `[-5,5]`, set by center `(5,0)` and size `10`.
- Local player position `(0.5,1.0,0.5)`, standing dimensions `0.6F × 1.8F`, `onGround=false`. Both source `setPosition` methods use a float half-width `0.6F/2.0F = 0.30000001192092896`; the resulting box is X/Z `[0.19999998807907104, 0.800000011920929]`, Y `[1.0, 2.7999999523162842]`.
- Request `(-0.5,0,0)`. Assume all cells that the old swept block query enumerates and all chunks requested by the new non-loading query are available and contain air; there are no colliding entity candidates.
- Old-only stored input `outsideWorldBorder=true`; the same old on-ground state is false and requested Y is zero on both endpoints, so the step alternative is not selected.

## Exact old route

1.13.2 `Entity.move` calls `world.getCollisions(this, shape, dx,dy,dz)` (`Entity.java:578–580`). `WorldView.getCollisions` reads `entity.isOutsideWorldBorder()`, calls `collidesWithBorder(entity)`, then passes the returned boolean as `checkWorldBorder` (`WorldView.java:170–176`). For prior bit `true`, `collidesWithBorder` increments min X/Z and decrements max X/Z by one; it returns true only if the entity center is strictly inside these contracted bounds (`WorldView.java:180–199`). Here the effective X test is `0.5 > 1.0`, false. Since old prior bit true differs from this false result, the bit is not updated (`:171–174`) and `checkWorldBorder=false` for the current collision request.

`getBlockCollisions` substitutes a full cube for an out-of-border enumerated cell only behind the `checkWorldBorder && ...` condition (`WorldView.java:130–137`). With `checkWorldBorder=false`, outside cells use their assumed air states. Thus the block-candidate stream is empty, and the resolver returns the full requested X displacement `-0.5`.

## Exact new route

1.14.4 `Entity.m_72373519` obtains `world.getWorldBorder().m_91823398()`, tests that shape against the contracted current box, and seeds the shape candidate when the contracted box has no overlap (`Entity.java:656–665`). The player's current box is wholly inside X `[0,10]`, so it does not overlap the border's outside shape and that shape is included.

The static `WorldBorder` extent constructs the shape as the infinite region minus the snapped interior block rectangle `[floor(minX),ceil(maxX)] × [floor(minZ),ceil(maxZ)]`, with unbounded Y (`WorldBorder.java:299–314`). For the stated bounds, the candidate has an exterior X face at 0 and includes the player's Y/Z slice. X-axis clipping against that face limits negative movement to the gap between the player box minimum and 0: `0 − 0.19999998807907104 = -0.19999998807907104`. The final player center is X `0.30000001192092896`, whereas the old unbounded displacement writes center X `0.0`.

## Scope and open history

The old bit can remain true as the center re-enters the one-block hysteresis band: when `outsideWorldBorder=true`, the old bound shrinks by one, the collision result is false for center X `0.5`, and the method deliberately retains the true bit because old bit and current result differ. This source report uses that state as a conditional historical input; it does not prove a specific preceding client trajectory. A bit-false old snapshot has a different gate and is not included.

The reported difference concerns the direct `Entity.move` resolved-vector/position terminal under the stated input. It excludes server border production, block/entity producer histories, and trajectory parity. Existing route inventories remain broader and pair freeze requires the rest of the eligible terminal graph and independent audit.

## Source identity

Read-only endpoint roots are exact Feather Gen2 build 2 source publications at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4). I recomputed every file hash below and matched it to the corresponding manifest row.

| File | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/world/border/WorldBorder.java` | `7593d7a8df153f2a039a5b38cca684e1e15529b80ffde743151419e125590718` | `dc01d59f1d8ad15fdf0cc33dc4280f871ce7d62f68a1822fe7233e28f606345f` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `net/minecraft/block/shape/VoxelShape.java` (`calculateMaxDistance`: old line 184+, new line 203+) | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

No product/wiki/backlog/Git sources were read or changed. No source tree was written or regenerated; no runtime, build, tests or game launch was run.
