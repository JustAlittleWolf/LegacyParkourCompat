# Ordinary gate follow-up: 1.13.2 → 1.14.4

**Scope:** Recheck only climb jump reachability, submerged sprint-forward threshold, and camera-flight jump+sneak rounding. Primary sources are the ready Ornithe Feather trees at both endpoints. This is bounded source evidence, not pair-completion acceptance. The rejected waterlogged-sign trajectory and water-gravity trajectory were not reopened.

## Pinned source identity

Both ready markers report `status=ready`, `versionId` matching the folder, `mapping=ornithe-feather`, and Vineflower decompilation. The 1.13.2 provenance records `mappingOption=feather`; the 1.14.4 Feather provenance records `mappingOption=feather,mojmap` and namespace `ornithe-feather`.

- 1.13.2 `ornithe-feather.ready.json`: source-manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; artifact-manifest SHA-256 `fdcacd9150f98ea70acafc5cab754027ab1a09828ff0eaa8e542dd7890d9ce1e`; `clientSha256` `3410887ba652f25792c7675bfaf9140e73b60e93cfbf113a803f8a98cb05c0f9`.
- 1.14.4 `ornithe-feather.ready.json`: source-manifest SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; artifact-manifest SHA-256 `308cc33ef6dffc047432ade6affc88eccc9de94a736ee9a98571fd92915c2970`; `clientSha256` `b3b2a798e2d67b566008fe4a03767ae2c7ff3f8c7ba6751e7b71fc7299672d0a`.

The on-disk SHA-256 of each source and artifact manifest matches its ready marker. The ready `clientSha256` values match the corresponding `client.jar` entries in each artifact manifest. Complete cited source-file hashes below match the per-endpoint source manifests.

## Findings

### Climb jump gate: ordinary branch-exclusive state is source-reachable

The endpoint operation changes from old `collidingHorizontally && isClimbing()` (`1.13.2 LivingEntity.java:1575–1578`) to new `(collidingHorizontally || jumping) && isClimbing()` (`1.14.4 LivingEntity.java:1844–1849`). A local jump key sets `input.jumping`; the local player's camera AI step copies it to the entity's `jumping` field (`1.13.2 LocalClientPlayerEntity.java:635–648`; `1.14.4 LocalClientPlayerEntity.java:601–616`). The shared living update runs that AI step before travel (`1.13.2 LivingEntity.java:1890–1928`; `1.14.4 LivingEntity.java:2191–2228`).

A minimal ordinary state satisfying the exclusive new condition is a non-spectator local player in a ladder block cell, with x/z velocity and directional input zero and jump held. Both endpoint climb predicates accept a ladder in the queried cell (`1.13.2 LivingEntity.java:1046–1057`; `1.14.4 LivingEntity.java:1239–1252`). With zero requested x/z movement, the move result cannot report a horizontal clip: old `Entity.move` derives `collidingHorizontally` from changed x/z (`1.13.2 Entity.java:677–680`), while new derives it from x/z displacement inequality (`1.14.4 Entity.java:472–475`). Thus `jumping && isClimbing && !collidingHorizontally` is reachable without a horizontal collision witness. New post-move handling assigns Y velocity `0.2`; old handling skips that assignment. **Verdict: source-closed ordinary gate and post-move delta for this ladder state.** This does not assert a broader collision trajectory or cover scaffolding.

### Submerged sprint threshold: source-closed input witness

Old keyboard input scales forward input to `0.3F` while sneak is held (`1.13.2 KeyboardInput.java:45–49`). The old sprint-key branch tests `movementForward >= 0.8F` (`LocalClientPlayerEntity.java:738–745`). New keyboard input also scales sneak input to `0.3F` for a non-spectator (`1.14.4 KeyboardInput.java:13–25`); new `Input` defines forward impulse as strictly `movementForward > 1.0E-5F` (`Input.java:21–24`). New local-player helper uses that positive-input predicate while submerged, retaining the `0.8` threshold otherwise (`LocalClientPlayerEntity.java:960–963`). Its sprint-key branch calls the helper and has no sneak exclusion (`:669–676`); the old branch directly requires `>=0.8F` and likewise has no sneak exclusion (`1.13.2 LocalClientPlayerEntity.java:738–745`).

Therefore, for a non-spectator submerged player holding forward+sneak+sprint, with ordinary sprint eligibility (not already sprinting, sufficient food or flight ability, not using an item, and not blind), new input `0.3F` passes the submerged positive check while old `0.3F` fails `0.8F`. Input is ticked before these start gates on both endpoints (`1.13.2 LocalClientPlayerEntity.java:698–706`; `1.14.4 LocalClientPlayerEntity.java:624–634`). **Verdict: source-closed sprint-key start-gate difference, conditional only on the stated submerged/eligibility state.** Auto-start is not needed for this witness.

### Camera flight with jump+sneak: conditional arithmetic-to-deadzone witness; incoming state open

At default ability speed `0.05F` (`PlayerAbilities.java:11` both versions), old camera flight executes `velocityY = velocityY - getFlySpeed() * 3.0F` followed by the matching addition (`1.13.2 LocalClientPlayerEntity.java:797–806`). The getter returns a float at both endpoints (`PlayerAbilities.java:44–49`), so the shared binary32 operand is `d = 0.05F * 3.0F = 0.15000000596046448`. New accumulates sneak/jump as `j--` and `j++`, and skips vector addition when they cancel (`1.14.4 LocalClientPlayerEntity.java:728–741`).

The old arithmetic is not an identity for every possible binary64 input. For `v = nextDown(0.003) = 0.0029999999999999996`, binary64 evaluation gives `(v - d) + d = 0.0030000000000000027`; new `j == 0` preserves `v`. The endpoint local-player method then calls its superclass living tick (`1.13.2 LocalClientPlayerEntity.java:837`; `1.14.4 LocalClientPlayerEntity.java:773`), whose `<0.003` Y-velocity cleanup zeros the new value but retains the old rounded value (`1.13.2 LivingEntity.java:1882–1884`; `1.14.4 LivingEntity.java:2182–2184`). This would create a movement-input delta on that tick if the stated incoming value is reached.

The ordinary producer for this narrow incoming-value interval is **not closed**. The bounded default-speed idle-decay path from one jump increment crosses from `0.003038963726486927` to `0.0029781845099208218`, and the latter does not round above the deadzone; no other camera velocity-producing input sequence was searched. **Verdict: exact conditional arithmetic/deadzone witness; ordinary reachability/effect remains open.** Do not claim a guaranteed camera-flight difference.

## Exact source file hashes

SHA-256 hashes below were recomputed from the canonical files and matched their endpoint source-manifest entries.

| Endpoint | Canonical file | SHA-256 |
|---|---|---|
| 1.13.2 Feather | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.14.4 Feather | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.13.2 Feather | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 Feather | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 Feather | `net/minecraft/client/entity/living/player/KeyboardInput.java` | `7be11425906be051c83e275f359816546e4677b16d212156380e8d2e9258654a` |
| 1.14.4 Feather | `net/minecraft/client/entity/living/player/KeyboardInput.java` | `5932453a9e48e7a798ae1be1cd3a4bf660b6b3be43bb7e5dc22686b3c4a82526` |
| 1.14.4 Feather | `net/minecraft/client/entity/living/player/Input.java` | `acb63d46fb6e6a1cb6b285a5d0702fb62575f7d54344ad1f0f9d51e8f671f33f` |
| 1.13.2 Feather | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 Feather | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 Feather | `net/minecraft/entity/living/player/PlayerAbilities.java` | `03c506732bb599c2a6d5f6c7d6f13175b9d27a0abfd9058811cf443f51af012d` |
| 1.14.4 Feather | `net/minecraft/entity/living/player/PlayerAbilities.java` | `706f0011836698a9be661cda922d42c7143fdb385b7086ed79143ef3d68874ee` |

## Coverage

- **Closed:** ordinary ladder jump gate reachability from zero horizontal movement; submerged sprint-key threshold/input witness.
- **Conditional/open:** camera-flight rounding reaches the living Y deadzone for a specific binary64 input, but no ordinary camera-flight producer reaches that input yet.
- **Not examined:** any other ordinary gate, the rejected waterlogged-sign trajectory, the water-gravity trajectory, full pair coverage, and runtime parity.
