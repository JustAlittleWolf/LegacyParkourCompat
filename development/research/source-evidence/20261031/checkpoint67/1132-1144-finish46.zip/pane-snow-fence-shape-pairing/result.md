# Glass pane, snow layer, and oak fence state-shape pairing (1.13.2 → 1.14.4)

## Scope and evidence

Source-only endpoint comparison using Ornithe Feather Gen2 build 2 on both sides. Canonical trees are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. The source publication identities and verified source-manifest, ready-marker, and provenance hashes are recorded in `../providers/inventory.md`; this pass did not write or regenerate those trees. The compared file hashes are listed below.

Paired registered IDs: `minecraft:glass_pane`, `minecraft:snow`, and `minecraft:oak_fence`. I compared shape-table construction and outline/collision provider outputs over every raw state combination in each endpoint's `buildStateDefinition`. These are shape-input results only. No state-production or ordinary player trajectory was assessed, and this does not claim full provider coverage or pair freeze. The parent scope's default vanilla tag recipe is established; custom/runtime replacements are excluded.

## Query and cache dispatch

- In 1.13.2, `BlockState.getShape(world,pos)` dispatches to `Block.getShape(state,world,pos)` and `BlockState.getCollisionShape(world,pos)` dispatches to `Block.getCollisionShape`. Base `Block.getCollisionShape` applies `hasCollision` and then calls the state's shape method. The three registered blocks have ordinary collision enabled.
- In 1.14.4, `BlockState.getShape(world,pos,context)` dispatches to the context overload and the entity collision query can call `getCollisionShape(world,pos,context)`. The no-context collision query returns a cached collision shape when present, otherwise calls the empty-context overload. Static cache construction computes that shape from `Block.getCollisionShape(state,DummyBlockView,origin,CollisionContext.empty())`. These provider methods ignore world, position, and context, so cache, empty-context, and entity-context dispatch produce the same paired result.
- 1.14.4 `BlockState.cacheShape` caches only when `!block.hasDynamicShape()`. `Block.Properties` defaults to a non-dynamic shape; none of these registrations changes it. Thus static cache routing does not introduce a state-specific result difference here.

## State/output pairing

Pane connection bits use `1 << Direction.getIdHorizontal()`: SOUTH=1, WEST=2, NORTH=4, EAST=8. The bitmask is the sum of the connected directions. In both endpoints pane tables are built from the same central post plus the same union of the connected arms; the table-index decision reads only NORTH/EAST/SOUTH/WEST. WATERLOGGED does not affect outline or collision geometry. The new per-state index memoization in `PaneBlock.getShapeIndex` caches the same integer mask and changes no result.

| Registered family and raw state row set | Outline result for each row | Collision result for each row |
|---|---|---|
| `glass_pane`: for each `m ∈ [0,15]`, `N/E/S/W` equal the corresponding bit in `m`, and for each `w ∈ {false,true}`, `WATERLOGGED=w` (32 rows) | Both endpoints select `PaneBlock.collisionShapes[m]`. In both registrations this is the same 16-entry union table built by `IronBarsBlock(1,1,16,16,16,...)`: 2/16-wide central post plus connected 2/16-wide arms, extending to the block top. | Both endpoints select `PaneBlock.shapes[m]`, built from the same `IronBarsBlock(1,1,16,16,16,...)` recipe. This has the same 16-entry union geometry as the outline table. Waterlogged does not alter either result. |
| `snow`: `LAYERS=n` for each `n ∈ {1,2,3,4,5,6,7,8}` (8 rows) | Both endpoints return `SHAPES[n]`, a full-footprint box from y=0 to `2n/16`. | Both endpoints return `SHAPES[n-1]`, a full-footprint box from y=0 to `2(n-1)/16`; layer 1 is empty and layer 8 is a full cube. |
| `oak_fence`: for each `m ∈ [0,15]`, `N/E/S/W` equal the corresponding bit in `m`, and for each `w ∈ {false,true}`, `WATERLOGGED=w` (32 rows) | Both endpoints inherit `PaneBlock.getShape` and select `collisionShapes[m]`, built by `FenceBlock`'s `PaneBlock(2,2,16,16,24,...)` parameters: the central post and selected arms rise to y=16/16. | Both endpoints inherit `PaneBlock.getCollisionShape` and select `shapes[m]`, built from the same parameters: central post and selected arms rise to y=24/16. This 1.5-block collision height is present at both endpoints. Waterlogged does not alter either result. |

The table covers 72 explicit raw rows (32 glass-pane + 8 snow + 32 oak-fence). For the two four-direction families, each mask row occurs once with `WATERLOGGED=false` and once with `WATERLOGGED=true`; the output equations in the table apply to each of those individual rows. No output difference was found.

For explicit mask-to-state coverage, the following 16 rows are applied independently to both `glass_pane` and `oak_fence`; each row stands for its two waterlogged values. On each endpoint, the named direction set is exactly the set of true connection properties and both providers return that mask's table entry:

| Mask | True connection properties | Glass-pane outline/collision table index, both endpoints | Oak-fence outline/collision table index, both endpoints |
|---:|---|---:|---:|
| 0 | none | 0 | 0 |
| 1 | SOUTH | 1 | 1 |
| 2 | WEST | 2 | 2 |
| 3 | SOUTH, WEST | 3 | 3 |
| 4 | NORTH | 4 | 4 |
| 5 | NORTH, SOUTH | 5 | 5 |
| 6 | NORTH, WEST | 6 | 6 |
| 7 | NORTH, SOUTH, WEST | 7 | 7 |
| 8 | EAST | 8 | 8 |
| 9 | EAST, SOUTH | 9 | 9 |
| 10 | EAST, WEST | 10 | 10 |
| 11 | EAST, SOUTH, WEST | 11 | 11 |
| 12 | NORTH, EAST | 12 | 12 |
| 13 | NORTH, EAST, SOUTH | 13 | 13 |
| 14 | NORTH, EAST, WEST | 14 | 14 |
| 15 | NORTH, EAST, SOUTH, WEST | 15 | 15 |

For snow the eight rows are `LAYERS=1..8`, paired respectively to outline table indices `1..8` and collision table indices `0..7`, with box heights given above.

### Registration identity and old glass-pane alias

- 1.13.2 `Block.java:1184` registers `minecraft:glass_pane` as `GlassPaneBlock`; the old `GlassPaneBlock` subclass only specializes drops and extends `IronBarsBlock`, whose constructor supplies shape parameters `(1,1,16,16,16)`. It has the same inherited state definition and provider outputs as the 1.14.4 registration.
- 1.14.4 `Blocks.java:707` registers `minecraft:glass_pane` directly as `IronBarsBlock` with the same material/strength/sound properties and same constructor shape parameters. `GlassPaneBlock` is therefore a removed implementation alias/subclass, not an additional registered vanilla state ID to pair separately.
- 1.13.2 `Block.java:1067` and 1.14.4 `Blocks.java:559` register `minecraft:snow` as `SnowLayerBlock`; each `buildStateDefinition` adds `LAYERS`, whose raw values are 1–8.
- 1.13.2 `Block.java:1075` and 1.14.4 `Blocks.java:574` register `minecraft:oak_fence` as `FenceBlock`; each inherited pane state has NORTH/EAST/SOUTH/WEST/WATERLOGGED, all boolean.

## Exact source locations and hashes (SHA-256)

Provider/state evidence: 1.13.2 `PaneBlock.java:32–91`, `IronBarsBlock.java:20–23`, `FenceBlock.java:24–29,111–112`, `SnowLayerBlock.java:27–32,73–80,155–156`; 1.14.4 `PaneBlock.java:34–103`, `IronBarsBlock.java:19–22`, `FenceBlock.java:26–31,96–97`, `SnowLayerBlock.java:20–23,55–63,114–115`. Cache/dispatch evidence: old `BlockState.java:205–210`; new `BlockState.java:189–202,393–417`, and `Block.java:783` (`hasDynamicShape`). Registration line references are above.

| Relative source path | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |
| `net/minecraft/block/IronBarsBlock.java` | `df6d956bb2745241e59294056f31513151b976dbd9ceed3f5478fd72b66c68a0` | `10ccd6a2135cb05e74cdd4c440da29992dbc60655beedcb5f648f73bbc150541` |
| `net/minecraft/block/GlassPaneBlock.java` | `7abf507b21b920c76e63e34293e6f40bbdefc95df396eb4847406a6d41df96a0` | — |
| `net/minecraft/block/SnowLayerBlock.java` | `12b2d50064fd306c09007bc9a3629cc14a540123ce37e3b53a7f6615c9915df2` | `2307bd4ad1b41210c8c82fddad03dea2e6867b87e7539b9249a6ed49960f6dcb` |
| `net/minecraft/block/FenceBlock.java` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` | `4319ffb95ad81e969b11b39a8e6361d678b5fb5f3ad210d9834ce5e30d5f45d8` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | — | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a98413319000895f49e88db224335f62b2baf21e77` |
