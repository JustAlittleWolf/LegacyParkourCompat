# Small terrain and utility shape provider pairing: 1.13.2 → 1.14.4

## Scope and evidence

This source-only endpoint slice pairs the registered vanilla `farmland`, `grass_path`, all 16 carpet IDs, `cake`, `dragon_egg`, and `brewing_stand` shape providers. Inputs were the supplied provider inventory/TSVs, exact 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 sources, and existing shape-pairing reports only to check for already-closed classes. None of these six classes/IDs appeared in those earlier shape-pairing reports, so this slice adds their first per-state rows. No product code, wiki lane, backlog, Git history, producer source, server source, or other comparison lane was consulted.

The provider inventory identifies exact source publication/mapping identity and verifies the endpoint source manifests, ready markers, and provenance. It lists these six direct `getShape` declarations and source-file hashes; I recomputed the twelve class-file hashes below from the canonical trees. Both sides use the same Feather Gen2 build 2 mapping family.

`states.tsv` contains 41 rows across 21 same-ID registrations: farmland 8, grass path 1, carpets 16, cake 7, dragon egg 1, brewing stand 8. It stores the raw property tuple plus normalized outline and collision box descriptors in integer sixteenths of a block and SHA-256 hashes. Hash input is ASCII descriptor text: ordered comma-separated `x0,y0,z0,x1,y1,z1` boxes, with `;` separating constituents of a union; empty would be an empty string. These are source-derived canonical geometry descriptors, not shapes obtained by launching game code.

## Registrations, states, and provider results

All listed IDs exist at both endpoints and instantiate the corresponding class. In 1.13.2 the registry is built by `Block.register` in `net/minecraft/block/Block.java`; 1.14.4 uses `Blocks.register` in `net/minecraft/block/Blocks.java`. Registration source slices establish the common identifiers: old `Block.java:1000–1001` farmland, `:1090` cake, `:1215` brewing stand, `:1225` dragon egg, `:1399–1429` carpet colors and `:1599–1600` grass path; newer `Blocks.java:426` farmland, `:596` cake, `:755` brewing stand, `:769` dragon egg, `:1106–1153` carpet colors and `:1429` grass path. The matching IDs are `farmland`, `cake`, `brewing_stand`, `dragon_egg`, `grass_path`, and the 16 listed `*_carpet` IDs. The block singleton aliases in `Blocks.java` resolve the registered values.

Both endpoints use the same state properties and value domains:

| ID family | State domain | Count | Provider geometry in sixteenths |
|---|---|---:|---|
| `farmland` | `MOISTURE=0..7` | 8 | `0,0,0,16,15,16` |
| `grass_path` | no properties | 1 | `0,0,0,16,15,16` |
| each carpet color | no properties | 16 total IDs | `0,0,0,16,1,16` |
| `cake` | `BITES=0..6` | 7 | `1+2*BITES,0,1,15,8,15` |
| `dragon_egg` | no properties | 1 | `1,0,1,15,16,15` |
| `brewing_stand` | all combinations of `HAS_BOTTLE_0/1/2={false,true}` | 8 | union of `1,0,1,15,2,15` and `7,0,7,9,14,9` |

`MOISTURE` and `BITES` domains are declared in both `state/property/Properties.java` as integer ranges 0–7 and 0–6. Brewing stand's three bottle properties are booleans in each endpoint's `Properties.java`; each `BrewingStandBlock.buildStateDefinition` adds all three. `CakeBlock.buildStateDefinition` adds `BITES`; `FarmlandBlock.buildStateDefinition` adds `MOISTURE`. The other four provider classes have no state properties relevant to their shape; the three-boolean brewing-stand domain is exhaustive. `StateDefinition` has the same complete source hash at both endpoints and enumerates the registered combinations.

For each of the 41 rows, the old and new outline descriptors and hashes match; collision descriptors and hashes also match. All six methods ignore world and position. Every 1.14.4 overload ignores `CollisionContext`. The provider methods return the same static geometry as their 1.13.2 counterparts. Cake's bite-indexed left edge is `1+2*BITES` in both. Brewing stand's two constituent boxes and union construction are the same in both.

## Collision and cache dispatch

At 1.13.2 `BlockState.getShape(world,pos)` (BlockState.java:206) dispatches to `Block.getShape(state,world,pos)`; `BlockState.getCollisionShape(world,pos)` (BlockState.java:209–210) dispatches to `Block.getCollisionShape` (Block.java:393–395), whose base implementation returns the state's outline shape when `hasCollision` is true. These registrations use ordinary collision-enabled properties (none uses `.noCollision()`), and none overrides collision separately, so the paired `getShape` output is also its collision output.

At 1.14.4 `BlockState.getShape(world,pos,context)` (BlockState.java:193–194) dispatches to the context overload. Its base collision provider applies the same collision gate and delegates to the state's context shape (Block.java:376–378). The context-free collision call uses the state's cached collision shape when present, otherwise invokes the empty-context overload (BlockState.java:197–203). `BlockState.cacheShape()` caches when `!block.hasDynamicShape()` (BlockState.java:65–67); the six registrations do not opt into `.dynamicShape()`. `Blocks.java:1960–1963` iterates registered block states and calls `cacheShape()`. Cache construction evaluates the collision provider with empty context against a dummy view and origin (BlockState.java:410). Because these six providers ignore view, position and context, the cache path and direct contextual path produce the per-state descriptors recorded in `states.tsv`.

## Exact source references and hashes

Relative paths are from each endpoint's `ornithe-feather` tree. SHA-256 hashes are complete files.

| File | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/FarmlandBlock.java` | `581dae15cc29abe90f9cf20232a3cd1b7ab6c868808bc5e4f05816952b61eef9` | `27227a174fa9d51ab3b618e52d1ec6226fcd0610d4c89ed5648e113731eb66c3` |
| `net/minecraft/block/GrassPathBlock.java` | `8acdb82a274f68c5dd89faa92c82d450bbe9906ee65584c981633ed922430cfe` | `5924874f0eda2942dd1ce889e665dfa7fa1d8b28a2dbed42917e44014540b0a8` |
| `net/minecraft/block/CarpetBlock.java` | `cc3a3e0356a9a0e1ba4d82e4dc2caf880999294bc72ad7be62a43e031faaa4a4` | `55a7faf5d395480ebd6a47ff9820f6a5082807d5f5b2c6072d11a79316a00b25` |
| `net/minecraft/block/CakeBlock.java` | `f9464e8a2f328c21b788654dc81115ba236c31984e93949f69df2b2dace5fd6c` | `72f4d89064e007e24a98465e67631928d41a90e8fa581f189b8de4d5863f7905` |
| `net/minecraft/block/DragonEggBlock.java` | `4d11fb7ca6e092ced4b69ffbf896d4a1a68bde0f113a075364aca8f821731253` | `445931bd984bb95f7602321b39e32850b0302f07049f75966d0ff7a85378c007` |
| `net/minecraft/block/BrewingStandBlock.java` | `0ff465b18dc0377c1a1a123ad083f04d07f77cea8a0bc88a218a67d750f886d3` | `ccda744516bdf232db4ed600bd468833640ac56a4b559725f220cd838c283761` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/state/StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |

Provider methods are `FarmlandBlock.getShape` (old line 57, new 58), `GrassPathBlock.getShape` (56, 56), `CarpetBlock.getShape` (26, 27), `CakeBlock.getShape` (39, 39), `DragonEggBlock.getShape` (23, 25), and `BrewingStandBlock.getShape` (56, 52). Registration rows are the paired same-ID calls in the registry files above; full IDs are enumerated in `states.tsv` for carpet and explicitly in this report for all other families.

## Limits

This closes only same-ID, same-raw-state outline/collision provider outputs for these six class families under the inspected default vanilla registrations. It makes no claim about how the states are produced, trajectories, support predicates, other shape providers, custom registrations, intermediate release boundaries, pair-wide coverage, or runtime parity. No source tree was written or regenerated; no build, test, game or server was run.



