# 1.13.2–1.14.4 external local-player responses: bounded source coverage

## Inputs and provenance

Primary pair: exact 1.13.2 Ornithe/Feather → exact 1.14.4 Ornithe/Feather. Both ready markers report Vineflower sources, exact version metadata, and 2,711/3,250 source files respectively. Readiness source-manifest hashes: 1.13.2 `ornithe-feather.sources.sha256` = `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 = `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. Their artifact-manifest hashes match readiness (`fdcacd9150f98ea70acafc5cab754027ab1a09828ff0eaa8e542dd7890d9ce1e` and `308cc33ef6dffc047432ade6affc88eccc9de94a736ee9a98571fd92915c2970`). `*.provenance.json` identifies Feather build. In-scope source members below were individually rehashed and match the corresponding source manifests. Mojmap 1.14.4 was consulted only as a semantic cross-check; primary comparison uses Feather at both endpoints.

## Terminal member inventory

| Trigger / terminal member | 1.13.2 → 1.14.4 source reference | Result |
|---|---|---|
| Server position correction to player | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java`: `handlePlayerMove(PlayerMoveS2CPacket)`, lines 621–661 → same member, lines 652–706 | **Difference:** 1.14.4 records each axis in `prevX/prevY/prevZ` as it applies the packet: relative axes add the packet offset to the corresponding previous coordinate, absolute axes assign the absolute packet coordinate. 1.13.2 applies the relative offset or absolute value and clears velocity only for absolute axes, then calls `updatePositionAndAngles`; that method sets `lastX/Y/Z` but leaves `prevX/Y/Z` untouched. Both versions retain velocity on relative axes, clear it on absolute axes, apply relative yaw/pitch against current rotation, and acknowledge/echo the resolved position. Reachable effect: after a server correction, 1.13.2 may carry stale previous-position fields into later local-player interpolation/state consumers; 1.14.4 synchronizes them to the correction. The trajectory consequence is not established by this bounded inventory. |
| Entity-velocity packet (may address the local entity by ID) | same handler: `handleEntityVelocity`, lines 507–513 → lines 537–543 | **No difference found:** when the target ID resolves, both pass each packet component divided by `8000.0` to `Entity.lerpVelocity`; absent IDs are ignored. |
| Explosion knockback packet response | same handler: `handleExplosion`, lines 968–977 → lines 1044–1053 | **No difference found:** both process the client-side explosion/block effect, then add the server-supplied three-component velocity vector to the current local-player velocity. The 1.14.4 call uses the vector getter/setter chain; component math and additive behavior match 1.13.2. Damage/health and explosion block production are outside this inventory. |
| Moving piston contact / slime impulse | `net/minecraft/block/entity/MovingBlockEntity.java`: `moveEntities(float)`, lines 102–153 → same member, lines 102–160 | **No difference found:** both skip `IGNORE` entities; slime pushes replace only the movement-axis velocity component with the direction step while retaining the other two; collision overlap determines the maximum movement, capped at the piston progress delta then increased by `0.01`; movement is dispatched as `MoverType.PISTON`; retracting source pistons perform the follow-up base correction. |
| Piston movement cap applied to entity movement | `net/minecraft/entity/Entity.java`: `move(MoverType,double,double,double)`, lines 473–515 → `move(MoverType,Vec3d)`, lines 449–455 plus piston limiter `m_19881916(Vec3d)` / axis helper `m_94421288`, lines 621–654 | **No difference found in the limiter:** both reset accumulated piston deltas when world time changes; process X, else Y, else Z; clamp accumulated displacement to `[-0.51, 0.51]`; subtract the previous accumulated amount; and return early when the permitted component is at most `1.0E-5F` in magnitude. 1.14.4 extracts this logic into a helper and adapts the vector API. |
| Entity teleport packet route | same handler: `handleEntityTeleport`, lines 551–570 → lines 581–601 | **Checked routing; no local-player terminal difference accepted here:** the handler looks up an entity ID and only lerps coordinates if `!entity.isLogicalSideForUpdatingMovement()`. The normal local-player correction route is `handlePlayerMove` above. The `EntityMap.updatePosition` / `m_33357175` bookkeeping is not itself a local-player physical-position write. A server path that deliberately targets the local ID through this packet was not traced. |

## Hashes for examined source files

Hashes below were recomputed from the decompiled trees and matched the source-manifest entries.

- 1.13.2 `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` — `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11`
- 1.13.2 `net/minecraft/block/entity/MovingBlockEntity.java` — `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46`
- 1.13.2 `net/minecraft/world/explosion/Explosion.java` — `72d86b4acfdfc963ca9a912ad4a9e697f52bf770b91fa8bf88e89881b6e774e2`
- 1.13.2 `net/minecraft/entity/Entity.java` — `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`
- 1.14.4 `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` — `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef`
- 1.14.4 `net/minecraft/block/entity/MovingBlockEntity.java` — `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a`
- 1.14.4 `net/minecraft/entity/Entity.java` — `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55`

## Boundaries and remaining gaps

This is terminal coverage only for server correction, entity velocity, explosion knockback, and piston contact/cap. It excludes damage/health, block-state production, vehicles/nonplayers, and collision-free waterlogged-sign trajectories as assigned. It does not close neighboring collision, shape, or full tick dependencies, does not establish an exact intermediate patch boundary, and is not a full-pair coverage audit. The checked 1.14.4 Mojmap sources semantically agree with the Feather descriptions above; no Mojmap-only claim is used.

