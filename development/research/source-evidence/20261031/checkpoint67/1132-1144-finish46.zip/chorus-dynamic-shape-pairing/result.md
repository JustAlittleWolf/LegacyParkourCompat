# Chorus plant / chorus flower shape pair: 1.13.2 → 1.14.4

## Verdict and boundary

For the two common vanilla block IDs `minecraft:chorus_plant` and `minecraft:chorus_flower`, the endpoint collision and outline shape outputs pair exactly for equal block state and equal world inputs. The paired provider outputs cover all 64 chorus-plant boolean states and all six chorus-flower age states. The plant shape depends only on its six booleans; its neighbor arrangement matters upstream only insofar as it determines those booleans or whether a neighbor update is allowed to write one. The flower shape is constant across age and neighbors.

This is a source-level shape-provider result only. It does not establish block-state production histories, runtime execution, trajectory parity, or whole-movement applicability. In particular, 1.13.2 `ChorusPlantBlock.getFaceShape` returns `UNDEFINED`, while the 1.14.4 class has no override and inherits the base default; that face-support query is outside this collision/outline shape comparison and remains a separate potential movement-query dependency.

## Pair identity and method mapping

The selected pair is Feather-to-Feather (not Mojmap): `decompiled_minecraft/1.13.2/ornithe-feather` against `decompiled_minecraft/1.14.4/ornithe-feather`. This follows the existing published Feather pair inventory; the independent 1.14.4 Mojmap tree is not used to rename or invalidate this endpoint pair.

| Role | 1.13.2 | 1.14.4 |
|---|---|---|
| Plant concrete class / state builder / neighbor state writer | `net/minecraft/block/ChorusPlantBlock.java` | same |
| Plant shape constructor, state-index lookup, shape provider | `net/minecraft/block/PipeBlock.java` (`makeShapes`, `getShape`, `getShapeIndex`) | same (`getShape` gains `CollisionContext`) |
| Flower concrete class / state builder | `net/minecraft/block/ChorusFlowerBlock.java` | same |
| Block registration | `net/minecraft/block/Block.java` static registrations | `net/minecraft/block/Blocks.java` registrations |
| Shared collision and default outline route | `net/minecraft/block/Block.java`; `net/minecraft/block/state/BlockState.java` | same paths |
| Age domain | `net/minecraft/state/property/Properties.java:AGE_5` | same |
| Shape mask direction ordinal order | `net/minecraft/util/math/Direction.java:values()` | same |

## Plant outputs: complete 64-state crosswalk

Both classes build exactly `NORTH,EAST,SOUTH,WEST,UP,DOWN`; both set those six defaults to false. Both `PipeBlock`s map the same `Direction` values to the same properties and compute the mask in `Direction.values()` order: `DOWN=bit0, UP=bit1, NORTH=bit2, SOUTH=bit3, WEST=bit4, EAST=bit5`. The attached [states.tsv](states.tsv) enumerates every one of the 64 assignments and the active arm set. For each row, both endpoints return the same union: a central cube plus arms for precisely the true properties in that row.

The shared shape recipe is exact in both `PipeBlock.makeShapes`: radius `0.3125F` (5/16); core limits `0.5F-radius` and `0.5F+radius`, i.e. 3/16 and 13/16 on each axis; for each direction, one arm extends from the core to that block face and has the same 5/16 cross-section; the mask loop unions selected arms with the core. Each endpoint allocates 64 shapes and `getShapeIndex` uses the same six property/bit tests. 1.14.4's overload accepts `CollisionContext` but ignores it; no shape branch differs by context, world, or position.

## Flower outputs and shape route

Both `ChorusFlowerBlock`s define only `AGE=Properties.AGE_5` in their state definition, with `AGE_5` ranging 0 through 5. Neither class overrides `getShape` or `getCollisionShape`; so all six age values inherit the same base full-cube outline. Both chorus-flower registrations use ordinary plant properties and omit `.noCollision()`. `Block.Properties.hasCollision` defaults true at each endpoint. Therefore collision resolves to that same full cube for each age value.

For plant outline, `BlockState.getShape` dispatches to the registered block's shape method, which is inherited from `PipeBlock`. For plant collision, 1.13.2 `BlockState.getCollisionShape` dispatches to base `Block.getCollisionShape`, whose `hasCollision ? state.getShape(world,pos) : empty` then reaches the plant shape override. In 1.14.4 the same route is `BlockState.getCollisionShape` → base `Block.getCollisionShape` → `state.getSHape` → `BlockState.getShape(..., CollisionContext.empty())` → `PipeBlock.getShape(..., context)`; the plant override ignores that context and selects the same mask. Flower collision follows the analogous base route but lands on base `Block.getShape`, the full cube. No chorus registration disables collision.

## Neighbor predicates and applicability limits

The shape methods themselves make no neighbor query. The connection booleans are built/written by the following matching upstream code at both endpoints:

- Placement reads the six orthogonal neighboring block IDs. For `DOWN`, true iff the neighbor is this `CHORUS_PLANT`, `CHORUS_FLOWER`, or `END_STONE`. For `UP`, `NORTH`, `EAST`, `SOUTH`, and `WEST`, true iff the neighbor is this `CHORUS_PLANT` or `CHORUS_FLOWER`.
- Incremental `updateShape` first gates on `state.canSurvive(world,pos)`. If false, it schedules a one-tick update and returns the superclass result without writing the requested connection property. If true, it sets the property for `dir` to true iff the neighbor is this plant or chorus flower, or iff `dir == DOWN` and the neighbor is end stone. No `isAir` predicate is in the connection expression itself.
- The survival gate delegates through `BlockState.canSurvive` to `ChorusPlantBlock.canBePlaced` at both endpoints. That method checks `!above.isAir() && !below.isAir()`; then scans horizontal neighbors for this plant; for each such horizontal plant it may accept when the above/below non-air conjunction is false, otherwise it checks the block one below that horizontal plant for this plant or end stone; if no horizontal branch accepts, it accepts only when the block below the current plant is this plant or end stone. These `isAir` and block-ID checks affect whether the incremental property writer runs, not the `PipeBlock` output for a supplied state. The identical old/new methods mean they pair for equal raw neighbor IDs/air results and equal logical state histories.

The state/neighbor arrangement crosswalk relevant to the output is therefore: enumerate each central six-bit property state using `states.tsv`; hold the raw ID in each of its six adjacent positions equal between endpoints; apply the same placement/update result and survival-gate history; then both provider lookups produce the corresponding table row. No assumption is made that all 64 boolean assignments are reachable from every history.

## Evidence hashes (whole-file SHA-256)

Hashes bind every source used for the verdict. Paths are relative to each version's `ornithe-feather` root.

| Source | SHA-256 |
|---|---|
| 1.13.2 `net/minecraft/block/PipeBlock.java` | `4c56867771e5848fec41d7ccbce5339af3dfefa7f98afb4712dfd0d5abd8f9a9` |
| 1.14.4 `net/minecraft/block/PipeBlock.java` | `50974f5a929e70166c8edbac17dd22b295ceb50bacd345d2b89a25bb150740b6` |
| 1.13.2 `net/minecraft/block/ChorusPlantBlock.java` | `299acaed9644e0837a29f282e830dc7582b8d8f14a1c904147c034518e474433` |
| 1.14.4 `net/minecraft/block/ChorusPlantBlock.java` | `0c05da2c054d2912bd667aaa200c4428fcc8e4064874056907656376b6120189` |
| 1.13.2 `net/minecraft/block/ChorusFlowerBlock.java` | `cacbbd84e9be8912d8e79d6d90cafd72a70b81d3e96518b8f0eb2eaf65fe19c4` |
| 1.14.4 `net/minecraft/block/ChorusFlowerBlock.java` | `5f8de15e04efd8f98a1dcc82628550cfcfe2d65c00bfbae6f56586b9e11adda4` |
| 1.13.2 `net/minecraft/block/Block.java` (registry, base gates/default shape) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 `net/minecraft/block/Blocks.java` (registry) | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 `net/minecraft/block/Block.java` (base gates/default shape) | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.13.2 `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.13.2 `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` |
| 1.14.4 `net/minecraft/state/property/Properties.java` | `9b524af5065100919c60667778e38986380c9df954ef70d9ac0a739132ddca` |
| 1.13.2 `net/minecraft/util/math/Direction.java` | `6d5c496ff65377fee9f00c826e48c7be14d3889e5ae5191e110a464007549082` |
| 1.14.4 `net/minecraft/util/math/Direction.java` | `121f8b78eda07640eccbe369f40acc7ccbdcb275dcb6aca87c4495cd193b01c0` |
| This report's `states.tsv` | `009162b345e592f2452781b3f496f8ff1d2cbf0bb1bfcbb320f9d44ca03eecd81` |