# Provider state pairing: 1.13.2 → 1.14.4

## Scope and evidence identity

This is a bounded continuation of the frozen source-only provider inventory at `../providers/inventory.md`. It pairs same-state collision provider bodies for the old endpoint's explicit collision declarations and checks a representative movement-facing face-provider output. It does not complete the shape tables, audit every face result, establish a player trajectory, or freeze the pair.

Primary source family: Ornithe Feather Gen2 build 2 at both endpoints. Before reading provider bodies, I verified each ready marker's `status`, `versionId`, `mapping`, and `sourceManifestSha256`; recomputed the source-manifest, ready-marker, and provenance file SHA-256 values against the inventory; and recomputed every source-file hash referenced by both TSVs. All checks matched. Counts revalidated: `shape-provider-overrides.tsv` contains 93 old and 115 new rows; `fluid-face-shape-providers.tsv` contains 65 old `getFaceShape` rows and no new `getFaceShape` rows. The 1.14.4 Mojmap tree was not used in this pass.

## Paired explicit collision providers

The old endpoint's nine unique `getCollisionShape` declarations (the TSV repeats the MovingBlockEntity row) were paired to the same registration/class provider in 1.14.4. All inspected direct outputs match for matching raw logical states. The newer overload adds `CollisionContext`, but these provider bodies ignore it. Static per-state caching changes dispatch in 1.14.4; it does not change these provider results. Moving piston collision remains dependent on matching block-entity progress/state and the same `NOCLIP_DIR` thread-local value.

| Provider member | 1.13.2 source | 1.14.4 source | Paired output result |
|---|---|---|---|
| `Block.getCollisionShape` | `net/minecraft/block/Block.java:393–395` | `net/minecraft/block/Block.java:376–378` | Same `hasCollision` gate; old calls state shape, new calls the empty-context state shape (`BlockState.getSHape`, which delegates to `getShape(..., CollisionContext.empty())`). Base shape is the unit cube. |
| `CactusBlock.getCollisionShape` | `net/minecraft/block/CactusBlock.java:60–62` | `net/minecraft/block/CactusBlock.java:61–63` | Both return `COLLISION_SHAPE`, independent of state; paired outline provider also returns `OUTLINE_SHAPE`. |
| `FenceGateBlock.getCollisionShape` | `net/minecraft/block/FenceGateBlock.java:67–73` | `net/minecraft/block/FenceGateBlock.java:70–76` | Same: OPEN returns empty; otherwise FACING axis selects the same X/Z collision shape. `IN_WALL` does not affect this method. |
| `MovingBlock.getCollisionShape` | `net/minecraft/block/MovingBlock.java:108–111` | `net/minecraft/block/MovingBlock.java:104–107` | Same: delegate to a MovingBlockEntity when present, else empty. |
| `PaneBlock.getCollisionShape` | `net/minecraft/block/PaneBlock.java:82–84` | `net/minecraft/block/PaneBlock.java:89–91` | Same `shapes[getShapeIndex(state)]` output. The pane shape-table construction, state connection index, and iron-bars constructor dimensions match. The old glass-pane subclass delegates to the same iron-bars constructor used for the new `glass_pane` registration. |
| `SnowLayerBlock.getCollisionShape` | `net/minecraft/block/SnowLayerBlock.java:78–80` | `net/minecraft/block/SnowLayerBlock.java:60–63` | Same `SHAPES[LAYERS - 1]`; paired shape arrays have the same layer boxes. |
| `SoulSandBlock.getCollisionShape` | `net/minecraft/block/SoulSandBlock.java:21–23` | `net/minecraft/block/SoulSandBlock.java:23–25` | Both return the same fixed 14/16-height `SHAPE`. |
| `WallBlock.getCollisionShape` | `net/minecraft/block/WallBlock.java:37–39` | `net/minecraft/block/WallBlock.java:39–41` | Same UP gate, state-derived shape index, and collision-shape table. Constructor dimensions and table generator match. |
| `MovingBlockEntity.getCollisionShape` | `net/minecraft/block/entity/MovingBlockEntity.java:324–352` | `net/minecraft/block/entity/MovingBlockEntity.java:332–360` | Method body is identical after line offset: same source/extending gate, moved state, no-clip/progress gate, piston-head short-state expression, translation, and union. |

Representative matching vanilla registration IDs inspected alongside these bodies include `cactus`, `snow`, `soul_sand`, `oak_fence_gate`, `iron_bars`, `glass_pane`, and the common wall registrations. The frozen shape TSV remains authoritative for the exact source row paths, members, lines, and file hashes.

## Same-state movement-facing face-provider delta

Old ordinary fluid flow asks `FlowingFluid.isSolidFace` on horizontal neighbors when its falling-fluid branch computes flow. In 1.13.2 the method rejects same-fluid neighbors, accepts UP, rejects ICE, then rejects `Block.isExceptionForAttachment(block)` and every `StairsBlock` before asking for `FaceShape.SOLID` (`net/minecraft/fluid/FlowingFluid.java:105–123`). `Block.isExceptionForAttachment` includes all `isExceptionForPlacement` blocks plus piston base/head (`net/minecraft/block/Block.java:241–257`).

In 1.14.4, the same fluid helper delegates the non-ICE horizontal case to the BlockState face-sturdy predicate (`FlowingFluid.java:106–115`; `block/state/BlockState.java:326–327`). For static shapes the predicate is cached per state/direction when the cache is built (`BlockState.java:412–416`); the cache calls `Block.isFaceSolid`, which only rejects active `BlockTags.LEAVES` membership and otherwise tests whether the collision shape fills that face (`Block.java:402–410`). The old attachment-exception set is no longer part of this predicate.

### Concrete stair witness

Both registries contain `minecraft:stone_brick_stairs`: 1.13.2 `net/minecraft/block/Block.java:1206`; 1.14.4 `net/minecraft/block/Blocks.java:735–736`. Both `StairsBlock` state definitions contain the same raw `FACING`, `HALF`, `SHAPE`, and `WATERLOGGED` properties (`1.13.2 StairsBlock.java:33–36, 330–331`; `1.14.4 StairsBlock.java:33–36, 283–284`). The state `FACING=SOUTH, HALF=BOTTOM, SHAPE=STRAIGHT, WATERLOGGED=false` is a concrete matching state.

For that state, both endpoints use the same shape index and union table (`StairsBlock.java:39–81, 99–105` in each version). SOUTH has horizontal id 0; straight therefore selects `SHAPE_INDICES[0] == 12`. Mask 12 unions the bottom base with both bottom-south quarter shapes, filling the complete SOUTH face. The old fluid helper returns false before consulting the stair's own `getFaceShape` because of its explicit stair exclusion. The new face predicate returns true from the full collision face under the generated vanilla LEAVES recipes: both endpoint recipes contain exactly the six vanilla leaf blocks and omit stairs (`1.13.2 net/minecraft/data/tag/BlockTagsProvider.java:239–240`; `1.14.4 net/minecraft/data/tag/BlockTagsProvider.java:299–300`). This establishes the vanilla-tag provider result; custom/runtime tag replacement is excluded.

This changes a boolean input to the falling-fluid flow-vector branch under the stated same-state/fluid-neighbor precondition. It is not an ordinary player trajectory claim.

A second source-level candidate is common `minecraft:piston_head` facing SOUTH: both registrations exist (`1.13.2 Block.java:934`; `1.14.4 Blocks.java:284`), the head-shape box covers the full SOUTH face (`PistonHeadBlock.java:24–41, 48–69` in both endpoints), and the old attachment exception rejects it. Under the generated vanilla LEAVES recipes cited above, the new face result is true. Custom/runtime tag replacement is excluded. It has not been independently closed against all piston head states/progress contexts in this pass.

`minecraft:glass` is another common registration: 1.13.2 registers it in `Block.java:892` and rejects it through the old attachment exception; 1.14.4 registers it in `Blocks.java:204`, where the inherited default collision shape is full. The generated vanilla LEAVES recipes above omit glass, so its new default-vanilla result is true. Custom/runtime tag replacement is excluded.

## Exact unpaired members and limits

- All 65 old direct `Block.getFaceShape` declarations remain unpaired against the new shape-derived face-sturdy result, except the specific stair witness above. The exact class/member/line/hash rows are the endpoint=`1.13.2` rows in `../providers/fluid-face-shape-providers.tsv`; 1.14.4 declares no direct `getFaceShape` member. Old classes include the direct overrides listed by that TSV, including `Block`, `CauldronBlock`, `FenceBlock`, `FenceGateBlock`, `PistonBaseBlock`, `PistonHeadBlock`, `ShulkerBoxBlock`, `SlabBlock`, `SnowLayerBlock`, `StairsBlock`, `TrapdoorBlock`, and `WallBlock`.
- The 83 old and 97 new `getShape` declarations remain unpaired member-by-member for every concrete common state/registration. Exact path/member/line/hash rows are the corresponding `getShape` rows in `../providers/shape-provider-overrides.tsv`.
- The explicit collision declarations listed above have direct body pairing, but do not close all inherited `getShape` results, constructor registrations, state branches, neighboring-state dependencies, or contexts for all 208 inventory rows.
- Step/support helper outputs were not paired in this bounded pass. In particular, the newer `Block.canSupportBase` (`Block.java:390–394`) and `canSupportCenter` (`Block.java:396–400`) need caller and same-state comparison against old support predicates before any support/step closure claim.
- Active tag payloads and client/server tag replacement, fluid state-production histories, ordinary input histories, and intermediate patch boundaries remain open.

No product, wiki lane, backlog, or Git data was read or changed. No source tree was written or regenerated; no build, test, or game was run.

## Relevant exact file hashes

- 1.13.2 `StairsBlock.java`: `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761`
- 1.14.4 `StairsBlock.java`: `b49cbd43a9be5e848623f25769dede5795f50435ba0e82bbdbbf571527396b9f`
- 1.13.2 `Block.java`: `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4`
- 1.14.4 `Block.java`: `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5`
- 1.13.2 `FlowingFluid.java`: `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253`
- 1.14.4 `FlowingFluid.java`: `6afb033d18e6d28ff6d7deda88f5f1432914903b0f0ef100c44fb8372d3e148ce`
- 1.14.4 `BlockState.java`: `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f`
- 1.13.2 `BlockTagsProvider.java`: `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e`
- 1.14.4 `BlockTagsProvider.java`: `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa`
