# Step-resolution pairing: 1.13.2 → 1.14.4

## Assignment and boundary

Source-only pairing of the `Entity.move` step-up alternatives, their gates and candidate selection, collision clipping helpers, and the resolved movement/position writer at Minecraft 1.13.2 and 1.14.4 (Ornithe Feather Gen2 build 2). Comparison assumes equal preprocessed request vectors, player/entity/world state, collision candidates and provider outputs at the relevant calls. This is not spawn-history or trajectory proof. It does not freeze the pair or close all collision-shape dependencies.

Allowed prior evidence used as leads: the 1.13.2→1.14.4 collision-query closure and its independent audit, collision/contact source review, travel-terminal pairing, and the paired oak stair/slab/trapdoor provider results. In particular, oak stair, slab and trapdoor collision outputs match for all raw states inventoried in the common-shape report. Generic base full-cube witnesses and the resolver axis-order facts are reused from the audited collision-query work. No other provider family is implied to be closed.

## Source identity

Canonical read-only roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Both are Feather Gen2 build 2. Exact ready source-manifest identities and the full `Entity.java` SHA-256 values, verified against the manifests in the permitted prior reports:

| Endpoint | Mapping/source identity | Source manifest SHA-256 | `Entity.java` SHA-256 |
|---|---|---|---|
| 1.13.2 | Ornithe Feather Gen2 `1.13.2+build.2` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | Ornithe Feather Gen2 `1.14.4+build.2` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |

Method hashes below are SHA-256 of exact decompiled member text including signature and braces. The endpoint full-file hashes above are the selected source-file identity.

| Paired member | 1.13.2 Feather | 1.14.4 Feather |
|---|---|---|
| `Entity.move(MoverType,double,double,double)` | `Entity.java:473–776`, `4a2270fbb434f7bde4f2f15062993063560bcda5c372723ee5cdf081fc63cff8` | — |
| `Entity.move(MoverType,Vec3d)` | — | `Entity.java:444–571`, `81d5cd437e39b4eaa7b3af2d7de998bce53493e4f7e0a40a4b5ee03b5998b907` |
| `Entity.m_72373519(Vec3d)` step and normal-resolution selector | — | `Entity.java:656–686`, `f7f67bfaeb759553f8aa259271138d8cf5fc152e98dd863cdb9d7ee676c6e291` |
| `Entity.m_64271959(...)` axis-helper dispatcher | — | `Entity.java:692–706`, `654d56b987a6a70b391edc781d697a13912bd2a0fbea0b922eeac2fd6dda7c19` |
| `Entity.m_79801352(...)` diagonal clip order | — | `Entity.java:708–739`, `1fdd9bb71ff2f7c9835bf58b37447fbcdbf5ed62adb0e7e4e34623d48e7027e0` |
| `Entity.m_73670363(...)` single-axis/zero-axis clip order | — | `Entity.java:741–772`, `6551be4b2e63f00961cd456939979a4a7edcc32a566ab7cefd61238894f26333` |
| `Entity.setPositionFromShape()` | `Entity.java:782–787`, `5668ebc787ab9aec731ff0c7983ff51a2174bb27c810e953e8851103a1e61bb0` | `Entity.java:778–783`, same hash `5668ebc787ab9aec731ff0c7983ff51a2174bb27c810e953e8851103a1e61bb0` |

`LivingEntity` sets `stepHeight=0.6F` at 1.13.2 `LivingEntity.java:185` and 1.14.4 `LivingEntity.java:206`; the value is unchanged for players. The paired `Entity.move` source therefore receives the same positive step height under the ordinary living-player state assumption.

## Gates and preprocessing

Both `Entity.move` methods return through a direct shape/position update for `noClip`. Otherwise, piston preprocessing runs before collision clipping. Sneak-edge reduction applies to a player only when mover type is `SELF` or `PLAYER`, `onGround` is true and the player is sneaking. The old inline loop reduces X, then Z, then both together by `0.05`; new `m_91740517` uses the same three phases and threshold before returning the adjusted vector. This task compares step resolution under equal post-preprocessing vectors; it does not claim the upstream piston or cobweb producers match.

The step gate is materially the same conditional structure. Old requires `stepHeight > 0`, `onGround || (requestedY was negative and was clipped)`, and X or Z clipping (`Entity.java:601–603`). New uses `stepHeight > 0`, `onGround || (requestedY < 0 && resolvedY differs)`, and a clipped X or Z (`Entity.java:667–670`). Both use the pre-collision horizontal request for the step candidate. Neither adds an additional `MoverType` restriction to the step gate itself. Differences in how horizontal clipping/flags are computed elsewhere are a separate dependency; under equal exact resolved vectors the gates coincide.

## Candidate construction and resolution

**1.13.2 inline resolver.** `Entity.move` gathers one collision-shape list for the preprocessed full request (`Entity.java:578–580`), clips the ordinary candidate Y→X→Z while moving its working box after each nonzero axis, and retains the resulting resolved vector and box. If the step gate opens, it saves the ordinary result and resets to the original box. It then gathers one collision list for `(requestedX, stepHeight, requestedZ)` (`:604–618`).

Two step alternatives use that same step collision list:

1. The first expands the original box by requested X/Z for a Y clip up to `stepHeight`, then applies X followed by Z to the raised box (`:619–640`).
2. The second clips Y on the original box, then X, then Z, moving the candidate box after each clip (`:642–663`).

The code compares horizontal squared progress `(v²+w²)` versus `(ab²+ac²)` (`:664–675`). It selects alternative one only if its value is strictly greater; equality selects alternative two. It then clips a downward Y request equal to the negative of the selected rise (`y=-u` or `y=-aa`) (`:676–680`). Finally, it keeps the step result only if its horizontal squared progress strictly exceeds the ordinary result; equality or less restores the ordinary X/Y/Z and original resolved box (`:682–688`).

**1.14.4 delegated resolver.** `Entity.move` preprocesses the vector, calls `m_72373519`, and applies the returned vector to the box and position only when the resolved vector squared length is strictly greater than `1.0E-7` (`Entity.java:456–468`). `m_72373519` creates an entity collision context, an initial candidate stream for entity collisions and the world-border shape, then resolves the normal motion. Its step gate mirrors the old positive-height, grounded-or-clipped-downward, clipped-horizontal structure.

For the first alternative, it calls `m_64271959` with `(requestX, stepHeight, requestZ)` against the original box. For the second, it first clips `(0,stepHeight,0)` against a box expanded by request X/Z. If that rise is less than `stepHeight`, it resolves horizontal `(requestX,0,requestZ)` from the box moved by that rise, then adds the rise vector. The second alternative replaces the first only when its horizontal squared progress is strictly greater; ties retain the first alternative (`:671–678`). The selected step result is returned only when its horizontal squared progress is strictly greater than the ordinary result (`:680–683`); ties retain normal movement.

For calls with at least two nonzero components, `m_64271959` appends a fresh block-collision query for that vector's swept box to the accumulated entity/border candidates, then invokes `m_79801352`. That helper clips Y first, then clips the smaller-magnitude horizontal axis first: Z first only when `abs(X) < abs(Z)`; ties take X before Z (`:692–739`). One-/zero-axis calls use `m_73670363`, which also clips Y first and chooses the same horizontal ordering, but delegates each offset calculation to contextual `VoxelShapes.m_10425781` (`:741–772`). The new step alternatives therefore make different vectors and swept-box block queries than the old one-list reuse. The prior collision-query reports close the query-route shape only for their explicit witnesses, not all candidate shapes/world states.

## Source-confirmed terminal delta

When a step alternative wins, the old downward component is only `-selectedRise`; it discards the original requested vertical component. The new downward component request is `-selectedRise + originalRequestedY` (`m_72373519`, `:680–683`). Under the equal-state assumptions, for a grounded living player with downward requested Y, a clipped horizontal obstacle, and a selected step candidate whose descent is unobstructed, the old net Y displacement for the up/down candidate is zero, while the new net Y displacement retains the original requested negative Y. This is a concrete conditional `Entity.move` output delta; it does not require claiming a keyboard-input trajectory. The final downward collision clip can alter the result if the descent path is obstructed, so the stated witness condition includes unobstructed descent.

Candidate tie behavior also differs: where the two alternative horizontal progress values tie, 1.13.2 chooses its second alternative while 1.14.4 keeps its first. This is a distinct source-level selection delta; no separate runtime geometry witness for that tie was constructed here. Both versions use strict `>` to decide whether any step result beats the ordinary horizontal result, so ties with ordinary movement preserve the ordinary candidate.

The newer `move` output gate can suppress the final position write for nonzero resolved vectors whose squared length is `<=1.0E-7`, while old `move` always calls `setPositionFromShape` at its rest continuation. This endpoint-level writer delta is already established by the permitted collision-query closure/audit and is retained as a dependency here; this report does not duplicate its full-cube witness or assert a trajectory for its exact vector. The `setPositionFromShape` member text itself is identical across these endpoints as its matching method hash shows.

## Shape and callback dependencies

The selected step alternatives depend on the returned collision shapes, candidate enumeration, entity collisions, world-border handling, loaded-chunk behavior and the relevant `VoxelShapes` offset methods. Reused shape evidence establishes matching collision output for all inventoried oak stair/slab/trapdoor states and the generic full-cube witness; it does not establish every old-era block's provider, contextual shape behavior, moving-block shape, candidate ordering, or all entity collision shapes. New contextual provider calls can also depend on `CollisionContext.of(entity)`; oak stairs/slabs/trapdoors in the prior paired result ignore that context.

After resolution, old and new write the position from the selected box only after their respective position-update gates, then derive collision flags, `onGround`, and axis-velocity clearing from the request/result. Old horizontal collision flags use exact `requestedX != resolvedX || requestedZ != resolvedZ`; new uses the approximate equality helper with its `1.0E-5F` tolerance (`Entity.java:700` and `MathHelper.java:155–157` as cited by the travel-terminal report). That may affect later movement continuations such as climbing; it is not needed to establish the step-alternative vertical terminal delta above, whose step gate can be provided by exact horizontal clipping.

## Residuals and conclusion

- The exact step-up source procedure differs, and there is a conditional source-level vertical terminal delta when a step wins with downward requested motion and an unobstructed descent.
- Step alternative selection differs on equal horizontal-progress ties (old chooses the second alternative; new retains the first); no tie-specific map geometry is established here.
- Candidate-list construction/query envelopes and contextual clipping differ. Full collision-provider, block-neighbor, entity-shape, border and chunk closure remains open beyond the specifically reused witnesses and oak shape families.
- No keyboard/input trajectory, spawn history, runtime behavior, pair freeze, implementation acceptance, or intermediate 1.14.0–1.14.3 boundary is established.

No product/wiki/backlog/Git data was consulted or changed. Canonical sources were read only. No build, tests, gameplay launch, or decompilation was performed.
