# Residual falling-fluid face providers: 1.13.2 → 1.14.4

## Scope and source identity

This source-only reconciliation uses the published Ornithe Feather Gen2 build 2 trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. The endpoint identity and source-manifest checks are bound in `../providers/inventory.md`. It reconciles the 65 old direct `getFaceShape` declarations from `../providers/fluid-face-shape-providers.tsv` against the prior assigned reports, then pairs the remaining direct provider rows and the explicit old attachment-exception families relevant to the same flow terminal. It assumes equal raw block/fluid states, no same-fluid short circuit unless stated, and generated vanilla `LEAVES` membership. Active tag replacement and producers are not claimed.

This closes the direct residual class rows listed below, including their raw state domains. It does **not** freeze the complete face terminal: exact per-state closure of the broad inherited `Block.getFaceShape` registrations (including non-full `getShape` subclasses), all 80 oak-stair states against the new sturdy result, and non-vanilla tag payloads remain open. The older class-wide `Block.getFaceShape` default cannot be generalized to every subclass from its own body alone.

## Caller and terminal predicates

Both endpoint `FlowingFluid.getFlow` implementations call `isSolidFace` only for horizontal directions and the same horizontal directions one block above, inside the falling-fluid branch. UP is an early `true` result in both helper versions; DOWN is not queried by this caller. The old helper then returns false for ICE and for `Block.isExceptionForAttachment` or stairs, else compares direct `getFaceShape` to `SOLID`. The new helper retains same-fluid, UP and ICE gates, then uses `BlockState.isFaceSturdy` → `Block.isFaceSolid`: not active `LEAVES` and a collision face covering the full block face. Under the generated vanilla recipes, both endpoint `LEAVES` lists contain only the six leaf blocks; no residual registration below is a leaf.

For residual classes whose registrations set `noCollision`, new face-sturdy is false on all six faces regardless of outline output or raw state. Old direct `UNDEFINED` likewise yields false on horizontal faces after common gates; UP remains true from the helper, not from the direct face method. This property lets the state-domain rows below compress without sampling every state.

## Residual direct-provider state/output matrix

Face order is `DOWN, UP, NORTH, EAST, SOUTH, WEST`. `U` is old direct `UNDEFINED`; `0`/`1` are raw 1.14.4 face-sturdy results. Old helper results are `UP=1`; on horizontal directions they equal old direct output except where the old exception gate is noted. Only horizontal helper queries are consumed by `getFlow`.

| Old direct provider / common registration crosswalk | Complete raw state domain | Old direct output, all six | New sturdy output, all six | Flowing caller reach / closure basis |
|---|---|---|---|---|
| `AirBlock`: `air`, `cave_air`, `void_air` (old default registry key is `air`) | 1 state per ID | `U,U,U,U,U,U` | `0,0,0,0,0,0` | No collision at both endpoints; all states/IDs. |
| `BubbleColumnBlock`: `bubble_column` | `DRAG∈{false,true}` (2) | `U,U,U,U,U,U` | all false | `noCollision`; `DRAG` affects no collision shape. |
| `ChorusFlowerBlock`: `chorus_flower` | `AGE=0..5` (6) | `U,U,U,U,U,U` | **`1,1,1,1,1,1`** | Both registrations keep collision enabled. Old class overrides only face shape and returns `UNDEFINED`; new class inherits base full-cube collision/shape for all six ages. Horizontal outputs differ in the falling-fluid caller; UP helper result agrees via early gate; DOWN is not queried. This is a bounded terminal-input difference, not a flow-vector trajectory. |
| `ChorusPlantBlock` → `PipeBlock`: `chorus_plant` | `NORTH,EAST,SOUTH,WEST,UP,DOWN∈{false,true}` (64) | `U,U,U,U,U,U` | `0,0,0,0,0,0` | Collision enabled; `PipeBlock` radius `0.3125` creates a `[3,13]` core and arms whose perpendicular cross-section remains `[3,13]`. Every directional boundary slice therefore lacks the full 16×16 face for all 64 unions. The boolean state only selects arm unions. |
| `CobwebBlock`: `cobweb` | no properties (1) | `U,U,U,U,U,U` | all false | `noCollision`; all directions. |
| `EndGatewayBlock`: `end_gateway` | no properties (1) | `U,U,U,U,U,U` | all false | `noCollision`; all directions. |
| `EndPortalBlock`: `end_portal` | no properties (1) | `U,U,U,U,U,U` | all false | `noCollision`; its outline is irrelevant to collision-face dispatch. |
| `FireBlock`: `fire` | `AGE=0..15 × NORTH/EAST/SOUTH/WEST/UP booleans` (512) | `U,U,U,U,U,U` | all false | `noCollision`; new/old fire outline is empty; all raw assignments. |
| `LiquidBlock`: `water`, `lava` | `LEVEL=0..15` (16 per ID) | `U,U,U,U,U,U` | all false | `noCollision`; old height/neighbor-dependent outline is bypassed by old and new collision gates. Same-fluid short circuit also returns false when applicable. |
| `PortalBlock`: `nether_portal` | `AXIS∈{X,Z}` (2) | `U,U,U,U,U,U` | all false | `noCollision`; orientation-dependent outline is bypassed on the collision route. |
| `SignBlock` (abstract shared provider): old `sign`, `wall_sign`; new six standing species IDs and six wall species IDs | Standing: `ROTATION=0..15`; wall: `FACING` horizontal × `WATERLOGGED` boolean (8). Species IDs share these domains. | `U,U,U,U,U,U` | all false | All registrations are `noCollision`; old/new ID rename/split is recorded as a provider/domain crosswalk, not claimed as common literal IDs. The waterlogged-sign trajectory is not asserted. |
| `SkullBlock` old shared face provider; floor/wall skull registration family | Floor: `ROTATION=0..15`; wall: horizontal `FACING` (4); 12 common species IDs (six floor, six wall) | `U,U,U,U,U,U` | all false | Collision-enabled but never a full face: floor shape is centered 8×8 footprint and 8/16 high; wall shape is 8×8 on its support plane and only 8/16 high, leaving at least half of each boundary face uncovered. New Feather replaces the shared base with `BannerBlock` inheritance but paired floor/wall shape formulas retain these boxes. |
| `StructureVoidBlock`: `structure_void` | no properties (1) | `U,U,U,U,U,U` | all false | `noCollision`; all directions. |

For each row with old direct `U`, the complete old helper is `false` on each queried horizontal direction and `true` for UP from the common gate. The new helper has the sturdy result shown horizontally and also returns true for UP from its common gate. There is no state-specific producer or world-neighbor input in these residual face outputs, except shape geometry selected by the enumerated chorus-plant booleans and the fixed fluid/material gates.

## Old exception families using inherited `Block.getFaceShape`

The old `isExceptionForAttachment` gate also suppresses selected classes before the inherited default `Block.getFaceShape=SOLID`. The following exact common families have source-closed vanilla outputs that must be reconciled alongside direct overrides:

| Old exception / IDs | Old horizontal helper | New face-sturdy under generated vanilla tags | Domain / disposition |
|---|---|---|---|
| `GLASS`, all 16 `*_stained_glass` | false (explicit old placement exception) | true on all six faces | One state per ID; full default cube collision. This includes `glass` already used as the prior concrete witness, plus the 16 stained-glass registrations. |
| `BEACON`, `GLOWSTONE`, `SEA_LANTERN` | false (explicit old placement exception) | true on all six faces | One state each; each uses full-cube collision and is absent from default LEAVES. |
| `CONDUIT` | false (explicit old placement exception) | false on all six faces | `WATERLOGGED=false/true`; paired 6/16 centered collision box from `special-block-shape-pairing`. |
| Leaves | false (old LeavesBlock exception) | false on all six faces | All registered old leaf states are rejected by default generated `LEAVES`; its six-ID recipe is documented in the boundary report. Active runtime membership is not asserted. |
| Trapdoors | false (old `TRAPDOORS` tag exception) | false on all six faces for paired oak states | Existing full 64-state slab/trapdoor/snow report closes oak; remaining trapdoor species share the same thin panel shape provider, but a per-registration constructor audit is still part of the broad inherited-provider remainder. |
| Shulker boxes; piston base/head | false (old exception) | Progress/state-dependent sturdy results | Existing `shulker-collision-pairing` and `fluid-face-masonry` reports close their bounded state/context results; do not substitute static truth for moving pistons. |
| Cauldron; ICE; stairs | Cauldron/ICE false by exception/material gate; stairs false by old helper gate | Cauldron/ICE false under paired shapes and common ICE gate; stairs depends on raw state | Cauldron is closed by `cauldron-movement-relevance`; the complete oak-stair matrix is below. |

The glass, stained-glass, beacon, glowstone and sea-lantern rows are genuine same-state terminal differences for the horizontal helper if the falling-fluid caller samples one of those blocks: old false versus new true. This is not proof that a falling-fluid/player trajectory reaches such a sample. Conduit and leaves do not differ under the cited outputs. Runtime tag extensions/replacements are excluded.

## Complete oak-stair face matrix

The existing `common-block-shape-pairing/result.md` pairs all 80 `oak_stairs` tuples. The direct provider's raw domain is `FACING∈{N,E,S,W} × HALF∈{BOTTOM,TOP} × SHAPE∈{STRAIGHT,INNER_LEFT,INNER_RIGHT,OUTER_LEFT,OUTER_RIGHT} × WATERLOGGED∈{false,true}`. `WATERLOGGED` is ignored by both shape and old face providers, so each row below covers both values (40 geometry classes, 80 raw tuples). `D,U,N,E,S,W` bit order is Down, Up, North, East, South, West; `1` means the corresponding direct/sturdy result is true. The old direct mask follows the exact `StairsBlock.getFaceShape` switch. The new mask is calculated from the paired 1/2-grid collision-shape union selected by the source `SHAPE_INDICES` and `FACING.getIdHorizontal` tables; face slices are full iff all four half-by-half boundary cells are occupied.

| HALF | FACING | SHAPE | Old direct face mask | New sturdy mask |
|---|---|---|---|---|
| BOTTOM | N | STRAIGHT | `101000` | `101000` |
| BOTTOM | N | INNER_LEFT | `101100` | `101001` |
| BOTTOM | N | INNER_RIGHT | `101001` | `101100` |
| BOTTOM | N | OUTER_LEFT | `100000` | `100000` |
| BOTTOM | N | OUTER_RIGHT | `100000` | `100000` |
| BOTTOM | E | STRAIGHT | `100100` | `100100` |
| BOTTOM | E | INNER_LEFT | `100110` | `101100` |
| BOTTOM | E | INNER_RIGHT | `101100` | `100110` |
| BOTTOM | E | OUTER_LEFT | `100000` | `100000` |
| BOTTOM | E | OUTER_RIGHT | `100000` | `100000` |
| BOTTOM | S | STRAIGHT | `100010` | `100010` |
| BOTTOM | S | INNER_LEFT | `100011` | `100110` |
| BOTTOM | S | INNER_RIGHT | `100110` | `100011` |
| BOTTOM | S | OUTER_LEFT | `100000` | `100000` |
| BOTTOM | S | OUTER_RIGHT | `100000` | `100000` |
| BOTTOM | W | STRAIGHT | `100001` | `100001` |
| BOTTOM | W | INNER_LEFT | `101001` | `100011` |
| BOTTOM | W | INNER_RIGHT | `100011` | `101001` |
| BOTTOM | W | OUTER_LEFT | `100000` | `100000` |
| BOTTOM | W | OUTER_RIGHT | `100000` | `100000` |
| TOP | N | STRAIGHT | `011000` | `011000` |
| TOP | N | INNER_LEFT | `011100` | `011001` |
| TOP | N | INNER_RIGHT | `011001` | `011100` |
| TOP | N | OUTER_LEFT | `010000` | `010000` |
| TOP | N | OUTER_RIGHT | `010000` | `010000` |
| TOP | E | STRAIGHT | `010100` | `010100` |
| TOP | E | INNER_LEFT | `010110` | `011100` |
| TOP | E | INNER_RIGHT | `011100` | `010110` |
| TOP | E | OUTER_LEFT | `010000` | `010000` |
| TOP | E | OUTER_RIGHT | `010000` | `010000` |
| TOP | S | STRAIGHT | `010010` | `010010` |
| TOP | S | INNER_LEFT | `010011` | `010110` |
| TOP | S | INNER_RIGHT | `010110` | `010011` |
| TOP | S | OUTER_LEFT | `010000` | `010000` |
| TOP | S | OUTER_RIGHT | `010000` | `010000` |
| TOP | W | STRAIGHT | `010001` | `010001` |
| TOP | W | INNER_LEFT | `011001` | `010011` |
| TOP | W | INNER_RIGHT | `010011` | `011001` |
| TOP | W | OUTER_LEFT | `010000` | `010000` |
| TOP | W | OUTER_RIGHT | `010000` | `010000` |

This table compares raw direct old `FaceShape` output with the new sturdy bit, but the complete old fluid helper suppresses every stair state before that direct result is consumed. Therefore the actual old helper mask is `010000` for every stair state (the common UP early return), while the new helper mask is the sturdy mask with its UP bit forced to `1`. The horizontal `new helper=true` bits are direct old/new terminal differences in states where this falling-fluid caller samples that stair face. The fixed-state boolean is conditional source evidence only; this table does not prove any fluid/player trajectory. `WATERLOGGED` is not read by the provider or collision geometry.

## Coverage reconciliation against the 65-row old inventory

The following prior reports were inspected and reused; their state matrices were not repeated:

| Prior report | Direct face-provider classes closed in that report |
|---|---|
| `fluid-face-remaining-static/result.md` | `AnvilBlock`, `BannerBlock`, `BrewingStandBlock`, `ChestBlock`, `DragonEggBlock`, `EnderChestBlock`, `EndPortalFrameBlock`, `EndRodBlock`, `FlowerPotBlock`, `HopperBlock`, `IronBarsBlock`, `CakeBlock`, `CarpetBlock`, `FarmlandBlock`, `GrassPathBlock`, `TurtleEggBlock` |
| `fluid-face-slab-trapdoor-snow/result.md` | `SlabBlock`, `TrapdoorBlock`, `SnowLayerBlock` |
| `fluid-face-masonry/result.md` | `FenceBlock`, `FenceGateBlock`, `WallBlock`, `PistonBaseBlock`, `PistonHeadBlock`, `MovingBlock` and `MovingBlockEntity` dynamic result |
| `cauldron-movement-relevance/result.md` | `CauldronBlock` |
| `shulker-collision-pairing/result.md` | `ShulkerBoxBlock` registered facings/progress |
| `fluid-face-current-terminal/result.md` / `fluid-face-boundary/result.md` | Bounded `StairsBlock` source witness and accepted fluid operation boundary; the complete 80-state sturdy matrix remains open |
| `bed-shape-pairing/result.md` | `BedBlock` all 256 common raw states and face result |
| `rail-redstone-shape-pairing/result.md` | `AbstractPressurePlateBlock`, `AbstractRailBlock`, `ButtonBlock`, `DiodeBlock`, `LeverBlock`; their registrations are `noCollision`, so raw old `UNDEFINED` / new false outputs close for the complete state domains |
| `climb-trigger-shapes/comparison.md` | `LadderBlock`, `VineBlock`, `TripwireBlock`, `TripwireHookBlock`; collision/no-collision registration gates are stated there |
| `plant-crop-shapes-pairing/result.md` | `BaseCoralPlantTypeBlock` concrete family (no standalone ID), `CactusBlock`, `KelpBlock`, `KelpPlantBlock`, `SugarCaneBlock`; no-collision dominates all but cactus, whose inset collision box has no full face |
| `door-gate-shape-pairing/result.md` | `DoorBlock` and gate provider states (gate face separately in masonry); state/provider outputs are paired |
| `special-block-shape-pairing/result.md` | `CocoaBlock`, `ConduitBlock`, `EnchantingTableBlock` |
| `fluid-face-unpaired-closure/result.md` | Residual table above |

Remaining terminal gaps are the broad old base `Block.getFaceShape` inheritance census over concrete subclass registrations whose collision providers are not yet face-paired. The previously closed concrete direct Block full-cube witness is not generalized to these unpaired subclass registrations. This keeps the result explicitly partial and prevents an unsupported pair-freeze verdict.

## Exact source SHA-256

The following full-file hashes were recomputed from the canonical source roots. Shared terminal files are included because state cache, collision-shape dispatch, fluid helper gates and generated vanilla leaf membership determine these outputs.

| Relative source path | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |
| `net/minecraft/data/tag/BlockTagsProvider.java` | `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` | `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |
| `AirBlock.java` | `dc80bcd262bc9e8e84bfd66971bfaf8ed621f02899ae8802c9cb2b2fef8a93c4` | `5f39eac1ec12b6e5c37e07a6c153a3a539c10c26accb016e8384c801b6083d04` |
| `BubbleColumnBlock.java` | `0320e1b70b215dfff209f8e5003b97cac3a247fd3d642597f2db8ab46d251b2e` | `d5b9bdcf81349e96920134d6519629479787203d59ea2bd1683088c0b5223ef2` |
| `ChorusFlowerBlock.java` | `cacbbd84e9be8912d8e79d6d90cafd72a70b81d3e96518b8f0eb2eaf65fe19c4` | `5f8de15e04efd8f98a1dcc82628550cfcfe2d65c00bfbae6f56586b9e11adda4` |
| `ChorusPlantBlock.java` | `299acaed9644e0837a29f282e830dc7582b8d8f14a1c904147c034518e474433` | `0c05da2c054d2912bd667aaa200c4428fcc8e4064874056907656376b6120189` |
| `PipeBlock.java` | `4c56867771e5848fec41d7ccbce5339af3dfefa7f98afb4712dfd0d5abd8f9a9` | `50974f5a929e70166c8edbac17dd22b295ceb50bacd345d2b89a25bb150740b6` |
| `CobwebBlock.java` | `a0848fddd8d8c526e99241f6f6fab74df108d0f8861a4f04cc331fd6fd058875` | `ec068b2ead79f4986dad8afdbbf442dafb0725c39f1bbde286f670631324d704` |
| `EndGatewayBlock.java` | `f02bf4b06ab7bf2de97dac396f14a1e8d03d32bf386f3ef8676402d6baf05023` | `2bf5e035c7c770617c5156fe49ba120d44e1ce7f6815bf78c96efac16f60bb8c` |
| `EndPortalBlock.java` | `9541e703d04bf9148cb324741de73c4f3ce76021bc358f22308c946bccb72ad3` | `02c5ed627568172fc2dcb0a6b2f3263bebf7a975ff71bcbebe6067124bb6a050` |
| `FireBlock.java` | `cd9da861e6594e8ac5ab93bd26e268c03e9dbd0cc790c2a8e4a8d062e2af6336` | `b4d5e6e5b096bab0e353ed780fb8876ed9e086dc570d8397a1a4384b56dc9643` |
| `LiquidBlock.java` | `feedc9a5f1843604e6755a447e89d8d5599613799e25cf8c93a0562e52e97856` | `bfbbe2997ce6c03224b5833176d6b19b4b4b4cbc3337960fb3d867de77519ca1` |
| `PortalBlock.java` | `075976960fdb4518ec5ee70443d8bfd175981aeb01b71aec9bc8ad5d957ccee9` | `4e350efb356a684dfb554a83c06c1d138ac075e67cb6a9f9afa72881e17996f5` |
| `SignBlock.java` | `64d61e8c4758d6f1d13d92e56a25f7599736e625fcfaa980fcb1f8bebfe5ad39` | `0094a15d80c84593ebff08e68f0f0d5b9983ead9e289940b1dbdde734929c51c` |
| `SkullBlock.java` / new replacement base | `cb23466df16370da0f1e708210af9bca0f42e40270afa9d7eef21abc3254ac0c` | replaced by `BannerBlock` inheritance |
| `FloorSkullBlock.java` | `a23ac417451ead612e2a34185700c0631bdf75f7c6b6f7e1639b4624b8b12fc7` | `017f758d85d37d7d4bc86506e2c3e03fd7ff4f2027e9e8fa3d1b8abe8e9060a8` |
| `WallSkullBlock.java` | `d7ab74c4f259b2a6c742580a381f1f87a49862512d9324562f4b01679ef988dd` | `e5cedfc3f01dac16915c82f88bb620da894562f9994c25a6f84aae223975f179` |
| `StructureVoidBlock.java` | `4f3eadb2f4d3e5dfc3f193f7cb7e7fd477a29e8511df2a7bc60494a936dbabc8` | `9acd9449376d07a2b4a9e5fb3428c3ef37dc42ee4e4c08fd4ef556c31fffd250` |

No canonical source tree was modified or regenerated. No product, wiki, backlog or Git data was used; no builds, tests, game launches or decompilation were performed.
