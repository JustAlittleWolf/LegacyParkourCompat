# Default tag-provider movement membership closure: 1.13.2 → 1.14.4

## Result

Compared the vanilla default `BlockTagsProvider` and `FluidTagsProvider` recipes and traced tag reads in the paired movement/shape consumers. Source roots are the exact read-only Ornithe Feather Gen2 build 2 publications at `decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. All six reviewed source files' recomputed SHA-256 values match their endpoint `ornithe-feather.sources.sha256` entries (hashes below).

The effective default `WATER` and `LAVA` recipes are identical: `WATER` contains `Fluids.WATER` and `Fluids.FLOWING_WATER`; `LAVA` contains `Fluids.LAVA` and `Fluids.FLOWING_LAVA` (`FluidTagsProvider.addTags`, both versions lines 17–20). The corresponding `FluidTags` ids and `FluidTagsProvider.java` are identical across endpoints. This closes default membership inputs only; it does not establish fluid/player producer histories or runtime tag replacement.

The default `LEAVES` recipe is identical across endpoints and contains exactly the six old-era leaves blocks: jungle, oak, spruce, dark oak, acacia, birch (`BlockTagsProvider.addTags`, old lines 239–240; new lines 299–300). The old `BlockTags.TRAPDOORS` recipe is also unchanged: it references `WOODEN_TRAPDOORS` (acacia, birch, dark oak, jungle, oak, spruce) plus iron trapdoor (old lines 261–263; new lines 321–323). `BlockTags.LEAVES` and `TRAPDOORS` retain the same resource ids. These default memberships supply legacy SnowLayer support (`SnowLayerBlock.canBePlaced`, old lines 82–88), the newer full-face/sturdy/attachment helpers (`Block`, new lines 392–403), and old placement/support helpers; dynamic custom tag payloads remain outside this closure.

The 1.14.4 provider adds `WOODEN_FENCES`, composite `FENCES`, and `WALLS` recipes (provider lines 69–70, 270–288, 370). `FENCES` is the six wooden fences plus nether-brick fence; `WALLS` lists fourteen blocks, of which only cobblestone and mossy-cobblestone wall are from the old-era shared roster. These ids/recipes have no 1.13.2 tag counterpart. New `Entity.move` reads `FENCES`/`WALLS` at line 485 only in its air-block fall-damage surface fallback before calling `checkFallDamage`; this is not evidence of changed resolved position, velocity, box, or collision output. The new FenceBlock/WallBlock neighbor-shape branches also use these tags; their same-state/provider output coverage is owned by the pair's shape/state census and is not re-claimed here. New-only wall variants and arbitrary replacement tag membership are not paired old-era inputs.

## Exact source identities

| Release | Relative source | SHA-256 (recomputed; manifest match) |
|---|---|---|
| 1.13.2 | `net/minecraft/data/tag/BlockTagsProvider.java` | `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` |
| 1.13.2 | `net/minecraft/data/tag/FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` |
| 1.13.2 | `net/minecraft/tag/BlockTags.java` | `61ece958afe7fb7faca880064fcc11edd6f07fbc9fb118f0de22b6de6d2e9143` |
| 1.14.4 | `net/minecraft/data/tag/BlockTagsProvider.java` | `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |
| 1.14.4 | `net/minecraft/data/tag/FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` |
| 1.14.4 | `net/minecraft/tag/BlockTags.java` | `dc59d07204b25e5d852d0384e849975367590a3cbc2b9a293396d0bf5637e52a` |

Consumer traces checked: old `Block.java:244` trapdoor placement exception and `:295` water navigation predicate; old `SnowLayerBlock.java:82–88` leaves predicate; new `Entity.java:485` fence/wall check; new `Block.java:290,392–403` water and leaves-based shape/support predicates; local-player water membership reads in `Entity` and `PlayerEntity` at both endpoints. This report closes default tag recipes and records the new-only tag consumer scope; it does not claim a pair-wide freeze or re-open excluded producer evidence.
