# Independent inherited face-output recheck: 1.13.2 → 1.14.4

## Verdict and scope

**The reported 252-registration inherited `Block.getFaceShape` slice and its horizontal output partition are independently corroborated.** Under equal registered old-era raw block/fluid state, the same generated vanilla tag recipes, and the falling-fluid caller's non-same-fluid path, I recomputed 224 true→true, 8 false→false, and 20 false→true results. I found no omitted class/provider or state-property case within this 252-row roster.

This is only the fixed-state face predicate used by the falling-fluid current branch. It is not a fluid-vector, player trajectory, active tag collection, block/fluid producer, or full-pair-freeze finding. The other 10 inherited-shape registrations with non-`Block` old face behavior and the remaining custom-shape registrations are outside this recheck.

## Independent roster and source checks

I used the frozen common inherited-shape roster as the bounded registration input, then independently resolved its old face implementation against the actual old Feather source declarations. A search for exact `FaceShape getFaceShape(...)` source declarations in the old block package returns 65 files, matching the frozen direct-face inventory's 65 rows; the corresponding 1.14.4 search returns zero declarations. For each roster row, I compared the old inheritance chain against the source-derived direct-face class set, excluding base `Block`: **252** rows have no nearer face override and therefore dispatch to `Block.getFaceShape`; the other ten are exactly `chorus_flower`, `cobweb`, `end_gateway`, `kelp_plant`, `large_fern`, `lilac`, `peony`, `rose_bush`, `sunflower`, and `tall_grass`.

For those 252 rows, the frozen registration table records base collision output `cube` on both endpoints and `dynamicShape=false` on both. I checked that no class in either endpoint inheritance chain for these 252 IDs intersects a non-`Block` direct shape/collision provider in the frozen provider declaration inventory. The endpoint base methods supply the rest of the result directly: old `Block.getFaceShape` always returns `SOLID`; old/new `Block.getShape` returns a unit cube; old/new base collision dispatch returns that shape when `hasCollision` is true. The 252 registered rows have that true/cube output. These base methods do not read state, position, world, direction, or entity context, and the new states are static, so no omitted state-property branch changes these face outputs.

## Formula and result recomputation

In the old falling-fluid helper, a same-fluid neighbor returns false, UP returns true, `Material.ICE` returns false, then `Block.isExceptionForAttachment` or stairs return false; otherwise the queried old face shape is compared with `SOLID`. In the new helper, the same-fluid, UP, and `Material.ICE` gates precede the state face-sturdy query. That query resolves through `Block.isFaceSolid`: reject `BlockTags.LEAVES`, then require a full face of the collision shape. The falling-flow caller queries horizontal neighbors and the same horizontal faces one block above; it does not consume DOWN, and its UP short-circuit is common.

The old source's exact attachment-exception formula and the 252-row class/ID list give these subsets:

| Recomputed horizontal category | IDs | Count | Old result → new result |
|---|---|---:|---|
| Default leaves | `acacia_leaves`, `birch_leaves`, `dark_oak_leaves`, `jungle_leaves`, `oak_leaves`, `spruce_leaves` | 6 | false → false |
| `Material.ICE` gate | `ice`, `frosted_ice` | 2 | false → false |
| Old attachment exception; retained full cube and not a default leaf | All 16 `*_stained_glass` IDs, `glass`, `beacon`, `glowstone`, `sea_lantern` | 20 | false → true |
| Base SOLID face, no old helper exception, not a default leaf or ICE | Remaining 224 roster IDs | 224 | true → true |

The old exception source also names Shulker boxes, cauldrons, trapdoors, conduits, pistons/piston heads, and other classes; none is in this default-face/base-shape subset, because its registered class/shape ancestry is outside the 252 rows. I did not generalize the result to them.

Both endpoint `BlockTagsProvider` recipes list the same six `LEAVES` entries: jungle, oak, spruce, dark oak, acacia and birch. Therefore the 20 false→true rows are not default leaves, while the six leaf rows are rejected by the old class exception and new vanilla `LEAVES` predicate. Runtime tag replacement remains an excluded input.

## Source identities and reproducibility

I recomputed the exact endpoint source hashes below; each hash appears in its corresponding Feather source manifest. The source-manifest hashes are 1.13.2 `2C8CFB646BF622FB26AC0CA0CB5E02A354FB512E29F8B1010F1AAACD509E1211` and 1.14.4 `717B468536348557F9DAE8CF57EDCCF80AD16EB65E5BEF6C60BDB5EA3C9F75BC`.

| Release | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/Block.java` | `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496FDA381628E90B3B3FF8AE376A5BAE24CBD662366F34D70991252FAB2FE70` |
| 1.13.2 | `net/minecraft/fluid/FlowingFluid.java` | `2398D109DDC5785CB1BC8872B8C157319137DF8957FA8A03581A8F68AFB1253` |
| 1.13.2 | `net/minecraft/data/tag/BlockTagsProvider.java` | `DB7E0AA20A1E9429380328B64812BDFF9D2D4B3B9D2016888CB7348D0EBafc7e` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1F8EC3628F08E196C2793E91CA0B94FEACEA6BC3939E7FB770F0682A6E66F2C5` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6C6703C7C2F7203A7507D8A621BC83E1DAD613B32089394F5AF4FBD8636B165F` |
| 1.14.4 | `net/minecraft/fluid/FlowingFluid.java` | `6AFB033D18E6D28FF6D7DEDA88F5F1432914903B0FEF100C44FB8372D3E148CE` |
| 1.14.4 | `net/minecraft/data/tag/BlockTagsProvider.java` | `0BD051D11A0C85ECC61CD2202A6ED33923DB97238DA0B065A647B932132D1BFA` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9C0323497B31F8A284456E5692898897B92B6F0817D0371FAE9A8AFB54C638F8` |

Input artifacts checked by hash: the bounded registration roster `base-shape-registration-census/inherited-common-registrations.tsv` (`44005DE72F8E952C0DD72C19D0E6D037D5040F86D27482CD698D69C7B2D269AF`), direct old face inventory `providers/fluid-face-shape-providers.tsv` (`DD6CEBCBF8BE7C4CCF51C2FA23A45115C3CD19B5AECAA64A2BDEAEF44038FB20`), and shape-provider declaration inventory `providers/shape-provider-overrides.tsv` (`84000A32434DD95817FB6BA6B4834C001FC22EC113272FA536638041DF71ACAD`). The independently recomputed 252/10 class split and four output counts above do not consume the prior face-result table as proof.

No source tree was written or regenerated. No product, wiki, backlog or Git information was used; no build, test, runtime, or decompilation was performed.
