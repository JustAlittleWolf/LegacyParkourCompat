# 1.13.2–1.14.4 special block shape provider pairing

## Scope and source identity

Compared only the Feather-mapped exact sources for the four assigned block providers and their registration/state/collision dispatch. Old source root: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` (provenance identifies Minecraft 1.13.2 and Feather Gen2 build 2). New source root: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather` (provenance identifies Minecraft 1.14.4 and Feather Gen2 build 2). These are the published Feather mappings; the 1.14.4 Mojmap output and unpublished Yarn staging directory were not used.

The registered identifiers and constructor properties match across endpoints. All four use the default collision-enabled `Block.Properties` (`hasCollision=true`); none calls `noCollision()` or `dynamicShape()`. Registration sources are old `net/minecraft/block/Block.java` and new `net/minecraft/block/Blocks.java`.

## Paired provider results

| Block ID | State domain | Old → new shape method | Effective collision shape (sixteenths) | Provider inputs |
|---|---:|---|---|---|
| `minecraft:end_portal_frame` | `FACING` = 4 horizontal directions × `EYE` = false/true = 8 | `getShape(state, world, pos)` → `getShape(state, world, pos, context)` | Eye false: base `[0,0,0–16,13,16]`. Eye true: union of base and `[4,13,4–12,16,12]`. | Reads only `EYE`; `FACING`, world, position, and new collision context are ignored. |
| `minecraft:cocoa` | horizontal `FACING` × `AGE_2` values 0–2 = 12 | `getShape(state, world, pos)` → `getShape(state, world, pos, context)` | Same 12 facing/age combinations on both sides: N age0 `[6,7,1–10,12,5]`, age1 `[5,5,1–11,12,7]`, age2 `[4,3,1–12,12,9]`; S age0 `[6,7,11–10,12,15]`, age1 `[5,5,9–11,12,15]`, age2 `[4,3,7–12,12,15]`; W age0 `[1,7,6–5,12,10]`, age1 `[1,5,5–7,12,11]`, age2 `[1,3,4–9,12,12]`; E age0 `[11,7,6–15,12,10]`, age1 `[9,5,5–15,12,11]`, age2 `[7,3,4–15,12,12]`. | Reads only `AGE` and `FACING`; world, position, and new context are ignored. Neighbor support is checked by placement/update methods, not by the shape getter. |
| `minecraft:enchanting_table` | no block state properties = 1 | `getShape(state, world, pos)` → `getShape(state, world, pos, context)` | `[0,0,0–16,12,16]` on both sides | Constant; state, world, position, and new context are ignored. |
| `minecraft:conduit` | `WATERLOGGED` = false/true = 2 | `getShape(state, world, pos)` → `getShape(state, world, pos, context)` | `[5,5,5–11,11,11]` on both sides | Constant; waterlogged state, world, position, and new context are ignored. The waterlogging implementation/interface changed, but it does not feed the shape getter. |

Thus the collision output is equal for all 23 registered state tuples. No provider reads neighboring block state, world contents, entity identity, or collision context. The new context parameter is a signature/dispatch change only for these bodies. Cocoa’s placement/support dependency and Conduit’s fluid state production do not alter these fixed-state shape outputs.

## Movement collision route and bounded caveat

Old `Entity.move` gathers `world.getCollisions(...)` before clipping its requested motion against the returned voxel shapes. Old `WorldView.getBlockCollisions` obtains each candidate with `BlockState.getCollisionShape(world, pos)`. New `Entity.move` includes `world.getBlockCollisions(entity, box)` in its collision set; new `WorldView.getBlockCollisions` builds `CollisionContext.of(entity)` and calls `BlockState.getCollisionShape(world, pos, collisionContext)`. Each of the four new shape overrides ignores that context, so this call path returns the paired shapes above. Under equal raw block-state/world inputs, this provider batch yields no movement collision-shape delta.

Separate state metadata changed: all four old block classes explicitly return `false` from `isCube`; in 1.14.4 EndPortalFrameBlock and EnchantingTableBlock explicitly return `true`, while CocoaBlock and ConduitBlock inherit Block’s `true` default. This is not the geometry result: both old `World.isFullCube` and the 1.14.4 movement collision consumers inspected here test fullness from the collision shape, which is non-full for these geometries. The flag difference should remain visible to the full-pair inventory if other direct consumers are in scope; this report does not claim the broader state-predicate inventory is closed.

## Exact source references and SHA-256

Relative paths below are under the corresponding source root above.

| File | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/block/EndPortalFrameBlock.java` | `c196aeba3dd6c9683659ab08b71a759b448709e8cc45e68aca448a7e6e470523` | `4346ef0aa80c4d40edc7f33c65a72cc4428190c02af16516d9df5084ed2be4db` |
| `net/minecraft/block/CocoaBlock.java` | `6655df26d136eb21d94b323496c77b5237484a86a1362e4ddd636e35c6997445` | `67deecadff4cc8435e15722f1d38523dd367fdbb175bc45d1463082e34f53d86` |
| `net/minecraft/block/EnchantingTableBlock.java` | `db240cb9087fa871f964df7ded66581c567b41240ecd8d517b02295329a3f69d` | `ef5fe857df45dc69c7ef67f75d5f397c92bc312cf1a5c5e3b8dfcae5e2739c88` |
| `net/minecraft/block/ConduitBlock.java` | `66b110a324d9c3fe60eaa6595e59eab1b720a92a234307a8a77796b8b26a8eee` | `462f208e190b2364efc53f442b1861752272d28038696cf036786169bd1ecd70` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| Registration source (`Block.java` → `Blocks.java`) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/state/StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |

Registration excerpts: old `Block.java` around lines 1214, 1221–1227, 1871; new `Blocks.java` around lines 753–775, 1835. Shape methods: EndPortalFrameBlock old/new around lines 32/41; CocoaBlock around 63/64; EnchantingTableBlock around 26/41; ConduitBlock around 71/66. Collision dispatch references: old `Entity.move` around 473–590 and `WorldView.getBlockCollisions` around 112–158; new `Entity.move` around 444–710 and `WorldView.getBlockCollisions` around 133–185. State domains come from the listed `buildStateDefinition` methods plus each class’s default state and `Properties` declarations.

This closes only the assigned fixed-state outline/collision-provider batch. It does not prove state production, trajectory parity, intermediate patch boundaries, or full-pair freeze.
