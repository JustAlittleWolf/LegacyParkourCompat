# 1.13.2 → 1.14.4 BlockState shape-cache and entity-context pairing

## Scope and disposition

This source-only slice pairs the `BlockState` shape dispatch/cache entry points with the block collision query used by local `Entity.move` and its `hasNoCollisions` step/sneak probes. The result narrows the query/context dependency: 1.14.4's player collision query passes a live entity `CollisionContext` directly to the block's world-and-position collision-shape method; it does not consume the precomputed state collision cache. The old player query uses the old world-and-position method without entity context. At 1.14.4, only the new `ScaffoldingBlock` source found in this block package reads context fields; scaffolding was introduced after 1.13.2 and is outside historical-era block-shape scope. No context-dependent output difference for common old-era block registrations is established here.

The provider inventory remains open: this report does not pair all per-state/world/neighbor shape outputs, movement collision-candidate enumeration, entity shapes, or border/chunk terminals. It makes no trajectory or full-pair-freeze claim.

## Exact source identity

Both endpoint roots are the read-only published Ornithe Feather Gen2 trees for Minecraft 1.13.2 and 1.14.4. SHA-256 was recomputed from each named source file:

| Endpoint | Source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/world/CollisionContext.java` | `36a2e4a1aeedccbb1b916ec7619a6660f3889cae7e336c2f24b631976c2a8e86d` |
| 1.14.4 | `net/minecraft/world/EntityCollisionContext.java` | `baef568686dfbcfd2b36f78f41b4517421585ba2d1df8dc7f90964fc7dc76a6d` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `net/minecraft/block/ScaffoldingBlock.java` | `4b22b178d03266296d715c1b7208f347b879ae24ba55da01a2c1e4983168e64c` |

There is no 1.13.2 `net/minecraft/world/CollisionContext.java` or scaffolding block source. No source was generated or modified.

## Dispatch and cache behavior

In 1.13.2 `BlockState.getCollisionShape(world,pos)` directly delegates to `Block.getCollisionShape(state,world,pos)`; the old API has no collision-context overload. In 1.14.4 the same no-context overload returns the cached `collisionShape` when a cache exists; otherwise it calls the context overload with `CollisionContext.empty()`. The explicit three-argument overload always delegates to `Block.getCollisionShape(state,world,pos,context)`.

`BlockState.cacheShape()` creates the cache only when `!block.hasDynamicShape()`. During `Blocks` static initialization, every registered block state receives `cacheShape()`. The cache constructor samples collision shape with `DummyBlockView.INSTANCE`, `BlockPos.ORIGIN`, and `CollisionContext.empty()`. Consequently, no-context reads of non-dynamic states can return a construction-time shape and do not re-evaluate world/position inputs; dynamic states leave the cache null and the no-context route evaluates at the supplied world/position with empty context. Shape declaration or dynamic flag differences still need provider-specific pairing. Static caching itself is not the path used by the local-player collision iterator below.

## Player collision query and context

1.13.2 `Entity.move` calls `WorldView.getCollisions(this, box, dx, dy, dz)` at the primary collision solve (and again on a step alternative). The `WorldView` expansion/clipping route enumerates its block region then calls `state.getCollisionShape(world,pos)`. Its entity argument affects border hysteresis, not the block-shape method; no player-specific shape context is supplied.

1.14.4 `Entity.move` concatenates its selected collision candidates with `world.getBlockCollisions(entity, expandedBox)`. The `WorldView` iterator creates `CollisionContext.empty()` only for a null entity; for a non-null entity it constructs `CollisionContext.of(entity)` once and calls `blockState.getCollisionShape(world,pos,collisionContext)` for each candidate. `WorldView.hasNoCollisions(entity,box)` used by the paired player step/sneak probes routes through `getCollisions`, then the same `getBlockCollisions(entity,box)` method, so it also uses a live context. The cache overload is bypassed in both ordinary main collision and these probes.

`CollisionContext.of(entity)` creates `EntityCollisionContext`, capturing `entity.isSneaking()`, `entity.getShape().minY`, and, for a `LivingEntity`, its main-hand `Item`; non-living entities use `Items.AIR`. Empty context reports non-sneaking, does not hold an item, and its `isAbove` implementation returns the supplied default. Entity context tests the captured bottom Y against the candidate position/shape's top with a `1.0E-5F` margin. This context can make new shape providers depend on player pose/sneak/held-item and relative height, whereas the 1.13.2 shape dispatch cannot receive those values.

The 1.14.4 block-package search for context reads (`context.isSneaking`, `.isAbove`, `.isHoldingItem`) found `ScaffoldingBlock` as the only consuming block source. Its collision output branches on `isAbove` and sneaking. `Blocks` registers scaffolding with `.dynamicShape()`, so it is also excluded from the cache and evaluated dynamically. It has no 1.13.2 registration/source; the context-specific behavior is therefore not a changed shape for an old-era common block. Other 1.14.4 context-signature collision overrides found in the block package do not read context fields. Their world/position/state geometry remains covered only where paired in the separate provider-state reports.

## Remaining inputs

- Pair every still-uncovered common old-era collision provider's shape for all reachable property states and any world/neighbor inputs. This context pass does not close the large provider inventory.
- Keep the broader 1.13.2/1.14.4 collision-query differences open: swept candidate bounds/order, unloaded chunk handling, border hysteresis, entity candidate sources, and step tie/candidate paths have separate partial reports.
- A state/context trajectory cannot be inferred from this API pairing. Equal entity and raw world inputs are comparison assumptions; no input-device, server producer, block-state producer, or runtime-tag replacement evidence is included.

No tests, builds, game launches, source preparation, product implementation/wiki/backlog reads, or shared-root Git operations were performed.
