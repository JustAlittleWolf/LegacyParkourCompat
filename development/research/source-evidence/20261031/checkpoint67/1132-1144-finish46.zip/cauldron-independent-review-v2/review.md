# Independent review v2: cauldron collision volume candidate

## Verdict

**CONDITIONAL.** The revised draft now explicitly states `noClip=false` and a paired collision query with no other clipping block or entity shapes. Those close the premises raised by the first review. I independently reread the exact Feather provider and movement sources and verified the cited SHA-256 values. The shape arithmetic and clip limits are correct for a standard standing box.

One remaining input is not fixed in the draft: the movement argument entering collision resolution must be `(0,+0.5,0)` at both endpoints. In 1.13.2 `Entity.move` transforms the request when `inCobweb` is set (Y multiplied by `0.05F`); in 1.14.4 it transforms it when the pending movement multiplier has nonzero squared length. Therefore the literal call argument alone does not guarantee that the collision resolver receives the stated displacement. Add an explicit neutral pre-movement multiplier premise (`inCobweb=false` old and movement multiplier zero new), or state that `(0,+0.5,0)` is the vector after those gates. Then the direct operation result is acceptable under the already stated raw-state/query assumptions. This is not a trajectory requirement.

## Independent source arithmetic

- The old cauldron is `unitBlock  INSIDE_SHAPE`, with the interior cavity beginning at y=`4/16`, so the centered player footprint intersects a bottom collision slab whose top is at y=`4/16`.
- The new provider also subtracts three boxes whose union contains the centered x/z square `[2/16,14/16]²` through y=`3/16`. The player footprint `[0.2,0.8]²` lies inside that square. The residual plate begins at y=`3/16`.
- From initial player top y=`-0.2`, the corresponding single-shape upward max offsets are old `0 - (-0.2) = +0.2` and new `3/16 - (-0.2) = +0.3875`. A vertical-only `SELF` request does not invoke horizontal step alternatives. With the candidate's explicit noClip and no-other-clipping-shape conditions, no other collision query output changes those values.
- The candidate correctly limits its claim to a direct operation input and does not claim a preceding tick history or producer.

## Exact input identities

| Input | SHA-256 |
|---|---|
| Revised candidate `.native-source/20261031/1132-1144-finish46/candidates/cauldron-collision-volume.draft.md` | `08b13f799ff1cfb2cc6ded9242d2681d948d4fdc5aac7807637c7465c71bcd3b` |
| `cauldron-storage-shapes/result.md` | `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360` |
| `cauldron-movement-relevance/result.md` | `a77f53dcbc21d9e9a4c1b3aff59394bfcff534ac219900a2e2606758f0ced591` |
| 1.13.2 `net/minecraft/block/CauldronBlock.java` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` |
| 1.14.4 `net/minecraft/block/CauldronBlock.java` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| 1.13.2 `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 `net/minecraft/entity/living/player/PlayerEntity.java` (standing dimensions) | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 `net/minecraft/entity/living/player/PlayerEntity.java` (standing dimensions) | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

No product implementation, wiki, backlog, or Git source was consulted. No build, test, game launch, or source generation was performed.
