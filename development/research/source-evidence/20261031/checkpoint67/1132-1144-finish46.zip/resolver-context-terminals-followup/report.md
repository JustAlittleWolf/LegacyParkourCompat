# Resolver context terminals and mixed-vector overlap residual: 1.13.2 → 1.14.4

## Bounded scope and source identity

Read-only continuation of `resolver-query-branch-closure/report.md`, limited to special/dynamic/context collision providers and the old `excludeBlock` versus new mixed-vector candidate membership. It does not revisit the closed query-stream call mapping or bounded disjoint unit-cube witnesses. Source roots are the published Ornithe Feather Gen2 build 2 trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`; source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` respectively.

## Context and dynamic provider routes

- **Context-sensitive provider found: 1.14.4 scaffolding.** `WorldView.getBlockCollisions(entity, box)` creates `CollisionContext.of(entity)` and passes it to `BlockState.getCollisionShape(world,pos,context)` (`net/minecraft/world/WorldView.java:133–176`; `net/minecraft/block/state/BlockState.java:201–202`). `ScaffoldingBlock.getCollisionShape` is the only collision-shape provider found in the paired 1.14.4 block source that reads the context (`net/minecraft/block/ScaffoldingBlock.java:118–124`): it branches on `isAbove`, `isSneaking`, `DISTANCE`, and `BOTTOM`; the collision-context entity supplies bottom Y and sneaking, and supplies main-hand item for `isHoldingItem` where relevant to the outline `getShape` at `:43–49`. The registered `minecraft:scaffolding` instance is `.noCollision().dynamicShape()` (`net/minecraft/block/Blocks.java:1913–1916`), but the state dispatch invokes the override directly; this override itself returns the collision geometry and does not call the base `hasCollision` gate. Its dynamic registration also bypasses static state-shape caching (`BlockState.cacheShape`, `:65–68`). There is no 1.13.2 scaffolding class or registration in the exact old block source (`rg scaffolding` returned no match), so this terminal is **new-only/unpaired** and not an old-era fixed-profile shape comparison. This is not evidence for an intermediate introduction boundary.
- **Common dynamic shulkers: paired terminal.** `ShulkerBoxBlock.getShape` reads the block entity at `(world,pos)` and returns its animated shape, falling back to a full cube when the expected entity is absent. Old `:210–213`; new `:226–229`. New `CollisionContext` is ignored. Both registrations opt into `dynamicShape`; the existing `shulker-collision-pairing/result.md` reports equal outputs for matching facing and raw animation inputs. This is a paired provider result conditional on the same block-entity/world/position inputs, not proof of their production or synchronization.
- **Common moving-piston provider: paired terminal.** Old/new `MovingBlock.getCollisionShape` fetches a `MovingBlockEntity` at the same position and delegates to its dynamic collision shape, otherwise returning empty (old `MovingBlock.java:108–111`; new `:104–107`). The new context argument is ignored. Both `moving_piston` registrations use `dynamicShape`; the existing `piston-shape-pairing/result.md` and `moving-piston-nested-shape-closure/report.md` find the wrapper formula equal for matched entity fields, with equality of arbitrary moved-block output conditional on the nested provider. The new no-context `BlockState.getCollisionShape` uses cached static output or `CollisionContext.empty()` (`BlockState.java:197–203`); this is the nested moved-state path, distinct from the outer entity-context query.

The context API inputs are exact: `EntityCollisionContext(Entity)` captures `entity.isSneaking()`, entity-shape minimum Y, and the main-hand item for `LivingEntity` (else AIR); `isAbove` compares bottom Y against `pos.y + shape.maxY - 1.0E-5F`. Source method bodies show no additional context-reading block collision provider among the scanned 1.14.4 block sources. Other overloaded shape methods accept the context but do not read it. This census is about provider method inputs only; it does not prove movement-path reachability for arbitrary state histories.

## Mixed-vector overlap / excludeBlock condition

The old candidate method is `WorldView.getBlockCollisions(VoxelShape shape, VoxelShape excludeBlock, boolean checkWorldBorder)` (`1.13.2 net/minecraft/world/WorldView.java:112–150`). For each enumerated cell it computes that cell's collision shape, shifts `excludeBlock` by the negative cell position, and discards the whole cell shape if `VoxelShapes.overlap(localExclude, cellShape, AND)` is true. The old query caller supplies the original player box as `excludeBlock` while `shape` is the movement shell (`WorldView.java:158–177`). Consequently any positive 3D overlap between the original box and a provider shape suppresses that cell candidate, even where the provider also extends into the movement-only shell.

For the new mixed-vector route, the resolver calls `WorldView.getBlockCollisions(entity, box.expand(vector))` (`1.14.4 WorldView.java:133–176`, via `Entity.m_64271959`, crosswalk in the permitted query-branch report). New enumeration has no `excludeBlock` parameter: after state/provider dispatch it emits a translated shape when it positively overlaps `VoxelShapes.block(queryBox)` under `AND`. Thus, holding the effective provider output fixed, the **unclosed membership case** is a candidate shape that (a) is in an eligible old enumerated cell and intersects the old movement shell, (b) positively overlaps the original entity box so old local `excludeBlock` removes it, and (c) positively overlaps that invocation's new expanded query box so new emits it. For step alternatives, (c) must be evaluated at that alternative's actual raised/expanded box. This is a route-level condition only: no ordinary-player movement/clip-result witness for it was established, and no old/new provider equality is inferred for unmatched or context-dependent outputs.

This condition is separate from the bounded report's disjoint-initial-box witness: there `excludeBlock` overlap is false, so candidate membership agrees for the fixed unit cube. It also does not resolve zero-volume face/edge contact, which the positive-volume `AND` overlap test rejects.

## Exact files and hashes

Hashes below are SHA-256 of full Feather Java files; paths are relative to each version's `ornithe-feather` root. The WorldView hashes match the preceding query-branch closure report.

| Version | File | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.14.4 | `net/minecraft/block/ScaffoldingBlock.java` | `4B22B178D03266296D715C1B7208F347B879AE24BA55DA01A2C1E4983168E64C` |
| 1.14.4 | `net/minecraft/world/EntityCollisionContext.java` | `BAEF568686DFBCFD2B36F78F41B4517421585BA2D1DF8DC7F90964FC7DC76A6D` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9C0323497B31F8A284456E5692898897B92B6F0817D0371FAE9A8AFB54C638F8` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6C6703C7C2F7203A7507D8A621BC83E1DAD613B32089394F5AF4FBD8636B165F` |
| 1.13.2 | `net/minecraft/block/MovingBlock.java` | `19B8A41104DA7B13EAC58E2C01704043F6FF7AC1EEA33457833BD41EA5810D61` |
| 1.14.4 | `net/minecraft/block/MovingBlock.java` | `6E3EC2D4C9712F8012BB2BCAD5474125DACD1ACF3D4B02BD8A5D8EA0C4BF4E6E` |
| 1.13.2 | `net/minecraft/block/ShulkerBoxBlock.java` | `9D2652C2944CC8FAF1A277349FBF2015170A4799AD882F876D24EE1D7F344FB8` |
| 1.14.4 | `net/minecraft/block/ShulkerBoxBlock.java` | `016487146BC14ABA8DE02272E0BF5C76B4DFF16C276ABF30BF92CFA3061593DF` |

## Next exact residual and exclusions

Next source-only residual: establish whether a valid same-era player box/provider-state pair can meet the three overlap conditions above, then compare the exact old/new candidate handoff and axis clip inputs while separately pairing that provider's effective state/context output. Keep actual movement outcome unclaimed unless the paired clip path proves it. Server checks, input histories and fluid/state producer histories were not examined and are explicitly excluded from this report.

No source, product, wiki, backlog, or Git data was read or changed beyond the explicitly permitted source-only reports and exact source trees. No build, test, runtime, decompilation, or network activity was performed.
