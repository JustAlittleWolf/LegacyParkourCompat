# Independent review: cauldron lower collision volume

## Verdict

**CONDITIONAL — the candidate's shape and clipping arithmetic are source-confirmed, but the query premises need one explicit closure before acceptance.** For the specified cauldron and centered 0.6-wide box, with no other intersecting collision shapes and with ordinary non-noClip movement, the old cauldron clips upward movement at `+0.2`, while the 1.14.4 lower cross-removal exposes the remaining plate at `3/16`, permitting `+0.3875`. I independently recomputed both provider source hashes and both `Entity.java` hashes; they match the candidate and the paired reports.

The draft does not explicitly state that the collision snapshot contains no other blockers/entities (or otherwise that none clips this requested vertical move). It says the first collision is the cauldron plate, which depends on that condition. Add the collision snapshot/no-other-clip premise, and state `noClip=false`; then the operation-level claim is acceptable under the project's paired raw-position/query assumptions. The below-block position has no preceding ordinary tick history claimed, as the draft correctly says, and no producer proof is needed for this direct operation input. This review does not assert a reachable trajectory.

## Independent source check

- 1.13.2 `CauldronBlock.getShape` returns `VoxelShapes.block() ONLY_FIRST INSIDE_SHAPE`; the cavity starts at local Y `4/16`, leaving the full horizontal bottom footprint from Y `0` through `4/16` solid.
- 1.14.4 `CauldronBlock.getShape` subtracts the same inside cavity plus three boxes spanning local Y `0` through `3/16`. Their union covers the centered `[2/16,14/16] × [2/16,14/16]` footprint. The assumed player footprint `[0.2,0.8]²` is contained in it, leaving no shape collision there below the plate.
- Both versions use the regular axis clip for the vertical-only `SELF` request; the old route computes a maximum Y offset from world collisions, and the new route's vertical-only fast route does likewise. No step alternative is eligible because X/Z input is zero. With no other clipping candidate, old contact begins at Y `0` for `+0.2`; new contact begins at Y `3/16` for `+0.3875`.
- The 1.14.4 context overload does not change this provider; the cauldron method returns a constant shape. `LEVEL` is not read by either shape provider. This is a direct collision terminal difference for the same raw block state and player query inputs, separate from the cauldron fluid-face result.

## Input identities

| Input | SHA-256 |
|---|---|
| Candidate `.native-source/20261031/1132-1144-finish46/candidates/cauldron-collision-volume.draft.md` | `349eae6fca5d00bd2a650367a2941743d07ba6a7ccce779352cc664885080362` |
| `cauldron-storage-shapes/result.md` | `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360` |
| `cauldron-movement-relevance/result.md` | `a77f53dcbc21d9e9a4c1b3aff59394bfcff534ac219900a2e2606758f0ced591` |
| 1.13.2 `net/minecraft/block/CauldronBlock.java` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` |
| 1.14.4 `net/minecraft/block/CauldronBlock.java` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| 1.13.2 `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |

No product implementation, wiki, backlog, or product Git was read. No build, test, game launch, or source generation was performed.
