# 1.13.2 → 1.14.4 local-player construction and reset pairing

## Scope and disposition

Paired initial-login construction and world installation, local-player reset, ability application, and player replacement on respawn. Compared only movement-facing position, bounding box/dimensions, velocity, pose/flags, yaw/pitch, and abilities reached through `setWorld`, `initPlayer`, `adjustPlayer`, and `resetPos`. Packet fields (dimension, game mode, entity ID, reduced-debug flag) and prior-player state are treated as equal logical inputs. No server packet producer is inferred. No pair-freeze claim is made.

## Exact source identity

Read-only roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, the exact Ornithe Feather Gen2 build 2 / Vineflower / Java 25 trees described in the permitted adjacent pairing reports. Those reports bind the trees to their ready markers, provenance, mapping artifacts, and full source manifests. I rechecked hashes for every source file named below; the handler, interaction-manager, player, game-mode, and entity hashes match the source-manifest entries and the adjacent reports. Neither source tree was written or regenerated.

| Release | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/Minecraft.java` | `b1d35473cd12bdf38e87f9888b4ed6f620614cbe914cf7e7a40c601d4e284875` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/client/ClientPlayerInteractionManager.java` | `892bdb99e894b538daeeb7fd9ae6f9a0970b854f38f51b4b39c446e905692359` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/client/Minecraft.java` | `6a5d9fac7092e8ec89bb86dd545e083d20df27edd039e26d68a216442ed039b2` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.14.4 | `net/minecraft/client/ClientPlayerInteractionManager.java` | `86707c46294dae65c878e43da56b9330ab46e7069d8119e179e485baafb2d0de` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54e9d308703bf49cb53b72646b05253857e9557d657df` |
| both | `net/minecraft/world/GameMode.java` | `f245fb32c78232d3e936edfd517c76e727591c93001049f4e5e94ce86ed48971` |

## Initial login and identity routing

In 1.13.2, `ClientPlayNetworkHandler.handleLogin` (`ClientPlayNetworkHandler.java:316–340`) constructs the interaction manager and client world, then calls `Minecraft.setWorld`. When `Minecraft.player` is null, `Minecraft.setWorld` (`Minecraft.java:1434–1446`) constructs a `LocalClientPlayerEntity` from the connection profile, calls `ClientPlayerInteractionManager.initPlayer` (yaw `-180.0F`), optionally publishes its UUID to the integrated server, calls `resetPos`, adds it to the world, installs `KeyboardInput`, applies the manager's current game mode through `adjustPlayer`, and assigns the camera. The handler then writes packet dimension, opens the terrain screen, sets the packet network ID and reduced-debug flag, applies packet game mode, and syncs client settings.

In 1.14.4, `Minecraft.setWorld` (`Minecraft.java:1534–1549`) only installs the world and updates renderer/particle/block-entity world references (plus profile services). `handleLogin` (`ClientPlayNetworkHandler.java:341–384`) then constructs the player if null, writes yaw `-180.0F`, optionally publishes its UUID, resets position, registers it in `ClientWorld` under the packet entity ID, installs input, applies the manager game mode, assigns the camera, writes packet dimension, opens the terrain screen, writes network ID and reduced-debug state, applies packet game mode, and syncs settings.

Both `LocalClientPlayerEntity` constructors delegate to the same-shaped `PlayerEntity` constructor: it initializes from `EntityType.PLAYER`, sets UUID/profile and menus, and positions at the world's spawn point plus `(0.5, 1, 0.5)` with zero yaw/pitch (`PlayerEntity.java:144–153` → `:159–168`). `Entity.setPositionAndAngles` writes current, `last`, and `prev` coordinates, then yaw/pitch, then the box; its operation body matches at both endpoints (`Entity.java:1125–1138` → `:1127–1140`).

The local player is addressed directly by `minecraft.player` for construction, reset, camera, and ability writes. For entity-ID routes, 1.13.2 `ClientWorld.getEntity` returns the current `minecraft.player` when the requested ID equals its current network ID (`ClientWorld.java:220–221`); 1.14.4 inserts the local player into `entitiesById` by the supplied packet ID and resolves through that map (`ClientWorld.java:262–274, 307–308`). This distinction explains the login registration order: 1.13.2 adds the player before replacing its initial ID, while 1.14.4 registers with the server ID before the later redundant `setNetworkId` write. No handler in this pairing identifies a different local player.

## Reset, dimensions, and abilities

`Entity.resetPos` has the same movement procedure at both releases: while `world != null` and `0 < y < 256`, set the entity box from current `(x,y,z)` and current dimensions, stop if collision-free, otherwise increment Y by one and retry; then zero all three velocity components and pitch. The old collision call `hasNoCollisions(this, this.getShape())` and new `hasNoCollisions(this)` both delegate to the entity/current box with an empty exclusion set (`WorldView.java:201–206` old, `:113–118` new). It does not restore X/Z to spawn or clear yaw, previous/last coordinates, on-ground, fall distance, or the other copied movement flags. `PlayerEntity` then heals to max and clears `deathTicks` in both releases.

The wrapper operation differs. 1.13.2 `PlayerEntity.resetPos` first calls `setSize(0.6F, 1.8F)` (`PlayerEntity.java:449–454`); 1.14.4 first sets tracked pose to `STANDING` (`PlayerEntity.java:477–482`). In 1.14.4 the pose data callback updates the active `EntityDimensions`, eye height, and box (`Entity.java:2239–2266`); for a width increase it anchors the new box at the old minimum corner, matching the old `setSize` expansion branch, while a width decrease centers it on current X/Z. The new reset also explicitly restores tracked standing pose and recalculates eye height when the tracked pose changes. Whether a non-standing copied pose can reach this replacement path, and the exact applicable player-dimension scaling input, remain open; do not collapse this pose/callback delta into a proven movement trajectory.

`ClientPlayerInteractionManager.adjustPlayer` delegates to `gameMode.apply(player.abilities)` in both releases (`ClientPlayerInteractionManager.java:68–70` → `:76–78`). `setGameMode` stores the mode and applies it again to `minecraft.player.abilities` (`:72–75` → `:80–83`). `GameMode.apply` is byte-identical: creative/spectator/survival branches write `canFly`, `creativeMode`, `invulnerable`, and (for spectator or non-creative modes) `flying`, then set `canModifyWorld` from the mode predicate (`GameMode.java:34–52`). Login and respawn both apply the existing manager mode during reset setup, then apply packet game mode at handler end. No ability-state difference found for equal mode inputs.

## Respawn replacement and ordering

1.13.2 `handlePlayerRespawn` (`ClientPlayNetworkHandler.java:944–965`) changes world only when packet dimension differs; it preserves scoreboard, calls `Minecraft.setWorld`, writes the old player's dimension, and opens terrain loading. It then calls `Minecraft.respawnPlayer` and applies packet game mode. The `setWorld` call on a dimension change also resets/re-adds the old player and applies current manager abilities before replacement. `Minecraft.respawnPlayer` (`Minecraft.java:1454–1485`) resets spawn/unloads entities, removes the old player, creates a replacement reusing stats and recipe book, copies synced data, writes packet dimension, resets position, restores brand, registers the player, calls `initPlayer` (yaw `-180.0F`), installs input, writes old network ID, applies manager abilities, and copies reduced-debug state.

1.14.4 `handlePlayerRespawn` (`ClientPlayNetworkHandler.java:996–1041`) captures the old local-player pointer and network ID first. On dimension change it installs the new world and opens terrain loading, but the narrower `Minecraft.setWorld` does not reset/re-add the old player or adjust its abilities. The handler resets spawn/unloads entities, creates a replacement reusing stats and recipe book, writes ID and packet dimension, assigns global player/camera references, copies synced data, resets position, restores brand, registers the replacement, writes yaw `-180.0F`, installs input, applies manager abilities, and copies reduced-debug state; packet game mode is applied at handler end.

Thus both replacement players receive copied synced data before reset, and both reset after writing the packet dimension. Both preserve the old local player's network ID, stats, recipe book, server brand and reduced-debug flag; both preserve copied tracked movement flags, while reset clears velocity/pitch and establishes standing geometry by their version-specific operation. For same-dimension respawn, the broad call order on the replacement is aligned. For dimension-changing respawn, 1.13.2 has an additional old-player reset/add/ability-adjust pass before replacement; 1.14.4 does not. The old player is replaced before the handler returns, so the movement consequence of that transient pass and the effect of `unloadEntities` on its registration are not established here.

## Open inputs and dependencies

- Compare the callback consequences of copied synced pose data under the reachable respawn states, especially whether a sleeping/non-standing local-player state can survive to `handlePlayerRespawn` and whether the standing-pose write changes dimensions/eye height in that state.
- Determine whether either version's respawn packet path can run with no current local player; this report treats the old local player and its stats, recipe book, synced data, brand, ID and debug flag as present paired inputs.
- The exact world spawn coordinates, current Y, collision geometry/shape inputs, player pose/dimensions, and selected packet dimension/game mode are state inputs; no server-side source establishes their producer behavior here.
- The first movement tick after these handlers, copied attribute/effect/equipment state, synced-data callbacks beyond pose, and ordinary position/velocity producers remain outside this bounded pairing.

No tests, game launch, build, source regeneration, product/wiki/backlog/Git-history inspection, or source-tree write was performed. No pair-freeze claim is made.
