# 1.13.2 → 1.14.4 ordinary candidate patch-boundary audit

## Scope and source identity

Read-only source audit, using the published endpoint pair `1.13.2 ornithe-feather` → `1.14.4 ornithe-feather` and exact stable intermediates `1.14` through `1.14.3` (`yarn`). These intermediates have `.decompile-provenance.json` records with per-file source hashes; the two endpoint Feather trees have ready/provenance/source-manifest records. Endpoint source locations are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`; intermediate locations are `.../{1.14,1.14.1,1.14.2,1.14.3}/yarn`. No source was regenerated. The unpublished `.yarn.staging-*` folder was not used. The full `PlayerEntity` source files below were rehashed and match each exact source manifest/provenance entry.

| Release/mapping | Source member path | SHA-256 |
|---|---|---|
| 1.13.2 Feather | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14 Yarn | `net/minecraft/entity/player/PlayerEntity.java` | `ebda4ad25a265f8c85e88345efcce753b78e248a29a9b910c5cfd311a4a69319` |
| 1.14.1 Yarn | `net/minecraft/entity/player/PlayerEntity.java` | `ebda4ad25a265f8c85e88345efcce753b78e248a29a9b910c5cfd311a4a69319` |
| 1.14.2 Yarn | `net/minecraft/entity/player/PlayerEntity.java` | `333bb39db18af4cef320eb73b7abe359d438fb2a6ca7d8798ee449da6c684398` |
| 1.14.3 Yarn | `net/minecraft/entity/player/PlayerEntity.java` | `e3f361ac4e369d01473f3d84044ee33f9685d182c4485e2e80b7f62756950963` |
| 1.14.4 Feather | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

1.14.4 `mojmap` is also published, but not needed as primary comparison. The prior Feather-based 1.14.4 audit identities are valid against a published canonical source tree.

## Patch-boundary results

### Sneaking dimensions: 1.65F → 1.5F

1.13.2 `PlayerEntity.updatePlayerPose()` chooses height `1.65F` for sneaking (`:334–360`). The 1.14 release already maps the sneaking pose to `(0.6F, 1.5F)` and its updater selects the sneaking pose before fitting/fallback (`PlayerEntity.java:115, 330–352`). The value and path remain in 1.14.1 and 1.14.2 at the same Yarn locations; 1.14.3 has renamed `EntityPose.field_18081` to `EntityPose.SNEAKING` but keeps `(0.6F, 1.5F)` (`:116`); 1.14.4 Feather retains the same 1.5F mapping (`:109–117`). Therefore the stable endpoint comparison narrows this candidate's introduction to 1.14.0, with no later 1.14.x patch boundary. This confirms a dimensions delta, not the prior witness by itself.

The prior collision/query closure remains relevant and says the concrete bottom-slab walkway witness is reachable by ordinary movement. This patch-boundary check does not independently reproduce or renew that witness review.

### Submerged sprint forward threshold

1.14.0 and 1.14.1 `ClientPlayerEntity` retain direct `movementForward >= 0.8F` gates for auto-start and sprint-key start (`:617, 646, 660` in 1.14.0; same in 1.14.1). In 1.14.2, `Input.method_20622()` returns `movementForward > 1.0E-5F` (`Input.java:21–24`), and `ClientPlayerEntity.method_20623()` calls it when in water while retaining the 0.8 threshold otherwise (`ClientPlayerEntity.java:949–951`); the sprint-key start branch invokes `method_20623()` at `:660–666`. The 1.14.3 source retains those same semantic calls at the same line ranges. 1.14.4 Feather renames the helper to `m_03985577()` and calls it from both sprint-start gates (`LocalClientPlayerEntity.java:655–676`); the helper selects `input.m_49149051()` only while submerged (`:961–964`). The strict-positive predicate remains in 1.14.3 and maps by semantic method to the 1.14.4 Feather helper `m_03985577()` and its input predicate `m_49149051()`. Thus the submerged threshold change's stable patch boundary is 1.14.2, not 1.14.0. The input and sprint gate are source-closed here; this audit does not re-prove the fluid eligibility/state producers.

### Shared 1.14.0 candidate family

The prior endpoint source report and this intermediate check agree that pose-driven dimensions/fallback, pose-aware keyboard slowdown, the widened climb-boost gate, dry-ground acceleration arithmetic, water gravity threshold caching and camera-flight simultaneous input arithmetic are present in the 1.14 code line. For this audit, only dimensions and sprint-forward received the intermediate member-by-member check above. The other candidates retain their previous dispositions (conditional or witness/open); this report does not claim their intermediate patch boundary. Their exact 1.14.0–1.14.4 member-body comparisons remain open.

## Coverage and open inputs

Examined: complete release/mapping identity for the listed inputs; manifest/provenance hash matching for the selected player source files; sneaking dimensions/update branch in 1.13.2, 1.14–1.14.4; submerged sprint threshold in 1.14.0–1.14.3 and its 1.14.4 Feather endpoint helper mapping.

Partial: prior ordinary tick, pose, collision, fluid and selected callback slices are summarized in `.native-source/20261030/1132-1144-pool31/ordinary-tick/source-review.md`, its corrections, and the `remaining34` closure reports. Those reports are leads, not this audit's independent complete member audit. Other members have not been retraced against the current source-only inventory.

Unexamined/open: full pretravel/travel/step/move operation inventory; every intermediate method-body delta for candidates other than the two above; complete direct response and block/provider dependency graph; locally controlled item/equipment interactions; exact terminal tick graph and independent full-pair audit. Therefore this does not freeze the pair and does not establish runtime parity.


**Gate-condition refinement:** the strict-positive `Input` predicate is used in the water-gated helper from 1.14.2; 1.14.2 and 1.14.3 condition it on `isInWater()` (`ClientPlayerEntity.java:949–951`), whereas 1.14.4 Feather conditions it on `isSubmergedInWater()` (`LocalClientPlayerEntity.java:961–964`). Treat the predicate-threshold introduction as 1.14.2 and the consumer's water-state condition as a separate later change first present in 1.14.4; do not collapse these into one cutover.
