# Local-player respawn pose reset closure

## Scope and verdict

This closes the specific question whether a copied non-standing pose can determine the replacement local player's dimensions at the first movement tick after the paired respawn operation. Exact sources are the read-only 1.13.2 and 1.14.4 Ornithe Feather trees. Treat the old player's copied synchronized entries, prior local-player state, world/position, and packet data as equal logical inputs; no packet producer or reachability history is asserted.

**Pose/dimension sub-slice closed:** on 1.14.4, any copied pose that differs from `STANDING` is synchronously reset by `PlayerEntity.resetPos()` before the handler returns. The pose callback computes the player-specific `STANDING` dimensions and eye height and updates the box. The old operation instead unconditionally requests player size `0.6F × 1.8F` before reset. The replacement's next normal local-player tick therefore does not consume the copied non-standing pose or its dimensions: both reset paths establish the same standing player dimensions before that tick.

This is not a whole-respawn or first-tick movement-equivalence claim. An adjacent, still-open dependency is the distinct copied sleeping-position value: 1.14.4's `LivingEntity.baseTick()` repositions any first-tick entity with a sleeping position before later tick work; 1.13.2 has no such first-tick branch. That state can affect the first tick independently of the reset pose and is not closed here.

## Paired source trace

1.13.2 `Minecraft.respawnPlayer` creates the replacement, calls `getSyncedData().update(old.getSyncedData().getAll())`, sets its dimension, then invokes `PlayerEntity.resetPos()` (`Minecraft.java:1454–1480`). Old `PlayerEntity.resetPos()` first calls `setSize(0.6F, 1.8F)`, then `Entity.resetPos()` (`PlayerEntity.java:449–455`). `Entity.setSize` writes width/height and reconstructs the shape when they differ (`Entity.java:285–299`). The old `Entity.onDataValueChanged` implementation is empty (`Entity.java:2219–2220`); the old player has no synchronized Pose dimension selector. Thus copied shared movement flags remain copied, but no copied non-standing pose changes this replacement's dimensions.

1.14.4 `ClientPlayNetworkHandler.handlePlayerRespawn` creates the replacement, sets ID/dimension and player/camera references, copies all synchronized entries with `getSyncedData().update(old.getSyncedData().getAll())`, then calls `resetPos()` (`ClientPlayNetworkHandler.java:1020–1031`). `SyncedData.update` applies each matching entry and calls the new entity's `onDataValueChanged` (`SyncedData.java:236–249`). Pose is an entity synchronized datum initialized to `STANDING` (`Entity.java:208`); `Entity.onDataValueChanged` recomputes dimensions/eye height when this datum changes (`Entity.java:2239–2243`), and `m_84943753` replaces the dimensions and updates the shape using the old minimum corner on width increase or recenters on width decrease (`Entity.java:2245–2268`).

New `PlayerEntity.resetPos()` writes `Pose.STANDING` before delegating to `Entity.resetPos()` (`PlayerEntity.java:476–482`). The player override of `getDimensionsForPose` maps standing to the exact `EntityDimensions.dynamic(0.6F, 1.8F)` constant and returns that constant for unlisted poses (`PlayerEntity.java:109–119, 1964–1967`); it does not use the generic living-entity scale path. Thus no applicable player-size attribute input remains open for this route. If copied pose is non-standing, the standing write synchronously updates the active dimensions/box before `Entity.resetPos` checks collisions and zeroes velocity/pitch. If it is already standing, construction and the pose value already select the same standing dimensions.

The first normal replacement tick is later: `LocalClientPlayerEntity.tick()` calls `super.tick()` (`1.13.2 LocalClientPlayerEntity.java:181–184`; `1.14.4 LocalClientPlayerEntity.java:178–181`). Therefore the reset pose write completes before that movement-bearing tick begins. This establishes that the copied non-standing pose itself does not survive as the dimensions consumed by the next tick.

## Remaining boundary

The new synchronized sleeping-position callback remains distinct from the pose issue. On the client, `LivingEntity.onDataValueChanged` calls its bed-position setter when the sleeping-position attribute changes (`1.14.4 LivingEntity.java:2510–2516`). Also, new `LivingEntity.baseTick()` places a `firstTick` entity at its copied sleeping position before ordinary base-tick work (`LivingEntity.java:272–279`); the old base tick starts at line 241 and has no `firstTick` relocation. The reset sequence follows the synchronized-data copy, and this report does not compare the resulting first-tick position/collision adjustments for a nonempty sleeping position. Keep that as an exact open first-tick lifecycle input, not as evidence that a non-standing pose survives reset.

## Exact source identities

All hashes were recomputed from the endpoint Feather trees and match their `ornithe-feather.sources.sha256` publication manifests.

| Version | Source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/Minecraft.java` | `b1d35473cd12bdf38e87f9888b4ed6f620614cbe914cf7e7a40c601d4e284875` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/data/SyncedData.java` | `93177865e23be0f8db5741bd505b952daee03d33761838ca782bd10bceb748e4` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/data/SyncedData.java` | `4d0c0bee069994f64a31e1ff600ae59c3217eadb8678473e2256c2363e657e17` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

No tests, build, runtime launch, source regeneration, product/wiki/backlog/Git-history inspection, or source-tree write was used.
