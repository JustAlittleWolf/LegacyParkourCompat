# Entity-collision query margin and cutoff: same-invocation terminal closure

## Scope and verdict

This source-only closure isolates final entity-collision candidate filtering for 1.13.2 → 1.14.4 Ornithe Feather Gen2 build 2. For each compared movement call it holds the player box, requested vector, eligible entity snapshot, exclusion/vehicle state, and shapes fixed. It excludes the separately accepted old-fresh/new-reused step-only Boat candidate terminal in `step-only-entity-candidate-terminal/result.md`.

**Verdict: neither the `+0.25` old broadphase margin nor the new `1.0E-7` cutoff/expansion produces a same-invocation entity candidate membership difference for an endpoint player box under the assumptions below.** The old broadphase margin is removed by its final filter. The old filter box is the full outer swept envelope; the new method's expanded query/final-filter box is that same envelope. The new average-side cutoff cannot fire on an endpoint player movement box: the smallest player pose dimension is `0.2`, while the cutoff is `<1.0E-7`. Therefore no candidate present only because of these query-margin/cutoff rules can clip the same requested movement or a same-query step subcall. This does not address the separate lifetime difference in which old step attempts query a raised sweep afresh and new step attempts reuse the original candidate stream.

## Exact query path and box equality

1.13.2 `WorldView.getCollisions(entity, box, dx,dy,dz)` forms the directional sweep `S = box.expanded(dx,dy,dz).expand(1.0E-7)` and subtracts the starting box shifted by the per-axis `±1.0E-7` direction (`WorldView.java:158–163`). It passes the resulting voxel shape to the world collision route; `World.getCollisions` appends `EntityView.getEntityCollisions` for a non-null entity (`World.java:1755–1757`). The old entity method sets `B_old = shape.bounds()`, queries entities in `B_old.expand(0.25)`, then keeps only collision shapes strictly intersecting `B_old` (`EntityView.java:21–35`).

For a positive-volume player box, the shifted starting box is contained in the expanded sweep. Their `ONLY_FIRST` difference is the outer shell of that sweep. That shell has the expanded sweep's full bounds: each outer face remains represented by a positive-volume shell slab (where the shifted start box reaches that face, an orthogonal shell slab supplies the same coordinate extrema). Hence `B_old = bounds(S)`, the complete outer swept AABB including the existing `1.0E-7` tolerance—not the smaller unexpanded player path box. This is the box produced by the old expression for any nonempty player box and finite movement vector; no assumed Boat/Shulker fixture is needed for the bounds identity.

In 1.14.4 `Entity.move` calls `getEntityCollisions(this, box.m_78709828(vec3d), …)` with the directionally swept player box (`Entity.java:656–665`). `Box.m_78709828` is the directional vector expansion. `EntityView.getEntityCollisions` expands that result by `1.0E-7` and uses the expanded box both for `getEntities` and the final strict shape-intersection filter (`EntityView.java:53–67`). Call this `B_new`. The directional sweep plus `1.0E-7` is the same outer box as `B_old`; thus `B_new = B_old` for an aligned movement invocation. In old code, `+0.25` widens only entity enumeration: any old final-filter survivor intersects `B_old` and so lies inside that broader enumeration box, while any broadphase-only candidate is rejected. In new code, entity enumeration and the final filter both use `B_new`. Under equal entity availability and box-intersection semantics, both filtered methods therefore emit the same candidate collision shapes.

The exact endpoint source scan finds native `getCollisionShape()` overrides only in Boat and Shulker. Boat returns its current `getShape()`; Shulker returns its current `getShape()` while alive. `Entity.getShape()` is the current entity bounding box. The excluded local player inherits `Entity.getCollisionAgainstShape()`, which returns null. So the native player's collision-candidate stream is exactly based on candidate entity boxes; there is no native collision shape protruding beyond a candidate's broadphase box to defeat the containment argument. Arbitrary external/modded subclasses are outside this closure.

1.14.4 also returns empty before entity enumeration when `shape.getAverageSideLength() < 1.0E-7`. Player source dimensions include 0.6 × 1.8 standing, 0.6 × 1.5 sneaking, 0.6 × 0.6 flying/swimming/spin poses, and 0.2 × 0.2 dying; the 1.13.2 player sizes include 0.6 × 1.8 and 0.2 × 0.2 (PlayerEntity.java:450, 563, 1268, 1306). The 1.14.4 pose map uses 0.6 × 1.8 standing, 0.6 × 0.6 fall-flying/swimming/spin-attack, 0.6 × 1.5 sneaking, and 0.2 × 0.2 dying (PlayerEntity.java:108–117); sleeping uses inherited 0.2 × 0.2 (LivingEntity.java:124). Other available player poses are no smaller. Directional sweep expansion cannot reduce the current side lengths, so even the smallest player-box average is at least `0.2`, and the new cutoff is unreachable in these movement calls.

## Step subcalls and explicitly separate difference

1.14.4 `m_72373519` obtains the entity stream once from the original requested sweep and reuses it for step vectors; `m_64271959` separately rebuilds block candidates for mixed-axis subcalls (`Entity.java:656–705`). 1.13.2 invokes the `WorldView` collision query again for each step alternative (`Entity.java:578–674`). A candidate absent from the old ordinary sweep but present in the raised old step sweep can therefore differ because of query lifetime, as the separately accepted Boat witness demonstrates. That witness is not evidence of a final-filter margin/cutoff difference. For a same-invocation comparison—same swept box and same vector—box equality above still gives identical filtered candidate membership.

## Counterexample to an unqualified API claim

The cutoff conclusion is specific to actual endpoint player boxes. An arbitrary direct call with a nonempty `1.14.4` box whose three sides are `1.0E-8` has average side length below `1.0E-7`; new `EntityView` returns empty immediately. Old `EntityView` has no average-side cutoff and can emit a fixed intersecting candidate (provided the old query box and broadphase contain it). This is not a player movement counterexample: the smallest source-defined player dimensions at these endpoints are `0.2 × 0.2`, not sub-epsilon. Likewise, an external entity subclass returning a collision shape beyond its own entity box would invalidate the native-candidate containment premise, but neither endpoint's native eligible collision-shape override does so.

## Remaining unpaired entity-query branches

- **Step candidate lifetime:** old fresh raised-step query versus new reused original entity list; this is the separate accepted Boat witness, intentionally excluded here.
- **Entity/world producers:** histories producing current entity boxes, shapes, eligibility, and exact requested vectors are not established. Chunk/entity availability and world enumeration are assumed equivalent for this same-invocation query comparison.
- **Other movement inputs:** world-border candidates, block candidates and providers, vector/axis resolution order, and block-list rebuilding are outside this terminal.
- **Coverage:** no full-pair inventory, intermediate patch boundary, implementation, or runtime-parity claim is made. Arbitrary external entity subclasses are outside the native source class proof.

## Exact evidence identity

Read-only endpoint sources: Ornithe Feather Gen2 build 2, mapping `ornithe-feather`, roots `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Ready records identify 1.13.2 and 1.14.4 respectively. Canonical source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4). Each cited Java-file hash was recomputed from the read-only root and matches its manifest row.

| Source relative to Feather root | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` | `3822844ced53882c52f0523a1bd714baa3cd9bb9dab38a5e2c53051c7b1590e3` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` |
| `net/minecraft/entity/vehicle/BoatEntity.java` | `3d9c248c8cb5846ac157b7973e4c6f448fe12bdc63c8d33931dace98682c0f66` | `2a33747d7d429ed58ef599de2eceddec5b377a78a1c3ddecd20def1d4907e3c9` |
| `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `35d3f858f7e06c035ee66b74b08420b678665dcdff9e4cf0619d68570966afa5` | `cea369aa7057a6adf8ec84e238458a83fe4762fa0b3ad8b230bdf5531bd1b8c` |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| `net/minecraft/entity/living/LivingEntity.java` | — | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |

Source-only context reports used and SHA-256 hash-bound as read: `entity-collision-epsilon-movement-terminal/result.md` `bc53f8aca2bf44c253d56eeaa54bcfa80fab933119631a3979b178bd70082bee`; `step-only-entity-candidate-terminal/result.md` `0d35292ee9b72894b49181d3c7a9619fad37b4a30ae143d01838b0ffabc7d43a`; and `collision-query/closure-report.md` `30670ce15cba31f5dc7ced918ae9911dd68ace3e9b5fcb1b7b2230d91a872aa8`.

No product, wiki, backlog, or Git evidence was read. No source was modified; no build, test, decompilation, game launch, or runtime trajectory was run.


