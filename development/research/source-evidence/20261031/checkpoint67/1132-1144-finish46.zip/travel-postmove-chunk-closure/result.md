# Post-move dry-gravity chunk gate: 1.13.2 → 1.14.4

## Verdict

**Conditional direct movement writer difference confirmed.** The exact old member is `LivingEntity.moveRelative(float,float,float)` (`1.13.2 LivingEntity.java:1478`) and the exact new member is `LivingEntity.moveRelative(Vec3d)` (`1.14.4 LivingEntity.java:1786`). Old client movement samples chunk availability at the post-move X/Z and also requires the returned `WorldChunk.isLoaded()` bit. New movement samples only the block position created before movement. For equal raw local-player movement state crossing an X/Z chunk boundary from an available chunk into an absent one, the branches can differ and write different next Y velocity. This is a source-level local-player operation candidate; it does not establish how that movement/chunk snapshot was produced or a general trajectory. The method bodies are invoked from the living-entity `mobTick` travel section; `travel` is the profiler section label, not the exact method name in these Feather sources.

## Fixed operation inputs

Use a standing local client player with the old-era `0.6F × 1.8F` dimensions (`1.13.2 PlayerEntity.java:450`; `1.14.4 PlayerEntity.java:109–112`), centered horizontally at pre-method position `(15.5, 1.0, 0.5)`, `onGround=false`, and horizontal velocity `(0.6, 0, 0)`. Each `LocalClientPlayerEntity.isLocallyControlled()` returns true (`1.13.2 LocalClientPlayerEntity.java:489–490`; `1.14.4 :486–487`), satisfying the movement method's outer gate. Logical movement input is zero; the ordinary dry, non-flying, non-fall-flying branch has no levitation or slow-falling effect, gravity is enabled, there are no collision obstacles, no ladder/climb correction, and there is no water/lava state. Both methods pass X request `0.6` to `move`: old multiplies horizontal velocity by `0.91F` after moving; new's `m_19439509` helper is identity when not climbing, so its `move` also receives the unchanged velocity and applies `w=0.91F` after moving. The equal no-ground branch makes both horizontal movement factors `0.91F` for the post-move velocity write and makes sampled slipperiness irrelevant. Thus both move from chunk X=0 to X=1 (to X=16.1 under the stated no-collision raw request). The resulting position is used only to show the old post-move versus new pre-move chunk sample.

Assume the same effective client chunk state on both sides: chunk `(0,0)` is cached and present at full-chunk status, and chunk `(1,0)` is absent. Treat those chunk states and the no-obstacle resolved movement as raw operation inputs; no chunk streaming, movement-history, server, or provider production is asserted. At the end of both moves, entity Y is still `1.0`, so the fallback's `this.y > 0.0` branch is selected if reached.

## Exact paired data flow

In old `LivingEntity.moveRelative(float,float,float)`, after `Entity.move`, the ordinary dry branch mutates the pooled position to `(this.x, 0.0, this.z)` and evaluates `!world.isClient || (world.isChunkLoaded(pos) && world.getChunk(pos).isLoaded())` (`1.13.2 LivingEntity.java:1585–1594`). For a client, `WorldView.isChunkLoaded(BlockPos)` calls its overload with `allowEmpty=true` (`WorldView.java:274–279`); `ClientWorld.isChunkLoaded(cx,cz,allowEmpty)` returns true immediately when `allowEmpty` is true (`ClientWorld.java:112–113`). It therefore proceeds to `World.getChunk(pos).isLoaded()`. `World.getChunk` forwards to `getChunkAt`; old `ClientChunkCache.getChunk(cx,cz,load,generate)` returns its empty singleton when no cached chunk exists and `generate` is true (`World.java:187–195`; `ClientChunkCache.java:47–50`). `WorldChunk.loaded` defaults false, and only a chunk replacement sets it true; `EmptyChunk` does not override `isLoaded()` (`WorldChunk.java:63, 947–952`; `EmptyChunk.java:17–24`). Thus the absent post-move chunk fails the conjunction. The old client fallback writes `velocityY=-0.1` because entity Y is positive, then applies `velocityY *= 0.98F` (`LivingEntity.java:1592–1603`), yielding approximately `-0.098`.

In new `LivingEntity.moveRelative(Vec3d)`, the `BlockPos` `(this.x, this.getShape().minY - 1.0, this.z)` is created before `move` (`1.14.4 LivingEntity.java:1841`). The same object is later tested after movement in `world.isChunkLoaded(blockPos)` (`LivingEntity.java:1856`); no X/Z refresh occurs between its creation and the test. `BlockPos` delegates double coordinates to `Vec3i`, whose double constructor floors them, so this remains chunk `(0,0)` for pre-move X `15.5` (`BlockPos.java:39`; `Vec3i.java:19–21`). New `WorldView.isChunkLoaded(BlockPos)` shifts that position's X/Z to chunk coordinates (`WorldView.java:225–226`); the `WorldAccess` default forwards them to `ChunkSource.isChunkLoaded`, which checks for a non-null `FULL_CHUNK` returned without loading (`WorldAccess.java:54–56`; `ChunkSource.java:30–31`). The client cache returns a matching cached chunk and otherwise returns null when `load=false` (`ClientChunkCache.java:68–76`). Since the pre-move chunk `(0,0)` is present, the client fallback is skipped. The ordinary gravity branch subtracts `d=0.08` from the post-move Y vector component 0, and the final vector write multiplies by `0.98F` (`LivingEntity.java:1787–1805, 1855–1866`), yielding approximately `-0.0784`.

The difference is caused by the sample position moving from the pre-move block to the post-move block, while both compared local-player methods take their client gravity branch after `move`; `mobTick` calls each method in its profiler `travel` section (`1.13.2 LivingEntity.java:1896–1926`; `1.14.4 LivingEntity.java:2197–2227`). The extra old `WorldChunk.isLoaded()` check is not needed to create this witness: the old destination chunk is absent and yields the unloaded empty singleton. It remains an additional old condition for other equal-coordinate snapshots.

## Exact source identities

All listed endpoint source-file hashes were recomputed and matched the corresponding `ornithe-feather.sources.sha256` entries. Mapping identity is Ornithe Feather Gen2.

| Version | Source member(s) | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.13.2 | `net/minecraft/client/world/ClientWorld.java` | `BAE1D6D653260E42D735B9652E5C89711F1BD78EACBA7993E2460F2F2528640A` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023DE30DA608DB73C6C6188334D2BB19039D86FE4D6F5E4AD79D732A5D2CD1A` |
| 1.13.2 | `net/minecraft/client/world/chunk/ClientChunkCache.java` | `D416574E48CF414145B2C8CB8C1B7EF9E39D44AAF876972D724316FD01957F88` |
| 1.13.2 | `net/minecraft/world/chunk/WorldChunk.java` | `D800FAC11AA2672A4DD69CB5A599E5F84BB6E2C71CFC8080FA972ACDABFB4914` |
| 1.13.2 | `net/minecraft/world/chunk/EmptyChunk.java` | `42EF83DD4325EAA9589F243E0034E86CD76CF357FB33EE82C515D043E336C2A1` |
| 1.13.2 | `net/minecraft/util/math/BlockPos.java` | `EE71CFDEDCAA27458F48168AB761B435CF9C878B04F21E971DDBAFB6254AA3FD` |
| 1.13.2 | `net/minecraft/util/math/Vec3i.java` | `481827F072A5D36AE3A7F133AFED5396988E3CE7C0501B2777A92B60C6A498B8` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ED22F6C5A3C55D67EED782070AC722201DF4D624ADBC90779F1FD29C2876633` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495F3A02B4791AA036E6A8D354D7596C4984761969A0F29B29D8D9BF42BF` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2CCCF4331CE9E62013EEB8E96163E5E146E1291619EB998CE9867DAA87C02B61` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.14.4 | `net/minecraft/world/WorldAccess.java` | `F57639756ACDEDBD0E5A598F7740A8E17F0DC3B2BA710AA4690D05F4F3BCD746` |
| 1.14.4 | `net/minecraft/world/chunk/ChunkSource.java` | `277957E4EC3AF8AB31A4171F41BBA62079812BC454444636D7E59EAC13AD1A32` |
| 1.14.4 | `net/minecraft/client/world/chunk/ClientChunkCache.java` | `612082958CF2C54CD26822B653B84FA8A3F93CA2808DDED55F3C5AA86CF1409C` |
| 1.14.4 | `net/minecraft/util/math/BlockPos.java` | `8AA3D3A9AD3B3B9F230EFAF5AC06A45ED7AF3F59636EF7CF9507BA9317C22FD8` |
| 1.14.4 | `net/minecraft/util/math/Vec3i.java` | `F1D2E85D690B69C546B2DC783EDE2DDBBFAC400CA72271828929A45DB03729A9` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614DEB3B50D11F6CDF54D9E308703BF49CB53B72646B05253857E9557D657DF` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708AF6A3880FB58B67BF4604A5509B351719A9C2A0C06A8EC261586435BF00CE` |

The 1.13.2 → 1.14.4 endpoint boundary is known; no intermediate patch cutover was inspected in this tranche. No source tree was written, and no build, test, game launch, decompilation, or product/wiki/backlog/Git access was used.
