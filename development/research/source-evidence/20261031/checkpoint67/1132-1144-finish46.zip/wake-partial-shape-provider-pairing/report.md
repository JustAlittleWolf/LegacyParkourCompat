# Bed wake-position search over partial collision/support states

## Result

The wake-position algorithms differ for the same fixed vanilla state snapshot, and the difference directly writes the local player's position. The 1.13.2 search accepts support using `isFullBlock` plus the current/upper material solidity flags, then places at the chosen cell center and `Y + 0.1`. The 1.14.4 search uses collision-shape height/emptiness, descends to the first collision shape, and requires the entity-type AABB to be collision-free before writing the returned support top plus `2.0E-7`.

This report closes the previously open shape/support-gate source slice with a bounded same-input witness below. It does not claim bed-entry eligibility, an event/server producer, or a trajectory into the fixed sleeping state. The direct wake response is a changed player-position terminal under that paired raw snapshot.

## Exact same-input witness

Assume a loaded, unobstructed client world away from the world border, with no colliding entities. `sleepingPos` is a north-facing bed at `(0,2,0)`. The bed state may be either occupied value because `OCCUPIED` does not affect its search geometry. Put a stone full cube at `(-1,1,-1)`, a dandelion at `P=(-1,2,-1)`, and air at `P.up()`. All other bed-search candidate cells have air below them. The player type is `EntityType.PLAYER` with dimensions `0.6 × 1.8`.

Both methods traverse candidate positions in the same order. The first is `P`: for the first loop pass, `FACING=NORTH` gives the x/z scan starting at `(-1,-1)`. In 1.13.2, the block below P is full (`Block.isFullBlock` checks solid-blocking material and cube state; stone satisfies it), dandelion has `Material.PLANT` whose `isSolid` bit is false, and the block above is non-solid air. Thus `BedBlock.isValidSpawnPos` accepts P and depth zero returns it. `PlayerEntity.wakeUp` writes:

```text
(-1 + 0.5F, 2 + 0.1F, -1 + 0.5F) = (-0.5, 2.1, -0.5)
```

In 1.14.4, the registered dandelion uses `Material.PLANT` and `noCollision()`. The base `Block.getCollisionShape` therefore yields the empty shape at P; its Y maximum is negative infinity, so it passes the `> 0.4375` rejection. The downward scan crosses empty P, stops at the stone support, and obtains `d = 1 + 1 + 2.0E-7 = 2.0000002`. The resulting player box has x/z `[-0.8,-0.2]` and does not overlap the bed at x/z `[0,1]`; its lower face is 2.0000002, above the stone top at 2.0. With the remaining neighborhood clear, `hasNoCollisions` accepts it. The search returns `(-0.5,2.0000002,-0.5)`, and `LivingEntity.stopSleeping` writes that position.

The direct vertical position write differs by `-0.0999998` blocks for this valid old-era block-state snapshot. Changing support/current-state conditions can of course alter which scan cell is returned; the witness fixes them and keeps the ordinary search's first candidate common to both endpoints.

## Source trace and gates

- **1.13.2 wake terminal:** `PlayerEntity.wakeUp` changes dimensions first, checks that `sleepingPos` is a bed, clears `OCCUPIED`, calls `BedBlock.getSpawnPoint(..., 0)`, falls back to `sleepingPos.up()` only when the search returns null, and sets position from integer block coordinates plus `(0.5F, 0.1F, 0.5F)` (`PlayerEntity.java:1305–1330`). The bed search reads facing, performs the two ordered 3×3 passes, and accepts the first cell whose block below is full and whose cell and cell above have non-solid materials (`BedBlock.java:220–253`).
- **1.14.4 wake terminal:** `PlayerEntity.stopSleeping` delegates to `wakeUp`; `wakeUp` calls `super.stopSleeping` (`PlayerEntity.java:1278–1294`). `LivingEntity.stopSleeping` requires the optional sleeping position's chunk loaded, verifies the block remains a bed, clears `OCCUPIED`, calls `BedBlock.getSpawnPoint`, uses the same up-cell `+0.1` fallback when empty, and writes the returned vector before restoring standing pose (`LivingEntity.java:2742–2756`). The ordered two-pass candidate scan remains the same (`BedBlock.java:200–227`).
- **New support/clearance gates:** `BedBlock.isValidSpawnPos` rejects a candidate only when its collision-shape maximum Y exceeds `7/16`; descends at most two blocks (and not below Y=0) while shapes are empty; rejects if no support shape is found or support is more than two blocks below; then tests a centered entity-type box using `worldView.hasNoCollisions` (`BedBlock.java:230–255`). Empty shapes report maximum Y as negative infinity (`VoxelShape.java:30–33`) and `isEmpty()` from an empty voxel set (`:56–57`).
- **Fixed block identities:** old `Block.java:952,962` constructs/registers dandelion as `FlowerBlock(Material.PLANT).noCollision()`; new `Blocks.java:336–338` registers the same vanilla ID and properties. In both releases `Material.PLANT` is declared `notSolid` (`Material.java:10`; old `isSolid` at `:128`, new at `:131`). New `Block.Properties.noCollision()` clears `hasCollision` (`Block.java:853–855`), and base `Block.getCollisionShape` returns empty when that flag is false (`:376–378`). New `EntityType.PLAYER` dimensions are `0.6F,1.8F` (`EntityType.java:398–400`).

The adjacent completed bed-provider reports remain authoritative for bed shape/face state enumeration: `../bed-shape-pairing/result.md` and `../bed-shape-movement-query/result.md`. This report does not redo those tables. Its witness box does not intersect the bed itself; the difference is the wake candidate provider's use of partial/non-colliding current/support shapes and its placement formula.

## Source identity

Primary read-only roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather` (Ornithe Feather Gen2 build 2; source records identify the exact Minecraft versions). I recomputed the listed Java hashes and matched each to its endpoint source manifest. Endpoint record hashes are:

| Release | Ready record SHA-256 | Provenance SHA-256 | Source-manifest SHA-256 |
|---|---|---|---|
| 1.13.2 | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |
| 1.14.4 | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` |

| Release | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/BedBlock.java` | `a274ed3d3dd8e4f4895fe1f3d1444425a9248e9cd41bc6e1f2677af7dacbec18` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `net/minecraft/block/material/Material.java` | `9bf4fc6893e07f15b7db2b03cba7cba7850370a2499870c621f422c356cf3b4f` |
| 1.14.4 | `net/minecraft/block/BedBlock.java` | `aab431c7d85bc654b74215d2b2be5fbe6de81643f5e2be466658d918f272abe1` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `net/minecraft/block/material/Material.java` | `b976f0011b0cf0f05831a799f40632f2824a4c09019f75d29ef7d88f33f72acf` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| 1.14.4 | `net/minecraft/entity/EntityType.java` | `0b4bebd0cbe746bdc99b80fc173b9cff1ce69016012da2505638c600685273fe` |

No canonical source was modified or generated. No product, wiki, backlog, or Git history was read. No build, test, or runtime launch was performed.
