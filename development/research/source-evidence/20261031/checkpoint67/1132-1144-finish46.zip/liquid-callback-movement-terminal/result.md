# Lava-contact callback feeds the next local-player movement branch

## Finding

Under equal default lava membership, loaded-world inputs, and the same local-player box and position at the end of a movement call, the new endpoint can set `isInLava()` from a lava block that the old endpoint's contracted-box query excludes. The next `LivingEntity.mobTick()` calls `LivingEntity.moveRelative`; its lava gate selects the lava continuation on 1.14.4 and the dry continuation on 1.13.2 for the same fixed input. This is a direct movement-route input difference; no trajectory, numeric final position, or damage/fire conclusion is made.

## Bounded same-input witness

Use a standing local player with a 0.6 × 1.8 box centered at `(0.71,0,0.5)`, giving X `[0.41,1.01]`, Y `[0,1.8]`, and Z `[0.2,0.8]`. A default vanilla `minecraft:lava` block at `(1,0,0)` is the only lava cell in this box. Assume the area is loaded and the next tick has neither water contact nor flight. The witness is a fixed post-move box/state snapshot followed by the exact endpoint contact/query code; it does not require proving how input or fluid state was produced.

1.13.2 `Entity.isInLava()` asks `World.containsMaterial(getShape().contract(0.1F,0.4F,0.1F), Material.LAVA)` (`Entity.java:1053–1055`). For this box the contracted X interval is `[0.51,0.91]`; `World.containsMaterial` floors the minimum and ceils the maximum, then scans with an exclusive upper bound (`World.java:1310–1325`). It therefore checks only X cell 0, not lava at X=1, and returns false.

1.14.4 `Entity.move` clears the stored lava-contact flag immediately before its `checkBlockCollisions()` call (`Entity.java:541–543`). That scan contracts the entity box by only `0.001` (`:797–814`), so the X range becomes `[0.411,1.009]` and the inclusive floored scan includes cell X=1. It invokes the block state's callback for `(1,0,0)`. The registered `LiquidBlock` stores `Fluids.LAVA` (`Blocks.java:92–94`); its `onEntityCollision` checks `this.liquid.is(FluidTags.LAVA)` and calls the entity lava-contact setter (`LiquidBlock.java:168–172`; `Entity.java:1054–1060`). The default `FluidTagsProvider` LAVA recipe contains source and flowing lava on both endpoints; the source-confirmed recipe and hashes are in `../default-tag-provider-membership/result.md`.

The new contact flag is not cleared again before the next local-player movement call. `Entity.isInLava()` returns that flag (`Entity.java:1058–1059`). `LivingEntity.mobTick()` checks it before jump handling (`:2206–2210`) and then calls `LivingEntity.moveRelative` (`:2227`). In that method, the same flag selects the dry versus lava continuation (`:1795–1800`). The old endpoint has no callback-produced lava flag; its live material query stays false for the same box and world cells. The paired travel-terminal report confirms the lava continuation has distinct acceleration/move/drag operations, while this finding claims only the branch selection.

## Scope and limits

This is an exact conditional direct-player movement difference under the stated fixed box/state snapshot. It does not claim that an ordinary prior trajectory places a player at this position, that world/fluid/player producers differ, or that the resulting trajectories diverge by a particular amount. Fire, health, damage, and lava-contact effects outside movement-route selection are excluded. Pair freeze remains separate.

## Exact source identities

The endpoint roots are the read-only Ornithe Feather Gen2 build 2 Minecraft 1.13.2 and 1.14.4 source publications at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Relevant file hashes below were recomputed from those trees; the collision callback inventory and tag-provider report independently record their exact endpoint source manifest matches.

| Release | Relative file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/block/LiquidBlock.java` | `bfbbe2997ce6c03224b5833176d6b19b4b4b4cbc3337960fb3d867de77519ca1` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

No source tree was changed or regenerated. No runtime, test, build, or game launch was run.
