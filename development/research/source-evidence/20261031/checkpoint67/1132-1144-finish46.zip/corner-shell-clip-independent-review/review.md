# Independent review: corner-shell moving-piston clip

## Verdict

**Accept narrowly as a conditional exact movement-query/clip terminal.** The supplied equal inputs yield requested X `-0.5` unchanged in 1.13.2 and clipped to `-0.1` in 1.14.4, assuming the stated single relevant block candidate and no other blockers. This does not establish that ordinary piston production or a player trajectory reaches the raw moving-block entity inputs.

## Immutable inputs and source verification

- Candidate draft SHA-256: `6d11b353978b17392da13bb130b36646870ba65954dbb062de7dfdedfd371478`.
- Search report SHA-256: `8fe19e62c3c5d4152ffcbf2024917e2d7e418b68da82ccb158a2f323a4583ed7` (matches the candidate's reference).
- Read-only exact source trees: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.
- Hashes of `1.13.2/ornithe-feather.sources.sha256` and `1.14.4/ornithe-feather.sources.sha256` match report identities `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. Provenance records identify Feather Gen2 build 2 for both endpoints.
- Independently recomputed SHA-256 for every cited Java source file in the report: all 20/20 match.

## Source and arithmetic checks

- **1.13.2 shell and prune:** `WorldView.getCollisions(entity, Box, dx,dy,dz)` builds the movement shell from the expanded box minus the sign-shifted original box. `getBlockCollisions` rejects a candidate when it lies on two boundary dimensions: `(!bl3 || !bl4) && (!bl4 || !bl5) && (!bl5 || !bl3)`. For this shell, `(-1,-1,0)` is boundary on X and Y and interior on Z, so it is pruned before the state lookup and shape provider. Consequently this shape is absent from the old `Entity.move` clip stream.
- **Old exclusion guard:** the specified box's X minimum is `0.6`, while the candidate's translated wall maximum X is `0.5`. The box and complete wall union are X-disjoint, so `excludeBlock` overlap is false; this does not account for the omission.
- **1.14.4 admission:** the one-axis resolver scans X while enumerating the Y/Z cross-range. At this cell, the two boundary coordinates give `s=2`; `VoxelShapes.m_84822986` admits it through `(s != 2 || blockState.getBlock() == Blocks.MOVING_BLOCK)`. The block is `MOVING_BLOCK`, and the branch then calculates the maximum offset against that state’s collision shape.
- **Provider equivalence and translation:** both `WallBlock` implementations construct collision shapes with the same `makeShapes(4,3,24,0,24)` parameters and select the same shape index for the given state. Both moving-block providers delegate to the moving-block entity. With `extending=false`, `source=false`, `progress=0.5F`, and `facing=EAST`, `getAmountExtended` is `1-progress = 0.5F`; the moved wall is translated +0.5 X. Its east arm has local-to-world maximum X `0.5` at block `(-1,-1,0)`, equivalently translated block-local maximum X `1.5`.
- **Gap and result:** player local X interval at that block is `[1.6,2.2]`. Negative-X clipping computes the gap from shape max to box min: `1.5 - 1.6 = -0.1`. Thus the new resolver clips `-0.5` to `-0.1`; absent other shapes, the old empty candidate set leaves `-0.5` unchanged.
- **Entity gates:** `noClip=false` selects collision resolution. `MoverType.SELF` avoids the piston-only movement adjustment. The request has zero Y and `onGround=false`, so the 1.14.4 step gate's `bl4 = onGround || yClipped && requestedY < 0` is false. The result does not rely on stepping. The old step gate is also false because its grounded/falling prerequisite is false.

## Scope and correction

The report correctly bounds this to a conditional source-level terminal and expressly excludes proof of ordinary piston production and trajectory reachability. Its stated no-other-candidate assumption is necessary because 1.14.4 performs axis-local state queries during clipping and the movement method also considers other collision sources.

Wording clarification for the draft/report: the displayed subtraction `0.5 - 0.6 = -0.1` uses **world-coordinate** extrema. The equivalent block-local arithmetic is `1.5 - 1.6 = -0.1`; call out the coordinate frame explicitly wherever the gap is stated. This is a clarity correction, not a numerical defect.

No product, canonical research, wiki, backlog, or Git data was inspected or changed. No builds, tests, launches, decompilation, or canonical source writes were performed.
