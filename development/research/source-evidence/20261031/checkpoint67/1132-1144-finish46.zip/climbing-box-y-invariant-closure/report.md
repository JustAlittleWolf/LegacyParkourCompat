# `isClimbing` position/box Y closure: 1.13.2 → 1.14.4

## Verdict

For a stable local-player state produced by the paired position, movement, dimensions/pose, login, correction, sleep/wake, and respawn writers below, `player.y == player.getShape().minY`. The changed lookup therefore names the same Y block: old `LivingEntity.isClimbing()` floors `getShape().minY`; new `LivingEntity.m_83221421()` constructs `BlockPos(this)`, whose `BlockPos(Entity)` constructor forwards `entity.y` to the double-coordinate constructor. No persistent, ordinary client-response state was found that makes this coordinate substitution alone change the climb gate.

This is a scoped closure, not a class-wide assertion that the two fields can never differ. `LivingEntity.tryTeleport` temporarily assigns raw `x/y/z` while testing a candidate, then every terminal success/failure path calls `teleport`, which reconstructs the box. `Entity.resetPos` has a separate upper-loop-bound exit: if a colliding iteration increments Y from below 256 to `>= 256`, the loop exits without rebuilding the box at the incremented Y. That can leave a persistent Y/box mismatch at the build-height edge. Both facts are explicit exceptions to a universal primitive-level invariant. The paired login/respawn reset normally tests identical block collision geometry; this audit found no common response witness where that edge makes the old and new climb predicates return different values. The source-level terminal remains conditional on an exceptional reset collision/state at the upper bound, so this report does not claim all possible out-of-range or externally-mutated states equivalent.

## Predicate and state identity

- 1.13.2 `LivingEntity.isClimbing()` (`LivingEntity.java:1046–1058`) computes `floor(x)`, `floor(getShape().minY)`, `floor(z)`, then looks up that position after the spectator gate.
- 1.14.4 `LivingEntity.isClimbing()` (`LivingEntity.java:1239–1253`) uses `m_83221421()`, which reads `world.getBlockState(new BlockPos(this))`; `BlockPos(Entity)` forwards `(entity.x, entity.y, entity.z)` (`BlockPos.java:43–45`), and the double-coordinate `Vec3i` constructor floors each coordinate (`Vec3i.java:19–20`). Both endpoint `Entity.setPositionFromShape()` implementations set `y = box.minY` (`Entity.java:781–786`). Thus the changed argument is exactly equal whenever the entity's stored position and box are synchronized.
- Both `Entity.setPosition(x,y,z)` implementations write `y` and construct the box with `minY = y` (old `Entity.java:309–316`; new `:308–315`). Both `setPositionAndAngles` implementations write the coordinate fields and call `setPosition` before returning (old `:1125–1138`; new `:1127–1140`). `refreshPositionAndAngles`, reset's per-iteration placement, and server-correction placement delegate through these routines.
- Both movement implementations may replace/move the box several times while clipping; they call `setPositionFromShape()` before returning from the movement operation (old `Entity.java:473–477, 578–680`; new `:444–468`). Living travel's climbing checks occur before that movement call or after it returns (old `LivingEntity.java:1560–1577`; new `:1848–1850, 1907–1909, 1945–1947`). There is no climb check in the intermediate shape-only clipping section.

## Local-player writers and lifecycle roster

| Writer/route | Paired source coverage and Y/box terminal |
|---|---|
| Constructor, login, world install | `PlayerEntity` constructor positions through `setPositionAndAngles`; old `Minecraft.setWorld` / new `ClientPlayNetworkHandler.handleLogin` complete reset before the player enters ordinary ticking. The handlers and construction/reset order are paired in `local-player-reset-pairing/report.md` (SHA-256 below). |
| Ordinary movement and no-clip | `Entity.move` updates the shape, then derives `x/y/z` from that final shape. In the old axis-by-axis and step-up branches, speculative `setShape` writes do not call `isClimbing`; the owning travel caller invokes the predicate only before or after `move`. In the new resolver, shape and position are updated together before `move` returns. |
| Size/pose changes | Old `PlayerEntity.updatePlayerPose()` creates candidate dimensions from the current box minimum and calls `setSize` only after the collision gate (`PlayerEntity.java:334–360`); old `Entity.setSize` preserves `box.minY` on expansion and uses `this.y` on width contraction (`Entity.java:285–300`). New pose callbacks flow through `Entity.onDataValueChanged` / `m_84943753()` (`Entity.java:2239–2266`): same-width/expansion retains `box.minY`, contraction uses `this.y`. With synchronized input state, each leaves or rebuilds `minY` equal to `y`. The paired pose report closes the dimensions/response routes and their collision gates. |
| Respawn reset | `PlayerEntity.resetPos` normalizes old size or new standing pose before shared `Entity.resetPos` (old `PlayerEntity.java:449–455`; new `:477–482`). The reset loop calls `setPosition` at the current Y before each collision query (old `Entity.java:260–274`; new `:266–283`). The upper-bound increment exit is the persistent exception stated above. Respawn handler order and first-tick state are covered by the cited pairing reports. |
| Position correction | `ClientPlayNetworkHandler.handlePlayerMove` resolves packet-relative axes against local `x/y/z`, then calls the paired position-and-angle updater, which reconstructs the box at that same Y. The existing direct-response pairing records the previous-coordinate difference; that does not alter current Y/box identity. |
| Sleep and wake | Old `PlayerEntity.trySleep`/`wakeUp` use `setSize` and then `setPosition`; the 1.14.4 synchronized sleeping-position callback and `setPositionInBed`, plus `stopSleeping` wake placement, use `setPosition`. The paired response and respawn reports cover callback order and the distinct bed-center offset. Those offsets change the selected position but not the equality between that position's Y and box minimum. Bed-entry eligibility is excluded. |
| Temporary teleport candidate | Old/new `LivingEntity.tryTeleport` directly assign candidate `x/y/z` while searching. The candidate scan does not call `isClimbing`; success and failure both finish through `teleport`, which calls `setPositionAndAngles` and restores the position/box identity before returning. This transient state is not a climb-gate input in the traced local-player path. |

No `LocalClientPlayerEntity` override writes the current Y or shape independently. Client entity move/teleport packets do not physically update the local player under the paired `isLogicalSideForUpdatingMovement` gate; direct local correction is the separate position-correction route. The assignment's permitted paired reports cover the remaining response dispatch and sleep/pose terminals listed here. State and packet producers, server processing, input-device producers, trajectories, and profile switching are excluded.

## Source identity and hashes

Read-only exact roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Ornithe Feather Gen2 build 2. Mapping/source provenance and full-tree manifests are bound in the permitted `client-response-pairing/report.md`. These are source-file SHA-256 values recomputed for this closure.

| Version | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/client/Minecraft.java` | `b1d35473cd12bdf38e87f9888b4ed6f620614cbe914cf7e7a40c601d4e284875` |
| 1.13.2 | `net/minecraft/entity/data/SyncedData.java` | `93177865e23be0f8db5741bd505b952daee03d33761838ca782bd10bceb748e4` |
| 1.13.2 | `net/minecraft/util/math/BlockPos.java` | `ee71cfdedcaa27458f48168ab761b435cf9c878b04f21e971ddbafb6254aa3fd` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.14.4 | `net/minecraft/client/Minecraft.java` | `6a5d9fac7092e8ec89bb86dd545e083d20df27edd039e26d68a216442ed039b2` |
| 1.14.4 | `net/minecraft/entity/data/SyncedData.java` | `4d0c0bee069994f64a31e1ff600ae59c3217eadb8678473e2256c2363e657e17` |
| 1.14.4 | `net/minecraft/util/math/BlockPos.java` | `8aa3d3a9ad3b3b9f230efaf5ac06a45ed7af3f59636ef7cf9507ba9317c22fd8` |
| 1.14.4 | `net/minecraft/util/math/Vec3i.java` | `f1d2e85d690b69c546b2dc783ede2ddbbfac400ca72271828929a45db03729a9` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8da8a238edf834f3963e401e6eeef6cb475c4909` |

## Roster cross-check

Read-only prior pair reports used to avoid duplicating already paired lifecycle/response work: `local-player-reset-pairing/report.md` (`c449abea73a5511aa547c8cd0b6a96155db7bc770bf8185a4ce80e5be0e5fd48`), `local-player-pose-lifecycle-closure/report.md` (`0544acf3ea91c71194460c9947633201fd6c4b7a0ab052bce9133078b26bef18`), `client-response-pairing/report.md` (`7563d89bc605f330ac8fac55cf7045f600013a250df07d0ab8a30216eb849f3f`), `client-response-modifier-residual/result.md` (`840661b7af22e851fa1e290dbff13493bdf2ed1ecc95d0081cfecc2e7c4107a1`), `respawn-first-tick-followup/result.md` (`f1bc052ac06185d24047267fe51584a20b366a3aee4774fd6728da2ebe7d6e7a`), and `sleep-position-boundary/boundary-check.md` (`ae1a244a078afea53eb1a4d18969b3e7d64be2b88465b7d242141b98c5727c32`). The roster above closes the specific stored-Y/box-minY dependency only; it does not certify full pair freeze, producer history, or runtime parity.

No source tree was written or regenerated. No product, wiki, backlog, Git history, build, test, or runtime was used.
