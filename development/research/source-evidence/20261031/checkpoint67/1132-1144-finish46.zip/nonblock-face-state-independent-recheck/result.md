# Independent non-Block face-provider state closure (1.13.2 → 1.14.4)

## Result

Independently closed all ten requested registered IDs and their raw state domains against Feather endpoint sources. This is source-output closure only. No accepted candidate claim is extended, and no trajectory/runtime behavior is asserted.

| ID | 1.13.2 registration / state domain | 1.14.4 registration / state domain | Old horizontal face result | New horizontal sturdy result |
|---|---|---|---|---|
| chorus_flower | `ChorusFlowerBlock`; AGE_5 0..5 (6) | same class; AGE_5 0..5 (6) | UNDEFINED | true (collision enabled, base unit-cube shape, not default LEAVES) |
| cobweb | `CobwebBlock`; no properties (1) | same; no properties (1) | UNDEFINED | false (noCollision → empty collision shape) |
| end_gateway | `EndGatewayBlock`; no properties (1) | same; no properties (1) | UNDEFINED | false (noCollision → empty collision shape) |
| kelp_plant | `KelpPlantBlock`; no properties (1) | same; no properties (1) | UNDEFINED | false (noCollision → empty collision shape); same-fluid water gate also returns false |
| large_fern | `DoublePlantBlock`; HALF={LOWER,UPPER} (2) | `BushBlock`; HALF={LOWER,UPPER} (2) | inherited PlantBlock UNDEFINED | false (noCollision → empty collision shape) |
| lilac | `TallFlowerBlock`; HALF={LOWER,UPPER} (2) | same; HALF={LOWER,UPPER} (2) | inherited PlantBlock UNDEFINED | false (noCollision → empty collision shape) |
| peony | `TallFlowerBlock`; HALF={LOWER,UPPER} (2) | same; HALF={LOWER,UPPER} (2) | inherited PlantBlock UNDEFINED | false (noCollision → empty collision shape) |
| rose_bush | `TallFlowerBlock`; HALF={LOWER,UPPER} (2) | same; HALF={LOWER,UPPER} (2) | inherited PlantBlock UNDEFINED | false (noCollision → empty collision shape) |
| sunflower | `TallFlowerBlock`; HALF={LOWER,UPPER} (2) | same; HALF={LOWER,UPPER} (2) | inherited PlantBlock UNDEFINED | false (noCollision → empty collision shape) |
| tall_grass | `DoublePlantBlock`; HALF={LOWER,UPPER} (2) | `BushBlock`; HALF={LOWER,UPPER} (2) | inherited PlantBlock UNDEFINED | false (noCollision → empty collision shape) |

Total domain: 21 registered raw states. Output is constant for every state within each row; the only row-level difference is chorus_flower. In 1.13.2 FlowingFluid's falling-flow branch calls `isSolidFace` for each horizontal direction and both the neighbor and above-neighbor. Its helper rejects same-fluid, UP, ICE and attachment exceptions before testing `getFaceShape(...) == SOLID`; these ten providers yield false on horizontal directions. In 1.14.4 the same caller shape persists and the helper uses `BlockState.isFaceSturdy` (mapped source method `m_87223014`) for the horizontal test. It delegates to `Block.isFaceSolid`, which requires non-LEAVES and a full collision face. The new registrations set noCollision on the nine non-chorus rows. Chorus flower is default collision-enabled and has no shape override, so base full cube gives true; AGE does not affect the result. This report does not characterize any possible map/runtime frequency of that membership.

## Exact source anchors and identities

Paths below are relative to `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{version}/ornithe-feather/net/minecraft/`.

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 | Relevant anchors |
|---|---|---|---|
| `block/Block.java` | `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` | `1F8EC3628F08E196C2793E91CA0B94FEACEA6BC3939E7FB770F0682A6E66F2C5` | old registry and `Properties.noCollision`; new `isFaceSolid` around 402–403 and collision shape |
| `block/Blocks.java` | n/a | `9C0323497B31F8A284456E5692898897B92B6F0817D0371FAE9A8AFB54C638F8` | requested registrations in crop / gateway / kelp sections |
| `block/state/BlockState.java` | `0496FDA381628E90B3B3FF8AE376A5BAE24CBD662366F34D70991252FAB2FE70` | `6C6703C7C2F7203A7507D8A621BC83E1DAD613B32089394F5AF4FBD8636B165F` | old face delegation; new sturdy delegation / state cache |
| `fluid/FlowingFluid.java` | `2398D109DDC5785CB1BC8872B8C157319137DF8957FA8A03581A8F68AFB1253` | `6AFB033D18E6D28FF6D7DEDA88F5F1432914903B0FEF100C44FB8372D3E148CE` | falling caller and `isSolidFace` (old 105–123; new 106 onward) |
| `data/tag/BlockTagsProvider.java` | `DB7E0AA20A1E9429380328B64812BDFF9D2D4B3B9D2016888CB7348D0EBAFC7E` | `0BD051D11A0C85ECC61CD2202A6ED33923DB97238DA0B065A647B932132D1BFA` | default LEAVES recipe at 239–240 / 299–300, same six leaf IDs; none of ten requested IDs |
| `block/PlantBlock.java` | `A1234CCEC309BD8805FBE3BAD48BCE076E17C131E048D2A57D18CDB75F0F286E` | `6EDE310FCB1E0163865DD4161B291CC02FE223BB56DFA1F89AA64B1CF72A1F75` | inherited old `getFaceShape` UNDEFINED; new plant class remains ancestor where applicable |
| `block/ChorusFlowerBlock.java` | `CACBBD84E9BE8912D8E79D6D90CAFD72A70B81D3E96518B8F0EB2EAF65FE19C4` | `5F8DE15E04EFD8F98A1DCC82628550CFCFE2D65C00BFBAE6F56586B9E11ADDA4` | AGE property and no face/collision-shape override |
| `block/CobwebBlock.java` | `A0848FDDD8D8C526E99241F6F6FAB74DF108D0F8861A4F04CC331FD6FD058875` | `EC068B2EAD79F4986DAD8AFDBBF442DAFB0725C39F1BBDE286F670631324D704` | no face override |
| `block/EndGatewayBlock.java` | `F02BF4B06AB7BF2DE97DAC396F14A1E8D03D32BF386F3EF8676402D6BAF05023` | `2BF5E035C7C770617C5156FE49BA120D44E1CE7F6815BF78C96EFAC16F60BB8C` | no face override |
| `block/KelpPlantBlock.java` | `DBA4DFFADA2A7BAAE6A0F06E973B5AF7DD175B71B9387581497087F76378751F` | `0178BAAD268C0CCC7FF9DA8BDA721F933CB3CCE81736B2DCC968C8D626EDD345` | no face override; water source state behavior |
| `block/TallFlowerBlock.java` | `BE73145A27670281B9A7DCEB5AAA635210205CD408D31E8F463FCAA0AA75C564` | same | HALF definition; inherited PlantBlock face result |
| `block/DoublePlantBlock.java` | `95E782D379A7E8FBBE24497BD25D840AAB47CCC6FB2DE8F50F5AFA0CBD8080FA` | n/a (IDs now registered as BushBlock) | old HALF definition and PlantBlock ancestry |
| `block/BushBlock.java` | `F4602BF78BD7477F7A4EA5FF3FBAB862FF523D853900C7A72A7CE14B5D7B30F8` | `BAE19AADCD260D90011DBED798F4D3B343C678DA36D04FBB0FCB559E47F7B443` | new HALF definition / state definition and base behavior |

Source manifest SHA-256: 1.13.2 Feather `ornithe-feather.sources.sha256` = `2C8CFB646BF622FB26AC0CA0CB5E02A354FB512E29F8B1010F1AAACD509E1211`; 1.14.4 Feather `ornithe-feather.sources.sha256` = `717B468536348557F9DAE8CF57EDCCF80AD16EB65E5BEF6C60BDB5EA3C9F75BC`. Thirty relevant path/hash entries were independently checked against these manifests; zero mismatches. Each file SHA above is the exact endpoint file content identity.

## Coverage limits

This closes only the ten rows delegated here. It relies on equal raw registered block-state inputs and vanilla default tag membership as source facts; it does not prove state production, live fluid/player histories, trajectories, or application reachability. It does not report block-state generation changes. Chorus is noted as a provider-output delta for bounded coverage and must not be read as an extension or independent acceptance of any existing chorus candidate claim.
