# Fluid-face outputs for slab, trapdoor, and snow: 1.13.2 → 1.14.4

## Scope and evidence identity

Source-only comparison of exact 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 trees, at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Publication, manifest, ready-marker, and provenance identities are in the assigned `../providers/inventory.md`. I recomputed the six provider-file hashes below from those trees; each matches the assigned provider TSV and the existing paired shape report. `FlowingFluid.java`, `Block.java`, `BlockState.java`, and `BlockTagsProvider.java` hashes also match that inventory and existing fluid-face reports.

The paired vanilla registrations are `minecraft:oak_slab`, `minecraft:oak_trapdoor`, and `minecraft:snow`. The existing `../common-block-shape-pairing/result.md` pairs all 6 oak-slab and 64 oak-trapdoor collision/outline outputs; `../pane-snow-fence-shape-pairing/result.md` and `../provider-state-pairing/result.md` bind the snow collision formula and equal layer boxes across all 8 states. The old and new providers ignore context, world, and position. This pass evaluates all six directions for each raw state against the old direct face method and 1.14.4's face-sturdy route. It assumes the same raw block state on both sides, default vanilla tags, and a nonmatching neighbor fluid; the common ICE and same-fluid short-circuit gates are therefore inactive. This is not a state-production, player-trajectory, or full-pair claim.

## Predicate chain and tag gates

In 1.13.2, `FlowingFluid.isSolidFace` (`FlowingFluid.java:105–123`) returns false for same-fluid neighbors, true for `UP`, false for ICE, then returns false for `Block.isExceptionForAttachment(block)` or `StairsBlock`, and otherwise tests whether the direct `getFaceShape(...)` result is `SOLID`. The vanilla `TRAPDOORS` recipe contains `WOODEN_TRAPDOORS` plus iron trapdoor (`BlockTagsProvider.java:261–263`); the wooden recipe lists the six wooden trapdoors (`:261–262`). Consequently every common registered `TrapdoorBlock`, including the paired oak trapdoor, is rejected before its direct face result is read.

In 1.14.4, the same-fluid and `UP` gates remain and ICE still returns false; the remaining branch asks `BlockState.isFaceSturdy` (`FlowingFluid.java:106–115`, Feather's `m_87223014`). For the assigned static registrations this resolves through the per-state face cache to `Block.isFaceSolid`, which rejects active `LEAVES` membership and then checks whether the collision shape fills the requested face (`Block.java:402–410`, `BlockState.java:326–327,412–416`). Both default generated `LEAVES` recipes list exactly the six vanilla leaf blocks (`1.13.2 BlockTagsProvider.java:239–240`; `1.14.4 :299–300`); these three registrations are absent. Custom or runtime tag replacements are outside this comparison.

## Raw states, providers, and all six directions

`SlabBlock` defines `HALF × WATERLOGGED` (3 × 2 = 6 states); `WATERLOGGED` is not read by either face or shape provider. The state value named `HALF` is the `SlabType` enum (`BOTTOM`, `TOP`, `DOUBLE`). `TrapdoorBlock` defines `FACING × OPEN × HALF × POWERED × WATERLOGGED` (4 × 2 × 2 × 2 × 2 = 64); its face result reads only `OPEN` and `HALF`, and its shape reads `OPEN`, `HALF` when closed, or `FACING` when open. `SnowLayerBlock` defines `LAYERS=1..8` (8 states); its old direct face result ignores `LAYERS`.

The following tables cover each member of those Cartesian state domains. Face order is `DOWN, UP, NORTH, EAST, SOUTH, WEST`; `S` means the queried face is solid, `.` means it is not. “Old fluid result” applies the complete old helper including the old trapdoor exception and the `UP` short-circuit. “New face-sturdy” is the collision-face result before the common same-fluid, UP, and ICE gates in `FlowingFluid`.

### Slabs

| Raw state descriptor | Both endpoint collision box (sixteenths) | Old direct `getFaceShape` | Old fluid result | New face-sturdy |
|---|---|---|---|---|
| `HALF=BOTTOM, WATERLOGGED∈{false,true}` | `[0,0,0,16,8,16]` | `DOWN=S`; all other faces `.` | `DOWN=S, UP=S; N/E/S/W=.` | `DOWN=S`; all other faces `.` |
| `HALF=TOP, WATERLOGGED∈{false,true}` | `[0,8,0,16,16,16]` | `UP=S`; all other faces `.` | `UP=S; DOWN/N/E/S/W=.` | `UP=S`; all other faces `.` |
| `HALF=DOUBLE, WATERLOGGED∈{false,true}` | `[0,0,0,16,16,16]` | all six `S` | all six `S` | all six `S` |

The terminal old and new `isSolidFace` results agree for every direction and all six raw states. The `UP` old result is true from the helper's earlier gate for every slab state, regardless of the direct method row; the table records that actual helper result separately from direct `getFaceShape`.

### Trapdoors

| Raw state descriptor | Both endpoint collision box (sixteenths) | Old direct `getFaceShape` | Old fluid result after `TRAPDOORS` exception | New face-sturdy |
|---|---|---|---|---|
| `OPEN=false, HALF=BOTTOM, FACING∈{N,E,S,W}, POWERED∈{false,true}, WATERLOGGED∈{false,true}` | `[0,0,0,16,3,16]` | `DOWN=S`; all other faces `.` | all six `.` | all six `.` |
| `OPEN=false, HALF=TOP`, with the same other-property domains | `[0,13,0,16,16,16]` | `UP=S`; all other faces `.` | all six `.` | all six `.` |
| `OPEN=true, FACING=NORTH`, with either `HALF`, `POWERED`, or `WATERLOGGED` | `[0,0,13,16,16,16]` | all six `.` | all six `.` | all six `.` |
| `OPEN=true, FACING=SOUTH`, with either `HALF`, `POWERED`, or `WATERLOGGED` | `[0,0,0,16,16,3]` | all six `.` | all six `.` | all six `.` |
| `OPEN=true, FACING=WEST`, with either `HALF`, `POWERED`, or `WATERLOGGED` | `[13,0,0,16,16,16]` | all six `.` | all six `.` | all six `.` |
| `OPEN=true, FACING=EAST`, with either `HALF`, `POWERED`, or `WATERLOGGED` | `[0,0,0,3,16,16]` | all six `.` | all six `.` | all six `.` |

The open rows stand for all 16 combinations of `HALF × POWERED × WATERLOGGED` for the named facing; the closed rows each stand for all 16 combinations of `FACING × POWERED × WATERLOGGED`. The 3/16-thick panel never fills a unit face. The direct old provider's closed top/bottom `SOLID` labels do not reach the old fluid terminal because the default `TRAPDOORS` gate rejects the block first. Therefore actual old and new helper results match as false for every state and face.

### Snow

| Raw state descriptor | Both endpoint collision box (sixteenths) | Old direct `getFaceShape` | Old fluid result | New face-sturdy |
|---|---|---|---|---|
| `LAYERS=n`, for every `n∈{1,2,3,4,5,6,7,8}` | `[0,0,0,16,2(n−1),16]` | `DOWN=S`; all other faces `.` | `DOWN=S, UP=S; N/E/S/W=.` | all six `.` |

The collision provider uses `SHAPES[LAYERS−1]`: layer 1 is empty and layer 8 is only 14/16 high, so no layer produces a full unit face. Thus the actual old and new `isSolidFace` result differs on `DOWN` for all eight states (old true, new false); `UP` agrees due the helper gate, and horizontal faces agree as false. `FlowingFluid.getFlow` calls this helper only for horizontal directions and each such direction's upper neighbor (`FlowingFluid.java:87–96` old; `:84–98` new). Its player-facing falling-flow branch therefore never consumes the snow `DOWN` difference. The source difference is a predicate output outside the directions used by this flow-vector caller.

## Context, cache, and hashes

The slab/trapdoor report verifies both endpoint output boxes for all 6 and 64 state combinations and confirms no provider reads context, world, or position (`../common-block-shape-pairing/result.md`). Snow uses the paired shape-array result cited above. In 1.14.4 `BlockState` builds cached face-sturdy results for nondynamic static shapes using empty context (`BlockState.java:412–416`); the assigned vanilla registrations do not set `dynamicShape`, and the entity-context route selects the same provider output because these providers ignore context. Cache routing therefore does not change any boolean in the tables. The 1.13.2 collision path likewise reaches these registered blocks' same-state shape providers.

Whole-file SHA-256 values, recomputed from canonical read-only endpoint source:

| Relative source path | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` | `91f2ebc592e5cb07d5ce8a6faa123ec0d4b7bf10aa6323d6aceb343bc0f73a53` |
| `net/minecraft/block/TrapdoorBlock.java` | `26dd6911517029daef779cef046e943953356644a76372f1d47b1323054629da` | `129b1c0eda5e1431fe3845ef129524dd96c4eb018b686e6d0e38b093e198b3a5` |
| `net/minecraft/block/SnowLayerBlock.java` | `12b2d50064fd306c09007bc9a3629cc14a540123ce37e3b53a7f6615c9915df2` | `2307bd4ad1b41210c8c82fddad03dea2e6867b87e7539b9249a6ed49960f6dcb` |
| `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/data/tag/BlockTagsProvider.java` | `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` | `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |

This closes the assigned three-family, six-face source comparison under the stated same-state/default-tag assumptions. It does not establish a reachable player trajectory, the actual active runtime tag payload, any intermediate release boundary, or full pair coverage/audit.
