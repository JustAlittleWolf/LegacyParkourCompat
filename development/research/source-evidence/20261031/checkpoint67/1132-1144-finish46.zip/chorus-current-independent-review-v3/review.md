# Independent review: chorus-flower falling current, v3

## Verdict

**Accepted for the bounded source-query claim.** The reviewed draft is SHA-256 `EE0BBA652A75B741C177B0CBD7E667C7F7D0FA4D82F04E8B3CC7A6C71EEE1B5B`. I found no remaining source or caveat error in its paired raw-state fixture. The draft correctly keeps this as a conditional source-query result: it does not claim a produced fluid/player trajectory, active tag provenance, or an intermediate version boundary.

## Independent retrace

- Pair identity: Ornithe Feather Gen2 build 2, 1.13.2 → 1.14.4, at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. The source-only provider inventory gives source-manifest hashes `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; recomputed manifest, ready-marker, provenance, and relevant source-file hashes match that inventory and the paired reports.
- In each `FlowingFluid.getFlow`, all four horizontal neighbors have empty fluid, so every gradient stays zero. `Material.PLANT` has `notBlocksMotion`; the east chorus-flower therefore triggers the lower-fluid lookup, which is empty by the fixture. Each horizontal face and its upper neighbor are checked in the falling branch. In 1.13.2 the flower's direct face provider returns `UNDEFINED`; the air samples are also non-solid. In 1.14.4 the flower has collision enabled and inherits the full-cube collision shape, giving a sturdy EAST face for every `AGE=0..5`; the east sample is the first matching direction. The old vector remains zero. The new branch normalizes zero, adds `(0,-6,0)`, and the final normalization yields `(0,-1,0)`.
- `LEVEL=8` gives raw height `8 / 9.0F`. The 1.14.4 contextual height returns the raw height when the block above is not the same fluid; `P+UP` is empty in the fixture. Thus both endpoint body scans use the same surface, and the specified box contraction yields `minY=0.481`. The loops run x/z at 0 and y at 0, 1, 2; `P+UP` and `P+2UP` are empty, so only `P` contributes. Its depth is about `0.40789`, not below `0.4`, so no depth scaling occurs. The contributor count is one.
- `Entity` averages accumulated flow by contributor count, then normalizes only non-player entities. For the local player the new `(0,-1,0)` remains unnormalized and the `length()>0` writer adds `0.014 × (0,-1,0)` to velocity. The old zero flow does not pass that writer gate. The claimed difference is therefore a `-0.014` Y-velocity delta for the paired query, not an absolute velocity or trajectory.

## Evidence checked

- Exact primary source files: `FlowingFluid.java`, `FluidState.java`, `Entity.java`, `ChorusFlowerBlock.java`, `Blocks.java`, `Block.java`, `Material.java`, and `Vec3d.java` at both endpoints where present. Relevant source references are `FlowingFluid.getFlow` / `isSolidFace` (old lines 54–123; new lines 54–115), contextual `FlowingFluid.getHeight` (new lines 442–453), `Entity.m_69693160` (old lines 2509–2571; new lines 2563–2622), old `ChorusFlowerBlock.getFaceShape` (lines 243–246), and new flower registration in `Blocks.java` (lines 1413–1418).
- `.native-source/20261031/1132-1144-finish46/fluid-face-unpaired-closure/result.md` and `.native-source/20261031/1132-1144-finish46/fluid-face-current-terminal/result.md`, including their stated exact-source identities and fixture/provider closure.
- `.native-source/20261031/1132-1144-finish46/providers/inventory.md`, including the paired endpoint publication identity and manifest checks.

Primary source hashes central to the retrace:

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0f0ef100c44fb8372d3e148ce` |
| `Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `ChorusFlowerBlock.java` | `cacbbd84e9be8912d8e79d6d90cafd72a70b81d3e96518b8f0eb2eaf65fe19c4` | `5f8de15e04efd8f98a1dcc82628550cfcfe2d65c00bfbae6f56586b9e11adda4` |
| `Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |

No canonical sources were modified. No tests, builds, gameplay, decompilation, product, wiki, backlog, prior review/audit, or Git data were used.
