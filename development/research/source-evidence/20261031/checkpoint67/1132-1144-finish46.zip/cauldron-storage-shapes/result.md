# Storage and cauldron shape pairing: 1.13.2 → 1.14.4

## Scope and evidence identity

Bounded source-only comparison of the matching raw-state outline/shape provider outputs for `CauldronBlock`, `ChestBlock` (including the inherited `TrappedChestBlock` provider), `EnderChestBlock`, `HopperBlock`, and `AnvilBlock`, plus common registry IDs, state domains, provider dispatch, and relevant chest neighbor updates. This does not complete the remaining provider inventory, establish a movement trajectory, or freeze the pair.

Primary source identity is the parent inventory's verified Ornithe Feather Gen2 build 2 pair: 1.13.2 build 2 and 1.14.4 build 2. The inventory records source-manifest/ready-marker/provenance identities and confirms its source hashes. The five target provider rows agree with those hashes. No source was modified or regenerated.

The prior `provider-state-pairing/result.md` closes only generic block dispatch and the listed explicit collision providers; its `getShape` providers remain unpaired there. The prior `support-predicate-pairing/result.md` expressly leaves per-state getShape providers unpaired. Neither report closes the five families in this assignment.

## Dispatch and common states

In 1.13.2, `BlockState.getCollisionShape(world,pos)` dispatches through `Block.getCollisionShape`, whose `hasCollision` gate calls the state shape provider; base `Block.getShape` returns a full cube. In 1.14.4, the state collision-shape overload dispatches through the corresponding block method and passes `CollisionContext`; base `Block.getShape` again returns a full cube. The target providers below override `getShape`, and each 1.14.4 override ignores its added context parameter. Thus each provider's `getShape` result is both its outline result and the input to inherited collision-shape dispatch when the block's collision gate is true. The providers do not inspect world, position, entity occupancy, or block-entity contents. Static-cache dispatch in 1.14.4 therefore uses the same context-independent result; no target class supplies a dynamic-shape override.

The target source definitions expose these same raw domains on both sides:

| Family | Common registration IDs | State properties in both endpoints | Provider output condition |
|---|---|---|---|
| Cauldron | `minecraft:cauldron` | `LEVEL={0,1,2,3}` | None; level is ignored. |
| Chest | `minecraft:chest`, `minecraft:trapped_chest` | `FACING={NORTH,SOUTH,WEST,EAST}`, `TYPE={SINGLE,LEFT,RIGHT}`, `WATERLOGGED={false,true}` | `TYPE`; connected side follows `FACING` and left/right. Trapped chest inherits the same provider in both endpoints. |
| Ender chest | `minecraft:ender_chest` | `FACING={NORTH,SOUTH,WEST,EAST}`, `WATERLOGGED={false,true}` | None; facing and waterlogged are ignored. |
| Hopper | `minecraft:hopper` | `FACING={DOWN,NORTH,SOUTH,WEST,EAST}`, `ENABLED={false,true}` | `FACING`; enabled is ignored. |
| Anvil | `minecraft:anvil`, `minecraft:chipped_anvil`, `minecraft:damaged_anvil` | `FACING={NORTH,SOUTH,WEST,EAST}` | Facing axis selects the perpendicular long-axis shape. Damage tier is the registered block instance, not a state property. |

The definitions are from each class's `buildStateDefinition` plus `Properties.LEVEL_3`, `Properties.CHEST_TYPE`, `Properties.HORIZONTAL_FACING` and `Properties.HOPPER_FACING`. The latter keeps all directions except UP in both versions; `ChestType` is the same enum domain in each source. Chest's paired `updateShape` code sets the double-chest side only when a same-block horizontal neighbor has matching facing and complementary non-single type, and resets to SINGLE when the connected side is lost. Therefore connectivity affects the provider through the same raw `TYPE` value on both sides; the provider itself does not read neighbor state.

Registry evidence: 1.13.2 `Block.java:994,1216,1230,1284–1287,1300`; 1.14.4 `Blocks.java:411,756,779–780,922–932,954–955`. The common IDs for the chest/anvil variants construct the same provider class family on each side; the trapped chest subclasses `ChestBlock` in both versions. Relevant state/property declarations: `CauldronBlock.java:22–25,43–45` (old) and `:29–40,50–52` (new); `ChestBlock.java:42–53,77–113,313–315` (old) and `:46–97,113–152,333–335` (new); `EnderChestBlock.java:30–42,135–137` (old) and `:33–46,121–123` (new); `HopperBlock.java:31–69,200–202` (old) and `:33–71,190–192` (new); `AnvilBlock.java:28–32,71–73,107–109` (old) and `:27–35,62–64,98–100` (new).

## Paired provider outputs

| Family | 1.13.2 provider | 1.14.4 provider | Same-state result |
|---|---|---|---|
| Cauldron | `CauldronBlock.getShape`, `net/minecraft/block/CauldronBlock.java:16–19,43–45` | `CauldronBlock.getShape`, `.../CauldronBlock.java:29–40,50–52` | **Different.** Both ignore `LEVEL`, world, position, and context, but the subtracted cavity changes. Old `SHAPE` is the unit block minus `INSIDE_SHAPE`, where the cavity is `x,z=2..14, y=4..16`, leaving a continuous full-footprint bottom slab from `y=0..4`. New shape subtracts the union of that same cavity and three boxes at `y=0..3`: `x=0..16,z=4..12`; `x=4..12,z=0..16`; and `x,z=2..14`. The same raw cauldron state therefore removes central bottom volume that was collision-solid before. For example, the interior point `(8,1,8)` in block-local coordinates is inside the old bottom solid and in the new subtraction. This is a movement-facing collision geometry difference; no player path through it is asserted. |
| Chest and trapped chest | `ChestBlock.getShape`, `net/minecraft/block/ChestBlock.java:45–49,93–107` | `ChestBlock.getShape`, `.../ChestBlock.java:48–52,132–146` | Same descriptor and state mapping. SINGLE returns `[1,0,1]–[15,14,15]`. For LEFT/RIGHT, `getConnectedDirection` maps FACING plus side to one of the same NORTH/SOUTH/WEST/EAST boxes; those four box coordinates match exactly. The 1.14.4 `CollisionContext` is unused. `WATERLOGGED` does not affect shape. |
| Ender chest | `EnderChestBlock.getShape`, `net/minecraft/block/EnderChestBlock.java:31–42` | `EnderChestBlock.getShape`, `.../EnderChestBlock.java:33–46` | Same descriptor `[1,0,1]–[15,14,15]` for every FACING/WATERLOGGED assignment. The newer context is unused. Opening/occupancy gates are in interaction code and do not affect shape. |
| Hopper | `HopperBlock.getShape`, `net/minecraft/block/HopperBlock.java:33–69` | `HopperBlock.getShape`, `.../HopperBlock.java:33–71` | Same descriptors and FACING dispatch: DOWN returns `DOWN_SHAPE`; each horizontal direction returns its matching spout shape; default returns `BASE_SHAPE`. `ENABLED` and context are unused. The shared `inventory/Hopper.java` dependency is byte-identical at both endpoints (SHA-256 `875ea61c315306699ac6d0e9d4551037515d4f9408521a391f6140044218b820`): `INSIDE` is `[2,11,2]–[14,16,14]`. All other component boxes and BooleanOp composition match. |
| Anvil family | `AnvilBlock.getShape`, `net/minecraft/block/AnvilBlock.java:30–38,71–74` | `AnvilBlock.getShape`, `.../AnvilBlock.java:28–35,62–65` | Same union of BASE, two leg boxes, and top box for each axis. The source expression changes from nested binary `VoxelShapes.or` calls to the four-operand `VoxelShapes.m_19519917` varargs helper, but both use the same component descriptors in the same order. FACING axis selects `SHAPE_Z` for X and `SHAPE_X` otherwise on both sides; raw horizontal FACING domain makes the fallback unreachable. The 1.14.4 context is unused. |

## Movement relevance and limits

The cauldron result is the sole paired output difference in this bounded slice. It changes the static collision geometry for the same existing vanilla `minecraft:cauldron` state, so it can change the collision boxes considered by ordinary player movement when a player overlaps the interior floor volume. This identifies a reachable movement-facing terminal only; it does not claim a demonstrated trajectory or quantify position/velocity divergence.

Adjacent contract left open: 1.13.2 `CauldronBlock.getFaceShape` returns BOWL for UP, UNDEFINED for DOWN, and SOLID for sides; 1.14.4 has no class-local `getFaceShape` override. The newer face-sturdiness path is the collision-face/tag mechanism described in the prior provider inventory. That distinct fluid-flow face predicate was not paired here.

Chest, trapped chest, ender chest, hopper, and all three anvil damage IDs have matching raw-state shape outputs in these endpoints. Their neighbor/connected, facing, enabled, and waterlogged state dimensions were checked as described above. Occupancy and block-entity state do not enter these providers. This closes only the listed provider families and does not claim all provider rows, active tag closure, state-production history, or intermediate release boundaries.

## Source-file hashes

Hashes match the corresponding rows in the frozen shape provider inventory where present.

| Endpoint | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/CauldronBlock.java` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` |
| 1.14.4 | `net/minecraft/block/CauldronBlock.java` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| 1.13.2 | `net/minecraft/block/ChestBlock.java` | `483ed7dc673f8acb33fbac6d5d883c652db05de2314931c522e0bee482792541` |
| 1.14.4 | `net/minecraft/block/ChestBlock.java` | `0103ffd23c63903f57efb76de25caae999eb06fc840f363afaaa4fcb6b54a5e5` |
| 1.13.2 | `net/minecraft/block/EnderChestBlock.java` | `12642f9af345dd70a0a1787af22c48f7ce9ae0f0c2ded1ae0fe6ba009bbff431` |
| 1.14.4 | `net/minecraft/block/EnderChestBlock.java` | `7c2ff5ddb905e1c3bd2a44b06d1579a6c532e7fa3598fa39c212f0c81601e010` |
| 1.13.2 | `net/minecraft/block/HopperBlock.java` | `c43588fd0bdf0c17ec7356090e67af8101335b5ee2a565088837d6d75a3a73ae` |
| 1.14.4 | `net/minecraft/block/HopperBlock.java` | `179c954e0c484ec1c613c9273b679725f5f352081a141540c31d8b20d6b03859` |
| Both | `net/minecraft/inventory/Hopper.java` | `875ea61c315306699ac6d0e9d4551037515d4f9408521a391f6140044218b820` |
| 1.13.2 | `net/minecraft/block/AnvilBlock.java` | `156505373606a0cf2c0df329e170465c207b72b2ab59798272cbec389373092e` |
| 1.14.4 | `net/minecraft/block/AnvilBlock.java` | `5edacda442a01ef963826463c4d5918eb699697e47eec4a073aed54c65fb918c` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

No product, wiki, backlog, or Git data was read or changed. No build, test, game launch, or source generation was performed.
