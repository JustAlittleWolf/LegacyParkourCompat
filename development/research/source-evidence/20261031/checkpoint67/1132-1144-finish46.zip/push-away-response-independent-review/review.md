# Independent source review: push-away response witness

**Verdict: CONDITIONAL.** The source-level behavior difference and the candidate's qualitative redstone explanation are correct. I cannot accept the claim as a retraced fixed-snapshot witness from `candidate.md` alone: it refers to an accompanying witness, but does not state the raw coordinates, bounding box, state layout around each sample, no-clip/swimming values, or starting velocity needed to verify each call and final vector. Include those values in the reviewed candidate revision (or bind the witness artifact by immutable identity) to close the numeric witness claim.

## Evidence identity

Read-only source roots: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.13.2\ornithe-feather` and `...\1.14.4\ornithe-feather`; both are Ornithe Feather Gen2, build 2. The provenance records identify 1.13.2 with `feather-gen2-1.13.2+build.2-mergedv2.jar` / `.tiny`, and 1.14.4 with the corresponding `1.14.4+build.2` artifacts. Their source-manifest SHA-256 values are respectively `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; the relevant file entries below match those manifests.

| Source | SHA-256 |
|---|---|
| 1.13.2 `LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 `PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 `Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 `Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` |
| 1.13.2 `RedstoneBlock.java` | `7b7284efaae2873529bc9da2a5e817716c0bcd83eb45f1333cc5ad77bf0bc9e0` |
| 1.14.4 `LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.14.4 `PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.14.4 `Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 `Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 `RedstoneBlock.java` | `7b7284efaae2873529bc9da2a5e817716c0bcd83eb45f1333cc5ad77bf0bc9e0` |

## Trace

- **1.13.2:** `LocalClientPlayerEntity.pushAwayFrom` has an internal `noClip` early return, constructs `BlockPos(x,y,z)`, and enters direction selection only when `wouldCollideAt` is true (`LocalClientPlayerEntity.java:401–454`). In the non-swimming branch, that predicate is `!doesNotSuffocate(pos)`. `PlayerEntity.doesNotSuffocate` requires `shouldSuffocate(pos)` and a non-solid block above; `shouldSuffocate` is `!state.isSolid()` (`PlayerEntity.java:1479–1484`). `Block.isSolid` requires solid-blocking material, cube state, and `!state.isSignalSource()` (`Block.java:265–267`). `RedstoneBlock.isSignalSource` returns true (same `RedstoneBlock.java:13–15` in both roots). Thus a redstone block at the tested position makes `isSolid` false; with air above, the non-swimming `wouldCollideAt` result is false, and this call does not replace horizontal velocity.
- **1.14.4:** the player calls `pushAwayFrom` at the four corner samples in order (`LocalClientPlayerEntity.java:647–650`) when `!noClip`; `pushAwayFrom` itself tests `wouldCollideAt` at the supplied position, then candidates west, east, north, south in that order (`:389–414`). `wouldCollideAt` scans Y from `floor(box.minY)` through but excluding `ceil(box.maxY)`, and returns true on the first position where `shouldSuffocate` is false (`:435–447`). `PlayerEntity.shouldSuffocate` negates `state.isViewBlocking(world,pos)` (`PlayerEntity.java:1420–1422`). The base `Block.isViewBlocking` requires movement-blocking material and a full collision shape (`Block.java:275–276`). The redstone block has the same `Material.IRON` registration in both versions (1.13.2 `Block.java:1298`; 1.14.4 `Blocks.java:948–950`), default collision enabled and full-block shape (`Block.java:376–378` in 1.14.4), and its unchanged signal-source override does not exclude it from `isViewBlocking`. For a tested vertical column containing that block, `wouldCollideAt` is true.
- A chosen horizontal direction writes exactly `-0.1` or `+0.1` on its axis. In 1.14.4 the call reads the current velocity vector and calls `m_32166403` with the selected component changed and the other two preserved (`LocalClientPlayerEntity.java:414–432`; `Entity.java:2646–2656`). This setter replaces the vector; it does not add an impulse. Repeated corner calls can overwrite earlier results, so they need not cancel. For example, with all four samples in one redstone cell, empty horizontal neighbors, and corner fractions `.29/.71` on both axes (player center `.5/.5`, width `.6`), strict `<` tie handling selects west, west, east, east; the last call leaves X at `+0.1`. This demonstrates that the claimed output is source-consistent for one concrete arrangement, but does not establish it is the candidate's unstated raw snapshot.

## Input validity and limits

`REDSTONE_BLOCK` is registered in both versions with the same material and signal-source behavior, so that block state is a valid common vanilla input. An identical player box and world-state arrangement may be supplied to both methods; the sampling methods impose no requirement that the box be collision-free. If the block intersects the player's box, the arrangement is not evidence of an ordinary collision-free placement or a trajectory into that state. The candidate already draws that reachability boundary correctly. The candidate must still state the actual fixed geometry and neighboring states to establish that all four 1.14.4 calls choose the claimed directions and leave the final `+0.1` X value.

The accepted source difference is therefore narrowly: for a non-swimming, non-no-clip snapshot whose 1.13.2 probe block is redstone with non-solid block above, while a 1.14.4 vertical sampled column contains redstone and candidate directions are available, the older call skips the push and the newer call can overwrite velocity with an axis-aligned `0.1` value. This is a direct player response; it says nothing about how that overlapped snapshot arose.
