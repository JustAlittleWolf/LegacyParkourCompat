# Hash-bound review addendum: revised push-away response witness

This addendum reviews the revised candidate only at SHA-256 `AE6FA929B0F60929F7FC7D57B3E33693E892EDB84781BBEE318DE66C90F61B87` (`.native-source/20261031/1132-1144-finish46/push-away-response-witness/candidate.md`). It does not revise the historical verdict in `review.md`, which remains **CONDITIONAL** for the earlier candidate revision because its raw snapshot was unstated.

**Renewed verdict for this candidate hash: ACCEPT.** I retraced the now-specified positions, vertical span, state layout and call sequence against the same read-only 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 endpoints and the same source-manifest/file hashes recorded in `review.md`.

## Independent snapshot trace

The call site uses four samples in this order: `(x-width*0.35,z+width*0.35)`, `(x-width*0.35,z-width*0.35)`, `(x+width*0.35,z-width*0.35)`, `(x+width*0.35,z+width*0.35)` (1.13.2 `LocalClientPlayerEntity.java:718–721`; 1.14.4 `:647–650`). With center `.5,.5` and width `0.6F`, the samples floor to central X/Z cell `(0,0)` and have the stated approximately `.29/.71` fractions. Every tested Y is `.25 + .5 = .75`, so the old `BlockPos` is `(0,0,0)` for all four calls.

For 1.13.2, `isSwimming=false` selects `!doesNotSuffocate`. Redstone at `(0,0,0)` has `isSolid=false` because `Block.isSolid` excludes signal sources and `RedstoneBlock.isSignalSource` is true; with air at `(0,1,0)`, `doesNotSuffocate` is true. Therefore `wouldCollideAt` is false for each central probe and no write occurs. Starting at `(0,0,0)`, the final old velocity remains `(0,0,0)`.

For 1.14.4, the stated shape bounds `[0.25,2.05]` make the scan range `floor(.25)=0` through `ceil(2.05)-1=2`. At each corner X/Z cell, row 0 is the redstone block, making `shouldSuffocate` false and the central `wouldCollideAt` true. Each candidate cardinal column contains air at rows 0, 1 and 2, so its `wouldCollideAt` is false. The ordered direction comparisons use strict `<` and visit west, east, north, south. With fractions `.29/.71`, the per-call minima are: west for `(.29,.71)` (west/south tie, west wins); west for `(.29,.29)` (west/north tie); east for `(.71,.29)` (east/north tie); east for `(.71,.71)` (east/south tie). The X component is therefore written `-0.1`, `-0.1`, `+0.1`, `+0.1` in order. Each setter preserves the other components and replaces the current vector, so final velocity is `(0.1,0,0)`, not a sum of four impulses and not a canceled result.

The common state and geometry are valid as equal raw inputs to both methods: the redstone block is registered in both endpoints with `Material.IRON`, has full collision shape, and remains a signal source. The redstone cube overlaps the stated player box, so this review accepts the direct response snapshot only; it does not accept or imply ordinary collision-free reachability, a trajectory into the snapshot, or how that world state arose. The revised candidate states that limitation correctly.

No source-code changes, builds, tests, runtime launches, or decompilation were performed.
