# Base-inherited shape registration census

Pair: Minecraft 1.13.2 → 1.14.4; exact decompiled source namespace: Ornithe Feather Gen2, build 2 on both sides. The assigned canonical roots were read-only.

## Scope and result

The registry declarations yield 597 direct string-key registrations in 1.13.2 and 676 in 1.14.4, with 595 common IDs. The 1.13.2 bootstrap is in `net/minecraft/block/Block.java`; 1.14.4 declarations are in `net/minecraft/block/Blocks.java`. Matching IDs are paired by namespace-free registry key. Full common-ID rows and registration recipes are in `inherited-common-registrations.tsv` and `excluded-custom-shape-registrations.tsv`.

Of 595 common IDs, 333 are excluded because at least one side's concrete class ancestry declares a direct `getShape` or `getCollisionShape` implementation. The remaining 262 common IDs inherit both shape methods from `Block` on both sides. Among these 262, 250 retain the same concrete class name, and 12 use a different class name. Every included ID has the same base collision outcome under its paired registration recipe: 253 have collision enabled and resolve to the base cube; 9 set `noCollision` and resolve to empty. All 262 retain the base full-cube outline shape. No included registration recipe sets `dynamicShape`; none has a changed `hasCollision` gate. These equalities are source-derived and are not claims about modded runtime replacements or active tags.

Custom-shape exclusions are listed individually with overriding class/method and recipes in `excluded-custom-shape-registrations.tsv`. The census did not consult implementation or wiki lanes, so any independently paired-family exclusions were not available as inputs; the concrete provider exclusions are the listed per-ID rows.

## Gate and shape evidence

- 1.13.2 `net/minecraft/block/Block.java`: `getShape` at line 388 returns `VoxelShapes.block()`; `getCollisionShape` at line 393 returns `this.hasCollision ? state.getShape(world, pos) : VoxelShapes.empty()`.
- 1.14.4 `net/minecraft/block/Block.java`: `getShape` at line 371 returns `VoxelShapes.block()`; `getCollisionShape` at line 376 returns `this.hasCollision ? state.getSHape(world, pos) : VoxelShapes.empty()`.
- Registration property construction is recorded per ID. `Block.Properties.copy` copies `hasCollision` and `dynamicShape` from its source block (1.13.2 line 1927; 1.14.4 line 838); `noCollision` clears the former (lines 1943 and 853); `dynamicShape` sets the latter (lines 1983 and 893). No included recipe uses `dynamicShape()`.
- The different 1.14.4 `CollisionContext` parameter is present in both base shape method signatures; these base bodies do not branch on it.

## Evidence identity and limits

Both source trees identify exact versions and namespace in `ornithe-feather.provenance.json`; each records Feather Gen2 `build.2` merged-v2 JAR and Tiny artifacts. Their verification manifests report `verified-identical-source-and-input-artifacts`, with 2,711 and 3,250 source files verified respectively and zero source differences. The 1.13.2 verifier notes a regenerated derived remapped archive hash difference while its published source and raw source inputs match; this does not change the source identity used here. The two source hashes and all provenance, ready, source/artifact, verification, diagnostic, and success manifests used are listed in `source-sha256.tsv`. Each hash is SHA-256 of the local file bytes. The input manifest records a prior immutable verification; it is not a new independent verification run.

The registration parser captures direct literal-key `register` calls in the identified bootstrap/declaration sources and resolves local constructor aliases. The two direct-key totals and common-key total are included to make this extraction boundary explicit. It does not expand IDs synthesized at runtime from nonliteral registry keys. This output is a bounded registration census, not full pair coverage or a freeze claim.

## Reconciliation with existing provider/state tranches

Of the 333 custom-shape common IDs excluded from the base-inherited table, the source-only lab already names 310 in provider/state pairing reports or explicitly complete family reports. The per-ID crosswalk and controlling report paths are in override-state-reconciliation.tsv; report scopes remain bounded by their stated raw-state, collision-context, vanilla-registration, and dynamic block-entity inputs. The remaining 23 IDs requiring provider/state/context pairing are listed in override-reconciliation.md: 16 colored stained-glass panes plus bubble_column, cave_air, end_portal, lava, nether_portal, structure_void, and water.

Registry ID differences are in registry-id-differences.tsv: old-only literal IDs are sign and wall_sign; there are 80 new-only literal IDs. air is a shared registry ID registered by the old default key and the new explicit string key, not an addition. These counts include ID crosswalks only and do not claim that provider/state pairings close state-production histories or trajectories.

