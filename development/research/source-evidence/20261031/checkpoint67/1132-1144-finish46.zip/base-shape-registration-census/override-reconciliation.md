# Provider-state reconciliation of custom-shape override registrations

The existing source-only lab has 333 common registered IDs whose class ancestry overrides getShape or getCollisionShape on at least one endpoint. Exact per-ID overlaps are in override-state-reconciliation.tsv. A report overlap identifies an ID explicitly or through a report stated as a complete family; it does not extend the report beyond its raw-state, context, vanilla-registration, or dynamic block-entity inputs. Rows without a named paired provider/state report are residual pairing work.

Named in at least one prior paired provider/state report/family: 310 IDs. Residual: 23 IDs. This is a report cross-reference, not a renewed independent audit.

## Paired reports and overlap counts

- bed-shape-pairing/result.md: 16 override IDs referenced as paired.
- block-chunk-collision-closure/result.md (AIR/VOID_AIR empty collision closure): 1 override IDs referenced as paired.
- cauldron-storage-shapes/result.md: 8 override IDs referenced as paired.
- chorus-dynamic-shape-pairing/result.md: 1 override IDs referenced as paired.
- climb-trigger-shapes/comparison.md: 7 override IDs referenced as paired.
- common-block-shape-pairing/result.md: 3 override IDs referenced as paired.
- container-shape-pairing/result.md: 7 override IDs referenced as paired.
- door-gate-shape-pairing/result.md: 2 override IDs referenced as paired.
- iron-door-shape-pairing/result.md: 1 override IDs referenced as paired.
- non-oak-slab-trapdoor-shapes/result.md: 25 override IDs referenced as paired.
- pane-snow-fence-shape-pairing/result.md: 3 override IDs referenced as paired.
- piston-shape-pairing/result.md: 4 override IDs referenced as paired.
- plant-crop-shapes-pairing/result.md: 69 override IDs referenced as paired.
- provider-state-pairing/result.md: 9 override IDs referenced as paired.
- provider-state-pairing/result.md (fixed collision provider paired): 1 override IDs referenced as paired.
- rail-redstone-shape-pairing/result.md: 28 override IDs referenced as paired.
- remaining-collision-provider-tranche/result.md: 17 override IDs referenced as paired.
- shape-provider-residual/result.md: 10 override IDs referenced as paired.
- shulker-collision-pairing/result.md (17 registrations explicitly covered as a family): 17 override IDs referenced as paired.
- sign-skull-banner-shapes/result.md: 45 override IDs referenced as paired.
- small-collider-shapes/result.md: 25 override IDs referenced as paired.
- special-block-shape-pairing/result.md: 4 override IDs referenced as paired.
- terrain-small-shapes/result.md: 6 override IDs referenced as paired.
- terrain-small-shapes/result.md (all 16 color IDs explicitly covered as a family): 16 override IDs referenced as paired.
- wall-shape-pairing/result.md: 1 override IDs referenced as paired.
- wood-door-gate-shape-tranche/result.md: 11 override IDs referenced as paired.

## Exact residual IDs

black_stained_glass_pane, blue_stained_glass_pane, brown_stained_glass_pane, bubble_column, cave_air, cyan_stained_glass_pane, end_portal, gray_stained_glass_pane, green_stained_glass_pane, lava, light_blue_stained_glass_pane, light_gray_stained_glass_pane, lime_stained_glass_pane, magenta_stained_glass_pane, nether_portal, orange_stained_glass_pane, pink_stained_glass_pane, purple_stained_glass_pane, red_stained_glass_pane, structure_void, water, white_stained_glass_pane, yellow_stained_glass_pane

The residual list still needs per-state pairing for context-sensitive, neighboring-state, or dynamic registrations as applicable. Provider-state-pairing closes direct fixed/explicit collision provider bodies only under its stated equal raw inputs; the piston report closes static head/base states and only conditionally closes dynamic moving-block geometry on matching nested providers. Movement context, upstream state production, and active tags remain open where those reports say so. No pair-freeze claim is made.
