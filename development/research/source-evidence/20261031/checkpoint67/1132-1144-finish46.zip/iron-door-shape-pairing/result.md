# Iron door shape pairing: 1.13.2 → 1.14.4

## Scope and result

Paired the common `minecraft:iron_door` registration in exact read-only Ornithe Feather Gen2 build 2 sources. `iron_door` is registered directly as `DoorBlock` at both endpoints; there is no separate `IronDoorBlock` implementation in either assigned source tree. The five properties give exactly 4 facings × 2 halves × 2 open values × 2 hinges × 2 powered values = 64 raw states. `states.tsv` enumerates each tuple once and records normalized outline and collision boxes plus SHA-256 hashes for both endpoints. All 64 rows match for outline and collision (64/64 each); the four distinct descriptors each occur for 16 rows. The per-row table hash is SHA-256 `029deafb4f16fb3e4f37d44ae939b4b2e7138c31afcf89c589ed0a725194834e`.

The descriptors use integer sixteenths `(minX,minY,minZ,maxX,maxY,maxZ)`:

| Selected slab | Descriptor | Rows |
|---|---|---:|
| south-facing panel | `0,0,0,16,16,3` | 16 |
| east-facing panel | `0,0,0,3,16,16` | 16 |
| north-facing panel | `0,0,13,16,16,16` | 16 |
| west-facing panel | `13,0,0,16,16,16` | 16 |

## Registration, state domain, and shape/collision route

- 1.13.2 `net/minecraft/block/Block.java:1014` registers `iron_door` as `new DoorBlock(Block.Properties.of(Material.IRON, MapColor.IRON).strength(5.0F).sounds(BlockSounds.METAL))`. 1.14.4 `net/minecraft/block/Blocks.java:498–500` registers the same key, class, material, map color, strength and sound.
- The shared class constructor takes `Block.Properties`, calls `super(properties)`, and sets the same default state (north, closed, left hinge, unpowered, lower) in 1.13.2 `DoorBlock.java:43–48` and 1.14.4 `DoorBlock.java:44–49`. Its state definition adds `HALF, FACING, OPEN, HINGE, POWERED` in both versions (`:265–267` and `:255–257`). `StateDefinition` enumerates the Cartesian product of property values; its source file is byte-identical at both endpoints.
- The outline provider in 1.13.2 `DoorBlock.java:51–65` and 1.14.4 `DoorBlock.java:52–66` selects one of four 3/16-thick, full-height/depth slabs. Closed selection depends on `FACING`; open selection depends on `FACING` and `HINGE`. `HALF` and `POWERED` are not read. The 1.14.4 overload accepts `CollisionContext`, but the method body does not read it. Neither provider reads `world` or `pos`.
- In 1.13.2, `BlockState.getCollisionShape` dispatches to `Block.getCollisionShape`, whose collision-enabled branch returns `state.getShape(world,pos)` (`BlockState.java:209–210`, `Block.java:393–395`). The iron registration does not call `noCollision()` and the `Properties` default is `hasCollision=true` (`Block.java:1901`), so collision is the same selected door slab as outline.
- In 1.14.4, the corresponding base collision method returns `state.getSHape(world,pos)` when collision is enabled (`Block.java:376–378`); it does not use the passed context. `hasCollision` defaults to true (`Block.java:811`), and the registration does not disable it. `dynamicShape` defaults false (`Block.java:819`), so registered states take the static cached route (`BlockState.java:65–68,197–203,410`). The cache constructs collision with empty context, and the door shape itself ignores context, world and position. Thus this cache/dispatch route selects the same slab for outline and collision.

## Old face-shape/helper route

In 1.13.2 `DoorBlock.getFaceShape` returns `FaceShape.UNDEFINED` for every queried face (`DoorBlock.java:270–272`). The old `FlowingFluid.isSolidFace` helper loads the block/fluid state, returns false for same-fluid, returns true for `UP`, returns false for ICE, then applies the attachment-exception/stairs gate before comparing the direct face result with `SOLID` (`FlowingFluid.java:105–123`). The helper returns false if the attachment-exception/stairs gate short-circuits; otherwise it compares the direct `FaceShape.UNDEFINED` result with `SOLID`, also yielding false. Thus for non-same-fluid, non-`UP`, non-ICE input the old helper result is false without assuming that the direct comparison is always reached. This records only the old helper route and predicate result under its stated gates. It does not pair the changed newer helper or establish a fluid-flow or player trajectory consequence.

## Exact source identity

Both endpoints are the assigned Ornithe Feather Gen2 build 2 mappings: 1.13.2 `feather-gen2-1.13.2+build.2-mergedv2.jar` / `.tiny`; 1.14.4 `feather-gen2-1.14.4+build.2-mergedv2.jar` / `.tiny`. The ready markers identify the source-manifest SHA-256 as `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4); recomputed source-file hashes and the manifest file hashes are in `source-hashes.tsv`. The marker values equal the recomputed SHA-256 of each `.sources.sha256` manifest. The exact version and mapping ready markers identify 2,711 and 3,250 source files respectively.

## Closed rows and residuals

Closed here: the common registered iron-door key; its constructor/property wiring; all 64 Cartesian raw states; per-state outline and collision selectors/output; the ordinary collision-enabled dispatch and static context/cache route; and the old direct face-shape method through the old helper gate. The table's descriptors also match the existing same-pair oak-door report for all 64 identical raw tuples (zero row deviations), as a shape-selector cross-check.

Residuals: this is raw-state shape/provider pairing, not proof every tuple is produced by ordinary placement, neighbor or redstone histories; it does not inspect active runtime tag payloads or modded registry replacement; it does not pair the 1.14.4 fluid-face helper route or prove a player trajectory; and it does not close other provider slices, full-pair coverage, independent audit, or a pair freeze.