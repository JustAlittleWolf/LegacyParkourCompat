# Independent review: revised tiny piston accumulator candidate

## Verdict

**ACCEPT.** I independently reread the exact Feather endpoint methods and verified the corrected candidate's first-call position divergence, accumulator state, and second-call convergence statement. The claim is suitable as a source finding for the direct local-player movement response under the stated paired assumptions. It does not rely on a piston producer or claim a preceding trajectory.

## Source verification

Source roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.

The old `Entity.move(MoverType,double,double,double)` resets its per-tick piston accumulator when world time changes, clamps and records the first nonzero-axis sum with the stored delta, then returns only if the accepted delta is at most `1.0E-5F`. For `(2.0E-5,0,0)` and accumulator zero, it stores `2.0E-5`; that value is greater than the component epsilon, so the call proceeds into collision resolution and the ordinary shape-position write. With no collision and no world-border clipping, the player position changes by that amount.

The new `Entity.move(MoverType,Vec3d)` calls `m_19881916` for non-noClip piston movement. That helper returns the input unchanged when squared length is at most `1.0E-7`, before reading the tick or touching the accumulator. For `(2.0E-5,0,0)`, squared length is `4.0E-10`; the returned nonzero vector is not `Vec3d.ZERO`, so the caller continues. Collision resolution returns the same vector for an empty collision snapshot, but the position writer only moves the shape when the resolved vector's squared length is greater than `1.0E-7`, so this first position write is skipped. Thus the old first-call position advances and accumulator records `2.0E-5`; the new first-call position does not advance and accumulator stays zero.

For the next same-tick `(0.51,0,0)` request, old accepted x is `0.50998` and new accepted x is `0.51`. Those calls' cumulative positions converge to `0.51` in the stated collision-free sequence. The revised candidate now explicitly says this and does not claim a net position difference after both calls.

The direct piston request is an eligible local-player response. The review assumes non-noClip movement, no pending cobweb movement multiplier, a collision-free region within the world border, and equal accumulator/tick/player state except for the effects of the first request. The candidate's empty-collision condition and direct-request setup support this witness; the source draft does not infer the request's producer. Intermediate patch boundary remains unknown.

## Hash-bound inputs

| Input | SHA-256 |
|---|---|
| Revised candidate `.native-source/20261031/1132-1144-finish46/candidates/piston-micro-request-bypasses-accumulator.draft.md` | `b77166ec38822a14d0665e5b93cf78d729dd625c53565bcc7732f1ddc71ffc74` |
| Paired terminal report `.native-source/20261031/1132-1144-finish46/piston-tiny-request-terminal/result.md` | `63d3db6365784ba2a8c065ca97bff37ba43b7a8197ae7a2a00f573d1974522a8` |
| 1.13.2 Feather `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 Feather `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 Feather `net/minecraft/util/math/Vec3d.java` | `6941a43536e8aefaa435a4e5f1731b0fa26a9d96503d1f4d07de8950c297f3c5` |
| 1.14.4 Feather `net/minecraft/util/math/Vec3d.java` | `b69b990b768e52d6fac6b3ed82f60e7526e78d0837c868a61a4171ebca21040b` |

All source hashes were recomputed from disk and match the paired report. No product implementation, wiki/backlog, product Git history, server producer, build, test, game launch, or source generation was used.
