# Core axis clipping pair: 1.13.2 → 1.14.4

## Verdict

**The per-axis shape clipping arithmetic is source-identical for an identical `VoxelShape`, input box, axis, and signed requested distance. The resolver axis order is different and can change the result under the same one-shape candidate list.** This closes only the bounded core-math comparison; candidate-list production, world-aware additions, border/entity context, stepping, and the complete movement pair remain separate dependencies.

The comparison uses the published `ornithe-feather` source roots. The complete files and SHA-256 values are listed below. The line numbers refer to those exact roots.

## Per-axis calculation and shape representation

Both `VoxelShapes.calculateMaxOffset` implementations iterate the supplied stream in order, return `0.0` once `abs(maxDist) < 1.0E-7`, and otherwise call each shape's `calculateMaxDistance(axis, box, maxDist` (`1.13.2 VoxelShapes.java:194-205`; `1.14.4 VoxelShapes.java:213-225`). The 1.14.4 method `m_10425781` is an additional world-aware query wrapper; it is not a changed version of the stream-only clipper (`VoxelShapes.java:227-291`). Its final supplied-stream pass calls the same shape distance method.

`VoxelShape.calculateMaxDistance` is identical in both versions at the algorithm level: empty-shape passthrough; `1.0E-7` near-zero gate; axis-cycle inversion; `getCoordIndex` bounds with `±1.0E-7` margins; positive and negative scan loops over the voxel occupancy; and the same `f >= -1.0E-7` / `g <= 1.0E-7` face tolerances before min/max clamping (`1.13.2 VoxelShape.java:184-245`; `1.14.4 VoxelShape.java:203-264`). `getCoordIndex` uses the same binary-search predicate in both (`1.13.2 VoxelShape.java:133-141`; `1.14.4 VoxelShape.java:138-146`). There is no shape-list union or normalization in either `calculateMaxOffset`; the bounded equality assumes identical voxel occupancy and coordinate grids for each supplied shape. If those representations differ, this comparison alone does not establish equivalence.

Consequently, a single axis step with the same candidate shape sequence, box, axis and request returns the same clipped distance, including strict overlap behavior induced by the coordinate-index margins and face tolerances. Repeating axis steps also agrees when the same component order and subsequent translated boxes are used.

## Resolver-order difference and same-list witness

1.13.2 resolves each nonzero component Y→X→Z (`Entity.java:578-598`). For multi-component motion, 1.14.4's `m_79801352` resolves Y first, then starts with Z when `abs(dx) < abs(dz)`, otherwise X, and resolves the other horizontal axis afterward (`Entity.java:708-738`). It moves the working box after each clipped component. The single-axis `m_73670363` instead calls world-aware `m_10425781` per axis (`Entity.java:746-770`).

Exact same-list fixture, independently checked against the paired resolver and clipper bodies: box `[0,0.6] × [0.25,2.05] × [0,0.6]`; supplied candidate list containing the single full cube `[1,2] × [0,1] × [1,2]`; vector `(0.5,0.01,0.6)`. The cube is separated by `0.4` in both horizontal axes initially.

| Resolver | Axis progression | Resolved vector |
|---|---|---|
| 1.13.2 | Y remains `0.01`; X sees no positive-volume Z overlap and remains `0.5`; after X translation, Z clips at `1−0.6=0.4`. | `(0.5, 0.01, 0.4)` |
| 1.14.4 | Y remains `0.01`; because `0.5 < 0.6`, Z first sees no positive-volume X overlap and remains `0.6`; after Z translation, X clips at `1−0.6=0.4`. | `(0.4, 0.01, 0.6)` |

Thus the arithmetic per axis is equal while order alone changes the vector. The existing independent collision-query audit also confirms this fixture and its ordinary-provider/state preconditions; this report does not reuse that audit as proof of my method-body comparison.

## Boundary of this result

- The proof is bounded to equivalent per-shape voxel occupancy/coordinate grids, identical candidate sequence, identical box and request at each axis, and the stream-only clip call. It does not prove equality of block/entity/border candidate producers or collision-context-dependent shapes.
- 1.14.4's `m_10425781` can scan world blocks before processing the supplied stream, and the resolver can append fresh block collisions in the diagonal path. Equality against the old list-only call therefore requires excluding or accounting for those extra queried shapes. The source makes no general identical-list claim for that world-aware wrapper.
- This comparison does not close step-up alternatives, movement-position update thresholds, context/lifecycle changes, or full-pair coverage.

## Exact source hashes

SHA-256 of complete files:

| Version | Source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `D95B0607647DA11595E24E1E26E9615CB7DA7705EA7885908544362DF62275C1` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8EFB68BF9D5EFDB0EC48E401D1852E90458C7094F8FA0C8E9AE418F268C40FDD` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java` | `313968D4E5855B5EC380272B6ABABCC5849D478AB771926355912A8CB6AA9C95` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java` | `51A09C297C7F01C8BAD9B66AF2A80900E95F33C6E3A250CE599F4817433587D9` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |

No build, test, game run, decompile, product/wiki/backlog read, or canonical/shared-root write was performed.
