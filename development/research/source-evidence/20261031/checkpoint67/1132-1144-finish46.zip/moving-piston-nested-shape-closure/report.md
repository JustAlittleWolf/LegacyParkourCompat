# Moving-piston nested collision-shape closure: 1.13.2 → 1.14.4

## Source identity and scope

Read-only exact endpoint trees: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Ornithe Feather Gen2 build 2. The source-manifest, ready-marker and provenance hashes were recomputed from the canonical endpoint directories; they match the prior paired source inventory (`../providers/inventory.md`, SHA-256 `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480`). Endpoint identity:

| Version | mapping/source manifest SHA-256 | ready marker SHA-256 | provenance SHA-256 |
|---|---|---|---|
| 1.13.2 | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` |
| 1.14.4 | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` |

This closes the moving-block dispatch and `MovingBlockEntity.getCollisionShape` wrapper formula under equal inputs. It does not close the nested shape of every possible `movedState`, every state/world/block-entity provider, or the full source pair. No trajectory or freeze claim is made.

## Collision route and caller

`MovingBlock.getCollisionShape` (1.13.2 `MovingBlock.java:108–118`; 1.14.4 `:104–114`) performs the same query: `world.getBlockEntity(pos)`, retain it only if it is a `MovingBlockEntity`, then delegate to `movingBlockEntity.getCollisionShape(world,pos)`. A missing entity or wrong entity type yields `VoxelShapes.empty()`. The newer method's added `CollisionContext` parameter is unused. Both `moving_piston` registrations opt into `dynamicShape()` (old `Block.java:951`; new `Blocks.java:333–334`), so the newer state cache does not replace this live block-entity lookup.

That query is reached from ordinary entity movement collision clipping. In 1.13.2 `Entity.move` calls `world.getCollisions(...)` before `VoxelShapes.calculateMaxOffset` clips the box on Y, X, and Z (`Entity.java:473,580–595`); `WorldView.getCollisions` reaches `getBlockCollisions`, whose candidate loop calls `BlockState.getCollisionShape(world,pos)` (`WorldView.java:154–177, 135`). In 1.14.4 `Entity.move` obtains block collisions while resolving movement (`Entity.java:444,693–746`, including `world.getBlockCollisions(entity,...)` at `:700`); `WorldView.getBlockCollisions` builds `CollisionContext.of(entity)` for a non-null entity and calls `blockState.getCollisionShape(world,pos,collisionContext)` (`WorldView.java:133–175`). The iterator expressly admits `Blocks.MOVING_BLOCK` in its special large-shape case (`:171`). The moving-piston provider ignores the supplied context and dispatches to its moving entity. Thus the entity context does not become an additional input to `MovingBlockEntity.getCollisionShape`.

Inside that method, each endpoint calls the nested moved-state collision query with the same `world,pos` through `BlockState.getCollisionShape(world,pos)`. In 1.13.2 this forwards directly to the block provider (`BlockState.java:209–210`). In 1.14.4 this no-context accessor returns the cached shape if present, otherwise calls the context overload with `CollisionContext.empty()` (`BlockState.java:197–203`). Dynamic moved-state providers therefore receive empty context through this wrapper; static cached shapes were also constructed with empty context. This is distinct from the outer player's entity context.

## Equal-input wrapper dependency and result

`MovingBlockEntity.getCollisionShape(BlockView world, BlockPos pos)` is source-identical in the two published files after an eight-line offset: old `MovingBlockEntity.java:324–352`, new `:332–360`. `getMoveDirection` (`:155–157` old, `:163–165` new) and the float `getAmountExtended` body (`:87–89` old, `:89–91` new) also match. The complete equal-input tuple needed for wrapper equality is:

- `movedState` including all raw properties;
- `world` and queried `pos`, including every nested provider's block-entity lookup/fallback at that same position;
- `facing`, `extending`, `source`, and the raw float `progress`;
- the current `NOCLIP_DIR` thread-local value.

For those matched values, both methods first seed `voxelShape` from `movedState` with `PistonBaseBlock.EXTENDED=true` only when `!extending && source`; otherwise the seed is empty. Both return that seed early only for `progress < 1.0` and `NOCLIP_DIR == getMoveDirection()`. Otherwise both choose a synthetic `PISTON_HEAD` state when `isSource()` (same facing and `SHORT = extending != 1.0F - progress < 4.0F`) or use `movedState`; compute the same float amount (`progress - 1.0F` when extending, else `1.0F - progress`); multiply it by the facing's three integer offsets as doubles; translate the selected nested collision shape; and union it with the seed, in that order. The float threshold expression, casts, comparisons, and branch boundaries are identical. Equality of the resulting dynamic wrapper is therefore compositional: the nested provider outputs must also match for the same raw state, world, position, and effective empty context.

Block-entity fallback is consequential. The outer lookup has the moving entity at `pos`. If the nested moved-state provider also asks for a block entity there, its lookup sees that same `MovingBlockEntity`, not a moved-block entity of another class; the nested provider's own type check and fallback then decide the output. As a concrete example, the paired shulker report confirms valid shulker-entity outputs for equal facing/progress inputs, but that result alone does not establish the nested moving-piston case: `ShulkerBoxBlock` falls back to a full block shape when the block entity at the queried position is not a `ShulkerBoxBlockEntity`. Both versions take that fallback when the position's entity is the outer moving piston entity. Matched fallback outputs are equal; shulker animation state is not a nested input in this case.

## Existing same-pair provider/state closures

The existing finish46 reports establish bounded nested provider/state domains, not all block states. The reports and their specific closures are:

| Existing report | Paired nested families / coverage |
|---|---|
| `provider-state-pairing/result.md` | Base `Block`, `CactusBlock`, `FenceGateBlock`, `MovingBlock`, `PaneBlock`, `SnowLayerBlock`, `SoulSandBlock`, `WallBlock`, and `MovingBlockEntity` explicit collision-provider bodies. It explicitly leaves the full `getShape` tables and all registered per-state outputs open. |
| `piston-shape-pairing/result.md` | Piston base: all 12 `EXTENDED × FACING` states; piston head: all 24 `FACING × SHORT × TYPE` states; plus matching dynamic wrapper formula. |
| `common-block-shape-pairing/result.md`; `remaining-collision-provider-tranche/result.md`; `non-oak-slab-trapdoor-shapes/result.md` | Oak stairs/slab/trapdoor, the other 16 common stair IDs (80 states each), and all common slab/trapdoor IDs (18 non-oak slabs and 6 non-oak trapdoors). These reported outputs match per raw tuple. |
| `door-gate-shape-pairing/result.md`; `wood-door-gate-shape-tranche/result.md` | Oak and the five other common wood doors and wood fence gates; state domains and output tables are paired. |
| `pane-snow-fence-shape-pairing/result.md`; `shape-provider-residual/result.md`; `wall-shape-pairing/result.md` | Glass pane, snow, oak fence; the other six common fences plus mossy wall; cobblestone wall. Paired raw provider rows match. |
| `container-shape-pairing/result.md`; `cauldron-storage-shapes/result.md` | Chest/trapped chest, ender chest, hopper, and all three anvil IDs match in their enumerated state domains. The cauldron is paired but differs (see witness below). |
| `bed-shape-pairing/result.md` | All 16 color bed IDs × 16 raw states (256 tuples) are paired; the new provider removes most of the lower 3/16 collision volume. |
| `shulker-collision-pairing/result.md`; `chorus-dynamic-shape-pairing/result.md` | Common shulker colors, facings, and matched raw block-entity animation inputs; chorus plant's 64 Boolean states and chorus flower's 6 ages. These are conditional provider closures with the block-entity/world-position caveat above for shulkers. |
| `special-block-shape-pairing/result.md` | End portal frame (8 states), cocoa (12), enchanting table (1), conduit (2), all paired. |
| `small-collider-shapes/result.md`; `terrain-small-shapes/result.md`; `plant-crop-shapes-pairing/result.md` | Lily pad, turtle egg, flower pot plus 22 common potted IDs, cactus; farmland, grass path, 16 carpets, cake, dragon egg, brewing stand; and the 66 common plant/crop/aquatic IDs with 257 raw tuples. Reports separately apply `hasCollision`; most in these groups are outline-only because their registrations disable collision. |
| `rail-redstone-shape-pairing/result.md`; `sign-skull-banner-shapes/result.md` | Paired common rail/redstone/attachment/torch formulas and the listed sign/banner/skull/daylight-detector domains. Repeater/comparator and skull/daylight shapes can enter movement collision; signs/banners and most other members are registered `noCollision()`. |

The bounded closures above show many common nested outputs, including two actual equal-input differences (beds and cauldron). They do **not** exhaust the provider inventory. The original `providers/shape-provider-overrides.tsv` enumerates 93 old and 115 new direct `getShape`/`getCollisionShape` declarations; states/providers not expressly closed by the reports above remain open. In particular, the census still identifies the 1.14.4-only `BambooBlock`, `BellBlock`, `ComposterBlock`, `GrindstoneBlock`, `LecternBlock`, and `ScaffoldingBlock` declarations, and no old-endpoint counterpart exists for those later blocks. The source inventory also leaves neighboring-state producers, live world/block-entity contents, and every not-listed registered state/provider combination open. No all-state or all-movable-block closure follows from this report.

## Concrete nested output witness: cauldron

The already paired `CauldronBlock` report establishes a same-state collision difference at all levels, including `LEVEL=0`: 1.13.2 removes only the upper interior cavity (`x,z=2..14, y=4..16`), leaving the full bottom 4/16 layer solid; 1.14.4 additionally subtracts the central lower interior through `y=3/16`. This creates a concrete difference in the moving-block composition itself. Fix identical inputs to `movedState=minecraft:cauldron[LEVEL=0]`, `facing=EAST`, `extending=true`, `source=false`, `progress=0.5F`, and `NOCLIP_DIR=null`, with the same world and moving-block position. The seed is empty; the early-return gate is false; the selected state is the cauldron; the float amount is `-0.5F`; both endpoints translate the nested shape by `(-0.5,0,0)` and union it with empty. At output-local point `(0,1/16,1/2)`, the old translated cauldron shape is solid (corresponding cauldron-local point `(1/2,1/16,1/2)`), while the new one is empty because the added bottom subtraction covers that point. The cauldron registration uses `Material.IRON` (old `Block.java:1216`, new `Blocks.java:756`); `Material.IRON` uses the builder default `PistonMoveBehavior.NORMAL` (old `Material.java:83,161`, new `:86,164`), and the piston scan accepts that behavior (old/new `PistonBaseBlock.java:215–216`). Thus this is a valid moved-state family. This is a shape-output witness only: it does not establish an entity's actual collision trajectory or tick result.

## No additional wrapper difference established

The public moving-block collision overloads and dynamic `MovingBlockEntity.getCollisionShape` formulas show no endpoint difference for equal complete inputs. A neighboring helper used by piston entity-push geometry, `MovingBlockEntity.getStateForShape` (old `:91–99`, new `:93–101`), does have a new guard requiring `movedState.getBlock() instanceof PistonBaseBlock` before synthesizing a piston head on source retraction. This is outside the collision-shape method audited here; this pass did not establish a valid concrete input with a different returned shape, so it is not counted as a finding.

## Source-file hashes

SHA-256 values were recomputed from the canonical Feather trees. Full provenance and source-manifest identities are listed above. See `source-hashes.tsv` for the exact files used: `MovingBlock.java`, `MovingBlockEntity.java`, `BlockState.java`, `WorldView.java`, `Entity.java`, registration/base `Block.java`, `Blocks.java`, `CauldronBlock.java`, `Material.java`, and `PistonBaseBlock.java`.

No canonical decompiled source was written or regenerated. No product code, wiki, backlog or Git data was read or changed; no build, test, game, TAS or server was run.

