# Independent review: moving-piston nested cauldron collision

## Verdict

**ACCEPT** the bounded claim in `candidates/moving-piston-cauldron-nested-collision.draft.md` for the exact matched collision-shape inputs stated there. The shape returned by the moving-block collision provider contains the specified point in 1.13.2 and excludes it in 1.14.4. This does not establish any player trajectory, clipped displacement, or movement-vector result.

## Bound evidence

- Candidate draft SHA-256: `0208F16284B4F04BF2EE0B8492AAD2FB2B7347B703E165CBB5CE21E30089C1E3` (recomputed).
- Canonical sources: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Feather Gen2 build 2.
- Source-manifest / ready-marker / provenance SHA-256 values, independently recomputed: 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` / `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` / `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383`; 1.14.4 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` / `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` / `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9`.
- Candidate support reports checked: `moving-piston-nested-shape-closure/report.md` SHA-256 `d6033b942ad5c22cbf9eef4c109ef7a0d9116e69add337714ed56c66917fd640`; `cauldron-storage-shapes/result.md` SHA-256 `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360`.

Relevant canonical source-file SHA-256 values (recomputed):

| File | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |
| `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/block/CauldronBlock.java` | `6948b2e208e1d7a52123fece400aa717b6fa5c35189fff1137490a96c170a3ac` | `686519b540dcb313c5226ebae2f77e902eb1d5b76997ba8fdf8cd37ab772179e` |
| `net/minecraft/block/material/Material.java` | `9bf4fc6893e07f15b7db2b03cba7cba7850370a2499870c621f422c356cf3b4f` | `b976f0011b0cf0f05831a799f40632f2824a4c09019f75d29ef7d88f33f72acf` |
| `net/minecraft/block/PistonBaseBlock.java` | `1722edaf96c15af587b4e169b62c5af1d352800e82a2070e1f4af86bdde4cb31` | `37409c9f2390642103155dcec3e922e0d387e9d0bbca069fb334277d5d84a058` |
| registration source (`Block.java` old; `Blocks.java` new) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

## Independent trace and geometry check

1. **Player collision route.** In 1.13.2, `Entity.move` (around lines 578–595) obtains swept collisions with `world.getCollisions(this, box, dx,dy,dz)` and clips each requested axis against those returned shapes. `WorldView.getBlockCollisions` dispatches each block state's collision shape (around lines 135–145). In 1.14.4, `Entity` movement obtains block collisions via `world.getBlockCollisions(entity, sweptBox)` (around lines 697–702) and clips with `VoxelShapes.calculateMaxOffset` (around lines 710–738); `WorldView` supplies `CollisionContext.of(entity)` and dispatches `blockState.getCollisionShape(world,pos,context)` (around lines 140, 169–175). These establish that the candidate is a collision-shape input to the ordinary entity clipping route, not a resulting movement claim.
2. **Outer moving-block dispatch.** Old `MovingBlock.getCollisionShape` at lines 108–111 and new at 104–107 look up the block entity at the same position, retain it only when it is `MovingBlockEntity`, and delegate to `getCollisionShape(world,pos)`; otherwise they return empty. The 1.14.4 overload does not use its `CollisionContext`. The moving-block registration is dynamic-shape in both endpoints (old `Block.java:951`, new `Blocks.java:333–334`), so the 1.14.4 cache does not bypass this live provider.
3. **Nested context and wrapper gates.** Old/new `MovingBlockEntity.getCollisionShape` bodies (old lines 324–352; new 332–360) use the same operation order and conditions. For the stated tuple, `extending=true, source=false` makes the seed empty; `NOCLIP_DIR=null` makes the early return false; `isSource()` returns the `source` field, so the selected state is the moved cauldron; `getAmountExtended(0.5F)` for extending is `-0.5F`; EAST has X offset `+1`, hence the moved shape translation is `(-0.5,0,0)`; both union it with the empty seed. The complete matched wrapper inputs relevant here are moved state, world and position, facing, extending, source, raw progress, and thread-local direction. `getMoveDirection()` is `facing` when extending in both versions. The nested call is `BlockState.getCollisionShape(world,pos)` without a context. The 1.14.4 accessor uses its static cache or empty-context overload; the cauldron provider ignores context and is not dynamic. Thus outer entity context cannot alter the nested cauldron geometry.
4. **Point witness.** Old cauldron `SHAPE` is the unit block minus `INSIDE_SHAPE = [2,4,2]–[14,16,14]` in sixteenths, leaving the entire bottom layer solid. New `SHAPE` subtracts that same cavity plus three boxes covering the centered lower footprint through Y=`3/16`. The output-local point `(0,1/16,1/2)` translated back by `( +1/2,0,0)` is cauldron-local `(1/2,1/16,1/2)` (sixteenths `(8,1,8)`). That point lies below the old cavity and so remains in old solid volume. It lies strictly inside each of the new lower subtraction boxes' relevant ranges, so the new `ONLY_FIRST` result excludes it. Translating by `(-1/2,0,0)` puts it at the stated output-local point. The union seed is empty for these inputs; therefore the returned shapes themselves differ at this point.
5. **Moved-state plausibility.** Both cauldron registrations use `Material.IRON`; its builder defaults piston behavior to `NORMAL`. The piston scan accepts NORMAL behavior, subject to ordinary border/height, hardness and block-entity constraints; the cauldron is not declared as a block entity. This supports the draft's movability statement without claiming any particular server-side producer/history.

## Limits

Acceptance is limited to the equal-input collision-shape output witness. I did not infer a piston state producer, a player trajectory, a clipped vector, or later movement/tick effects. No code, wiki, backlog, Git, build, test, game launch, or decompilation was used or changed.
