# Cauldron movement relevance: 1.13.2 → 1.14.4

## Scope and evidence

This follow-up traces only the paired cauldron shape and cauldron face-shape change reported in `cauldron-storage-shapes/result.md`, against `providers/inventory.md` and its frozen provider inventories. Exact primary sources are the same Feather Gen2 build 2 endpoint pair identified there. Source trees were read only. This is not a state-producer audit, trajectory proof, pair freeze, or implementation acceptance.

## Ordinary player collision: retained movement difference

In 1.13.2, `CauldronBlock.getShape` returns the unit block minus only `INSIDE_SHAPE`, whose bounds are `[2,4,2]–[14,16,14]` (`CauldronBlock.java:32–45`). Consequently the full horizontal footprint remains collision-solid from local y=0 through y=4/16.

In 1.14.4, the provider additionally subtracts the union of three boxes spanning local y=0–3/16 (`CauldronBlock.java:33–52`). That union contains the full central square `[2,14] × [2,14]` in X/Z, so a centered standard player footprint of width 0.6 blocks (`x,z=[0.2,0.8]`, or `[3.2,12.8]` in sixteenths) has no overlap with the cauldron collision shape from y=0 through y=3/16. The remaining y=3/16–4/16 bottom plate is still solid.

Concrete same-state movement query, with a cauldron at block position `(0,0,0)` and unchanged surrounding state:

- Player AABB: `x,z=[0.2,0.8]`, `y=[-2.0,-0.2]` (standing dimensions are 0.6×1.8 in both endpoints; 1.13.2 `PlayerEntity.java:448–451`, 1.14.4 `PlayerEntity.java:109–116`).
- Requested movement: `(dx,dy,dz)=(0,+0.5,0)` with normal non-sneaking `SELF` movement.
- 1.13.2 `Entity.move` gathers world collision shapes and clips Y via `VoxelShapes.calculateMaxOffset` (`Entity.java:578–584`); the cauldron’s bottom face at y=0 limits upward travel to `+0.2`.
- 1.14.4 `Entity.move` routes the vector through its collision solver (`Entity.java:463–467, 692–714`); `WorldView.getBlockCollisions` queries the entity-context collision shape (`WorldView.java:140, 169–175`). The cauldron provider ignores context. Since the centered player footprint lies wholly in the removed central square for y=0–3/16, its first cauldron contact is the remaining plate at y=3/16, limiting travel to `+0.3875`.

This is a source-level difference in a direct standard player `Entity.move` collision query. The requested displacement and world states are the comparison assumptions; no claim is made that a prior ordinary tick places a player in this exact below-block configuration. The provider difference therefore remains movement-relevant, independent of any trajectory proof. Step and pose-clearance behavior are not needed to establish this direct collision terminal.

## Fluid-face path: cauldron-specific dependency closed under vanilla defaults

1.13.2 `CauldronBlock.getFaceShape` returns `SOLID` for all horizontal directions (and `BOWL` up / `UNDEFINED` down; `CauldronBlock.java:233–240`). `FlowingFluid.isSolidFace` reaches that direct result after rejecting same-fluid neighbors, UP, ICE, leaves/other attachment exceptions, and stairs (`FlowingFluid.java:105–123`). Cauldron is not among the old explicit attachment exceptions (`Block.java:260–267`).

1.14.4 has no cauldron-local face-shape override. The replacement `Block.isFaceSolid` requires a full face of the block collision shape (`Block.java:402–408`), with a `BlockTags.LEAVES` exclusion. Each horizontal cauldron face is not full: the new low cross-subtractions remove a middle portion of each side face, and the inner-cavity subtraction leaves only narrow side rims above. Hence horizontal cauldron face-sturdiness is false regardless of whether the LEAVES guard is reached. The generated vanilla LEAVES recipe lists only the six leaf blocks (`data/tag/BlockTagsProvider.java:299–300`), not cauldrons.

The movement-facing caller is `FlowingFluid.getFlow`: for a falling state it checks each horizontal neighboring position and the position above it with `isSolidFace`; any accepted face changes the flow vector by normalizing and adding `(0,-6,0)` before final normalization (`FlowingFluid.java:54–98` on both endpoints). Player fluid movement samples tagged fluid states, calls `fluidState.getFlow`, and adds the resulting vector in `Entity.java:2527–2545` (1.13.2) and `2581–2599` (1.14.4). Therefore, under the equal-query assumption that a falling movement-consumed fluid state is adjacent to the same cauldron state on a horizontal side (or above that side probe), the cauldron face terminal changes true→false and can change the vector consumed by player fluid movement. This closes the cauldron-specific face-provider dependency; it does not prove the required fluid/block states are produced or that a resulting trajectory diverges.

The inventory's caveat about generated tag recipes still applies: decompiled Java does not establish active runtime tag resources or packets. The result for cauldron's new horizontal face is nevertheless false even if the LEAVES membership query were to differ, because its collision-shape face is not full.

## Disposition

Retain the cauldron provider delta as a direct movement-relevant collision difference, with the concrete `Entity.move` query above. Also retain the cauldron-specific old `getFaceShape` → new face-sturdiness difference as a movement-facing fluid-flow dependency under equal neighboring queries. No block/fluid state producer, standard tick trajectory, or intermediate patch boundary was examined.
