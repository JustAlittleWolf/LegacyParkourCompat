# Independent review — chorus-flower falling current

**Verdict: REJECT**

**Reviewed claim:** `.native-source/20261031/1132-1144-finish46/candidates/chorus-flower-falling-current.draft.md`

**Claim SHA-256:** `0476333B5FB70DD505B371B46A1593BDF920C9A116F70DBC9DCBF2AF52E85B96`

## Concrete blocking error

The fixture does not constrain the fluid states at `P+(0,1,0)` and `P+(0,2,0)`, but both cells are included in the stated player body scan. From the specified player position and dimensions, the contracted box is `[0.201,0.799] × [0.481,2.279] × [0.201,0.799]`. The `Entity.m_69693160` loops floor the minima and ceil the maxima, then use exclusive upper bounds, so they visit x=0, z=0, and y=0,1,2. Therefore they visit `P`, `P.up`, and `P.up(2)`. The draft's claim that only `P` is tagged water does not follow from its snapshot: its “four horizontal positions” and their upper/lower cells do not include these two vertical cells above `P`.

This omission can change the exact claimed current and velocity delta while retaining the stated inputs. For example, set `P.up` to the same tagged falling WATER state, `LEVEL=8`, in both versions, and set `P.up(2)` to air/empty. The specified horizontal blocks and all four horizontal-column upper/lower cells remain as stated. Both `Entity` scans then count two tagged-fluid contributors (`o=2`). The current query at `P.up` has zero flow because its horizontal neighbors are the specified empty-fluid air cells and its falling-face checks find only air; the query at `P` retains the asserted old zero/new downward unit flow. The entity scan does not normalize player flow, and it averages by contributor count. Thus the new accumulated flow is `(0,-0.5,0)` and the new velocity delta is `-0.007`, not `-0.014`. In 1.14.4, `FlowingFluid.getHeight(state, world, pos)` also returns `1.0F` when the fluid above is the same fluid (`FlowingFluid.java:442–449`), so the draft's single-cell surface/depth description is likewise not fixed by the stated snapshot.

To make the intended terminal claim reviewable, explicitly constrain both unassigned cells for the paired snapshot (and state that no other body-scan cell contains the selected tag), then recompute the height/depth and contributor count from that complete scan domain.

## Independently retraced source facts

The stated chorus-flower face difference itself is supported. The 1.13.2 `ChorusFlowerBlock` overrides `getFaceShape` to return `UNDEFINED`; its `AGE` property is `AGE_5`. The paired 1.14.4 flower has no face-shape override, is registered with default collision enabled, and inherits the base full-cube shape, so its sturdy faces are full under the default vanilla LEAVES recipe. Its `Material.PLANT` is non-motion-blocking in both endpoints, so the first gradient pass enters the lower-fluid query for the flower cell; the stated empty fluid below it leaves the gradient at zero. Both `FlowingFluid.getFlow` methods use horizontal directions in both passes, and their falling branch tests the horizontal neighbor and that neighbor's upper cell. The new flower face therefore contributes the stated downward normalized current at `P` under the stated horizontal/upper inputs.

The endpoint identity matches the assigned publication records: ready markers identify Feather Gen2 build 2 for 1.13.2 and 1.14.4; their source-manifest hashes match the recorded values in `fluid-face-unpaired-closure/result.md`. Recomputed full-file hashes for the paired `FlowingFluid.java`, `ChorusFlowerBlock.java`, `Block.java`, and `Entity.java` match the draft/evidence hashes.

## Scope

This verdict concerns the exact hashed claim and its static player-current/velocity conclusion. It makes no producer, trajectory, or active runtime tag claim. No source files were modified; no build, test, game launch, or decompilation was performed.
