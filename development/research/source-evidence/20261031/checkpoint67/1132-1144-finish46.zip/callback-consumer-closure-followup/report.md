# Local-player callback and response-consumer closure follow-up: 1.13.2 → 1.14.4

## Scope and source identity

This source-only follow-up closes the remaining ordinary local-client callback and direct-response/writer terminal inventory, while using the permitted pair reports to skip already-paired exact methods. It compares Minecraft 1.13.2 → 1.14.4 with Ornithe Feather Gen2 build 2 at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather/`. The ready records identify the exact versions, mappings, Vineflower, Java 25, and 2,711 / 3,250 source files. Source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; Feather build 2 provenance and artifact-manifest identities are recorded in the permitted neighboring reports. Every exact source hash below was recomputed from the read-only tree and matched its endpoint source manifest.

This is not a full-pair freeze or trajectory claim. It does not use product code/history, wiki, backlog, Git, server-side or device-input producers, or infer how a raw response/state was produced. No source was generated or edited.

## Remaining local-player callback terminals

### Four-corner block push response (`pushAwayFrom` / `wouldCollideAt`)

**Paired path and gate.** In the ordinary camera-controlled `LocalClientPlayerEntity.mobTick`, both endpoints make four calls at `(x ± width * 0.35, box.minY + 0.5, z ± width * 0.35)` before sprint/jump/travel staging (1.13.2 `LocalClientPlayerEntity.java:716–721`; 1.14.4 `:645–650`). In 1.13.2 the override itself returns immediately on `noClip`; in 1.14.4 the caller encloses the same four calls in `if (!noClip)` (`:643–651`). Therefore the no-clip gate moves but has the same no-write result. Both bodies choose the nearest west/east/north/south neighbor by comparing the point's fractional X/Z distances and write only the corresponding horizontal velocity component to `-0.1` or `+0.1`; the other velocity components are retained.

**Predicate difference / direct terminal.** Old `LocalClientPlayerEntity.wouldCollideAt(BlockPos)` tests only the supplied block: while swimming it returns `!shouldSuffocate(pos)`; otherwise it returns `!doesNotSuffocate(pos)` (`:453–455`). Old `PlayerEntity.shouldSuffocate` is `!state.isSolid()` and `doesNotSuffocate(pos)` is `shouldSuffocate(pos) && !state(pos.up()).isSolid()` (`PlayerEntity.java:1479–1485`). New `wouldCollideAt` ignores the swimming branch and scans every block Y from `floor(getShape().minY)` up to but excluding `ceil(getShape().maxY)`, returning true if any sampled state is view-blocking (`LocalClientPlayerEntity.java:435–448`; `PlayerEntity.shouldSuffocate`, `:1420–1422`). The paired low-level state predicates also change: old `Block.isSolid` uses solid-blocking material, cube state and non-signal-source; new `isViewBlocking` uses movement-blocking material and the full collision-shape face/shape test (`Block.java:265–276`; corresponding `BlockState` dispatch is old `:143–144` / new `:273–274`).

Thus the local velocity writer is source-confirmed to use a different block test and vertical sample domain. Under equal raw inputs whose queried center/neighbor columns produce different old `solid` versus new `view-blocking` results, the four calls can select a different horizontal impulse or no impulse. Ordinary collision-free placement will constrain such inputs; neither this report nor the reviewed sources establish a prior movement/packet history that reaches an output-different snapshot. Keep this as a **conditional direct local-player terminal gap**, not an accepted ordinary trajectory. The no-clip call-gate relocation itself is equivalent.

### Post-move auto-jump callback (`move` → `autoJump`)

Both local overrides snapshot X/Z, call the matching `Entity.move`, then call `autoJump((float)(newX-oldX), (float)(newZ-oldZ))` (`LocalClientPlayerEntity.java:871–876` old; `:846–851` new). The callback has the same enabled / cooldown / grounded / not-sneaking / not-riding gate, movement-input nonzero and normalized-direction checks, `-0.15F` facing threshold, `0.5F`–`1.2F` obstacle rise interval, jump-boost extension, and terminal `ticksToNextAutojump = 1` (`:882–980` old; `:857–955` new). That terminal schedules a forced local jump input on the next `mobTick`; it does not immediately write velocity.

The geometry/query dependency is not fully paired here: 1.13.2 calls `getCollisionShape(world,pos)` without a context and `world.getCollisions(this,box)`; 1.14.4 supplies `CollisionContext.of(this)` at the block-shape calls and uses `world.getCollisions(this,box,Collections.emptySet())`. The latter's block/entity candidate and context paths are already shown to differ in the permitted `collision-candidate-route-pairing/report.md`; provider/context membership and an auto-jump-specific output witness are not closed by this follow-up. Disposition: **remaining conditional callback/query dependency**, with no new independent finding or reachability claim.

## Already closed or explicitly excluded local-player methods

The following exact terminal families were skipped as already paired in the permitted reports; this follow-up does not reopen their claims:

- `tick`, `serverTickAi`, local input staging, `mobTick`, jump dispatch, and `LivingEntity.moveRelative` / `Entity.move` continuations: `ordinary-tick-staging-full-pair/result.md`, `travel-terminal-pairing/report.md`, and `callback-lifecycle-residual/result.md`. Existing climb, acceleration, cutoff, flags and fluid-state dependencies retain the limits stated there.
- `setSprinting`, movement attributes/effect application, item-use callbacks, `onDataValueChanged`, `doEvent` dispatch and local event overrides: `client-modifier-pairing/report.md`, `client-response-modifier-residual/result.md`, and `tracked-state-pairing/report.md`.
- Pose/dimensions, reset/login/respawn, copied sleeping state and first-tick response, sleep/wake positioning, and previous-position consumers: `synced-pose-response-pairing/result.md`, `local-player-reset-pairing/report.md`, `local-player-pose-lifecycle-closure/report.md`, `respawn-first-tick-followup/result.md`, `wake-partial-shape-provider-pairing/report.md`, and `prev-position-consumer-pairing/report.md`.
- Direct packet writers/consumers: `handlePlayerMove` correction, velocity/explosion, entity movement/teleport local-ID routing, abilities/game mode, attributes/effects/equipment/inventory, synced entity data and animation/sleep response are inventoried in `client-response-pairing/report.md`, `client-response-modifier-residual/result.md`, and `external-responses/report.md`. They establish incoming values as paired inputs; packet/server producers remain out of scope.
- Block callbacks feeding the player, including landing, bounce, contact and lava state: `block-callback-terminal-pairing/review.md`. Fluid and provider-state inputs remain with their assigned reports.

Other local subclass methods were screened for physical movement writes. `sendMovementToServer` updates outbound packet baselines and emits packets; it is not a local position/velocity consumer. `rideTick`, boat-input forwarding, riding start/stop and mount jump control are vehicle/input routes and excluded. `removeEffect(NAUSEA)` only clears portal timers; `getUnderwaterVisibility` is presentation-facing; underwater sound transitions do not add a distinct physical writer beyond the paired water-submersion/fluid state path. No other unpaired local subclass response was found in this bounded pass.

## Exact source files and hashes

| Version | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |

## Residuals

1. The four-corner push response has a paired source-level predicate/scan change and direct horizontal-velocity terminal; ordinary reachable state and downstream trajectory are not established.
2. Auto-jump retains its scalar gates/terminal scheduling, but context-sensitive shape and collision-candidate dependencies require the already assigned provider/collision closure before its response can be closed.
3. Server/state producers, malformed or embedded-position histories, input devices, vehicle physics and all broader shape/collision/fluid dependencies remain excluded or assigned elsewhere. This report does not freeze the pair or establish runtime parity.

