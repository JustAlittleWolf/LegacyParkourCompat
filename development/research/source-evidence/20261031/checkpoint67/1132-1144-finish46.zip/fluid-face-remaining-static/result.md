# Remaining common static fluid-face providers: 1.13.2 → 1.14.4

## Scope and source identity

Source-only pairing of the assigned common vanilla registrations at the exact 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 endpoints. The canonical read-only roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`; publication and ready-marker identities are recorded in `../providers/inventory.md`. Per-file hashes for every provider, registration, state-property and dispatch source used here are in `source-hashes.tsv`.

This completes the requested provider slice only. `state-face-results.tsv` contains 906 source-derived rows: every raw property assignment of each paired provider family crossed with all six directions. Where a family has multiple registration IDs using the same class/provider, each matrix state tuple applies independently to every listed ID below. This is not a player trajectory, producer history, full pair audit, or active runtime-tag claim.

## Predicate and dispatch closure

1.13.2 `FlowingFluid.isSolidFace` (`net/minecraft/fluid/FlowingFluid.java:105–123`) tests the neighboring fluid first and rejects a same-fluid neighbor; next it unconditionally accepts `UP`; next it rejects ICE; finally it rejects `Block.isExceptionForAttachment(block)` and stairs before testing the old direct `getFaceShape(...) == FaceShape.SOLID`. None of these assigned registrations is an old attachment-exception block or stairs. The only water-bearing assignments among this inventory are the `WATERLOGGED=true` chest, ender-chest and pane states; when the active fluid is WATER, both endpoints take the same early same-fluid false result for those assignments. For other fluid types they continue through the face tests. None of the registrations is ICE.

1.14.4 `FlowingFluid.isSolidFace` (`net/minecraft/fluid/FlowingFluid.java:106–115`) retains the same-fluid, `UP`, and ICE gates, then delegates to the state face-sturdy query (`BlockState.java:326–327`). For static states, `BlockState` caches face-sturdiness at construction (`BlockState.java:412–416`), using `Block.isFaceSolid` (`Block.java:402–410`): not in `BlockTags.LEAVES` and the collision shape covers the full directional face. The assigned default registrations are absent from the generated vanilla `LEAVES` recipe (`BlockTagsProvider.java:299–300`); only the six vanilla leaf blocks are present. Modded/runtime tag replacements remain outside this result.

The compared shape overloads do not read world, position, or `CollisionContext`. The assigned providers use the ordinary static shape route; the standing and wall banner registrations set `.noCollision()`, so their effective collision shape is empty. Static cache construction and entity-context collision queries therefore return the same directional face outcomes recorded here. The pane connection mask, chest type/facing boxes, anvil axis boxes, and previously paired terrain/utility provider outputs were cross-checked against the permitted shape reports in `cauldron-storage-shapes/result.md`, `pane-snow-fence-shape-pairing/result.md`, and `terrain-small-shapes/result.md`.

## Common registration families and exhaustive face results

All IDs below are present at both endpoints with the stated shared property domain. In the compact old-face column, values apply to every state in the family; the compact new column is the raw `BlockState.isFaceSturdy` result (not the whole fluid predicate). `UNDEFINED`, `BOWL`, and thin/center shapes are not `SOLID`.

| Family and common IDs | Raw state domain | 1.13.2 direct face result | 1.14.4 sturdy result |
|---|---|---|---|
| Anvil: `anvil`, `chipped_anvil`, `damaged_anvil` | `FACING=NORTH/EAST/SOUTH/WEST` (4 each) | All directions `UNDEFINED` (`AnvilBlock.java:50`). | False on all six faces; existing axis-selected shapes have no full directional face. |
| Standing banners: 16 `*_banner` IDs; wall banners: 16 `*_wall_banner` IDs | Standing `ROTATION=0..15`; wall `FACING=NORTH/EAST/SOUTH/WEST` | All directions `UNDEFINED`, inherited from `BannerBlock.java:48`. | False on all faces; registrations set `.noCollision()`. |
| Brewing stand: `brewing_stand` | 3 bottle booleans (8 states) | All directions `UNDEFINED` (`BrewingStandBlock.java:128`). | False on all faces; stand and stem union does not cover a full face. |
| Chest: `chest`, `trapped_chest` | `FACING` horizontal × `TYPE=SINGLE/LEFT/RIGHT` × `WATERLOGGED` (24 tuples each) | All directions `UNDEFINED` (`ChestBlock.java:318`). | False on all faces; the paired 14/16-inset single/double boxes do not fill a full face. |
| Ender chest: `ender_chest` | `FACING` horizontal × `WATERLOGGED` (8) | All directions `UNDEFINED` (`EnderChestBlock.java:140`). | False on all faces; paired 14/16-inset shape. |
| Dragon egg: `dragon_egg` | No properties (1) | All directions `UNDEFINED` (`DragonEggBlock.java:80`). | False on all faces; collision box is inset 1/16 at each horizontal edge. |
| End rod: `end_rod` | `FACING` all six directions (6) | All directions `UNDEFINED` (`EndRodBlock.java:99`). | False on all faces; cross-section is 4/16 wide. |
| End portal frame: `end_portal_frame` | horizontal `FACING` × `EYE` boolean (8) | `DOWN=SOLID`; other faces `UNDEFINED` (`EndPortalFrameBlock.java:117`). | `DOWN=true`; all other faces false for both eye values. The source boxes are full-footprint base only to height 13/16 plus a centered 8/16 eye up to height 1 (`EndPortalFrameBlock.java:25–27`); the base is short of the block-top face, while the eye reaches the top only over its centered 8/16 footprint. |
| Flower pots: `flower_pot`, `potted_oak_sapling`, `potted_spruce_sapling`, `potted_birch_sapling`, `potted_jungle_sapling`, `potted_acacia_sapling`, `potted_dark_oak_sapling`, `potted_fern`, `potted_dandelion`, `potted_poppy`, `potted_blue_orchid`, `potted_allium`, `potted_azure_bluet`, four `potted_*_tulip` IDs, `potted_oxeye_daisy`, `potted_red_mushroom`, `potted_brown_mushroom`, `potted_dead_bush`, `potted_cactus` | No properties (1 each) | All directions `UNDEFINED` (`FlowerPotBlock.java:110`). | False on all faces; its collision box is only a centered 6/16 × 6/16 footprint and 6/16 high. |
| Hopper: `hopper` | `FACING={DOWN,NORTH,SOUTH,WEST,EAST}` × `ENABLED` boolean (10) | `UP=BOWL`; other faces `UNDEFINED` (`HopperBlock.java:205`). | False on all faces; bowl, spout and base leave every directional face incomplete. |
| Iron bars and panes: `iron_bars`, `glass_pane`, and 16 `*_stained_glass_pane` IDs | Four connection booleans × `WATERLOGGED` (32 tuples each) | Horizontal faces `MIDDLE_POLE_THIN`; `UP/DOWN=CENTER_SMALL` (`IronBarsBlock.java:116`). | False on all faces; central posts and optional arms leave the unit face incomplete. |
| Cake: `cake` | `BITES=0..6` (7) | All directions `UNDEFINED` (`CakeBlock.java:110`). | False on all faces; every bite-indexed shape is inset and at most half-height. |
| Carpets: 16 `*_carpet` IDs | No properties (1 each) | `DOWN=SOLID`; other faces `UNDEFINED` (`CarpetBlock.java:46`). | `DOWN=true`; `UP` and horizontal faces false. The collision box is full footprint and only 1/16 high, so it does not reach the block-top face. |
| Farmland: `farmland` | `MOISTURE=0..7` (8) | `DOWN=SOLID`; other faces `UNDEFINED` (`FarmlandBlock.java:127`). | `DOWN=true`; `UP` and horizontal faces false. The full-footprint collision box ends 1/16 below the block-top face. |
| Grass path: `grass_path` | No properties (1) | `DOWN=SOLID`; other faces `UNDEFINED` (`GrassPathBlock.java:71`). | `DOWN=true`; `UP` and horizontal faces false. Same full-footprint 15/16-height face result as farmland. |
| Turtle egg: `turtle_egg` | `HATCH=0..2` × `EGGS=1..4` (12) | All directions `UNDEFINED` (`TurtleEggBlock.java:158`). | False on all faces; the one/multiple egg boxes are inset and shorter than the block. |

The old *complete* fluid predicate for these families is `false` on every same-fluid cell; otherwise `true` for `UP`; for non-ICE and non-exception cells on every other direction it is true exactly where the old direct face is `SOLID` (the explicit DOWN cases in the table). The new complete fluid predicate has the same first two gates, then equals the sturdy column. Therefore every complete `FlowingFluid.isSolidFace` result in this assigned matrix agrees across the endpoints under default vanilla tags and the paired fluid gates. The raw direct-face/sturdy values agree on each non-UP direction; the direct UP values are bypassed by the unchanged unconditional UP branch, including Hopper `BOWL`. Waterlogged same-fluid false results are included explicitly per row in the TSV.

`grass_path` is a common ID at both endpoints. The empty pot and 21 potted registrations listed by 1.13.2 have common IDs; 1.14.4-only `potted_cornflower`, `potted_lily_of_the_valley`, `potted_wither_rose`, and `potted_bamboo` are explicitly disposed because no 1.13.2 ID exists. No requested family lacks a common registration. Old `GlassPaneBlock` and stained-pane subclasses inherit the `IronBarsBlock` provider; 1.14.4 registers `glass_pane` directly as `IronBarsBlock` and stained panes as `StainedGlassPaneBlock`, which inherits it. These aliases keep the same effective face provider and state domain.

## Output files and limits

- `state-face-results.tsv`: exhaustive 906-row raw-state/direction matrix, including old direct result, old and new complete fluid predicate, new sturdy result, and default LEAVES disposition.
- `source-hashes.tsv`: recomputed whole-file SHA-256 for endpoint registrations, provider classes, shared state properties, shape-face implementation, fluid helper, BlockState dispatch, and tag recipe.

This report establishes source-level face/provider results for the requested common vanilla registrations only. It does not establish state reachability or player trajectory, loaded runtime tag contents, modded registrations, or an intermediate release boundary. No product/wiki/backlog/Git data was read or changed; canonical sources remained read-only; no decompile, build, test, game launch, or producer audit was run.




