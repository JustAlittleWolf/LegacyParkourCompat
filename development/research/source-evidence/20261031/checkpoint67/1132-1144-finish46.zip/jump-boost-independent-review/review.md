# Independent review: jump-boost Y rounding

## Verdict

**Accept, with one wording refinement.** The candidate identifies a real, conditional difference in the Y velocity written by a direct `PlayerEntity.jump()` call when JUMP_BOOST is active. The numeric example and the stated delta are correct for the paired inputs `getJumpStrength() == 0.42F` and amplifier `0`. This establishes a direct velocity-write difference only; it does not establish an ordinary trajectory or downstream displacement.

Refine “the base result is the local-player terminal” to “the base `LivingEntity.jump()` result is the final Y component for this player call.” `PlayerEntity.jump()` does continue after `super.jump()` to update jump statistics and exhaustion. Those statements do not alter the Y component in these source methods.

## Independent source checks

- In 1.13.2, `LivingEntity.getJumpStrength()` returns `0.42F`. `velocityY` is a `double`; `jump()` first assigns the float result to it, then evaluates `(amplifier + 1) * 0.1F` as a float expression and adds that float to the double field. Java binary numeric promotion makes the addition double precision after the float multiplication has rounded.
- In 1.14.4, `jump()` evaluates `getJumpStrength() + 0.1F * (amplifier + 1)` into local `float f`. Both multiplication and addition are float operations; the resulting binary32 `f` is promoted when passed to `m_32166403(double,double,double)`.
- For amplifier `0`, binary32 operands are `0.41999998688697815` and `0.10000000149011612`. Old Y is `0.5199999883770943`; new Y is `0.5199999809265137`; new minus old is `-7.450580596923828E-9`.
- The old write directly replaces `velocityY`. The new jump reads the current vector and calls `m_32166403(vec3d.x, f, vec3d.z)`. In `Entity`, that setter constructs `new Vec3d(d, e, f)` and stores it; it preserves current X/Z and writes `f` as Y. The subsequent sprint branch adds `0.0` to Y while adjusting horizontal components. The player override then updates statistics/exhaustion and does not rewrite velocity.
- Both LivingEntity jump gates have the same predicates: the `jumping` flag, fall-distance/on-ground conditions, lava handling, and zero cooldown at the direct jump call. Both local-client implementations copy `input.jumping` into the living flag in `serverTickAi()` when `isCamera()` is true; `mobTick()` calls the locally controlled AI before evaluating the gate. The candidate correctly treats gate state and effect state/amplifier as paired inputs and does not claim their history or production.
- LocalClientPlayerEntity extends ClientPlayerEntity, which extends PlayerEntity, in both trees. PlayerEntity's `jump()` override calls `super.jump()` first. Neither the PlayerEntity chain nor the rest of either `net/minecraft/entity` tree overrides `getJumpStrength()` for players, so the base `0.42F` applies here (the separate RabbitEntity override is not in that chain).
- With no JUMP_BOOST, both implementations write/promote the same `0.42F` Y value. The candidate scopes the delta to the active-effect branch.

## Bound identities

Candidate draft SHA-256: `a3ca165c35a8081be6623096f41948d14c714562f620461305c4bfc42df4ff12`.

Canonical roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.

All relevant source-file hashes below were recomputed from the canonical trees and match each endpoint's `ornithe-feather.sources.sha256` manifest. Manifest SHA-256 values are included to bind the manifest snapshots used for that check.

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |

| Source manifest | SHA-256 |
|---|---|
| 1.13.2 `ornithe-feather.sources.sha256` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |
| 1.14.4 `ornithe-feather.sources.sha256` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` |

## Scope

This review covers the bounded candidate and the paired direct-call source path. It makes no claim about how the gate, effect, amplifier, incoming velocity, or relevant world state arose, nor about movement after this velocity write.
