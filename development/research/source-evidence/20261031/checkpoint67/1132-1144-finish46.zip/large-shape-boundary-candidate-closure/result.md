# Large-shape boundary candidate closure: 1.13.2 → 1.14.4

## Verdict and bounded scope

**Existential result: yes.** Under equal supplied block-query geometry and explicit raw provider inputs below, the newer enumerator admits a common `MOVING_BLOCK` collision candidate that the older enumerator omits at a two-face boundary. The finite nested provider is a common `oak_fence` state whose east collision arm is translated east by the moving-block entity; the resulting shape extends beyond its moving-block cell in both X and Y and positively overlaps the query.

The same conditional witness also reaches the newer one-face `hasLargeCollisionShape` branch: make the query's X minimum exactly integral while keeping its Y minimum nonintegral. The old enumerated cell remains a two-face edge and is skipped; the same cell becomes a one-face boundary in the expanded new range. Since `MOVING_BLOCK` is dynamically shaped and its new state cache is null, `hasLargeCollisionShape()` returns true and the cell proceeds to collision-shape evaluation.

This closes the existential candidate question for these common vanilla registrations and raw inputs. It does **not** assert that vanilla piston state production creates this exact nested raw state or query trajectory, that this candidate changes the final clipped player position, or that every unpaired shape/provider in the source inventory has been paired.

## Frozen roster and coverage

The provider/member roster was frozen before reading endpoint provider and registration bodies in [`roster.md`](roster.md). It is derived from the paired source-only declaration inventory `providers/shape-provider-overrides.tsv` (93 old rows, 115 new rows; hash below): 85 old and 98 new provider classes, retaining new-only, collision-disabled, and inherited-path declarations rather than filtering by expected shape. The assignment-relevant common IDs and members are:

| Path | Frozen member/provider subset | Coverage used here |
|---|---|---|
| Static common moved state | `oak_fence` → `FenceBlock` / inherited `PaneBlock.getCollisionShape` | All 32 raw state tuples were previously paired, including the `EAST=true` mask; old/new collision table geometry is equal. |
| Dynamic outer state | `moving_piston` → `MovingBlock.getCollisionShape` → `MovingBlockEntity.getCollisionShape` | Common registration and wrapper are source-paired; dynamic cache-null dispatch and equal nested translation formula were verified below. The selected finite moved-state output is the paired `oak_fence` provider. |
| Full direct shape/collision inventory | Every row in the frozen roster | The existing provider inventory contains 93/115 declarations. The registration reconciliation lists 333 common override IDs: 310 have a named prior provider/state report, while 23 remain unpaired. Those residual IDs are not individually re-audited here. The residual IDs are `black_stained_glass_pane`, `blue_stained_glass_pane`, `brown_stained_glass_pane`, `bubble_column`, `cave_air`, `cyan_stained_glass_pane`, `end_portal`, `gray_stained_glass_pane`, `green_stained_glass_pane`, `lava`, `light_blue_stained_glass_pane`, `light_gray_stained_glass_pane`, `lime_stained_glass_pane`, `magenta_stained_glass_pane`, `nether_portal`, `orange_stained_glass_pane`, `pink_stained_glass_pane`, `purple_stained_glass_pane`, `red_stained_glass_pane`, `structure_void`, `water`, `white_stained_glass_pane`, and `yellow_stained_glass_pane`. The positive witness does not depend on their disposition. |

The exact common oak-fence registration and the full 32-state output table are recorded in `pane-snow-fence-shape-pairing/result.md`; that report gives `oak_fence` at 1.13.2 `Block.java:1075` and 1.14.4 `Blocks.java:574`. It records identical 16-mask outline/collision tables at both endpoints. For mask 8 (`EAST=true`, other directions false), the east collision arm is `[6/16,0,6/16]–[16/16,24/16,10/16]`. This is the parent `PaneBlock` collision array selected by `FenceBlock`; height is 24/16 and east extent is exactly 16/16. `states.tsv` and the paired report cover both waterlogged values. The fence state definition has the same connection booleans at both sides.

## Exact boundary membership

The exact scan bodies are old `WorldView.getBlockCollisions` (`WorldView.java:112–151`) and new `WorldView.getBlockCollisions` (`WorldView.java:133–181`), with boundary count in `C_29205863.m_87302669` (`C_29205863.java:53–67`). The prior block-query closure records old inclusive coordinates `[floor(min)-1, ceil(max)]` and new inclusive coordinates `[floor(min−1e−7)-1, floor(max+1e−7)+1]`. Old skips a cell that is a boundary coordinate on two or more axes. New counts cursor boundary coordinates as `lx`, skips only `lx==3`, admits `lx==1` iff `hasLargeCollisionShape()`, and admits `lx==2` iff the state block is `Blocks.MOVING_BLOCK` (`WorldView.java` and `C_29205863.java` references/hashes below).

Assumptions shared by both conditional examples: query is the given block-query box; the candidate chunk is present/loaded; it is interior to the world border; the cell at `(-1,-1,0)` is the common `moving_piston` state with a `MovingBlockEntity`; there are no additional provider substitutions; and the old `excludeBlock` input does not overlap the local moving collision shape. The same query box and same raw state/BE/provider inputs are compared at both endpoints. This isolates candidate enumeration and provider output; it is not a full movement-call or producer proof.

### Two-face `MOVING_BLOCK` filter witness

Use query box `Q₂ = [0.2,0.7] × [0.2,1.8] × [0.4,0.6]`.

- Both enumerators have lower cell bounds `(-1,-1,-1)` and upper bounds `(1,2,1)` for this box. Candidate `p=(-1,-1,0)` is a two-face boundary cell: X-min and Y-min, but not Z boundary. The old source skips it under its two-face prune.
- New cursor classification gives `lx=2` at `p`; the state is `Blocks.MOVING_BLOCK`, so the explicit two-face gate admits it.
- The finite nested provider input is `movedState = oak_fence(EAST=true, NORTH/SOUTH/WEST=false, WATERLOGGED=false)`, `facing=EAST`, `extending=false`, `source=false`, `progress=0.5F`, with `NOCLIP_DIR=null`. `getAmountExtended` (old `MovingBlockEntity.java:87–88`; new `:89–90`) gives `1.0F−0.5F = 0.5F`. The nonmatching no-clip gate falls through to the translated moved-state shape. The `FenceBlock` constructor calls `super(2,2,16,16,24)` (old `FenceBlock.java:25–29`; new `:27–31`), and `PaneBlock.makeShapes`/`getCollisionShape` (old `PaneBlock.java:38–84`; new `:40–91`) produce the paired east-arm box. The east arm at `p` therefore has bounds X `[-0.125,0.5]`, Y `[-1,0.5]`, Z `[0.375,0.625]`.
- Its positive intersection with `Q₂` has lengths `0.3 × 0.3 × 0.2`; it passes the new `VoxelShapes.overlap(..., AND)` rejection test. Thus a block collision candidate is emitted by the new two-face route and omitted by the old enumerator for these paired geometric inputs.

### One-face `hasLargeCollisionShape` filter witness

Use query box `Q₁ = [0.0,0.7] × [0.2,1.8] × [0.4,0.6]` with the same cell and raw provider inputs.

- Old lower bounds on X and Y are both `-1`, so `p=(-1,-1,0)` is again a two-face boundary cell and is skipped.
- New X lower bound is `floor(0−1e−7)−1 = -2`, while Y lower bound stays `floor(0.2−1e−7)−1 = -1`. The candidate is now interior on X and boundary only on Y (`lx=1`).
- New `Blocks.MOVING_BLOCK` registration (`Blocks.java:333–334`) opts into `.dynamicShape()`. `BlockState.cacheShape()` (`BlockState.java:65–68`) leaves its cache null for such a state; `hasLargeCollisionShape()` (`BlockState.java:97–99`) is exactly `cache == null || cache.largeCollisionShape`, therefore returns true on this dynamic state. The one-face filter admits it.
- The same nested east-fence shape intersects `Q₁` with positive lengths `0.5 × 0.3 × 0.2`, so the overlap check admits it.

This second case demonstrates the cache-null route directly. It does not interpret `cache==null` as a geometric proof; the provider output and positive overlap are checked separately.

## Nested-provider and scope checks

At both endpoints `MovingBlock.getCollisionShape` (old `MovingBlock.java:108–111`; new `:104–107`) looks up a `MovingBlockEntity`, delegates to `getCollisionShape(world,pos)`, and otherwise returns empty. The collision-context argument added in 1.14.4 is not read. The two `MovingBlockEntity.getCollisionShape` bodies (old `:324–352`; new `:332–360`) are operation-for-operation equal for the matched raw inputs: empty initial union for `extending=false, source=false`; `progress < 1 && NOCLIP_DIR == getMoveDirection()` gate; moved-state choice when `source=false`; amount formula; translation by facing offsets; union. The nested `oak_fence` provider ignores world, position, and collision context and selects the same east-mask table. The reports cited below also identify recursive self-nesting when `movedState` itself is `MOVING_BLOCK`; this witness uses a finite fence terminal and does not close producer reachability or arbitrary recursive moved states.

The new one-face filter's static cached branch computes largeness from `collisionShape.min(axis) < 0 || collisionShape.max(axis) > 1` across axes, but a dynamically shaped state takes the cache-null short circuit. The witness relies on that exact short circuit, not on the static-shape formula. Other dynamic common provider states and the remaining 23 census IDs are outside this narrow existential witness. Entity candidates, border outputs, chunk-state producers, piston reachability, and final clipper ordering remain assumptions/open gates as stated above.

## Exact source identities and hashes

Source family: Ornithe Feather Gen2 build 2. Source-manifest identities recorded by the permitted paired reports are 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and 1.14.4 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

SHA-256 hashes below were recomputed from the read-only endpoint files in `decompiled_minecraft/{version}/ornithe-feather/`.

| Endpoint | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.14.4 | `net/minecraft/unmapped/C_29205863.java` | `d15373ef21f58ed67755269d32b2dd5ff65eb33dd4eea33e854b505b9ac9afdb` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.13.2 | `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` |
| 1.14.4 | `net/minecraft/block/MovingBlock.java` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |
| 1.13.2 | `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` |
| 1.14.4 | `net/minecraft/block/entity/MovingBlockEntity.java` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |
| 1.13.2 | `net/minecraft/block/FenceBlock.java` | `abefbedea10306abf602d4e379a4793b415ca7635231752cd9f18a80aced5fc2` |
| 1.14.4 | `net/minecraft/block/FenceBlock.java` | `4319ffb95ad81e969b11b39a8e6361d678b5fb5f3ad210d9834ce5e30d5f45d8` |
| 1.13.2 | `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` |
| 1.14.4 | `net/minecraft/block/PaneBlock.java` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |

Relevant frozen/report inputs: `providers/shape-provider-overrides.tsv` SHA-256 `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad`; `pane-snow-fence-shape-pairing/result.md` SHA-256 `31f7e2e5fa169557469327d68f14e6d3732e8ca3d5c86c69eaebd29e44fc0b46`; `shape-provider-residual/states.tsv` SHA-256 `0fe3f19ad3a14b578ca7131c06fa1c70793e798ba1eddc051cd99f3ee96a3b7c`; and `moving-piston-nested-terminal-closure/report.md` SHA-256 `d6033b942ad5c22cbf9eef4c109ef7a0d9116e69add337714ed56c66917fd640`.

No producer/trajectory proof, final player displacement result, product/wiki/backlog/Git review, build, test, game launch, or source-tree write was performed. This report and the frozen roster are the only files written, inside the assigned lane directory.




## Follow-up: bounded exact clip terminals

This continuation checks the candidate-level witness through `Entity.move` and the axis clipper using exact endpoint formulas. It uses the same already-paired `moving_piston`/BE/`oak_fence(EAST=true)` provider input and assumes all other block, entity, and world-border candidates are absent or nonblocking. It does not assert a producer or ordinary player trajectory.

### Original `Q₂` fixture: candidate-list difference, no clip delta

Set player box `B=[0.2,0.4] × [0.2,1.8] × [0.4,0.5]`, vector `(0.3,0,0.1)`, `MoverType.SELF`, `noClip=false`, `onGround=false`, `inCobweb=false`, and zero piston movement deltas. Positive `Box.expanded(dx,dy,dz)` extends only the max X/Z bounds, so the new swept box is exactly `Q₂=[0.2,0.7] × [0.2,1.8] × [0.4,0.6]`. The old movement path forms the expanded box with its `1e-7` margin, subtracts the original box shifted by the sign-dependent epsilon, and separately passes the original box as `excludeBlock` (`WorldView.java:154–163`). The carved query still has the same integer scan bounds as `Q₂`.

- **Old candidates:** at `p=(-1,-1,0)`, X-min and Y-min are both boundary coordinates, so old `WorldView.getBlockCollisions` prunes the cell before state/provider evaluation. There is no block candidate from this cell. If the cell reached the old exclusion test, the original `B` moved into local cell coordinates would be `[1.2,1.4] × [1.2,2.8] × [0.4,0.5]`, which positively overlaps the local moved fence arm `[0.875,1.5] × [0,1.5] × [0.375,0.625]`; the old per-cell exclusion would suppress it as well. With other candidates assumed nonblocking, the old clipper list is empty.
- **New candidates:** the new two-face `MOVING_BLOCK` gate admits the cell, its translated shape `S` overlaps `Q₂`, and the block candidate list passed to the new resolver contains `S` (entity/border candidates assumed nonblocking). `S` has bounds `[-0.125,0.5] × [-1,0.5] × [0.375,0.625]`.
- **Exact new clip:** `Entity.m_79801352` sees `|dx|=0.3 > |dz|=0.1`, so it clips X before Z (`Entity.java:708–739`). The nested East-arm shape optimizes to the single cuboid just listed: its Y maximum 1.5 takes `VoxelShapes.block(...)`'s array fallback, and the East arm contains the post (`VoxelShapes.java:49–76,89–103`; `VoxelShape.optimize`). Thus its voxel grid has one X cell spanning `[-0.125,0.5]`. For positive X, the box's `maxX=0.4` is inside that cell: `getCoordIndex(X,0.4−1e−7)=0`, but `calculateMaxDistance` scans from `j+1=1` only while `< voxels.size(X)=1`; there is no later X cell, so X remains `0.3` (`VoxelShape.java:138–146,207–258`). The box then moves to X `[0.5,0.7]`. Its X interval has no positive overlap with `S` (whose `maxX=0.5`), leaving an empty cross-axis range for the subsequent Z clip; Z remains `0.1`. Y is zero. The new clip result is therefore `(0.3,0,0.1)`, the same as the old result with its empty blocking-candidate list.

**Correction to the candidate-level implication:** the new stream includes a positively overlapping block shape, but this particular player box starts inside that shape and the chosen X-first order lets it move out past the shape's X maximum before Z is clipped. The candidate-list difference does not produce a clipped-position difference for this terminal.

The step gates are false in both endpoints: old `bl = onGround || o != y && o < 0` is false for `onGround=false`, `o=y=0`; new `bl4 = onGround || bl2 && vec3d.y < 0` is likewise false, and neither X nor Z clips to make `(bl || bl3)` true (`Entity.java:601–602` old; `:664–670` new). No step alternative runs. `MoverType.SELF` bypasses both endpoints' piston movement adjustment; `inCobweb=false` bypasses the old web multiplier; `onGround=false` bypasses the sneaking-edge movement reducer. The resolved vector has squared length `0.1`, above the new `1e-7` position-write gate, so both endpoints apply the same `(+0.3,0,+0.1)` translation under these assumptions.

### Shifted-left fixture: the candidate is shared and both endpoints clip equally

As a separate control, keep the same nested collision provider and query Y/Z, set player box `B_L=[-0.6,-0.4] × [0.2,1.8] × [0.4,0.5]`, and request `(0.5,0,0.1)` with the same mover/gate assumptions. The swept X interval is `[-0.6,0.1]`; its old and new scan bounds are both `[-2,1]`. At the same `p=(-1,-1,0)`, only Y is now a boundary coordinate, so the old multi-face prune does not apply. New classification has `lx=1`; the dynamic cache-null `MOVING_BLOCK` state passes `hasLargeCollisionShape()`. Both candidate lists therefore contain `S`. The old original-box exclusion does not remove it: `B_L` translated into local cell coordinates has X `[0.4,0.6]`, disjoint from the local arm X `[0.875,1.5]`; the old carved swept query still overlaps the world-translated arm in X `[-0.125,0.1]`.

For both clippers, `B_L.maxX=-0.4` is left of `S.minX=-0.125`, while Y/Z cross intervals overlap. In the single X voxel, the positive-axis clip formula finds `f = S.minX − B_L.maxX = -0.125 − (-0.4) = 0.275`, so `dx` clips from `0.5` to `0.275`. The moved box ends at X `[-0.325,-0.125]`; it only touches `S` at its X minimum, so the subsequent Z clip has no positive X cross-axis interval and leaves `0.1`. Both endpoints resolve `(0.275,0,0.1)`. This shifted fixture supplies a real conditional collision clip, but no endpoint delta because old enumeration already admits the same cell.

The two checked fixtures therefore establish a candidate-stream delta for `Q₂`, but no final clip delta; shifting the box left enough to start outside the same shape restores an equal old/new candidate and equal clip. Provider production, reachability of the raw moving-block entity state, any other candidate stream, and trajectory remain open assumptions.

### Additional exact source hashes (SHA-256)

| Endpoint | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| 1.13.2 | `net/minecraft/util/math/Box.java` | `0f573d00cc10386f94cf51671c62815979973053c9e67a806e9fee98e55a4d8d` |
| 1.14.4 | `net/minecraft/util/math/Box.java` | `b68667118ba729fc18fefa3b9de9060184f9d71f53a4bf10a8b7215863ff8b6e` |
