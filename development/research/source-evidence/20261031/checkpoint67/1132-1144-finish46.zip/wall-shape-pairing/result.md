# `minecraft:cobblestone_wall` shape pairing

## Scope and verdict

Source-only pairing of the registered `minecraft:cobblestone_wall` (`WallBlock`) collision and outline shape outputs at 1.13.2 → 1.14.4, Ornithe Feather Gen2 build 2. Each endpoint defines six Boolean properties and therefore 64 raw states; `states.tsv` enumerates every assignment at each endpoint using an identical property-to-mask mapping. No collision or outline shape output difference was found for these 64 states. This is a provider-output result for the default vanilla registration, not a state-production history, trajectory, or full-pair-freeze claim.

Exact read-only sources are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`; their publication identities and verified manifest hashes are in `../providers/inventory.md`. The registered ID exists at both sides: 1.13.2 `Block.java:1240` registers `cobblestone_wall` as `new WallBlock(Block.Properties.copy(block3))`, with `block3` registered as cobblestone at `Block.java:790-791`; 1.14.4 `Blocks.java:796` registers `cobblestone_wall` as `new WallBlock(Block.Properties.copy(COBBLESTONE))`, with `COBBLESTONE` registered at line 45. The mossy wall is a separate ID and is not included in this assigned ID.

## State inputs and enumeration

Both `WallBlock.buildStateDefinition` methods add `UP, NORTH, EAST, WEST, SOUTH, WATERLOGGED` (old `WallBlock.java:111-114`; new `WallBlock.java:108-111`). These all refer to `BooleanProperty` values whose domain is `{false,true}`. The 1.13.2 and 1.14.4 property declarations have the same names and aliases: `WallBlock.UP` to `Properties.UP`; inherited `PaneBlock.NORTH/EAST/SOUTH/WEST/WATERLOGGED` to the corresponding `Properties` fields (via `PipeBlock` for directions). `BooleanProperty.java` is byte-identical at both endpoints. Therefore the Cartesian product is 2^6 = 64 states on each side. `states.tsv` explicitly enumerates those rows; rows with the same property values have the same output descriptor at both versions.

The arm table index reads only NORTH/EAST/SOUTH/WEST. Both `Direction` sources preserve `getIdHorizontal` values NORTH=2, EAST=3, SOUTH=0, WEST=1; thus the provider's `1 << getIdHorizontal()` mask is `N=4, E=8, S=1, W=2`. `mask` in `states.tsv` is the OR of the true direction bits. `UP` chooses the wall-specific table versus the inherited pane table. `WATERLOGGED` is never read by either shape provider, so each mask/UP output repeats identically for both waterlogged values.

## Providers, dispatch, context and cache

- 1.13.2 `WallBlock.getShape` selects `SHAPES[mask]` when UP is true and otherwise delegates to `PaneBlock.getShape`; `getCollisionShape` selects `COLLISION_SHAPES[mask]` when UP is true and otherwise delegates to `PaneBlock.getCollisionShape` (`WallBlock.java:27-39`). Old `BlockState` dispatches directly to these providers; the base `Block.getCollisionShape` gates on `hasCollision` before calling the state outline provider (`BlockState.java:205-211`, `Block.java:391-395`). Cobblestone's copied properties leave collision enabled: `Block.Properties.hasCollision` defaults true and copy preserves it (old `Block.java:1901,1932`). The gate does not replace the output with empty shape.
- 1.14.4 has the same branch/table selection with the added `CollisionContext` parameter; neither `WallBlock` nor the delegated `PaneBlock` reads context, world or position (`WallBlock.java:27-43`; `PaneBlock.java:80-104`). The base collision provider applies the same `hasCollision` gate and then routes through the state's shape provider (`Block.java:375-378`). The copied cobblestone properties also retain collision enabled (`Block.java:811,843`).
- The 1.14.4 static shape cache is not a hidden input difference: `BlockState.cacheShape()` caches only when `!hasDynamicShape()` (`BlockState.java:65-67`); `Block.Properties.dynamicShape` defaults false and the wall's copied cobblestone properties do not enable it (`Block.java:819,849,893-895`; `Blocks.java:45,796`). The bootstrap cache loop calls `cacheShape()` for registered state values (`Blocks.java:1960-1964`). Cached collision output uses the empty context; direct entity-context dispatch and the cached route select the same table because the provider and inherited pane provider ignore context. Outline queries likewise ignore context. The 1.13.2 direct route and 1.14.4 cached/direct routes therefore agree for every enumerated state.

## Normalized table descriptors

Coordinates below are normalized to sixteenths in `(x,y,z)`; each descriptor denotes the union of its component cuboids. For mask `m`, include exactly those direction arms whose bits are set (`N=4,E=8,S=1,W=2`). This is the exact 16-entry table-generation rule in both versions: `PaneBlock.makeShapes` creates these same directional pieces and combines them by the same mask-indexed union recipe; `WallBlock` invokes that recipe with the wall-specific arguments. Entries 0 through 15 are consequently specified without relying on state producers or runtime execution.

| Table selected by provider | Center post | N arm, bit 4 | E arm, bit 8 | S arm, bit 1 | W arm, bit 2 |
|---|---|---|---|---|---|
| `WALL_OUTLINE[m]` (`UP=true`, `WallBlock.SHAPES`) | `[4,0,4]-[12,16,12]` | `[5,0,0]-[11,14,11]` | `[5,0,5]-[16,14,11]` | `[5,0,5]-[11,14,16]` | `[0,0,5]-[11,14,11]` |
| `WALL_COLLISION[m]` (`UP=true`, `WallBlock.COLLISION_SHAPES`) | `[4,0,4]-[12,24,12]` | `[5,0,0]-[11,24,11]` | `[5,0,5]-[16,24,11]` | `[5,0,5]-[11,24,16]` | `[0,0,5]-[11,24,11]` |
| `PANE_OUTLINE[m]` (`UP=false`, inherited `PaneBlock.getShape`) | degenerate empty center | `[5,14,0]-[11,24,11]` | `[5,14,5]-[16,24,11]` | `[5,14,5]-[11,24,16]` | `[0,14,5]-[11,24,11]` |
| `PANE_COLLISION[m]` (`UP=false`, inherited `PaneBlock.getCollisionShape`) | degenerate empty center | `[5,0,0]-[11,24,11]` | `[5,0,5]-[16,24,11]` | `[5,0,5]-[11,24,16]` | `[0,0,5]-[11,24,11]` |

The pane fallback table recipes come from the `WallBlock` constructor's `super(0,3,0,14,24,properties)`: `PaneBlock.shapes` calls `makeShapes(0,3,24,0,24)` and `PaneBlock.collisionShapes` calls `makeShapes(0,3,0,14,24)`. In this historical API those array names are counterintuitive: `PaneBlock.getShape` returns `collisionShapes`, while `PaneBlock.getCollisionShape` returns `shapes`. The wall-specific arrays are both initialized from exactly the same arguments at both endpoints: `makeShapes(4,3,16,0,14)` and `makeShapes(4,3,24,0,24)` respectively. Pane table union order, box constants, `getShapeIndex` mask calculation, and wall constructor arguments match across the compared source bodies. New `PaneBlock` memoizes the same mask by state; that changes lookup work only, not table index or output.

## Exact source hashes (SHA-256)

All hashes were recomputed from the canonical source trees listed above.

| Relative source path | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/WallBlock.java` | `aeb67adf292a3b750e72a7d2fdc13f7b42f8633c6183964d00dfe8d6960e07bf` | `033da2cef0973f5d380a81b53ee76e23324fffece72edc74e12fcee0d8764be7` |
| `net/minecraft/block/PaneBlock.java` | `9422e3f2aa9843ecd041f5ced13d05a4c7472d697f7dfd838450e49969e5326c` | `7150e89268a84113453cd5416ffe25e1ca7d42a39f264f7ae989878a10ee2158` |
| `net/minecraft/block/PipeBlock.java` | `4c56867771e5848fec41d7ccbce5339af3dfefa7f98afb4712dfd0d5abd8f9a9` | `50974f5a929e70166c8edbac17dd22b295ceb50bacd345d2b89a25bb150740b6` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/state/StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |
| `net/minecraft/state/property/Property.java` | `364b9db0af26a3dc3f0e7a55349d7063efd7557c3b0f0a297db19b61c258b493` | `364b9db0af26a3dc3f0e7a55349d7063efd7557c3b0f0a297db19b61c258b493` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/state/property/BooleanProperty.java` | `7a414a5c7a8110a97b32fce9ad0bfa9df0212f286bfbe5b777962205cc9dcf11` | `7a414a5c7a8110a97b32fce9ad0bfa9df0212f286bfbe5b777962205cc9dcf11` |
| `net/minecraft/util/math/Direction.java` | `6d5c496ff65377fee9f00c826e48c7be14d3889e5ae5191e110a464007549082` | `121f8b78eda07640eccbe369f40acc7ccbdcb275dcb6aca87c4495cd193b01c0` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |

`states.tsv` SHA-256: `388fddfe8584ab7f1fb622973f6b44fd5a95e6602f2ca2cea8e9e1a9a32d848b`.




