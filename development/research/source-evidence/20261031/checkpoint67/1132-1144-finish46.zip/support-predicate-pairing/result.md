# Support and step predicate pairing: 1.13.2 → 1.14.4

## Scope and evidence identity

Source-only bounded pairing for player-facing support/step predicates, in the exact Ornithe Feather Gen2 build 2 pair. Read only the allowed source projections and exact 1.13.2 / 1.14.4 `ornithe-feather` source trees. The ready-marker, manifest, provenance, and source hash identities were verified in the parent provider inventory and provider-state-pairing report; the checks below rehash every source file used in this slice. No product/wiki/backlog/Git data, builds, tests, game, or source regeneration were used.

Paired terminal/member rows checked:

| Slice | 1.13.2 member(s) | 1.14.4 member(s) | Result |
|---|---|---|---|
| Face-solid/full-shape primitives | `Block.isFaceFull`, `Block.isShapeFullBlock`, `BlockState.getFaceShape` | `Block.isFaceFull`, `Block.isShapeFullBlock`, `Block.isFaceSolid`, `BlockState.isFaceSturdy` (Feather emits opaque member name; crosswalk is already verified in provider inventory) | `isFaceFull` still reduces a face shape then tests full unit-cube coverage. The new movement-facing face-sturdy predicate first rejects active `BlockTags.LEAVES`, then tests full coverage of the collision shape. Old fluid-flow caller pairing and stair witness are already recorded in `provider-state-pairing/result.md`; this pass does not re-audit the other old `getFaceShape` implementations. |
| Top/base and center support | No old `canSupportBase` / `canSupportCenter` helpers. Old `BlockState.isFullBlock` → `Block.isFullBlock`; old `BlockState.getFaceShape` is used by selected attachment callers. | `Block.canSupportBase`, `Block.canSupportCenter` | These are new geometric attachment/support tests over the collision shape, with active LEAVES exclusion. They are not player movement predicates in the checked callers. |
| Player step-up | `Entity.move`, step-up branch at `Entity.java:602–624`, candidate boxes checked through `World.hasNoCollisions`; collision shape is the terminal. | `Entity.move`, step-up branch at `Entity.java:670–684`, candidate displacement vectors checked through `World.hasNoCollisions`; collision shape is the terminal. | No support helper is called in either player step-up path. Step height, horizontal-collision gate, collision-shape clipping, and vertical candidate selection are a separate movement slice and are not closed here. The support-helper change does not by itself establish a step-height change. |
| Entity neighbor fullness helper | `World.isFullCube` at `World.java:1484–1486`, consumed by `Entity.pushAwayFrom` | `BlockState.isShapeFullBlock` at `BlockState.java:330–331`, consumed by `Entity.pushAwayFrom` | This resembles a full-shape substitution but `pushAwayFrom` callers are only `ItemEntity` and `ExperienceOrbEntity` in the checked source trees. The changed result, if any, has no player movement caller here. |
| Player suffocation / in-wall predicates | `PlayerEntity.shouldSuffocate` → `BlockState.isSolid`; `Entity.isInWall` → `BlockState.isViewBlocking` | `PlayerEntity.shouldSuffocate` → `BlockState.isViewBlocking`; `Entity.isInWall` → `BlockState.isViewBlocking` | The state semantics changed from old material + `isCube` logic to shape/material based checks. These consumers feed suffocation / damage eligibility, which is excluded from this movement assignment. They are not support or step callers. No damage-result finding is made. |

## Concrete new support result and caller meaning

Both registries include `minecraft:oak_slab` (old `Block.java:1549`; new `Blocks.java:1306`), and both slab state definitions expose `HALF` and `WATERLOGGED`. The generated vanilla LEAVES recipe excludes oak slabs; custom/runtime tag replacement is out of scope. For the matching raw state `HALF=BOTTOM, WATERLOGGED=false`, 1.13.2 `SlabBlock.isFullBlock` is false (the old rail, diode, and torch support checks consume that old fullness contract). In 1.14.4 the slab collision shape is the lower half-cube; its upward face fills the full horizontal footprint. `Block.canSupportBase` tests that face against `BASE_SUPPORT_SHAPE`, which only leaves a 2/16 border unsupported, so the same slab state supports the base. Therefore the same vanilla bottom slab changes from rejected to accepted as support under `canSupportBase`.

Concrete callers: `AbstractRailBlock.canBePlaced` and rail neighbor survival use `isFullBlock` in 1.13.2 and `canSupportBase` in 1.14.4; `DiodeBlock.canBePlaced` also changes to `canSupportBase`. `TorchBlock.canBePlaced` changes from a special-case list plus `isFullBlock` to `canSupportCenter(..., UP)`. This is a block placement / neighbor survival result, not a player movement trajectory or a player support/step read. Under the project invariant that block states remain vanilla and health/production effects are outside this lane, it does not establish an emulated player movement change. No trajectory claim is made.

The step-up callers are independent: both releases' `Entity.move` selects a step candidate through collision box clearance (`World.hasNoCollisions`) and axis clipping. The support helpers do not participate. A complete movement comparison of those step algorithms remains owned by the movement/collision coverage, not this helper pairing.

## Explicit remaining members and dependencies

- The 65 old direct `Block.getFaceShape` declarations remain unpaired against the new shape-derived face-sturdy result except the stair witness. Exact endpoint rows and hashes are in `../providers/fluid-face-shape-providers.tsv`; classes include `Block`, `CauldronBlock`, `FenceBlock`, `FenceGateBlock`, `PistonBaseBlock`, `PistonHeadBlock`, `ShulkerBoxBlock`, `SlabBlock`, `SnowLayerBlock`, `StairsBlock`, `TrapdoorBlock`, and `WallBlock`.
- All old/new `getShape` provider rows (83 old, 97 new) remain unpaired per common concrete state/registration, per `../providers/shape-provider-overrides.tsv`. This slice did not close those geometry dependencies for every face result.
- The new `Block.canSupportBase` and `Block.canSupportCenter` callers and their block-state consequences are inventoried above only to establish scope. Per-state pairing of every placement/support outcome is not performed.
- The old `isTopSolid` spelling does not occur in these Feather source trees. The exact candidate old contracts found here are `BlockState.isFullBlock`, `Block.isFaceFull` / `BlockState.getFaceShape`, and `World.isFullCube`.
- No ordinary player support predicate was located in the checked `Entity.move` / step path. Full step collision and candidate-selection parity remains open; so do all shape-provider and face-predicate dependencies named above.

## Source SHA-256

| Version | File | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.13.2 | `net/minecraft/block/AbstractRailBlock.java` | `ef89230726ce9bd5ebb009d9332da90969d074762fc7eca8d477640d020a0a8d` |
| 1.14.4 | `net/minecraft/block/AbstractRailBlock.java` | `9f889ccea3e80c29fe4c5ac97c6713b5e40878eeaf5ffadd71918572a4fff70a` |
| 1.13.2 | `net/minecraft/block/TorchBlock.java` | `da11308e51f57ce95764f2ee645dde8d15607914a3a68bac9c0635ab3d1531e0` |
| 1.14.4 | `net/minecraft/block/TorchBlock.java` | `8430a1058184d9e87596d5ba961ce092e6c77469c642f50e5c901db1a0588aab` |
| 1.13.2 | `net/minecraft/block/AbstractPressurePlateBlock.java` | `c920500d5b908f6f516e04b6c312ba7c848c3cfa97b24d3427ccf10d2b0de701` |
| 1.14.4 | `net/minecraft/block/AbstractPressurePlateBlock.java` | `23fa38e232fd91a736ae79c8d038c317707b72a2f312467efbacca42b903b1c3` |
| 1.13.2 | `net/minecraft/block/DiodeBlock.java` | `972925eff56fcaa0f1f00662679c12505a3e64dc79b24996d26110ec14b8608b` |
| 1.14.4 | `net/minecraft/block/DiodeBlock.java` | `54b3f2984c4b26a25e183fc8e958bfdbcdc66ca8950b78847aa1040fa2494a8` |
| 1.13.2 | `net/minecraft/block/SlabBlock.java` | `2e7ff3fcfa5faa83aa4af7ea9b68f07af8d8fe7047e08ee3a9d7d37b78c7128f` |
| 1.14.4 | `net/minecraft/block/SlabBlock.java` | `91f2ebc592e5cb07d5ce8a6faa123ec0d4b7bf10aa6323d6aceb343bc0f73a53` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.14.4 | `net/minecraft/world/World.java` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` |
