# Independent review: reset-position climb-coordinate candidate

## Verdict

**The predicate and travel-mechanics comparison is supported, but the combined fixed-world movement witness is not established as written.** The terminal requires a collision at the same stale box used by the immediate movement query. Unless the world/collision inputs change between `resetPos` and travel, the stated collision-free movement query is inconsistent with the reset terminal. Retain the narrower source fact that stale box-minY and stored Y make the two climb predicates read different blocks; revise or qualify the movement witness before accepting its demonstrated output under one unchanged world snapshot.

## Verified claims

- `Entity.resetPos` in both endpoints has the strict `0 < y < 256` loop, calls `setPosition` before testing collisions, increments only stored `y` after a failed test, and exits after an increment to 256 without another placement. The old query is `hasNoCollisions(this, this.getShape())`; the new overload delegates through the entity shape. For a terminal at exactly 256, the last collision check at 255 must fail (report wording: the box **collides**, so `hasNoCollisions` returns false). No box rebuild occurs after that increment.
- With stored Y 256 and box minY 255, old `isClimbing` floors `getShape().minY` and can read the vine at Y255; new `m_83221421()` reads `new BlockPos(this)` using stored Y and therefore reaches Y256. The source reports world-height lookup there as `VOID_AIR`. The stated non-spectator condition is necessary on both paths.
- The compared travel paths do reach a climb-conditioned horizontal clamp in the stated grounded land branch. Old code clamps before `move`; new code applies `m_19439509` immediately before `move`. The other listed branch requirements should be treated as fixed input conditions; this review does not claim parity for other branches.
- With zero movement input, the acceleration helper adds no horizontal acceleration, so the pre-existing X velocity reaches the climb gate. Under the old true predicate, `0.3` is clamped by the float bound `0.15F` (widened to double, exactly `0.15000000596046448`); under the new false predicate, it remains `0.3`. Thus the **requested** X values passed to `move` differ as claimed, with the float widening caveat. Actual position displacement is not proven to be those values unless collision resolution permits the full request.
- The vine is registered `noCollision()` on both endpoints. The paired `climb-trigger-shapes` inventory and output table support that it remains a predicate input rather than the collider responsible for the reset terminal.

## Material witness constraint

To reach the stale-box terminal through the stated loop, the collision query at Y255 must see at least one collision for the same box later used by travel: `[0.2,0.8] × [255.0,256.8] × [0.2,0.8]`. For unchanged block/entity collision inputs, that collision candidate lies in the starting volume of the subsequent X movement query as well. The candidate draft simultaneously specifies no colliding candidates in the X movement region, and the report's example relies on a solid block overlapping the player's horizontal box. The report explicitly leaves the collision-provider route unaudited, so it does not close this conflict.

The source-level predicate difference remains valid for an arbitrary supplied raw snapshot. What is not shown is that the specific resetPos-generated snapshot and the collision-free travel world are one coherent unchanged state. A changed world/collision set between reset and travel could permit it, but would need to be stated and evidenced; otherwise demonstrate the requested movement output with the collision from the terminal still present, including its effect on `move` resolution. This is a source review only, not runtime validation.

## Source identity and hashes

Read-only roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `.../1.14.4/ornithe-feather`. Both `ornithe-feather.ready.json` files identify their exact versions and Feather mapping (`feather-gen2-<version>+build.2`); each ready marker's source-manifest digest matches the corresponding `ornithe-feather.sources.sha256` file. Manifest entries and independently recomputed file hashes match all eight hashes quoted in `climb-resetpos-upper-bound-terminal/report.md`:

| Version | Entity.java | LivingEntity.java | World.java | WorldView.java |
|---|---|---|---|---|
| 1.13.2 | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` | `fcdf8dc98f97781f4639c4b8da8a238edf834f3963e401e6eeef6cb475c4909` |

Ready-marker source-manifest SHA-256 values: 1.13.2 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

## Scope

Reviewed only the assigned candidate and terminal report against the exact read-only Feather source and cited climb-shape evidence. No source generation, product/wiki/backlog/Git changes, build, tests, game launch, or runtime claim.
