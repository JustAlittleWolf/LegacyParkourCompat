# 1.13.2 → 1.14.4 direct client local-player response pairing

## Scope and result

This lane audits exact client-side packet application paths that can write local-player position, velocity, dimensions/pose, movement flags, abilities, attributes, status effects, or equipment/inventory state. It excludes packet production/server processing, damage and health, vehicles/nonplayers, input-device plumbing, block-state production, and custom runtime tags. Incoming packet values and synchronization order are treated as paired inputs, not as proof that a server producer emits them.

The endpoint handler inventory is complete for the requested classes of direct client response in `ClientPlayNetworkHandler` and its immediate local-player setup/terminal calls. It is not full-pair closure: several downstream state-to-movement effects and the ordinary state producers remain open. No freeze claim is made.

## Exact source identity

Roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. The inspected ready markers identify exact versions 1.13.2 and 1.14.4, Ornithe Feather Gen2 build 2, Vineflower, Java 25, and source counts 2,711 and 3,250. Provenance records Feather mapping artifacts and an exact run for each version. The source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; the artifact-manifest values are `fdcacd9150f98ea70acafc5cab754027ab1a09828ff0eaa8e542dd7890d9ce1e` and `308cc33ef6dffc047432ade6affc88eccc9de94a736ee9a98571fd92915c2970`. Ready-marker and provenance-file hashes match the permitted source-only inventory: 1.13.2 ready `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38`, provenance `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383`; 1.14.4 ready `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77`, provenance `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9`.

I recomputed the full SHA-256 of every source file listed below; each equals the corresponding source-manifest entry. The listed file hashes bind all cited method bodies and their enclosing gates. No decompiled sources were generated or changed.

## Pair inventory

### Direct position, velocity, box, and pose response

| Terminal | 1.13.2 → 1.14.4 route and local-player resolution | Paired result |
|---|---|---|
| Login/setup | `ClientPlayNetworkHandler.handleLogin`, 316–340 → 341–384; both use `minecraft.player`. 1.14.4 explicitly creates a player when absent, resets position, inserts it in the client-world ID map, installs keyboard input, and adjusts game mode. 1.13.2 changes the world and sets the existing player's network ID, then adjusts game mode. | Both are direct local-player setup routes. Their differing initialization sequence is a candidate state-reset boundary; `Minecraft.setWorld`/pre-login construction effects on the 1.13.2 side and exact spawn/reset consequences have not been closed here. |
| Server position correction | `handlePlayerMove(PlayerMoveS2CPacket)`, 621–670 → 652–712; explicitly binds `minecraft.player`. | Previously bounded exact difference, rechecked against both file hashes: both resolve relative axes against current position and clear velocity only for absolute axes. 1.14.4 also updates each `prevX/Y/Z` on the packet; 1.13.2 leaves those fields untouched. Both apply relative rotations, call `updatePositionAndAngles`, acknowledge the teleport, and echo the resolved position. This remains an accepted direct writer difference; downstream use of stale previous-position state is not established by this lane. |
| Entity velocity | `handleEntityVelocity`, 507–513 → 537–543. Resolves packet entity ID; local player is addressable by its network ID. | Same three components divided by `8000.0` and passed to `lerpVelocity`; no difference found. |
| Explosion impulse | `handleExplosion`, 968–977 → 1044–1053; direct use of `minecraft.player`. | Same additive server vector to current local velocity after client-side explosion handling. Block production and damage are excluded. |
| Entity relative move / teleport | `handleEntityMove`, 582–601 → 614–630; `handleEntityTeleport`, 551–571 → 583–603. Both resolve IDs. | **Not local physical writers.** Both gate interpolation/position and on-ground updates behind `!entity.isLogicalSideForUpdatingMovement()`. `Entity.isLogicalSideForUpdatingMovement()` delegates to `PlayerEntity.isLocal()` for player entities; `LocalClientPlayerEntity.isLocal()` returns true in both versions. These handlers still update network interpolation bookkeeping (`lastKnownX/Y/Z`, and old/new packed coordinates) for a locally addressed ID, but do not apply the entity move/teleport to local physical position. `EntityMap.updatePosition` in 1.13.2 and `Entity.m_33357175` in 1.14.4 only pack those tracking coordinates. |
| Player respawn / dimension transition | `handlePlayerRespawn`, 944–965 → 996–1041; both explicitly replace/reset `minecraft.player`. Old delegates to `Minecraft.respawnPlayer`; new constructs the replacement in the handler. | Both create a new local player, reset its position, copy synchronized entity data, and apply the packet game mode. The helper and ordering differ: old `Minecraft.respawnPlayer` removes the previous entity, creates/adds the replacement, copies synchronized data, calls `initPlayer`, installs input, restores network ID and adjusts abilities; 1.14.4 handler copies selected identity/state (ID, stats, recipe book, server brand, reduced-debug flag), copies synchronized data, resets position, registers the replacement, installs input, adjusts abilities, then applies game mode. Exact reset omissions and first-tick movement consequences remain open. |

### Ability, effect, attribute, equipment, and movement-state synchronization

| Terminal | Target and paired result |
|---|---|
| Abilities | `handlePlayerAbilities`, 1537–1546 → 1597–1606 directly writes the client player's `flying`, `creativeMode`, `invulnerable`, `canFly`, fly speed, and walk speed. Bodies match. `handleGameEvent` event 3, 1142–1225 → 1215–1298, also reaches `ClientPlayerInteractionManager.setGameMode`; the helper stores the game mode and applies it to `minecraft.player.abilities` in both versions. |
| Entity attributes | `handleEntityAttributes`, 1934–1960 → 2083–2109, resolves ID to a living entity, then sets/creates each attribute instance, base, clears modifiers and adds packet modifiers. The body matches; because client-world ID lookup resolves the local player, this is an eligible local movement-modifier route. Exact downstream attribute aggregation/use is outside this handler-only closure. |
| Status-effect add/remove | `handleEntityStatusEffect`, 1396–1409 → 1453–1466 resolves the ID and invokes `LivingEntity.addStatusEffect`; `handleEntityRemoveStatusEffect`, 1488–1494 → 1548–1554 resolves packet entity and invokes `removeEffect`. Bodies match and can target the local player. `addStatusEffect` calls application/upgrade callbacks; effect-specific movement attribute changes and their exact 1.13.2/1.14.4 terminal coverage remain open. |
| Entity equipment | `handleEntityEquipment`, 1115–1121 → 1188–1194 resolves entity ID and calls `setEquipment`. For a local `PlayerEntity`, both overrides write main hand to selected inventory slot, off hand to the offhand list, and armor to its armor list; the two override bodies match. Whether/how item modifiers are reflected into local movement attributes remains open. |
| Player inventory and selected hand | `handleInventoryMenuSlotContent`, 1006–1036 → 1076–1108 and `handleInventoryMenuContent`, 1055–1063 → 1127–1135 write the local player's inventory/menu. `handleSelectSlot`, 574–579 → 606–611 updates its selected hotbar slot. Menu-content and select-slot behavior match. The slot-content route differs for menu ID -1: 1.13.2 always writes cursor item; 1.14.4 skips that write while the creative inventory screen is open. Cursor contents are not equipped movement state, so this is recorded but not accepted as a movement terminal. Equipment-to-modifier propagation remains open. |
| Synchronized entity data / movement flags and pose | `handleEntityData`, 516–521 → 546–551 resolves any client-world entity ID and applies entries through `getSyncedData().update`; bodies match. The local player is addressable on both sides (1.13.2 `ClientWorld.getEntity` special-cases its network ID; 1.14.4 registers it in `entitiesById`). In 1.14.4, entity pose is synchronized data, and `LivingEntity` reads `Pose.SLEEPING` for sleeping dimensions; old shared entity flags and living flags are tracked data. Thus the route can affect local movement flags/pose when the incoming entries identify those fields. The paired serializer/accessor registration and callback consequences are open. |

### Sleep and entity-event paths

1.13.2 has `handlePlayerSleep`, 816–819, which obtains the packet player by client-world ID and calls `trySleep(pos)`. There is no `PlayerSleepS2CPacket` source class or matching handler in the 1.14.4 Feather tree. In 1.14.4 the matching client response surfaces are synchronized entity data (`Pose`, optional sleeping position) and entity-animation action 2 (`wakeUp(false,false,false)`); both target entities by ID and therefore can resolve the local player. `handleEntityAnimation`, 792–817 → 847–872, is otherwise the same. The sleep entry call reaches bed/sleep eligibility logic, explicitly excluded by the task; the direct position/pose writes it invokes and the new synchronized-pose route are recorded as an unresolved response pairing, without asserting a trajectory.

`handleEntityEvent`, 910–927 → 962–979, resolves any entity ID and otherwise dispatches `entity.doEvent(event)`. This can target the local player. The event handler's local effects are mostly nonmovement (including totem presentation); `Entity.doEvent` and `LivingEntity`/`PlayerEntity` overrides have not been completely paired against movement-flag or modifier writes, so this indirect event terminal remains open. Health and damage consequences are excluded.

## Local-ID proof and routing exclusions

1.13.2 `ClientWorld.getEntity(id)` returns `minecraft.player` when `id == minecraft.player.getNetworkId()`; 1.14.4 `ClientWorld.getEntity(id)` reads the `entitiesById` map and `handleLogin`/respawn register the local player there. `LocalClientPlayerEntity.isLocal()` returns true at both endpoints. The entity-move and entity-teleport handlers' `!isLogicalSideForUpdatingMovement()` guard therefore excludes their physical updates for the local player. By contrast, velocity, entity-data, attributes, effects, equipment, inventory and animation/sleep handlers do not exclude local identity after ID resolution.

Direct player routes are handled without entity-ID filtering: correction, abilities, game-mode, explosion and respawn/setup use `minecraft.player`. `handlePlayerHealth` and health metadata are excluded; `handleVehicleMove` is a vehicle response and excluded. `handleCamera` only changes camera selection. Entity passenger/mount state is vehicle-adjacent and excluded. `handlePlayerInfo` updates the player-list record, not the local entity's game mode or movement attributes. Packet creation and server-side route/producer checks were not used.

## Exact remaining members

- `Minecraft.setWorld` and the 1.13.2 initial local-player construction/registration route versus 1.14.4 `ClientPlayNetworkHandler.handleLogin`: resolve login reset/position/box initialization effects.
- `Minecraft.respawnPlayer` (1.13.2) versus `ClientPlayNetworkHandler.handlePlayerRespawn` (1.14.4), plus both `ClientPlayerInteractionManager.initPlayer`/`adjustPlayer` and `PlayerEntity.resetPos`: close copied state, ability application and reset ordering.
- `LivingEntity.onStatusEffectApplied`, `onStatusEffectUpgraded`, `onStatusEffectRemoved`, and movement-relevant `StatusEffect` attribute-modifier application: close the effect synchronization terminal through movement modifiers.
- Local player's item attribute path from `PlayerEntity.setEquipment`, inventory-slot writes, selected-slot writes, and item attribute aggregation: establish whether any equipment update changes movement modifiers immediately at each endpoint.
- `SyncedData.update` / tracked attribute serializers and the entity/living/player accessor registrations, including pose, sprint/sneak/swim/fall-flying flags and sleeping position: close which local movement fields each data update can mutate and compare callbacks.
- `LivingEntity.startSleeping`/`stopSleeping`, `PlayerEntity.trySleep`/`wakeUp`, and pose/dimension updates: compare direct physical response while keeping bed-entry eligibility excluded.
- `Entity.doEvent` and `LivingEntity`/`PlayerEntity.doEvent` overrides reached by `handleEntityEvent`: determine whether any event accepted for the local player writes movement state.
- Full attribute/effect/equipment synchronization order and its ordinary state history remain open. No server processing or producer claim is made.

## Rehashed exact source files

| Version | Relative file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/client/Minecraft.java` | `b1d35473cd12bdf38e87f9888b4ed6f620614cbe914cf7e7a40c601d4e284875` |
| 1.13.2 | `net/minecraft/client/ClientPlayerInteractionManager.java` | `892bdb99e894b538daeeb7fd9ae6f9a0970b854f38f51b4b39c446e905692359` |
| 1.13.2 | `net/minecraft/client/world/ClientWorld.java` | `bae1d6d653260e42d735b9652e5c89711f1bd78eacba7993e2460f2f2528640a` |
| 1.13.2 | `net/minecraft/server/EntityMap.java` | `5a3bf4051cb63d96896f3079dc653fcc97d43bb573e2925617fb6d12f0fddd98` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 | `net/minecraft/network/packet/s2c/play/PlayerSleepS2CPacket.java` | `68ca6966740d5ffa0239b0699dee2bbf9927b52ee5310c737a652652f91dfd14` |
| 1.13.2 | `net/minecraft/world/GameMode.java` | `f245fb32c78232d3e936edfd517c76e727591c93001049f4e5e94ce86ed48971` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.14.4 | `net/minecraft/client/ClientPlayerInteractionManager.java` | `86707c46294dae65c878e43da56b9330ab46e7069d8119e179e485baafb2d0de` |
| 1.14.4 | `net/minecraft/client/world/ClientWorld.java` | `c4674cc7c6b322bef6a5a951aa73be2b405de4bc64804fb9b6bb96c1832b1768` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54e9d308703bf49cb53b72646b05253857e9557d657df` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.14.4 | `net/minecraft/world/GameMode.java` | `f245fb32c78232d3e936edfd517c76e727591c93001049f4e5e94ce86ed48971` |

