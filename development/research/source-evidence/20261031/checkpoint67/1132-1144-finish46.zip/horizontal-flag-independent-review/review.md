# Independent review: horizontal collision flag tolerance

## Verdict

**ACCEPT.** The candidate's direct `Entity.move(MoverType.SELF)` fixture is source-consistent. With the stated box and stone block, a positive X request of `5.0E-6` clips to a resolved X movement of exactly zero at both endpoints. The old endpoint compares requested and resolved horizontal components exactly, so `collidingHorizontally=true`; the new endpoint treats component differences strictly smaller than `1.0E-5F` as equal, so `collidingHorizontally=false`. Both vertical collision and on-ground flags are false; the aggregate collision flag differs with the horizontal flag. Neither endpoint translates the box in this fixture.

## Independent source check

- The 1.13.2 player move path snapshots `n=x` and `p=z` after cobweb and sneaking adjustment, then clips against the world collision shapes. The candidate explicitly fixes `inCobweb=false`, `onGround=false`, and `isSneaking=false`, so those gates leave `(5.0E-6,0,0)` unchanged through entry to axis resolution. At the terminal, `collidingHorizontally = n != x || p != z` (`Entity.java:677`), which is true because `n=5.0E-6`, resolved `x=0`, and `p=z=0`.
- The 1.14.4 `Entity.move` applies neither pending cobweb movement multiplier nor sneak clipping under the stated inputs. Its collision resolver returns `(0,0,0)` when the player box touches the stone west face and requests positive X movement. The terminal is `!MathHelper.m_68886716(vec3d.x, vec3d2.x) || !MathHelper.m_68886716(vec3d.z, vec3d2.z)` (`Entity.java:472`). The helper returns `Math.abs(e-d) < 1.0E-5F` (`MathHelper.java:155–157`); the `5.0E-6` delta is below this threshold, so horizontal collision is false.
- Old `Blocks` initialization registers `stone` as a `StoneBlock` inheriting `Block.getShape` and `Block.getCollisionShape`. The 1.14.4 registration is a base `Block`. Both base `getShape` bodies return the unit cube; both default registrations have collision enabled. The collision shape is therefore a full cube at `(1,0,0)` in both versions.
- For positive X max-offset, a box whose max X is exactly the obstacle's min X is clipped to `0`; the fixture's Y/Z intervals overlap the unit cube. The swept query includes the block, while the report assumes no other clipping shapes and a world border outside the swept query. With `noClip=false`, no step alternative runs because `onGround=false`. Since the resolved movement is zero, neither version changes player position. Their vertical and on-ground results agree; the old/new aggregate `colliding` flags follow the differing horizontal value.

This is a conditional direct player movement-flag difference under the candidate's equal raw query/field assumptions. It does not establish a preceding ordinary history, input producer, later climb/travel effect, or intermediate patch boundary.

## Reviewed input hashes (SHA-256)

| Input | SHA-256 |
|---|---|
| Candidate draft | `e756d6d24c16526095b1552b4a29e051b566746bb31cf5568d595ad0fe72102a` |
| 1.13.2 `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 `net/minecraft/util/math/MathHelper.java` | `e39d5dfc69c17a9032be086d7d4d14cc63525962a0ff83615b1befdcca599843` |
| 1.13.2 `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 `net/minecraft/block/StoneBlock.java` | `4a85d515f1195600042d7e67de00767c77c91c2e74aa00ac7796ceb7ea78c906` |
| 1.14.4 `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.13.2 `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.14.4 `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |

No product implementation, wiki, backlog, product Git, build, test, game, or source generation was used.
