# Candidate: two-boundary MOVING_BLOCK admission changes X clipping

**Claim class:** conditional fixed-input local-player movement terminal.

For equal box, vector, world-state and moving-block-entity inputs, 1.13.2 omits a paired `moving_piston` collision shape because the enumerated cell lies on two shell boundaries. 1.14.4's one-axis resolver admits that same dynamic block through its `MOVING_BLOCK` exception. Under the isolated fixture below, `Entity.move` resolves X as `-0.5` in 1.13.2 and `-0.1` in 1.14.4.

**Inputs:** `B=[0.6,1.2]×[0.2,2.0]×[0.2,0.8]`, vector `(-0.5,0,0)`, `SELF`, `noClip=false`, `onGround=false`, not sneaking, not in cobweb, with no piston movement adjustment. At block `(-1,-1,0)`, use `moving_piston` and a `MovingBlockEntity` with moved state `cobblestone_wall[UP=true,NORTH=false,EAST=true,SOUTH=false,WEST=false,WATERLOGGED=false]`, facing EAST, `extending=false`, `source=false`, progress `0.5F`, and `NOCLIP_DIR=null`. Assume a loaded interior chunk, inactive border, and no other blocking candidate. The initial box is X-disjoint from the nested wall shape, so old `excludeBlock` does not suppress it.

The old shell route rejects the cell at two boundary dimensions before loading its state; no shape reaches the clipper, so the request remains `-0.5`. The new one-axis route counts two boundary coordinates and admits the cell because the block is `MOVING_BLOCK`. In world coordinates, the nested east wall arm's max X is `0.5` and the player box's min X is `0.6`, so the negative-direction gap is `0.5 - 0.6 = -0.1`. Equivalently, relative to block X `-1`, the arm's max X is `1.5` and the box's min X is `1.6`, giving `1.5 - 1.6 = -0.1`. The resolved new request is therefore `-0.1`.

This conditional source-level candidate does not claim that piston production or an ordinary movement trajectory reaches the stated raw block-entity fields. It claims only the paired movement terminal under the exact supplied inputs.

**Evidence:** `.native-source/20261031/1132-1144-finish46/corner-shell-clip-candidate-search/report.md`, SHA-256 `8fe19e62c3c5d4152ffcbf2024917e2d7e418b68da82ccb158a2f323a4583ed7`. Exact source identities and hash-verified arithmetic are in that report.
