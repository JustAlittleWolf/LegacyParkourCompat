# Respawning from copied sleeping state preserves an extra 1.14.4 sleep position

For equal client respawn inputs where the outgoing local player is asleep, 1.13.2 stores sleep as ordinary `PlayerEntity.sleeping`/`sleepingPos` fields; the replacement copies tracked data only, so it is awake and remains at client-world spawn (subject to the shared collision-based `resetPos` loop). In 1.14.4 sleeping position is a tracked `Optional<BlockPos>`: copying synced data invokes a callback that positions the replacement at the bed center before `resetPos`. `resetPos` sets pose to STANDING but does not clear the sleeping-position accessor. With the shared reset loop collision-free from both the old constructor spawn and new bed-centered start, the replacement therefore remains at different positions: old spawn vs new copied bed center.

On the first loaded local-player tick after that response, 1.14.4 `isSleeping()` remains true because it tests the optional sleeping position, despite standing pose. `PlayerEntity.isDead()` consequently selects the `LivingEntity.mobTick` branch that clears jump and movement axes rather than copying equal logical input. The 1.13.2 replacement's ordinary sleeping field is false, so it reaches local input copying. This establishes a source-level client response and first-tick input-state difference under the stated outgoing sleeping-state assumption; no server producer or general trajectory is inferred. An actual downstream movement delta additionally requires input and travel/collision state that turn that input into a different resolved move.

Assumptions: paired outgoing local-player sleeping state: the old sleeping boolean is true with a bed `sleepingPos`, corresponding to new `Pose.SLEEPING` plus optional sleeping position copied from that outgoing player's tracked data; local player is loaded for the first tick; the comparison holds local logical controls equal; the shared reset loop exits immediately from both the old constructor spawn and the new bed-centered starting position. Server respawn eligibility/timing and bed-entry eligibility are excluded.

Exact paired source hashes (SHA-256):

- 1.13.2 `ClientPlayNetworkHandler.java`: `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11`
- 1.14.4 `ClientPlayNetworkHandler.java`: `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef`
- 1.13.2 `Entity.java`: `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`
- 1.14.4 `Entity.java`: `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55`
- 1.13.2 `LivingEntity.java`: `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c`
- 1.14.4 `LivingEntity.java`: `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61`
- 1.13.2 `PlayerEntity.java`: `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633`
- 1.14.4 `PlayerEntity.java`: `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df`

See `.native-source/20261031/1132-1144-finish46/respawn-first-tick-followup/result.md` for ordered exact source tracing and report SHA `f1bc052ac06185d24047267fe51584a20b366a3aee4774fd6728da2ebeb7d6e7a`. Stable intermediate boundary is unknown.
