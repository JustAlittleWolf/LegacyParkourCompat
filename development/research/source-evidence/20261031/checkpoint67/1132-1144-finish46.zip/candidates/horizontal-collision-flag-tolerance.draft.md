# Horizontal collision flag uses a 1.14.4 tolerance

With the same non-sneaking, non-noClip player collision query and a full-cube stone block at `(1,0,0)`, let the player box be `x=[0.4,1.0]`, `y=[0.0,1.8]`, `z=[0.2,0.8]`, with `onGround=false`, and let the movement vector entering collision resolution be `(5.0E-6,0,0)`. Assume the swept query contains no other clipping shape and is not near the world border; old cobweb state is false and the new pending movement multiplier is zero. The player box exactly touches the stone's west face, so positive X motion clips to resolved X=`0` at both endpoints.

1.13.2 sets `collidingHorizontally` from exact component inequality (`requestedX != resolvedX || requestedZ != resolvedZ`), so it records `true`. 1.14.4 uses the equivalent of `abs(requested-resolved) < 1.0E-5F` before negating equality; `5.0E-6` is within that tolerance, so it records `false`. Vertical collision/on-ground remain false, and neither endpoint changes position in this fixture. The source-confirmed difference is the local player's horizontal collision flag (and aggregate `colliding` flag), not displacement or a proved later climb/travel trajectory.

The same position, block-state/query snapshot, collision-resolved movement vector, noClip/ground/sneak/modifier state are paired direct `Entity.move(MoverType.SELF)` operation inputs. This does not claim an ordinary input producer or preceding trajectory. No intermediate boundary is established.

Exact Feather endpoint source hashes (SHA-256):
- 1.13.2 `net/minecraft/entity/Entity.java`: `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`
- 1.14.4 `net/minecraft/entity/Entity.java`: `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55`
- 1.14.4 `net/minecraft/util/math/MathHelper.java`: `e39d5dfc69c17a9032be086d7d4d14cc63525962a0ff83615b1befdcca599843`

Base block collision dispatch and the full-cube provider are bound in `.native-source/20261031/1132-1144-finish46/providers/inventory.md` and the cited endpoint Block.java hashes there.
