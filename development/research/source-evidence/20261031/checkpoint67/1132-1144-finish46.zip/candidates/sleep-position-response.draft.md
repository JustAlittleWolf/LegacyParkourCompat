# Sleeping response places a player at a different bed offset

1.13.2, Ornithe Feather: `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java`, `handlePlayerSleep`, lines 816–819, resolves the packet player and calls `PlayerEntity.trySleep`; on the client, `net/minecraft/entity/living/player/PlayerEntity.java`, `trySleep`, lines 1262–1288, skips bed-entry eligibility checks but still writes the local player's position. When the chunk is loaded, it uses bed center plus `0.4F` along the bed-facing direction. SHA-256 values: `ClientPlayNetworkHandler.java` `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11`; `PlayerEntity.java` `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633`.

1.14.4, Ornithe Feather: the equivalent direct client input is synchronized sleeping position. `net/minecraft/entity/living/LivingEntity.java`, `onDataValueChanged`, lines 2510–2527, calls `m_57357409` for a present sleeping position; that helper sets `(blockX + 0.5, blockY + 0.6875F, blockZ + 0.5)` at lines 2734–2736. SHA-256: `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61`.

Difference: for the same loaded vanilla bed position and corresponding client sleep-state input, 1.13.2 offsets X/Z by `0.4F` toward the bed-facing direction while 1.14.4 uses the block center. The distinct incoming response values/order are paired assumptions; this finding does not infer server packet production or bed-entry eligibility.

Movement meaning: the direct local-player position write differs by `0.4` block on one horizontal axis for a bed facing along that axis. No ordinary post-sleep movement trajectory is claimed. Stable intermediate patch boundary is not established within 1.13.2–1.14.4.
