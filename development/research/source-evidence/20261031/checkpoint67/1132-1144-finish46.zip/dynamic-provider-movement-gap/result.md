# Dynamic and contextual block-shape movement gap: 1.13.2 → 1.14.4

## Scope and result

Bounded source-only inventory of direct `getShape` / `getCollisionShape` declarations whose outputs read world position, block-entity/animation state, or collision context, using the complete Feather Gen2 build 2 provider inventory (`providers/shape-provider-overrides.tsv`, SHA-256 `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad`). The inventory has 93 declarations at 1.13.2 and 115 at 1.14.4. I inspected each row's exact member body and registrations/collision gates for the input-dependent candidates; fixed state-only providers and the separately assigned state-pairing families were not re-audited.

No previously unpaired direct dynamic/context branch for a common old-era collision provider remains in this bounded roster. No new changed collision/clearance terminal is demonstrated here. This is not a blanket closure of every arbitrary moved state nested inside a moving piston, every shape provider state domain, or the full pair.

Exact sources are the read-only `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather` trees, the published Feather Gen2 build 2 pair recorded in `providers/inventory.md` (SHA-256 `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480`).

## Direct input-dependent provider roster

| Member | Endpoint inputs | Movement-facing disposition |
|---|---|---|
| 1.13.2 `ShulkerBoxBlock.getShape(BlockState, BlockView, BlockPos)` `:210–213`; 1.14.4 same with `CollisionContext` `:226–229` | World/position selects a block entity; entity progress supplies geometry. The added context is ignored. | **Covered; excluded from new work by the exact shulker pair.** Both return the same block-entity-derived box for a shulker entity and the same full-block fallback for missing/wrong entity. All 17 common registrations use dynamic shape, so live block-entity output reaches ordinary collision. See `shulker-collision-pairing/result.md` and independent recheck `shulker-dynamic-provider-independent-recheck/result.md`. No progress producer/history or trajectory was checked here.
| 1.13.2 `MovingBlock.getCollisionShape(BlockState, BlockView, BlockPos)` `:108–111`; 1.14.4 same plus context `:104–107` | World/position selects a `MovingBlockEntity`; context ignored. | **Covered; excluded by the piston reports.** The moving-piston registration is dynamic on both sides. Both wrappers delegate to the same moving-entity method or return empty if missing/wrong entity. See `piston-shape-pairing/result.md` and `moving-piston-nested-shape-closure/report.md`.
| 1.13.2 `MovingBlockEntity.getCollisionShape(BlockView, BlockPos)` `:324–352`; 1.14.4 `:332–360` | Raw extending/source/progress/no-clip inputs; nested moved-state collision query uses the supplied world/position. | **Covered wrapper; nested provider family remains conditional/open.** The wrapper expression, gates, translation and union are equal for equal inputs. Its nested `movedState.getCollisionShape(world,pos)` can select arbitrary moved-state providers, and the source reports do not assert complete state/output pairing for every movable block. This residual is not a new dynamic-method difference. See `moving-piston-nested-shape-closure/report.md`; exact remaining members are listed below.
| 1.13.2 `LiquidBlock.getShape(BlockState, BlockView, BlockPos)` `:89–96`; 1.14.4 same plus context `:86` | Old outline asks for fluid state above at `pos.up()`; newer outline is empty. | **Covered but not collision-facing.** Both `water` and `lava` registrations set `.noCollision()`, and base `Block.getCollisionShape` returns empty at the `hasCollision` gate before calling `getShape`. Therefore this world-dependent outline difference is not a player collision/clearance terminal. The exact residual provider report pairs fluid collision outputs and records the outline-only delta: `residual-23-provider-state-closure/result.md`.
| 1.14.4 `ScaffoldingBlock.getShape(BlockState, BlockView, BlockPos, CollisionContext)` `:43–47`; `getCollisionShape(...)` `:118–122` | Outline reads held-item context; collision reads above-entity and sneaking context plus raw distance/bottom state. | **Excluded new-only block.** The 1.14.4 registry adds scaffolding with `dynamicShape`; no 1.13.2 `ScaffoldingBlock` source or registration exists. The context consumer pass (`blockstate-context-pairing/result.md`) already identifies this as the only block-package context reader and explicitly excludes it from changed common old-era shape behavior.

Other new-only shape-provider declarations in the inventory (Bamboo, Bell, Composter, Grindstone, Lectern) do not have old-era counterparts; they are outside this historical common-block comparison. The specified excluded reports/families—shulker, face/stairs/slab/trapdoor/doors/fences/walls, wake/bed, chorus/current, piston and cauldron—were consulted only to prevent repetition, not re-paired here.

## Exact remaining unexamined members

No common-era direct `getShape` or `getCollisionShape` member that reads world/position/context/block-entity or animation state remains unexamined within this assigned inventory. The remaining open dependency is broader and conditional: the arbitrary nested moved-state provider selected by `MovingBlockEntity.getCollisionShape` through:

- 1.13.2 `net/minecraft/block/state/BlockState.java`, `getCollisionShape(BlockView, BlockPos)` (`:209–210`), invoked from `MovingBlockEntity.getCollisionShape`.
- 1.14.4 `net/minecraft/block/state/BlockState.java`, `getCollisionShape(BlockView, BlockPos)` (`:197–203`), invoked from `MovingBlockEntity.getCollisionShape`; dynamic providers receive empty context on this nested no-context route, while static results may use their empty-context cache.

The pair's existing reports expressly leave every not-listed registered moved-state/provider combination open. This assignment does not reproduce that larger state/registration inventory. The earlier exact cauldron/nested-piston witness is excluded from this assignment. Excluded candidate families are not considered open members of the direct dynamic/context roster.

## Evidence hashes

SHA-256 values are complete Java-file hashes, relative paths are within each endpoint's `ornithe-feather` root.

| Endpoint | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/ShulkerBoxBlock.java` | `9d2652c2944cc8faf1a277349fbf2015170a4799ad882f876d24ee1d7f344fb8` |
| 1.14.4 | `net/minecraft/block/ShulkerBoxBlock.java` | `016487146bc14aba8de02272e0bf5c76b4dff16c276abf30bf92cfa3061593df` |
| 1.13.2 | `net/minecraft/block/entity/ShulkerBoxBlockEntity.java` | `d123b08d4d3562ccb972a4433ec5a743cdd6877c59c5b6aa20d06af2063fa5ed` |
| 1.14.4 | `net/minecraft/block/entity/ShulkerBoxBlockEntity.java` | `58b5e9f68831f6e3a3d293ae29c8c0c55628fc5a8d941e18286eb10ec7c0ba73` |
| 1.13.2 | `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` |
| 1.14.4 | `net/minecraft/block/MovingBlock.java` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |
| 1.13.2 | `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` |
| 1.14.4 | `net/minecraft/block/entity/MovingBlockEntity.java` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |
| 1.13.2 | `net/minecraft/block/LiquidBlock.java` | `feedc9a5f1843604e6755a447e89d8d5599613799e25cf8c93a0562e52e97856` |
| 1.14.4 | `net/minecraft/block/LiquidBlock.java` | `bfbbe2997ce6c03224b5833176d6b19b4b4b4cbc3337960fb3d867de77519ca1` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `net/minecraft/block/ScaffoldingBlock.java` | `4b22b178d03266296d715c1b7208f347b879ae24ba55da01a2c1e4983168e64c` |

Input report hashes: `providers/inventory.md` `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480`; `providers/shape-provider-overrides.tsv` `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad`; `blockstate-context-pairing/result.md` `69d4acd6633e402225b9ca3d1c14178842153bf77e6d0e67ab03007ba21341c4`; `shulker-collision-pairing/result.md` `e39bd80f80271c48560f0c85d17531be25f847f58b484809481e2e757d84e3de`; `piston-shape-pairing/result.md` `1f288c9c75a144a84b3ccbff70939114807e0add8c551586ce70659c1f46010e`; `moving-piston-nested-shape-closure/report.md` `d6033b942ad5c22cbf9eef4c109ef7a0d9116e69add337714ed56c66917fd640`; `residual-23-provider-state-closure/result.md` `3de5b5bddad70ac2aa02c6120c7bc4c47f885b1626ddc002ea5b01a7533bc111`.

No product, wiki, backlog, or Git data was read. No source was written, regenerated, or decompiled. No tests, build, runtime, or trajectory verification was performed.

