# Auto-jump query terminal expansion v2: 1.13.2 → 1.14.4

## Scope and result

Source-only expansion of the callback/query residual in `autojump-callback-terminal/report.md`. Compared exact Minecraft 1.13.2 → 1.14.4 Ornithe Feather Gen2 build 2 sources. The input domain here is paired raw callback/player values, block states, query results and collision candidates; this report makes no trajectory or producer-history claim.

The full-cube/air fixture in the prior report remains closed only for its stated one-candidate setup. This pass traces all `autoJump` shape-query sites and the callback's collision-query candidate branches to the movement-facing scheduled-jump write. It does **not** close equality over the full movement query domain: contextual providers, missing-chunk fallback behavior, collision candidate ordering/contents, and border/entity candidates can feed distinct first-hit and clearance paths. Structural query differences alone do not establish a changed scheduled output for every differing query result.

## Exact endpoint identity

The read-only endpoint markers identify 1.13.2+build.2 and 1.14.4+build.2, `ornithe-feather`, with mapping jars `feather-gen2-1.13.2+build.2-mergedv2.jar` / `.tiny` and `feather-gen2-1.14.4+build.2-mergedv2.jar` / `.tiny`. Both ready markers specify Vineflower and Java 25. The source-manifest hashes were recomputed from the manifest files and match the ready records; the artifact-manifest hashes also match.

| Endpoint | Source manifest SHA-256 | Artifact manifest SHA-256 |
|---|---|---|
| 1.13.2 | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `fdcacd9150f98ea70acafc5cab754027ab1a09828ff0eaa8e542dd7890d9ce1e` |
| 1.14.4 | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | `308cc33ef6dffc047432ade6affc88eccc9de94a736ee9a98571fd92915c2970` |

Canonical sources are at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Source-file hashes below were recomputed read-only. Excerpt hashes use the listed 1-based lines joined with LF, UTF-8, without a terminal LF.

| Endpoint | Source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.14.4 | `net/minecraft/world/WorldAccess.java` | `f57639756acdedbd0e5a598f7740a8e17f0dc3b2ba710aa4690d05f4f3bcd746` |
| 1.13.2 | `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` |
| 1.14.4 | `net/minecraft/world/EntityView.java` | `3822844ced53882c52f0523a1bd714baa3cd9bb9dab38a5e2c53051c7b1590e3` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

| Endpoint | Excerpt | SHA-256 |
|---|---|---|
| 1.13.2 | `LocalClientPlayerEntity.autoJump`, `882–980` | `b6e4c904937d60167272aa8cb500c0656ed92a7cccd79545597154c3f20998a6` |
| 1.14.4 | `LocalClientPlayerEntity.autoJump`, `857–955` | `be38812c94537a5a66f8436965550de085619ba303aa285b7b06884f19d4a281` |
| 1.13.2 | `WorldView.getBlockCollisions`, `112–151` | `3e796782af119a76ebd3e037b05aa4e4281b85bd1c0116f47bbad47188b09927` |
| 1.14.4 | `WorldView.getEntityCollisions` and `getBlockCollisions`, `125–185` | `51ab72b9f028d3ca9d4f000040d810f48e1df898e1d6c28ccce8e0439e72ec32` |
| 1.13.2 | `EntityView.getEntityCollisions`, `21–36` | `c20eebba987bc892d91af7861a90bd9c8a682052930dd25ef3ecceb73ed2390a` |
| 1.14.4 | `EntityView.getEntityCollisions`, `53–67` | `7211ec628c5b7c649d2504898a18b82660557ffa814c3f84f419bea013b019ca` |

This report used the source-only callback and collision-candidate reports for their established endpoint identity and call-path context, not product, wiki, backlog, or Git evidence.

## Callback branches and terminal dataflow

The paired scalar gates and projected geometry remain as listed in the prior callback report. When they pass, both methods first query the player's block at `(x, getShape().maxY, z)` and then the block one cell above it. Empty shapes are required at both positions. The old calls are context-free (`LocalClientPlayerEntity.java:909–915`); the new method constructs one `CollisionContext.of(this)` after the facing test and passes it to both calls (`:884–890`).

Both methods then build the same swept query box conditional on equal effective speed, dimensions, positions and fallback direction. They form two raised probe segments, enumerate candidate boxes, and accept the **first** `box2` intersecting either segment (`old :935–965`, `new :911–944`). For that box, they set `s = box2.maxY` and derive `blockPos2` from its center. The loop visits integer `t` values while `t < o`, where `o` is the 1.2-block base limit plus any jump-boost extension. At each step it may replace `s` with the maximum Y of a queried collision shape above the candidate center; if the resulting rise exceeds `o`, it returns immediately. At `t > 1`, another context-free/contextual shape query can return immediately on any nonempty obstruction. After the first intersecting candidate's clearance loop, the callback breaks from candidate iteration. Only if `s` was set and `0.5F < (float)(s - getShape().minY) <= o` does it write `ticksToNextAutojump = 1` (`old :968–972`; `new :947–951`). The next `mobTick` consumes that scheduled state by setting `input.jumping = true` (`old :711–715`; `new :639–643`, as paired in the predecessor report).

Thus provider emptiness controls entry and early returns; candidate presence/order controls which top and center are selected; and above-center shape output can override that top or reject the callback. Equal candidates are insufficient to close the terminal unless the context-sensitive shape answers at every reached lookup are also equal.

## Query branches feeding the callback

### Block providers and collision context

The old collision scan invokes `BlockState.getCollisionShape(world,pos)` without entity context (`WorldView.java:135`); the new scan computes `CollisionContext.of(entity)` once and supplies it to each provider (`WorldView.java:140,172`). The newer direct `autoJump` checks and clearance checks likewise supply the same player context. The base 1.14.4 `Block.getCollisionShape(..., context)` forwards to the state's shape behind the `hasCollision` gate (`Block.java:376–378`), but this base case does not prove equality for overrides, contextual provider behavior, or every state/neighbor input. The prior fixture pairs only a base full cube and air.

For any callback lookup where paired old/new provider results differ in emptiness, top Y, or returned candidate shape, the result can change whether the callback proceeds, which `s` is retained, whether the loop returns, or whether the scheduled-jump interval is met. That is a conditional dataflow statement, not a demonstrated differing result for a named common-era block. Provider membership and provider outputs outside the prior fixture remain open. A new-only provider/state cannot alone establish an old-profile movement difference.

### Block scan membership and candidate order

In 1.13.2, the block scan computes floor/ceil bounds expanded by one cell, skips selected corner cells, checks `isChunkLoaded(pos)`, then uses the state collision shape. Non-full shapes are translated and emitted in mutable region order; unit cubes are accumulated into a voxel set and emitted later as one `IntVoxelShape` (`WorldView.java:112–151`). In the 1.14.4 callback route, the scan computes bounds using `floor(min−1e-7)−1` and `floor(max+1e-7)+1`, uses a cursor with position-category filters, asks for a non-loading `FULL_CHUNK` via `getChunk(..., false)`, applies `hasLargeCollisionShape` / moving-block filters for some categories, and emits each overlapping translated shape as the cursor advances (`WorldView.java:133–185`, collision status `World.java:874–877`). It has no final aggregate full-cube output.

Consequences for this callback are specifically unresolved at: a missing/non-loading chunk cell; any context-sensitive or dynamically supplied block shape; and query sets with multiple candidates whose order/shape decomposition differs. The first-intersecting-box rule can select a different `maxY` or center, but it can also converge to the same final `s` after the clearance lookup. The source establishes the branch and its consumer, not a scheduled-output witness for every membership/order delta. The prior single-cube interior fixture remains valid and is not generalized.

### Entity candidates

Both endpoints include an entity collision stream for this world callback, so it would be incorrect to treat 1.14.4's `getCollisions` as block-only. In 1.13.2, `World.getCollisions` appends `getEntityCollisions` after block candidates (`World.java:1754–1757`). `EntityView.getEntityCollisions` uses a `0.25` broad-phase expansion, then filters candidate collision shapes against the original query bounds (`EntityView.java:21–35`). In 1.14.4, `WorldView.getCollisions` concatenates block candidates then `getEntityCollisions` (`WorldView.java:129–131`); `WorldAccess` forwards to `EntityView`, which uses a `1e-7` query expansion and tests entity and mover-provided collision shapes against that expanded box (`EntityView.java:53–67`; `WorldAccess.java:74–77`). Both exclude explicitly excluded entities and same-vehicle entities and flatten accepted shapes in stream order.

The broad-phase and final intersection domains are not identical. That can alter callback candidates only for a candidate whose query bounds/collision shape distinguish those predicates; broad-phase list differences alone do not prove a terminal difference. If an entity candidate becomes or ceases to be the first intersecting probe candidate, its box top/center enter the same `s` and clearance path described above. No entity-specific auto-jump output witness is asserted in this report.

### World-border candidate

The 1.13.2 route updates `outsideWorldBorder` hysteresis and lets the block scan substitute unit cubes for enumerated out-of-border positions when its border gate permits (`WorldView.java:170–177,119–145`). The 1.14.4 block scan does not substitute those cubes; it seeds a border collision shape when the entity's contracted shape misses the border but the expanded shape overlaps it (`WorldView.java:150–156`), before scanning blocks. These routes can feed a candidate box into the callback's first-hit loop under border-adjacent raw inputs. Whether it intersects either raised probe, what first box follows it, and whether the resulting `s` survives clearance remain query-specific. The deep-interior fixture excludes this branch; no border-output witness is claimed.

## Coverage and residuals

| Conditional branch | Movement-facing path | Disposition |
|---|---|---|
| Initial headroom provider calls | Empty/nonempty answer gates all subsequent work | Paired only for base cube/air in the prior report; other context/provider outputs open |
| Collision candidate inclusion | Candidate boxes enter first-intersecting-box loop | Different scan/chunk/context predicates identified; output witness not closed generally |
| Candidate decomposition/order | First accepted box supplies `maxY` and center | Old aggregate full-cube stream versus new per-shape emission identified; downstream branch equality open |
| Entity candidate query | Entity boxes may enter the same first-hit loop | Both versions include entities; query predicates differ near their distinct broad-phase/intersection bounds; specific terminal effect open |
| Border candidate | Border shape or substituted cells may enter first-hit loop | Routes differ; border-adjacent callback output remains open |
| Above-center and overhead clearance | Can replace `s` or return before scheduling | Contextual calls paired structurally; equal answers outside prior fixture not established |
| Scheduled jump | `ticksToNextAutojump = 1`, then next `mobTick` forces `input.jumping` | Same terminal code; its query-derived precondition remains conditional |

No new independent finding or ordinary trajectory claim is made. This closes a more detailed source-to-terminal branch inventory but does not close the callback query domain, freeze the pair, or establish runtime parity. No source tree was written; no build, test, game launch, decompile, implementation, or network access was performed.
