# Independent residual 23 provider/state recheck

## Verdict

Closed the assigned 551-row check against the exact 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 sources, under equal raw state and provider-query inputs. I found no residual collision-shape or movement-facing sturdy-face mismatch. The outline-only differences recorded in the source-lane lead remain excluded from collision by matched `noCollision()` registration gates. This does not establish raw-state production, fluid/tag payload history, callback timing, trajectories, or producer behavior.

## Independent census and mechanical checks

I parsed `../residual-23-provider-state-closure/state-coverage.tsv` as a lead roster and independently checked state cardinality, duplicate raw tuples, endpoint source hashes, and formula classes against source. It contains 551 unique `(id, raw_state)` pairs across 23 IDs: 512 colored-pane states (16 IDs × 32), two bubble-column states, three propertyless IDs (`cave_air`, `end_portal`, `structure_void`), 32 liquid states (water/lava × 16), and two nether-portal states. There are no duplicate state tuples. The 16-row source hash table contains 31 actual endpoint file hashes (the old-only GlassPaneBlock has no new-side counterpart); all 31 recomputed hashes match the tabulated value and source manifest.

For all 512 pane rows, I recomputed the `PaneTable` selector from the four raw horizontal connection flags (`N=4`, `E=8`, `S=1`, `W=2`). Both endpoints select the same table entry; `WATERLOGGED` is not read by the geometry selector. Each matched table is the central post plus the selected full-height arms. Every collision output equals its outline shape in the table, and the new full-face sturdy predicate is false for all six directions. The old face provider returns `MIDDLE_POLE_THIN` horizontally and `CENTER_SMALL` vertically, neither `SOLID`. Pane geometry parameters and inherited providers are identical across the 16 dye registrations; waterlogged fluid output is source water iff the paired state says `WATERLOGGED=true` on both endpoints.

For the remaining 39 rows (bubble 2, propertyless 3, liquids 32, portal 2), direct source inspection paired the state domains and formulas. Every corresponding block has `hasCollision=false` from its registration, and both base collision dispatches short-circuit to empty. The legacy direct face result is `UNDEFINED` for these providers; the new face-sturdy result from empty collision is false. State-sensitive outlines that are not used as collision are:

- `bubble_column`: old inherited full cube, new empty, both DRAG states; the direct entity-collision callback formula and source-water getter match for equal inputs.
- `cave_air`: empty on both.
- `end_portal`: same fixed `[0,0,0]..[16,12,16]` footprint on both.
- `nether_portal`: same `AXIS=X` z-slab `[0,0,6]..[16,16,10]`, and `AXIS=Z` x-slab `[6,0,0]..[10,16,16]`, on both.
- `structure_void`: same fixed `[5,5,5]..[11,11,11]` box on both.
- water and lava: old outline is a full cube when the above-cell fluid is the same liquid, otherwise a base-to-height box from the equal `LEVEL`-derived fluid state; new outline is empty. At all 16 levels and for both IDs, collision remains empty due to the registration gate. Both constructors map LEVEL 0 to source, levels 1–7 to `asFlowing(8-level,false)`, and levels 8–15 to `asFlowing(8,true)`; fluid lookup clamps level to 8.

No collision context, neighboring connection state, block-entity state, or dynamic-shape condition changes these paired results: the pane provider reads only connection bits; the non-pane providers in this roster are non-dynamic and their collision path short-circuits before outline evaluation. The row inputs treat effective memberships and upper-cell query results as equal assumptions.

## Exact source trail

Read-only endpoints:

- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather`
- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather`

Relevant exact files include `Block.java`, `Blocks.java`, `BlockState.java`, `PaneBlock.java`, `GlassPaneBlock.java` (old only), `StainedGlassPaneBlock.java`, `IronBarsBlock.java`, `BubbleColumnBlock.java`, `AirBlock.java`, `EndPortalBlock.java`, `PortalBlock.java`, `StructureVoidBlock.java`, `LiquidBlock.java`, `FlowingFluid.java`, and `Properties.java`. Source manifest hashes and publication identities are recorded in the paired lead inventory at `../providers/inventory.md`; the source-file hashes were independently recomputed for all 31 existing file/endpoint entries.

No canonical files, product/wiki/backlog material, or shared-root Git state were read or changed. No builds, tests, game launches, or decompilation were run.
