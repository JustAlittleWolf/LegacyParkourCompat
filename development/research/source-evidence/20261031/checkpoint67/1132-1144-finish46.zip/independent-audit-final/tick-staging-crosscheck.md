# Independent tick-staging crosscheck

## Exact-source verification

I checked each method range and normalized body hash listed in `ordinary-tick-staging-full-pair/result.md` against the exact Feather source files. The report's normalization rule (body interior, strip comments and whitespace, UTF-8 SHA-256) reproduces **all 24 listed endpoint method hashes exactly**, including the corrected 1.14.4 `LivingEntity.tick` digest `ff78ea67a775733a7be197f112fd847a3e57134cd9391faa6cca70f6b4b9662f` from `LivingEntity.java:1979–2123`.

All seven tick report source-file hashes were also recomputed and matched their endpoint `ornithe-feather.sources.sha256` manifests: `Minecraft.java`, old `World.java`, new `ClientWorld.java`, `LocalClientPlayerEntity.java`, `PlayerEntity.java`, `LivingEntity.java`, and `Entity.java`. For the lava crosswalk, I separately verified the paired `LiquidBlock.java`, `FluidTagsProvider.java`, and `LivingEntity.java` hashes against those same manifests. The corrected tick report artifact hashes to `059B0225637C69883E0B4DC8AB5AE6547AC777B55E2A600872AEFE868AF7092F`.

## Call order and movement terminals

Direct source inspection confirms the report's eligible local path and order on both endpoints:

1. `Minecraft.tick` calls `world.tickEntities`; the endpoint-specific client/world dispatcher gates and ticks the in-chunk local player.
2. `LocalClientPlayerEntity.tick` calls `super.tick`. `PlayerEntity.tick` calls its superclass and runs `updatePlayerPose` after inherited living/entity tick work.
3. `LivingEntity.tick` calls virtual `mobTick`; dispatch enters the local-client override, whose ordinary path stages local control state before `PlayerEntity.mobTick`/`LivingEntity.mobTick`.
4. `LocalClientPlayerEntity.serverTickAi` copies `input.movementSideways`, `input.movementForward`, and `input.jumping` to entity fields before jump handling. `LivingEntity.mobTick` then evaluates jump gates and calls `moveRelative`; the eligible travel branch eventually calls `Entity.move(SELF, ...)`.

This crosswalk covers ordering from the driver through the ordinary movement entry, with keyboard/device acquisition and raw logical-input production treated as assumptions. It does not close collision resolution or the other partial provider/response edges recorded in `audit-crosswalk.md`.

The new `LivingEntity.tick` tail conditionally writes `pitch = 0.0F` when sleeping. I classify this as a conditional rotation-state write only. This slice supplies no consumer showing that this tail assignment changes an eligible movement terminal, so it is not counted as a movement finding.

## Lava-state sample and callback link

The old `Entity.isInLava` body queries the current contracted entity box for lava material. The new body returns stored contact state. New `Entity.move` clears that flag immediately before `checkBlockCollisions`; the new `LiquidBlock.onEntityCollision` sets it when the liquid is in the default LAVA tag. The next local tick reaches `LivingEntity.mobTick`, whose jump and travel selection read `isInLava`; `LivingEntity.moveRelative` uses the result to select lava versus dry travel. The old route samples live material at those reads instead. Exact default LAVA membership is paired by `FluidTagsProvider.addTags` (source/flowing lava on both endpoints).

This links the tick-staging reader to the already bounded lava callback movement-terminal report (`liquid-callback-movement-terminal/result.md`): under its fixed box/tag/contact inputs, the sources produce different lava-route inputs. The result is a conditional route-selection difference only; it does not show how a player or lava state was produced, establish callback timing in an arbitrary world, claim damage/fire behavior, or give a final trajectory.

## Disposition

The ordinary tick-staging source edge is closed for the listed method chain and exact method bodies, subject to the one correctable digest typo above. This does not change the pair-wide verdict: resolver/candidate ordering, remaining provider/context outputs, and remaining callback/support/client-response terminals are still open as recorded in the parent crosswalk.
