# Remaining common stair collision-shape tranche: 1.13.2 → 1.14.4

## Scope and result

This source-only tranche closes the common vanilla `StairsBlock` registrations other than `oak_stairs`, which is already fully paired in `../common-block-shape-pairing/result.md`. The exact provider-manifest/report diff showed one common direct provider declaration (`StairsBlock.getShape`) per endpoint; the existing oak report covers only `oak_stairs`, while the separate stair face/fluid witness does not pair the remaining stair collision outputs. This pass pairs all 16 other common IDs and every raw property tuple: 16 registrations × 80 tuples = 1,280 rows in [`states.tsv`](states.tsv). Registry IDs and source line numbers are in [`registrations.tsv`](registrations.tsv).

Every row selects the same old/new outline and collision shape. This is a provider result pairing for identical raw states. It makes no claim that every `SHAPE` tuple is reachable from a given neighbor arrangement, and it is not a trajectory, implementation-applicability, or pair-freeze claim.

## Exact common registrations and state domains

The registrations are `acacia_stairs`, `birch_stairs`, `brick_stairs`, `cobblestone_stairs`, `dark_oak_stairs`, `dark_prismarine_stairs`, `jungle_stairs`, `nether_brick_stairs`, `prismarine_brick_stairs`, `prismarine_stairs`, `purpur_stairs`, `quartz_stairs`, `red_sandstone_stairs`, `sandstone_stairs`, `spruce_stairs`, and `stone_brick_stairs`. The old IDs are registered as `StairsBlock` in `net/minecraft/block/Block.java`; the new IDs are registered as `StairsBlock` in `net/minecraft/block/Blocks.java` at the paired lines listed in `registrations.tsv`. All 16 IDs occur in both registries. `oak_stairs` is excluded here because it is the existing paired registration.

Both endpoint `StairsBlock.buildStateDefinition` methods add `FACING`, `HALF`, `SHAPE`, and `WATERLOGGED` (`1.13.2 StairsBlock.java:330–331`; `1.14.4 StairsBlock.java:283–284`). The paired state domain is horizontal `FACING={NORTH,EAST,SOUTH,WEST}`, `HALF={BOTTOM,TOP}`, `SHAPE={STRAIGHT,INNER_LEFT,INNER_RIGHT,OUTER_LEFT,OUTER_RIGHT}`, and `WATERLOGGED={false,true}`: 4×2×5×2 = 80 raw tuples per registration. The enum order for `StairShape` and `StairHalf` matches across endpoints. The `Direction.getIdHorizontal()` values consumed by the provider are N=2, E=3, S=0, W=1 in both endpoint enum constructors.

Every registration constructs the same `StairsBlock` class with copied properties from its corresponding ordinary solid base block. `Block.Properties.copy` carries the base block's `hasCollision` bit (`1.13.2 Block.java:1925–1940`; `1.14.4 Block.java:836–850`); the base property default is collision-enabled (`:1901` old; `:811` new), and these stair registrations do not call `noCollision`. Base collision dispatch therefore reaches the stair `getShape` result in both endpoints (`1.13.2 Block.java:393–395`; `1.14.4 Block.java:376–378`). The paired movement query can consume that collision output for clipping, step alternatives, and clearance checks.

## Provider body and state-by-state output selectors

The exact provider rows are the single `StairsBlock.getShape` declarations in `providers/shape-provider-overrides.tsv`: 1.13.2 `StairsBlock.java:99`, 1.14.4 `StairsBlock.java:99`. The endpoint method signatures differ by the added `CollisionContext` argument, but both return the same expression:

`(HALF == TOP ? TOP_SHAPES : BOTTOM_SHAPES)[SHAPE_INDICES[getShapeIndex(state)]]`

Both `getShapeIndex` bodies compute `SHAPE.ordinal() * 4 + FACING.getIdHorizontal()`. Both endpoint index tables are `{12,5,3,10,14,13,7,11,13,7,11,14,8,4,1,2,4,1,2,8}`. `WATERLOGGED` is ignored. Neither endpoint reads the supplied world or position; the new method also ignores `CollisionContext`.

For each raw tuple, `states.tsv` records the exact shape ordinal, horizontal direction ID, intermediate `getShapeIndex`, selected `SHAPE_INDICES` mask, and all four old/new outline/collision selectors. Both endpoints construct `TOP_SHAPES` and `BOTTOM_SHAPES` over masks 0–15 from the same base half-cube and quadrant pieces, OR-ing quadrants in the same NW, NE, SW, SE order. The box coordinates in sixteenths are:

- TOP base `(0,0,0)–(16,8,16)`; BOTTOM base `(0,8,0)–(16,16,16)`.
- NW quadrant `(0,0,0)–(8,8,8)` for TOP and `(0,8,0)–(8,16,8)` for BOTTOM.
- NE quadrant `(8,0,0)–(16,8,8)` for TOP and `(8,8,0)–(16,16,8)` for BOTTOM.
- SW quadrant `(0,0,8)–(8,8,16)` for TOP and `(0,8,8)–(8,16,16)` for BOTTOM.
- SE quadrant `(8,0,8)–(16,8,16)` for TOP and `(8,8,8)–(16,16,16)` for BOTTOM.

The previously paired oak report independently details and compares this shared table construction and VoxelShapes union path. Here, every remaining registration invokes that same class/provider; no per-registration geometry override or context branch exists. Old base collision returns the selected state shape. New base collision requests the state's context shape with `CollisionContext.empty()`; the movement collision route can also provide an entity context, but this stair method ignores it. New static state caching therefore stores the same selector output as direct context dispatch for these providers.

## Exact source identity and hashes

Canonical roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Feather Gen2 build 2. The endpoint source-manifest, ready-marker, and provenance file hashes below were recomputed from their exact endpoint artifacts and match the existing pair inventory (`../providers/inventory.md`, SHA-256 `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480`).

| Identity artifact | SHA-256 |
|---|---|
| 1.13.2 `ornithe-feather.sources.sha256` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |
| 1.13.2 `ornithe-feather.ready.json` | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` |
| 1.13.2 `ornithe-feather.provenance.json` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` |
| 1.14.4 `ornithe-feather.sources.sha256` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` |
| 1.14.4 `ornithe-feather.ready.json` | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` |
| 1.14.4 `ornithe-feather.provenance.json` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` |

Relevant complete Java-file hashes (SHA-256):

| Relative source | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/StairsBlock.java` | `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` | `b49cbd43a9be5e848623f25769dede5795f50435ba0e82bbdbbf571527396b9f` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| Registry: `Block.java` / `Blocks.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/state/StateDefinition.java` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` | `d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/block/state/property/StairShape.java` | `1f67c3ff79edc82d93be6ad553fd198cdd031277571fb7342a926c979f4236b3` | `1f67c3ff79edc82d93be6ad553fd198cdd031277571fb7342a926c979f4236b3` |
| `net/minecraft/block/state/property/StairHalf.java` | `ef1627ddd414bdf6ceeebe634b56799b9a7203ca4d61f943a794f1aa1e4c7381` | `ef1627ddd414bdf6ceeebe634b56799b9a7203ca4d61f943a794f1aa1e4c7381` |
| `net/minecraft/util/math/Direction.java` | `6d5c496ff65377fee9f00c826e48c7be14d3889e5ae5191e110a464007549082` | `121f8b78eda07640eccbe369f40acc7ccbdcb275dcb6aca87c4495cd193b01c0` |

The source provider inventory SHA-256 is `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad`. The existing oak pairing report SHA-256 is `98a6b71058a7ddfd5bc5f06e4f14cdaf5ce1fd63869a6cf0443fba0162a50fa9`; the stair fluid-face boundary report SHA-256 is `6734efee052e65cb48815b95a1a2c03f1ac0e14e429734aa8cbd285d2d990311`.

## Exact residuals and limits

- `oak_stairs` is the only common stair registration excluded from this table; its 80 raw tuples are already closed in `../common-block-shape-pairing/result.md`.
- These 14 `StairsBlock` registrations exist only in 1.14.4 and have no old common registration to pair: `andesite_stairs`, `diorite_stairs`, `end_stone_brick_stairs`, `granite_stairs`, `mossy_cobblestone_stairs`, `mossy_stone_brick_stairs`, `polished_andesite_stairs`, `polished_diorite_stairs`, `polished_granite_stairs`, `red_nether_brick_stairs`, `smooth_quartz_stairs`, `smooth_red_sandstone_stairs`, `smooth_sandstone_stairs`, and `stone_stairs`.
- `SHAPE` is a raw input here. The neighbor/placement/update paths that produce it were not paired; neither were custom registrations or runtime histories that might choose among the 80 rows.
- Other provider classes and non-stair registrations in `providers/shape-provider-overrides.tsv` remain outside this tranche, as do independent collision-candidate, border, and chunk terminals already scoped by their separate reports.

No product, wiki, backlog, or Git data was read or changed. Neither canonical source tree was written or regenerated. No build, test, game, server, decompile, or trajectory analysis was run.
