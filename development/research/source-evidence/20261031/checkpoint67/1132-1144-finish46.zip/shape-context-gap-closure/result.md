# Support-predicate caller closure: 1.13.2 → 1.14.4

## Scope and disposition

This bounded source-only pass paired the new 1.14.4 `Block.canSupportBase` / `canSupportCenter` helpers against their concrete old support checks, then traced every exact helper caller. The helper/caller changes feed block placement, survival, and neighbor-removal state updates. They do not feed an eligible local-player movement terminal when the same valid old-era block states are held fixed. Classify this as block-state production excluded from the movement comparison; it is not an accepted movement finding and does not close shape/query coverage or pair freeze.

Sources are the published Ornithe Feather Gen2 trees for Minecraft 1.13.2 and 1.14.4. Each listed source-file SHA-256 was recomputed and matches its version-root `ornithe-feather.sources.sha256` manifest entry. The trees were read only. No product, wiki, backlog, or Git data was consulted. No source was generated or written; no tests, build, game, runtime, or decompile was used.

## Exact paired methods and provider identity

| Source member | 1.13.2 | 1.14.4 |
|---|---|---|
| `Block.canSupportBase` / `Block.canSupportCenter` | No corresponding helper exists. | `net/minecraft/block/Block.java:390–401`; both read the world state, reject active `BlockTags.LEAVES`, and test support using the state's collision-shape face against `BASE_SUPPORT_SHAPE` or `CENTER_SUPPORT_SHAPE` with `BooleanOp.ONLY_SECOND`. |
| Pressure-plate base survival | `AbstractPressurePlateBlock.canBePlaced`, `:53–56`: below-state `isFullBlock()` or `FenceBlock`. | `AbstractPressurePlateBlock.canBePlaced`, `:49–52`: `canSupportBase(below) || canSupportCenter(below, UP)`. `updateShape` removes the pressure plate when `canSurvive` is false (`:43–46`). |
| Rail base/ascending support | `AbstractRailBlock.canBePlaced`, `:55–57`, and `neighborChanged`, `:76–89`: `isFullBlock()` at below/ascending-adjacent cells. | `AbstractRailBlock.canBePlaced`, `:45–47`, and `neighborChanged`, `:64–91`: corresponding cells use `canSupportBase`; failed support removes/drops the rail (`:88–90`). |
| Diode support | `DiodeBlock.canBePlaced`, `:37–39`: below-state `isFullBlock()`. | `DiodeBlock.canBePlaced`, `:34–36`: `canSupportBase` below. |
| Torch support | `TorchBlock.canBePlaced`, `:40–52`: explicit fence, stained glass, glass, two cobblestone-wall IDs, or `isFullBlock`, with an end-gateway exclusion. | `TorchBlock.canBePlaced`, `:36–38`: `canSupportCenter(below, UP)`. Its `updateShape` uses that placement predicate to remove it when the DOWN neighbor changes (`:27–33`). |
| Lantern support | No paired 1.13.2 lantern member; it is a later-era block. | `LanternBlock.canBePlaced`, `:61–64`, routes its hanging-or-floor attachment face through `canSupportCenter`; `updateShape` uses `canSurvive` to remove it (`:72–75`). |

Relevant file hashes (and manifest matches):

- 1.13.2 `Block.java`: `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4`
- 1.14.4 `Block.java`: `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5`
- 1.13.2 `AbstractPressurePlateBlock.java`: `c920500d5b908f6f516e04b6c312ba7c848c3cfa97b24d3427ccf10d2b0de701`
- 1.14.4 `AbstractPressurePlateBlock.java`: `23fa38e232fd91a736ae79c8d038c317707b72a2f312467efbacca42b903b1c3`
- 1.13.2 `AbstractRailBlock.java`: `ef89230726ce9bd5ebb009d9332da90969d074762fc7eca8d477640d020a0a8d`
- 1.14.4 `AbstractRailBlock.java`: `9f889ccea3e80c29fe4c5ac97c6713b5e40878eeaf5ffadd71918572a4fff70a`
- 1.13.2 `DiodeBlock.java`: `972925eff56fcaa0f1f00662679c12505a3e64dc79b24996d26110ec14b8608b`
- 1.14.4 `DiodeBlock.java`: `54b3f2984c4b26a25e183fc8e958bfdbcdc66ca8950b78847aa1040faf2494a8`
- 1.13.2 `TorchBlock.java`: `da11308e51f57ce95764f2ee645dde8d15607914a3a68bac9c0635ab3d1531e0`
- 1.14.4 `TorchBlock.java`: `8430a1058184d9e87596d5ba961ce092e6c77469c642f50e5c901db1a0588aab`
- 1.14.4 `LanternBlock.java`: `c14948e5aff219b8a91da5c8b16596a6236ca089a1a8a46b276921767bdf346d`

## Caller census and movement boundary

A full `rg` search of the 1.14.4 Feather `net/minecraft` source found all `canSupportBase` and `canSupportCenter` references:

- `canSupportBase`: `AbstractPressurePlateBlock`, `AbstractRailBlock` (placement and its support-driven `neighborChanged` checks), and `DiodeBlock`.
- `canSupportCenter`: `AbstractPressurePlateBlock`, `TorchBlock`, and the new-only `LanternBlock`.
- No player/entity movement, collision-query, travel, or direct response method calls either helper.

The old caller equivalents likewise reside only in those corresponding block classes: below/side `isFullBlock`, pressure-plate `isFullBlock || FenceBlock`, and torch's explicit support type list. The observed helper output difference can change whether those blocks may be placed or survive neighbor updates, which is a block-state production effect excluded by the assignment's equal-valid-state comparison. Lantern is not an old-era state. For already-present pressure plates, rails, diodes, or torches, movement-facing consumers read the resulting state's collision/shape/query behavior; they do not re-run these support checks. Therefore there is no eligible fixed-state movement output to accept from this helper change.

The 1.14.4 helper's LEAVES exclusion uses the vanilla default tag recipe already verified in the lane's separate tag-provider closure; runtime/custom tag replacement remains excluded. This pass does not infer shape outputs for every property state from the support call-site inventory.

## Residuals

This closes only the helper's direct caller scope and classifies it as a block-state producer. It does not close all 1.13.2/1.14.4 shape providers, player collision candidate enumeration, support/step outputs consumed directly by player movement, entity/border/chunk candidates, or any pair-level audit requirement. No intermediate cutover is claimed.
