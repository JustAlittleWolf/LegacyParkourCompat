# Rail, redstone, attachment, and torch shape pairing: 1.13.2 → 1.14.4

## Scope and result

Paired common vanilla registrations for rails, diodes, redstone wire, lever, pressure plates, buttons, and upright torches. Existing `climb-trigger-shapes/comparison.md` already covers `wall_torch` and `redstone_wall_torch`; I reused it and did not recalculate those outputs. Same block ID/property state is compared at both endpoints. All new `CollisionContext` arguments are ignored. Outputs may select geometry from the raw state as listed below, but the compared methods do not read world or position.

**No difference found** in the paired raw-state outline shape formulas. Only the `repeater` and `comparator` IDs in this batch have collision enabled and supply these boxes to local-player collision queries; their shared DiodeBlock collision box is exactly the same 16×2×16 cuboid at both endpoints. Rails, redstone wire, lever, pressure plates, buttons, torches, and redstone torch are explicitly registered with `noCollision()` at both endpoints, so their outline shape results do not enter the player block-collision stream through the base `Block.getCollisionShape` gate. Their output formulas are included to close this provider slice, not to claim player collision behavior from those outline boxes.

## Registration and state coverage

Old registrations are in 1.13.2 `net/minecraft/block/Block.java`; new registrations are in 1.14.4 `net/minecraft/block/Blocks.java`. The 26 common IDs covered here are:

- Rails: `rail`, `powered_rail`, `detector_rail`, `activator_rail`. The last three use `PoweredRailBlock` for powered and activator rails, and `DetectorRailBlock` for detector rail. `rail` has all ten `RailShape` values; powered/detector/activator use `RAIL_SHAPE_STRAIGHT`, the same six values excluding four curves, with `POWERED∈{false,true}` (10+12+12+12 = 46 raw states).
- Diodes: `repeater` and `comparator`. Repeater raw state is `FACING` (4) × `DELAY` (4) × `LOCKED` (2) × `POWERED` (2) = 64; comparator is `FACING` (4) × `MODE` (2) × `POWERED` (2) = 16. Their state-dependent logic does not enter the shape method.
- Redstone wire: `redstone_wire`; `NORTH/EAST/SOUTH/WEST∈{UP,SIDE,NONE}` and `POWER=0..15`, giving 3⁴×16 = 1,296 raw states. Shape index reads only whether each connection is non-`NONE`; `UP` and `SIDE` are equivalent to each other for shape, `POWER` is ignored.
- `lever`: horizontal `FACING` (4) × `FACE` (FLOOR/WALL/CEILING, 3) × `POWERED` (2) = 24 raw states. Shape reads `FACE` and `FACING` axis/direction; it ignores `POWERED`.
- Pressure plates: `stone_pressure_plate`, `oak_pressure_plate`, `spruce_pressure_plate`, `birch_pressure_plate`, `jungle_pressure_plate`, `acacia_pressure_plate`, `dark_oak_pressure_plate`, `light_weighted_pressure_plate`, and `heavy_weighted_pressure_plate`. Stone/wood plates have `POWERED∈{false,true}`; weighted plates have `POWER=0..15` and `POWER=0..150`. For each registration, output is the shared unpressed shape when signal is zero and the shared pressed shape for any positive signal. Total raw states: 7×2 + 16 + 151 = 181.
- Buttons: `stone_button`, `oak_button`, `spruce_button`, `birch_button`, `jungle_button`, `acacia_button`, `dark_oak_button`; each has `FACING` (4) × `FACE` (3) × `POWERED` (2) = 24, total 168 raw states. `getShape` reads orientation/face/powered and selects the same pressed/unpressed cuboid in both versions.
- Torches: `torch` (one state) and `redstone_torch` (`LIT` false/true), total three. The redstone torch inherits the constant floor-torch outline from `TorchBlock`; neither state changes its shape.

The four direction and three face domains, enum/property filters, defaults, and state definitions are the same for the paired common registrations. Only paired common IDs are listed; unpaired registrations are not compared. With wall torches covered by the prior report, this pass spans 1,798 raw states (sum above) over 26 common IDs.

## Paired shape formulas and movement gate

| Provider family | Exact method (1.13.2 → 1.14.4 Feather) | Output in both endpoints | Collision eligibility |
|---|---|---|---|
| `RailBlock` / `PoweredRailBlock` (also activator rail) / `DetectorRailBlock` | `AbstractRailBlock.getShape`, old `:39–42`, new `:39–42` | `ASCENDING_SHAPE` `(0,0,0)-(16,8,16)` iff `RailShape.isAscending`; otherwise `FLAT_SHAPE` `(0,0,0)-(16,2,16)`. All 4 ascending values select the former; all flat/curve values select the latter. | All four registration constructors include `.noCollision()`. |
| `RepeaterBlock` / `ComparatorBlock` | `DiodeBlock.getShape`, old `:27–29`, new `:29–31` | Constant `SHAPE` `(0,0,0)-(16,2,16)`, independent of facing, delay/lock/power, or mode. | Registrations do not call `.noCollision()`; base property defaults `hasCollision=true`, so this unchanged cuboid is used by player collision. |
| `RedstoneWireBlock` | `getShape` / `getShapeIndex`, old `:75–102`, new `:76–103` | Both use the same 16 `SHAPES` cuboids, each with Y `[0,1]`; the index bits are derived by the same four connection-presence predicates and bit operations. Each raw state maps to the same index. | Registration includes `.noCollision()`. |
| `LeverBlock` | `getShape`, old `:42–74`, new `:39–71` | Same eight orientation cuboids: four wall directions, floor X/Z and ceiling X/Z. Formula/constants match; `POWERED` is ignored. | Registration includes `.noCollision()`. |
| `PressurePlateBlock` / `WeightedPressurePlateBlock` | `AbstractPressurePlateBlock.getShape`, old `:26–28`, new `:27–29` | Unpressed `(1,0,1)-(15,1,15)`; pressed `(1,0,1)-(15,0.5,15)`. Subclass output-signal methods yield the same state-driven zero/nonzero selection. | All nine registration constructors include `.noCollision()`. The shape differs by pressed state, but base collision returns empty for every state. |
| `ButtonBlock` (stone and six wood IDs) | `getShape`, old `:61–91`, new `:58–88` | Same 16 orientation/pressed cuboids: 4 wall, 2 floor, 2 ceiling base and their 4 wall / 2 floor / 2 ceiling pressed counterparts. Formula and constants match. | All seven registration constructors include `.noCollision()`; the block method's shape lookup used for arrow-trigger overlap is a non-player interaction query. |
| `TorchBlock` / `RedstoneTorchBlock` | `TorchBlock.getShape`, old `:23–25`, new `:24–26` | Constant floor torch `(6,0,6)-(10,10,10)`; redstone `LIT` is not read by inherited formula. | Both registrations include `.noCollision()`. |

The provider inventory's paired collision dispatch applies: `Block.getCollisionShape` returns the state outline when `hasCollision` is true and an empty shape otherwise. 1.14.4's entity path can supply a context, but the methods above do not read it. `BlockState` static shape cache also cannot alter these values because they are not dynamic and the formulas are context-independent. This closes only these provider outputs and collision gates; it does not evaluate how powered/connected states are produced or claim rail/button/pressure-plate state transitions.

## Recomputed source-file SHA-256

Full hashes below are from the exact read-only Feather Gen2 build 2 endpoint trees. Provider publication and mapping identity are bound by `.native-source/20261031/1132-1144-finish46/providers/inventory.md` (SHA-256 `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480`); all listed endpoint files are included in the corresponding source manifests.

| Relative source file | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/Block.java` (old registry/base collision gate) / `net/minecraft/block/Blocks.java` (new registry) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/Block.java` (new base collision gate) | — | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/block/AbstractRailBlock.java` | `ef89230726ce9bd5ebb009d9332da90969d074762fc7eca8d477640d020a0a8d` | `9f889ccea3e80c29fe4c5ac97c6713b5e40878eeaf5ffadd71918572a4fff70a` |
| `net/minecraft/block/RailBlock.java` | `1853b7f0359e7b5d3dd21c86e2a70803e9066ae321c7f4fbe6cd6bb68a184537` | `1853b7f0359e7b5d3dd21c86e2a70803e9066ae321c7f4fbe6cd6bb68a184537` |
| `net/minecraft/block/PoweredRailBlock.java` | `960872830b7ef162b567c8b7dc901ee0d2af231a9f67de352814f3759c344aa1` | `960872830b7ef162b567c8b7dc901ee0d2af231a9f67de352814f3759c344aa1` |
| `net/minecraft/block/DetectorRailBlock.java` | `39c3cc54bd8ccc7c4d99669884e8dea9c3248d911815064ee049eda0872cae1b` | `0a8c54c7d650f7283281e49f04872b15069893c04deaf8466b6be799e300a3ad` |
| `net/minecraft/block/DiodeBlock.java` | `972925eff56fcaa0f1f00662679c12505a3e64dc79b24996d26110ec14b8608b` | `54b3f2984c4b26a25e183fc8e958bfdbcdc66ca8950b78847aa1040faf2494a8` |
| `net/minecraft/block/RepeaterBlock.java` | `c13357f93761ad9be3f5e26d07ab2a086a8b8bb3949165a7e01be4811da8ba65` | `35aa4f31a6c2280f610e27b39a2ade29a67edc2a6bf46378fad595a27230587b` |
| `net/minecraft/block/ComparatorBlock.java` | `e9a0910b44c8fca00cff9bbe54f5227dac4b90401390d1f9529f668933777fe2` | `a01c308d27e9456be827e28505ed90676ae2a51b330d1a4d479f6b0052681bf1` |
| `net/minecraft/block/RedstoneWireBlock.java` | `ba3ad2e45aad6455b4a30803bf4840f98151ac924eb8368755fde031fc5de497` | `d00795e4ff382340702901594f370d012ab3ae3ddaca2aed5b05fa32a827da94` |
| `net/minecraft/block/LeverBlock.java` | `0e9d5a08921c8b0f96c060742a24666f3a8eb2e4b9f7d408a5d242a0edc1daed` | `53dda36db5316f18985497b72e2d09b3e7a72e74141c4dfbe22addc621560111` |
| `net/minecraft/block/FaceAttachedHorizontalFacingBlock.java` | `dcbf54afdaab6c2c80613b11c7877a28cf4840de1f56e7fa3ac788b002addf5a` | `3e6c89f01896deb5fa88970ade4605621b9b59437126db7ffb0b081bf04e688c` |
| `net/minecraft/block/AbstractPressurePlateBlock.java` | `c920500d5b908f6f516e04b6c312ba7c848c3cfa97b24d3427ccf10d2b0de701` | `23fa38e232fd91a736ae79c8d038c317707b72a2f312467efbacca42b903b1c3` |
| `net/minecraft/block/PressurePlateBlock.java` | `9ab5cf13a568854699c4a06e1b25a9a606a83ab1aee5028e24300ef98111ac42` | `82dc2fda777367e78d27775bcd62f967e05984c5b4f3ff89945acca089374428` |
| `net/minecraft/block/WeightedPressurePlateBlock.java` | `f098879f6e52bab3f5371b603af36888d6fec455134ca9afae949954afafdb49` | `ab382a01851b35aab6813a3e37f1b0637b5c9ebf5b03b2a780a89306f327b4f1` |
| `net/minecraft/block/ButtonBlock.java` | `0cdd88bf4f0ee6b2d935a59867c1ba6df68c098d97701e800f499f83dc7a9578` | `9153636ceafd3c93882d8b9603a7813ff99695b955d17f45507e87860408ba63` |
| `net/minecraft/block/StoneButtonBlock.java` | `e9cef7b949924f49e7968d2f83e845a4fe818e32e3d25f013a9c326c4de406a4` | `e9cef7b949924f49e7968d2f83e845a4fe818e32e3d25f013a9c326c4de406a4` |
| `net/minecraft/block/WoodenButtonBlock.java` | `96fe7edbd74a167c35266bbd59eeb8cd5d797ebf49a8e1a2cbe49eb4d633dcb7` | `96fe7edbd74a167c35266bbd59eeb8cd5d797ebf49a8e1a2cbe49eb4d633dcb7` |
| `net/minecraft/block/TorchBlock.java` | `da11308e51f57ce95764f2ee645dde8d15607914a3a68bac9c0635ab3d1531e0` | `8430a1058184d9e87596d5ba961ce092e6c77469c642f50e5c901db1a0588aab` |
| `net/minecraft/block/RedstoneTorchBlock.java` | `d6be1c4a35b5112012e4b583310836bac3cac5e735e2671bb33c0cf9a8a7710f` | `dd5b2d30b0742609d6710c617013303e3d89db758f62043f454ea1dcd11f7612` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/block/state/property/RailShape.java` | `123115cc612b1848214a245f0ad0ae29abf968c9fc8d954b8686994e18a9c115` | `123115cc612b1848214a245f0ad0ae29abf968c9fc8d954b8686994e18a9c115` |
| `net/minecraft/block/state/property/ConnectionSide.java` | `97bd4598f2d645e296755768f38a9c45f5731e00aa8012f16c1fbdc8371a3bcd` | `97bd4598f2d645e296755768f38a9c45f5731e00aa8012f16c1fbdc8371a3bcd` |
| `net/minecraft/block/state/property/AttachFace.java` | `ed08dccb521529989d966407af736b74eb0ca795bfb5ec62c48670f2001c9da0` | `ed08dccb521529989d966407af736b74eb0ca795bfb5ec62c48670f2001c9da0` |

Existing `climb-trigger-shapes/comparison.md` already binds and pairs wall-torch outlines; it also records their `noCollision()` registrations. This task does not re-audit those classes. No source tree was changed or generated; no build, test, game, server, product, wiki, backlog, or product Git data was used.



