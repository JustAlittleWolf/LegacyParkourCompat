# Provider and tag inventory: 1.13.2 → 1.14.4

## Scope and verdict

This is a source-only inventory of block-shape and tag terminals directly reachable from the already examined ordinary player collision, fluid, and pose/submersion paths. It is not a complete paired audit of every state-specific block shape, a runtime tag-content proof, or a player trajectory. The earlier fixed full-cube collision witness remains closed by the base Block provider; this report identifies its broader unresolved terminal set and several additional movement-facing dependency edges.

Primary paired source family: 1.13.2 Ornithe Feather Gen2 build 2 and 1.14.4 Ornithe Feather Gen2 build 2. The 1.14.4 Mojmap tree was used only to crosswalk method semantics where Feather emitted an opaque m_ identifier.

## Publication identity and crosswalk

The canonical source trees are under D:/Javastuff/LegacyParkourCompat/decompiled_minecraft.

| Endpoint | Publication | Ready marker source-manifest SHA-256 | Ready marker SHA-256 | Provenance SHA-256 |
|---|---|---|---|---|
| 1.13.2 | ornithe-feather, Feather Gen2 1.13.2 build 2 | 2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211 | 1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38 | e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383 |
| 1.14.4 | ornithe-feather, Feather Gen2 1.14.4 build 2 | 717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc | bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77 | 7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9 |

I recomputed each published source-manifest file hash; it matches its ready marker. The source-file hashes listed below also match those manifests. The 1.13.2 provenance identifies a single-version Feather run and the Feather Gen2 build 2 jars. The 1.14.4 provenance records a dual Feather/Mojmap run over the same client artifact; both ready markers list client SHA-256 b3b2a798e2d67b566008fe4a03767ae2c7ff3f8c7ba6751e7b71fc7299672d0a. Its Mojmap source-manifest SHA-256 is af98406f3d4ed31494fbdce1078d1f3df3f712501878f9a0e9ad5879bdf23c3b; Mojmap ready-marker SHA-256 is ec7b6a6d9ba72f8a19908527977c970a8e2b3007b0e0b4323a725fb5943d3043; provenance SHA-256 is 9d1ad405e1e787d2fca5ed1897e6797b1f3cd79527da50d713232f46e2f30d97.

The method crosswalk was checked against that paired 1.14.4 output:
- Feather BlockState.m_87223014(BlockView, BlockPos, Direction) is Mojmap BlockState.isFaceSturdy(BlockGetter, BlockPos, Direction); both dispatch to the block face-solid helper and cache the result for non-dynamic shapes.
- Feather Block.isFaceSolid(BlockState, BlockView, BlockPos, Direction) is Mojmap Block.isFaceSturdy(BlockState, BlockGetter, BlockPos, Direction).
- Feather Entity.m_69330161(Tag<Fluid>, boolean) is Mojmap Entity.isUnderLiquid(Tag<Fluid>, boolean).
- Feather PlayerEntity.m_84943753(Pose, EntityDimensions) is Mojmap Player.getStandingEyeHeight(Pose, EntityDimensions); Feather getDimensionsForPose(Pose) is Mojmap Player.getDimensions(Pose).

## Collision-shape terminal dispatch

The previously closed witness calls the ordinary block collision route. Its terminal dispatch is:

- 1.13.2 BlockState.getCollisionShape(world,pos) → Block.getCollisionShape(state,world,pos); the base block returns empty when hasCollision is false, otherwise calls state.getShape(world,pos). Base Block.getShape returns the unit cube.
- 1.14.4 BlockState.getCollisionShape(world,pos) returns its cached shape when present, otherwise calls the context overload with CollisionContext.empty(). The movement query can call the context overload directly. BlockState.getCollisionShape(world,pos,context) dispatches to Block.getCollisionShape(state,world,pos,context); base Block again applies hasCollision and then calls state.getShape(...,context). Base Block.getShape returns the unit cube.
- 1.14.4 static shape caching is gated by !Block.hasDynamicShape(); cached collision shapes and face-sturdiness bits are built with CollisionContext.empty() at BlockState.Cache construction. Dynamic blocks bypass that cache. The entity collision-query path passes an entity CollisionContext, so context-sensitive block providers are a real terminal dependency absent from the older API.

Directly declared getCollisionShape provider methods, excluding the BlockState dispatch accessor, are:
- 1.13.2: Block, CactusBlock, FenceGateBlock, MovingBlock, PaneBlock, SnowLayerBlock, SoulSandBlock, WallBlock, and MovingBlockEntity.
- 1.14.4: Block, BambooBlock, BellBlock, CactusBlock, ComposterBlock, FenceGateBlock, GrindstoneBlock, LecternBlock, MovingBlock, PaneBlock, ScaffoldingBlock, SnowLayerBlock, SoulSandBlock, WallBlock, and MovingBlockEntity.
- Newer-only provider classes in that list are BambooBlock, BellBlock, ComposterBlock, GrindstoneBlock, LecternBlock, and ScaffoldingBlock. Their block-era applicability is not an old-version emulation claim; several are newer blocks. Moving piston state/provider classes also changed names/shapes and are included among the full shape override declarations below.

The complete direct declaration inventory is in shape-provider-overrides.tsv: 93 getShape/getCollisionShape declarations in 1.13.2 and 115 in 1.14.4, with exact relative path, member signature, line, and full Java-file SHA-256 for each entry. It includes providers inherited by collision dispatch through getShape. Not every getShape override produces a collision shape: Block.hasCollision remains the gate, and that table does not audit each constructor/property or every state/neighbor branch. That full per-state pairing remains open.

The prior collision-query closure remains the evidence for candidate enumeration, loaded chunks, world-border exclusion, entity exclusions, and the generic stone/full-cube witness. Its explicit witness needs only the base provider. The inventory above does not alter that result.

## Fluid flow face-provider terminal

Ordinary fluid travel consumes a flow vector calculated by FlowingFluid.getFlow. Its falling-fluid branch asks isSolidFace for horizontal neighboring cells and their upper neighbors. This branch can modify the vector by normalizing it and adding the downward -6 term; therefore the block-face predicate is directly reachable from player fluid travel when the sampled fluid state is falling.

- 1.13.2 FlowingFluid.isSolidFace(BlockView,BlockPos,Direction), lines 105–123, first rejects same-fluid neighbors, accepts UP, rejects ICE, then rejects Block.isExceptionForAttachment(block) and StairsBlock before requiring BlockState.getFaceShape(...) == FaceShape.SOLID. The default Block.getFaceShape returns SOLID. That old terminal method has many state/block overrides; fluid-face-shape-providers.tsv inventories 65 direct getFaceShape declarations with source-file hashes.
- 1.14.4 FlowingFluid.isSolidFace(BlockView,BlockPos,Direction), lines 106–115, first rejects same-fluid neighbors, accepts UP, rejects ICE, then asks BlockState.m_87223014(...), crosswalked to Mojmap isFaceSturdy. The helper rejects BlockTags.LEAVES and otherwise requires a full collision-shape face (Block.isFaceSolid / Mojmap Block.isFaceSturdy). Its terminal collision-shape declarations are part of shape-provider-overrides.tsv.

This is an exact source-level provider change, not a flow-vector trajectory claim. Old code depends on the FaceShape provider and its explicit exception set; new code depends on collision geometry plus the loaded LEAVES tag. Even with identical fluid gradient arithmetic, a falling-fluid state can reach this changed face terminal. A per-block, per-state paired audit of these terminal results and an ordinary player trajectory through a differing result remain open.

## Movement-facing tag reads

| Tag or provider | Reachable consumer | Source result and remaining dependency |
|---|---|---|
| FluidTags.WATER | Entity body-fluid scan, eye-submersion predicate, swimming update; LivingEntity water jump/travel branches | The previous fluid-contact and water-tag reports cover these calls. The Java source declares handles and data-generator recipes, but the loaded active tag collection/resource packet is absent; water membership must remain conditional. |
| FluidTags.LAVA | LivingEntity jump-in-liquid and the 1.14.4 LiquidBlock post-move lava callback | Covered by the prior fluid-contact closure. Loaded tag membership and resource contents are not established by these Java-only trees. |
| BlockTags.LEAVES | 1.14.4 Block.isFaceSolid → BlockState face-sturdiness cache/query → FlowingFluid.isSolidFace | In 1.13.2 the corresponding helper excludes LeavesBlock through Block.isExceptionForPlacement/Attachment. Both data-generator providers list the six vanilla leaf blocks. Runtime tag replacement is not included, so this only closes the generated vanilla recipe, not an active collection. Other old exceptions and the old FaceShape/ new collision-face geometry are still not pair-audited per block/state. |
| BlockTags.FENCES and BlockTags.WALLS | 1.14.4 Entity.move post-collision bottom-block fallback | 1.13.2 uses instanceof FenceBlock, WallBlock, or FenceGateBlock when the immediate below-player cell is air. 1.14.4 uses FENCES or WALLS membership, or the same FenceGateBlock class test. The selected block state is passed to checkFallDamage and, after a vertical collision, its block receives updateEntityAfterFallOn; in 1.13.2 the corresponding callback is beforeCollision. The 1.14.4 BlockTagsProvider recipe includes vanilla fences/nether-brick fence and all listed walls. No runtime tag resource/packet contents are present. The vanilla recipe is inspectable; modded/custom tag extensions are outside this source-only vanilla closure. |
| BlockTags.SIGNS | 1.14.4 FlowingFluid.canHoldFluid | New helper uses !block.is(BlockTags.SIGNS) where old helper explicitly excludes Blocks.STANDING_SIGN. This is a fluid spread/state-production gate, not a direct current-tick flow-vector consumer. It is outside the already examined movement consumer boundary here; no waterlogged-sign trajectory or state-production witness was attempted. |

The generated vanilla BlockTagsProvider recipes are code, not the runtime tag files. No JSON resources/tag packets are present in either canonical decompiled source tree. BlockTags and FluidTags install/reset a current tag collection, and client handlers may replace it from received tags. Accordingly, no report here asserts active vanilla/custom pack membership from the tag handle declarations alone.

## Eye-height → water-submersion → pose route

This closes the query/caller dependency requested by the coordinator, while leaving ordinary trajectory acceptance open.

- 1.13.2 PlayerEntity.getEyeHeight(), lines 1859–1870, returns 1.62F normally, 0.2F sleeping, 0.4F swimming/fall-flying/height 0.6F, and subtracts 0.08F for sneaking or height 1.65F (thus 1.54F on the ordinary sneaking branch). The old player tick calls updateWaterSubmersion before super.tick and calls updatePlayerPose after it; updatePlayerPose selects a 0.6F×1.65F sneaking box or a 0.6F×0.6F swimming/flying box when the world collision check allows resizing.
- 1.14.4 PlayerEntity uses pose dimensions; the SNEAKING dimensions are 0.6F×1.5F. Its eye-height override (Feather lines 1797–1813, Mojmap Player.getStandingEyeHeight) returns 1.27F for SNEAKING, 0.4F for swimming/fall-flying/spin attack, and 1.62F otherwise. Entity.refreshDimensions updates stored dimensions and eyeHeight when pose changes. Player.updatePlayerPose selects the pose from current swimming/sneak/fall-flight state, subject to canEnterPose.
- In both endpoints Entity.isSubmergedIn(tag) reads the eye coordinate y + getEyeHeight(), floors it into a BlockPos, tests the active fluid tag, and compares it strictly against the fluid surface plus 0.11111111F. The 1.14.4 contextual height query uses level/9 when no same-fluid cell is above, matching the old raw height.
- Both Entity.baseTick paths order checkWaterState (body contact), the eye-based submerged-water update, and updateSwimming. updateSwimming can set the swimming flag from sprinting + body water + eye-submersion state; the local Player override only forces false while flying. Player.tick separately refreshes its water-submersion field before super.tick and performs updatePlayerPose after it. The current body-fluid and eye-fluid flags therefore feed normal player tick gates, and a swim-state change can select different player dimensions for collision and subsequent movement. LivingEntity water-travel itself gates from body-water contact, not the eye predicate.
- Conditional static predicate witness: at feet y=0, a crouching player’s two eye heights 1.54 and 1.27 both floor into the y=1 cell. For an unstacked, WATER-tagged flowing state of level 2 in that cell, old/new raw surface height is 1 + 2/9 and the strict threshold is approximately 1.3333334. Old eye Y fails the query; new eye Y passes it. The state is a valid assignment, but this report does not prove ordinary fluid ticks or prior player inputs create this exact condition. It also does not claim the complete sprint→swim-pose transition as an accepted movement trajectory. Active WATER membership remains conditional as above.

## Closure limits

- Closed here: exact source publication/mapping identity; terminal dispatch for base and explicit shape/collision methods; inventory of direct getShape/getCollisionShape declarations; the direct old/new fluid-face terminal chain; direct movement-facing tag consumers and generated vanilla recipes; eye-height caller chain into the ordinary body-water/swimming/pose path.
- Still open: paired geometry/result audit for every state/neighbor-sensitive provider; effects of context-sensitive collision shapes across all player contexts; exact active tag resources and client/server tag packet contents; end-to-end ordinary input/state histories for changed provider or eye-fluid states; full fluid spread/state producer closure; wider block callbacks and arbitrary entity shapes; intermediate-release change boundaries.
- No trajectory through waterlogged signs is asserted. No product/wiki/backlog/Git was read or changed. No source tree was written, regenerated, built, tested, or launched.

## Source-file hashes

All paths below are relative to the stated source tree. Hashes are SHA-256 of complete Java files; the override TSVs preserve the complete provider declarations and hashes for the larger sets.

| Source/member area | 1.13.2 Feather SHA-256 | 1.14.4 Feather SHA-256 |
|---|---|---|
| net/minecraft/block/Block.java | 735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4 | 1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5 |
| net/minecraft/block/state/BlockState.java | 0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70 | 6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f |
| net/minecraft/entity/Entity.java | 1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269 | 7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55 |
| net/minecraft/entity/living/LivingEntity.java | bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c | 2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61 |
| net/minecraft/entity/living/player/PlayerEntity.java | 4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633 | 2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df |
| net/minecraft/fluid/FlowingFluid.java | 2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253 | 6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce |
| net/minecraft/tag/BlockTags.java | 61ece958afe7fb7faca880064fcc11edd6f07fbc9fb118f0de22b6de6d2e9143 | dc59d07204b25e5d852d0384e849975367590a3cbc2b9a293396d0bf5637e52a |
| net/minecraft/tag/FluidTags.java | b9d4c2d93f4594f27e235e2d5973cd0c81d269597cbdc400a11333cc617247aa | d70f3a8b097827d4ffbb714490453a74a87f6b062709f3e05ceb466ac82cb967 |
| net/minecraft/data/tag/BlockTagsProvider.java | db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e | 0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa |

Mojmap cross-check hashes (1.14.4): world/entity/Entity.java 31c6be42d165102d3e6dc4295fdfef6e8971fc3aea13f938a5b3a33b91d524a7; world/entity/player/Player.java e9ce5eb18c5581ffe2b610b273ffd85786587a00ba853e5dba0ac96593622b12; world/entity/LivingEntity.java 428762178a876efd4069086e6b7d51f571ea0401f44e7eff0927b7d26d9ef681; world/level/block/Block.java 276022cfc5bc00437fe65a23bbcdc9c078026e68d88930eb3244581f6dbfcf5f; world/level/block/state/BlockState.java 2bcc0167cb566df8745abbe967f0a8750038ad5a9b7843f5fb25bab714d73188; world/level/material/FlowingFluid.java e8a395552e53f33bcb5648325615d31bc1796ce2a8aeb501bdda3127622dccdf.
