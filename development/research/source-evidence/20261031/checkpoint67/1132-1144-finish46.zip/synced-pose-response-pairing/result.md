# Local-player pose and dimension response pairing

## Result

Exact pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2. This closes the live player pose-to-dimensions/eye-height pairing for old-era poses under equal logical inputs and a collision-free local snapshot. It is source-only: no packet or state producer history, runtime trajectory, health/death route, or bed-entry eligibility is claimed.

Five common live poses have matching nominal dimensions and eye-height outputs: standing, sleeping, fall-flying, swimming, and spin-attack. **Sneaking differs:** old `PlayerEntity.updatePlayerPose` selects height `1.65F` and `PlayerEntity.getEyeHeight` returns `1.54F`; new `Pose.SNEAKING` selects height `1.5F` and the pose eye-height callback returns `1.27F`. Width remains `0.6F`; both keep the same minimum X/Z/Y corner for this pose transition. The fixed-input difference is therefore a `0.15` lower bounding-box top and `0.27` lower eye query point. These values can affect the next movement collision query and the existing eye-position fluid/block-state predicates. No trajectory is asserted.

## Paired pose writers and geometry

Old `PlayerEntity.tick` calls `updatePlayerPose` at its end (`1.13.2 PlayerEntity.java:254`). The method maps current raw player state in order: fall-flying → `0.6F × 0.6F`; sleeping → `0.2F × 0.2F`; swimming or spin attack → `0.6F × 0.6F`; sneaking → `0.6F × 1.65F`; otherwise standing → `0.6F × 1.8F` (`PlayerEntity.java:334–360`). If size differs, it constructs the candidate box from the existing minimum corner and applies `setSize` only when `world.hasNoCollisions(null, box)` succeeds. Old `Entity.setSize` preserves that minimum corner when width is unchanged (`Entity.java:285–299`).

New `PlayerEntity.tick` also calls `updatePlayerPose` at its end (`1.14.4 PlayerEntity.java:281`). It selects the same old-era state conditions and chooses `Pose.FALL_FLYING`, `SLEEPING`, `SWIMMING`, `SPIN_ATTACK`, `SNEAKING`, or `STANDING` (`PlayerEntity.java:343–369`). It first tests whether the smaller swimming box fits, then tests the selected pose and falls back to sneaking or swimming when needed. For the stated collision-free snapshot, all of these fit checks pass and the desired pose is stored. The player dimension table binds standing to `0.6F × 1.8F`, sleeping to `0.2F × 0.2F`, fall-flying/swimming/spin-attack to `0.6F × 0.6F`, and sneaking to `0.6F × 1.5F` (`PlayerEntity.java:110–117, 1964–1966`).

The new pose write is synchronized data. `SyncedData.update` copies a received registered pose value and invokes `Entity.onDataValueChanged`; `ClientPlayNetworkHandler.handleEntityData` can resolve the local player through its entity ID as covered in `client-response-modifier-residual/result.md`. New `Entity.onDataValueChanged` calls the dimension updater when pose changes. That updater replaces dimensions and eye height and rewrites the shape (`Entity.java:2239–2268`). Shrinking width recenters on X/Z; otherwise it holds the prior minimum corner, matching the old unchanged-width anchor for the pose pairs in the table below. A received pose can therefore directly update client dimensions; its upstream server decision is outside scope. The subsequent local tick still derives a pose from its raw logical flags and conditions.

## Pose output table

| Semantic local-player state | 1.13.2 dimensions | 1.13.2 eye height | 1.14.4 pose dimensions | 1.14.4 eye height | Result |
|---|---:|---:|---:|---:|---|
| Standing | `0.6 × 1.8` | `1.62` | `STANDING: 0.6 × 1.8` | `1.62` | Match |
| Sleeping | `0.2 × 0.2` | `0.2` | `SLEEPING: 0.2 × 0.2` | `0.2` | Match for dimensions/eye height; sleeping-position response is separately covered |
| Fall-flying | `0.6 × 0.6` | `0.4` | `FALL_FLYING: 0.6 × 0.6` | `0.4` | Match |
| Swimming | `0.6 × 0.6` | `0.4` | `SWIMMING: 0.6 × 0.6` | `0.4` | Match |
| Spin attack | `0.6 × 0.6` | `0.4` | `SPIN_ATTACK: 0.6 × 0.6` | `0.4` | Match |
| Sneaking | `0.6 × 1.65` | `1.54` | `SNEAKING: 0.6 × 1.5` | `1.27` | Difference: top is `0.15` lower; eye query is `0.27` lower |

Old eye height uses `PlayerEntity.getEyeHeight` (`1.13.2 PlayerEntity.java:1861–1870`), which keys off sleeping/swimming/fall-flying/sneaking and the active height. New `LivingEntity` delegates pose eye height to `PlayerEntity.m_86089714`; it returns `1.27F` for sneaking, `0.4F` for swimming/fall-flying/spin attack, and `1.62F` otherwise (`1.14.4 LivingEntity.java:2770–2775`; `PlayerEntity.java:1802–1812`). Sleeping retains the distinct `0.2F` special case in `LivingEntity`.

For an eligible raw state with `isSneaking=true`, `isFallFlying=false`, `isSleeping=false`, `isSwimming=false`, `isDoingSpinAttack=false`, `abilities.flying=false`, and neither spectator nor riding, the old updater selects the 1.65-high box and the new updater selects `Pose.SNEAKING`. Choose an air/empty collision snapshot so both old and new fit predicates succeed; this is a valid fixed-state source input and avoids claims about prior pose or collision producers. At unchanged player position, the resulting boxes share their base and X/Z extent while their maxima are `y+1.65` and `y+1.5`. The outputs are directly source-derived.

The movement-facing consumer is concrete: both endpoint `LivingEntity.tick` paths query eye-position block state as `(x, y + getEyeHeight(), z)` in the water/air logic (`1.13.2 LivingEntity.java:266–267`; `1.14.4 LivingEntity.java:301–302`). New local and older entity fluid queries use these eye-related results; active fluid membership/production is not claimed. The box-height difference also changes the shape passed to later collision queries. The expected behavioral meaning is a conditional input difference to movement collision and eye-position predicates, not a predicted trajectory.

## Pose-fit collision input difference

The resize/pose gate also changed which collision candidates it checks. Old `PlayerEntity.updatePlayerPose` calls `world.hasNoCollisions(null, candidateBox)`. Old `World.getCollisions` appends entity collision shapes only for a non-null entity (`World.java:1755–1757`); with this null call, only block shapes can prevent the resize. New `Entity.m_87715359(Pose)` calls `world.hasNoCollisions(this, poseBox)` (`Entity.java:1628`), and new `WorldView.getCollisions` concatenates block and entity collisions. Its `WorldAccess`/`EntityView` path can include other collidable entities (`WorldView.java:121–131`; `EntityView.java:53–64`).

Therefore, after a crouched state with the logical sneak input cleared, a raw collidable entity shape intersecting only the standing candidate can make the new `updatePlayerPose` reject `STANDING`, fall back to `SNEAKING`, and retain its small box, while the old block-only fit test accepts standing in the same block-empty snapshot. The entity collision shape and inputs are treated as raw comparison inputs; this is not a claim about vehicle/non-player physics or how the entity entered that position. This specific conditional fit-result path remains a candidate for independent review and further query-context closure. Relevant exact source hashes are listed below.

## Non-equivalent and excluded cases

- `Pose.DYING` is new in the enum (`1.14.4 Pose.java:3–11`) and is not an ordinary live player movement state. The old death/damage-driven sizing branch is outside the requested movement scope; no equivalence claim is made for it.
- Live sleeping movement/bed positioning is not reopened; the accepted sleep/wake and respawn sleeping-position candidates separately bound those response operations. Sleeping here only records the dimension and eye-height row.
- The local-player pose updater can use collision results to retain a previous pose or select a fallback. This table's concrete differing witness assumes the stated collision-free snapshot; it does not close every collision-context branch of the updater.
- Packet handlers and synchronization are source consumer paths. Server pose producers, fluid histories, health/death production, vehicle and non-player physics remain excluded.

## Exact source identities

All source hashes were recomputed from the read-only endpoint Feather trees and match their `ornithe-feather.sources.sha256` publication manifests.

| Version | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ED22F6C5A3C55D67EED782070AC722201DF4D624ADBC90779F1FD29C2876633` |
| 1.13.2 | `net/minecraft/entity/data/SyncedData.java` | `93177865E23BE0F8DB5741BD505B952DAEE03D33761838CA782BD10BCEB748E4` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4F65502FBEE6476CEF0838563F03A66F07A1A9ED8C63E580F5338BA5FE274F11` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023DE30DA608DB73C6C6188334D2BB19039D86FE4D6F5E4AD79D732A5D2CD1A` |
| 1.13.2 | `net/minecraft/world/EntityView.java` | `2B5B59EEF6EFA93BB51C1D838C7A1CF64725BE96C55C47F76894FDE11E13D6DE` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2CCCF4331CE9E62013EEB8E96163E5E146E1291619EB998CE9867DAA87C02B61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614DEB3B50D11F6CDF54D9E308703BF49CB53B72646B05253857E9557D657DF` |
| 1.14.4 | `net/minecraft/entity/data/SyncedData.java` | `4D0C0BEE069994F64A31E1FF600AE59C3217EADB8678473E2256C2363E657E17` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6C840580285C7C7D4617E895EDAC82D4EEBF8289DD4994E7B593CEBEB49B43EF` |
| 1.14.4 | `net/minecraft/entity/Pose.java` | `88996DC2F6FBA703AB9C5BE3DACF6C53BAC2485F9BC5409B888E810370A8A618` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.14.4 | `net/minecraft/world/WorldAccess.java` | `F57639756ACDEDBD0E5A598F7740A8E17F0DC3B2BA710AA4690D05F4F3BCD746` |
| 1.14.4 | `net/minecraft/world/EntityView.java` | `3822844CED53882C52F0523A1BD714BAA3CD9BB9DAB38A5E2C53051C7B1590E3` |

No product, wiki, backlog, Git, build, test, runtime, or decompiler source was used. No source tree was written.
