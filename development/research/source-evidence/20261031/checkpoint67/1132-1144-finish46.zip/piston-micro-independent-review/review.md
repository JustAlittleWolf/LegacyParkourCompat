# Independent review: tiny piston accumulator candidate

## Verdict

**CONDITIONAL — do not accept this draft unchanged.** The source-level accumulator difference is real under its explicit direct-request assumptions, but the draft's first-call position statement is false. The old endpoint does not return for the proposed `2.0E-5` request: it is greater than `1.0E-5F`, so the old call continues into movement and translates the entity in an empty collision snapshot. The new endpoint's `squaredDistanceToOrigin() <= 1.0E-7` guard bypasses piston accounting, but its later position writer suppresses the tiny resolved vector. Thus the player positions already diverge after the first call.

On the subsequent `0.51` call the accepted vectors differ (`0.50998` old and `0.51` new), but the resulting endpoint positions in the stated collision-free sequence converge: old has already moved by `0.00002`, then moves `0.50998`; new did not move on the first request, then moves `0.51`. The candidate must not state or imply that the final player position differs after that second call. It may report (a) the first-call player-position difference and retained accumulator difference, or (b) the second-call accepted-movement difference, while explicitly noting the cumulative position convergence for this exact collision-free sequence.

## Independent source verification

I reread the exact Feather endpoint sources. Hashes recomputed from disk match the candidate and paired report:

| Source | SHA-256 |
|---|---|
| 1.13.2 `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 `net/minecraft/util/math/Vec3d.java` | `6941a43536e8aefaa435a4e5f1731b0fa26a9d96503d1f4d07de8950c297f3c5` |
| 1.14.4 `net/minecraft/util/math/Vec3d.java` | `b69b990b768e52d6fac6b3ed82f60e7526e78d0837c868a61a4171ebca21040b` |

The old `Entity.move` stores the clamped piston delta before testing `Math.abs(x) <= 1.0E-5F`, then continues into the ordinary move routine if the test is false. For `x=2.0E-5`, old accepted x is `2.0E-5`, and the test is false. With no clipping, it translates and sets its position. The new `m_19881916` returns the unchanged request when squared length is at most `1.0E-7`, before reading the tick or touching the accumulator; the caller's exact Vec3d-zero comparison does not return. The subsequent writer moves the shape only when the resolved squared length is greater than `1.0E-7`, so it suppresses that first tiny displacement. This confirms both the retained old accumulator `2.0E-5` versus new `0` and an immediate player-position divergence after the first request.

For the next same-tick x request `0.51`, old computes clamp(`0.51 + 0.00002`) = `0.51`, then accepted delta `0.50998`; new computes clamp(`0.51 + 0`) = `0.51`, then accepted delta `0.51`. Both second-call deltas exceed the new movement writer cutoff. Cumulatively, for empty collision queries, old position is `0.00002 + 0.50998 = 0.51` and new position is `0 + 0.51 = 0.51` (subject to binary64 rounding). Intermediate state and per-call accepted vector differ, but these two calls do not leave a net position difference at the end of the sequence.

The operation is a direct local-player piston response and the candidate appropriately treats equal direct requests, accumulator state, world tick and collision snapshot as assumptions. It does not infer the producer. This fits the scope for direct player movement responses; piston world/block production remains excluded. No intermediate boundary is established.

## Inputs and review identity

| Reviewed input | SHA-256 |
|---|---|
| Candidate `.native-source/20261031/1132-1144-finish46/candidates/piston-micro-request-bypasses-accumulator.draft.md` | `879fa5d50d2d545e8f7ee6107cc4f07be341defe1db200ca10e7f8daec9323a2` |
| Paired report `.native-source/20261031/1132-1144-finish46/piston-tiny-request-terminal/result.md` | `63d3db6365784ba2a8c065ca97bff37ba43b7a8197ae7a2a00f573d1974522a8` |

This review is source-only. No product implementation, wiki/backlog, product Git, build, test, game launch or source preparation was consulted or run.
