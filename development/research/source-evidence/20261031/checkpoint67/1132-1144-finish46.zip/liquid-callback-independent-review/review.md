# Independent review: lava-contact callback movement terminal

## Verdict

**ACCEPT, narrowly and conditionally**, for the exact direct movement-route difference in `liquid-callback-movement-terminal/result.md`, candidate SHA-256 `cef3485ccb54a5f83a8186631df3fe138245100c79ab70ae1d5367168b3ee003`. This accepts only that, for the same loaded vanilla snapshot and player box, 1.14.4 stores lava contact during the end-of-move callback scan and the next local-player movement call observes the flag, while 1.13.2's narrower live lava-material query returns false. It does not establish a prior trajectory, input/fluid/block producer behavior, or numerical player-output difference.

The revised report names the exact movement consumer as `LivingEntity.moveRelative`, called by `LivingEntity.mobTick` (`1.13.2` lines 1478–1490 and 1926; `1.14.4` lines 1786–1800 and 2227). The cited lava gate is present in both method bodies.

## Independent source trace

The specified 0.6-wide player box `[0.41,1.01]` in X is valid as a raw local-player box centered at `x=0.71`; equal box/world snapshots are a permitted operation-level premise. With the sole lava cell at `(1,0,0)`, the old `Entity.isInLava()` contracts by `0.1F`, producing an X interval of approximately `[0.51,0.91]`. `World.containsMaterial` starts at `floor(minX)` and ends before `ceil(maxX)` (`World.java:1310–1325`), so it visits only X=0 and returns false. The same calculation is independent of how that fixed snapshot was produced.

Both endpoints call `checkBlockCollisions()` after moving (`1.13.2 Entity.java:747–748`; `1.14.4 Entity.java:541–543`). Both scans use the same `+0.001/-0.001` inset, an area-loaded gate, and inclusive floored bounds (`Entity.java:801–818` old, `:797–814` new). For this box the floored maximum X remains 1, so the scan invokes the state callback for the lava at X=1 on each side.

The old block-state forwarding calls `Block.onEntityCollision`, whose base implementation is empty (`BlockState.java:261–262`; `Block.java:595–597`). Old `LiquidBlock.java` has no override. In 1.14.4, `LiquidBlock.onEntityCollision` sets the entity's stored lava-contact bit when `this.liquid.is(FluidTags.LAVA)` (`LiquidBlock.java:168–172`); its setter sets the bit (`Entity.java:1054–1056`). The bit is reset immediately before the callback scan in `Entity.move` (`:541–542`), and `rg` finds no other reset. The `LAVA` default recipe contains both source and flowing lava at both endpoints (`FluidTagsProvider.java:18–20`); the default `Blocks.LAVA` registration points at `Fluids.LAVA`. The report's fixed default-tag premise therefore applies.

At the next local movement call, `LocalClientPlayerEntity.isLocallyControlled()` is true on both endpoints (`LocalClientPlayerEntity.java:488–490` old, `:485–487` new), so `moveRelative` enters its applicable branch. With no water and no player flight, its `!isInLava()` gate diverges: old proceeds through the dry branch, while new takes the lava continuation (old `LivingEntity.java:1486–1490`; new `:1795–1800`). `mobTick` calls `moveRelative` (`:1926` old; `:2227` new). Thus the write is consumed by an eligible local-player movement decision before the next move resets the bit. No damage/fire or downstream tick trajectory is needed for this conclusion.

## Exact source identity

I independently recomputed the cited endpoint source hashes and checked them against the exact `ornithe-feather.sources.sha256` manifests. Endpoint mapping is Feather Gen2 build 2; ready/provenance/source-manifest hashes are included here for this review identity.

| Release | File | SHA-256 |
|---|---|---|
| 1.13.2 | `Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.13.2 | `LiquidBlock.java` | `feedc9a5f1843604e6755a447e89d8d5599613799e25cf8c93a0562e52e97856` |
| 1.13.2 | `Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.13.2 | `FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` |
| 1.13.2 | `LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `LiquidBlock.java` | `bfbbe2997ce6c03224b5833176d6b19b4b4b4cbc3337960fb3d867de77519ca1` |
| 1.14.4 | `Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `FluidTagsProvider.java` | `10ff8ccdde75f60999c88f16844c78e4419f94fcae3b1716634202b8f2ba671a` |
| 1.14.4 | `LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |

| Release | Ready marker SHA-256 | Provenance SHA-256 | Source manifest SHA-256 |
|---|---|---|---|
| 1.13.2 | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |
| 1.14.4 | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` |

No wiki, product, backlog, Git history, runtime, build, test, or generated source was used or changed. This is an operation-level independent review, not a full-pair audit.
