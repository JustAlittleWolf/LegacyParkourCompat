# Independent review: player pose response pairing

## Verdict

**Accept the bounded sneaking dimension/eye-height finding.** Candidate `synced-pose-response-pairing/result.md` SHA-256 `62F3FDFAB1F83D3BFE24F4B9AEE8E30DD9716D26F581B96F7E0A495FC886F5F2` matches the reviewed report. Under the stated same logical sneak state and empty collision snapshot, old `PlayerEntity.updatePlayerPose` selects `0.6F × 1.65F`, while new selects `Pose.SNEAKING` at `0.6F × 1.5F`. At the same player base, the new box top is 0.15 lower. Old eye height is `1.54F`; new pose eye height is `1.27F`, so the next eye-position block/fluid query differs by 0.27. Both dimensions and outputs are directly visible in the paired sources. The report correctly limits this to conditional source outputs and consumers, without asserting a trajectory or producer history.

**Accept the separate pose-fit collision-input branch conditionally.** Old resize fit calls `hasNoCollisions(null, candidateBox)`; the old world dispatch appends entity collisions only for a non-null queried entity, so only block collision shapes can veto this update. New fit calls `hasNoCollisions(this, poseBox)`; the 1.14.4 `WorldView` collision stream includes entity shapes and `EntityView` admits non-null shapes intersecting the expanded candidate box. Therefore a fixed raw entity collision shape that intersects only the standing candidate can block the new standing pose while the smaller swimming and sneaking candidates remain clear. A concrete geometric example is a standing player box `[0,1.8]` high and a collidable entity box overlapping X/Z with Y `[1.6,1.7]`, in a block-empty snapshot. The old null-entity query accepts standing; the new entity-aware query rejects standing and accepts sneaking. This is a bounded player-dimension response, not a claim about vehicle/non-player physics or entity production. Broader entity-query parity remains open.

The five matching nominal pose rows (standing, sleeping, fall-flying, swimming and spin attack) were checked against the cited source formulas. They do not erase the sneaking difference. Sleeping position and respawn/wake operations remain their separately scoped findings.

## Source identity and formula check

I independently recomputed the SHA-256 for all **17** Java sources listed in the candidate report. Every file hash matches the report and its version-root `ornithe-feather.sources.sha256` manifest entry. The exact endpoint mappings are Ornithe Feather Gen2.

I verified the player state selector and collision fit in both `PlayerEntity.updatePlayerPose` bodies, old `PlayerEntity.getEyeHeight`, new pose-to-dimensions map and pose eye-height callback, old/new box update anchor behavior, and both local `LivingEntity.tick` eye-position query sites. I also independently checked the old `World.getCollisions` null-entity branch and new `WorldView`/`EntityView` collision inclusion path. The report's raw-state exclusions are consistent with the selected fixed-input claims.

## Scope limits

- Accepted evidence is limited to the listed old-era pose states and the stated raw logical flags, collision-free or standing-only-entity query inputs, and unchanged player base position.
- It does not prove that any server or packet producer supplies a pose, entity, or fluid history; it does not predict subsequent movement vectors.
- It does not close every entity candidate/query path, collision provider, or intermediate-version boundary. The pose-fit branch is accepted only under its explicitly stated raw shape membership condition.
- No product, wiki, backlog, Git, build, test, runtime, or decompiler source was used; no source tree was written.
