# Resolver query branch closure (bounded)

## Scope and exact source identity

This closes the old/new block-query and clipper handoff for the ordinary candidate stream at the method/branch level, plus a bounded no-effect witness. It does not establish complete movement parity or a trajectory result.

Source family: published Ornithe Feather 1.13.2 and 1.14.4. The surrounding accepted source inventory identifies the roots as `ornithe-feather`; the 1.13.2 manifest is `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and 1.14.4 is `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. No source files were modified.

SHA-256 of the exact files used:

| Version | File | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360B1A1BDDE9280F0B72593E5E6DDE45D9A54719CD7FF933F3ECD31B971F` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `FCDF8DC98F97781F4639C4B8CDA8A238EDF834F3963E401E6EEEF6CB475C4909` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShapes.java` | `51A09C297C7F01C8BAD9B66AF2A80900E95F33C6E3A250CE599F4817433587D9` |

## Query and resolver branches closed

* **Old query construction:** 1.13.2 `Entity.move` calls `WorldView.getCollisions(entity, originalBox, dx,dy,dz)` for the main move and creates one fresh list after restoring the starting box for the step attempt. `WorldView.getCollisions` constructs `expanded(originalBox, vector).expand(1e-7)`, subtracts a directionally epsilon-shifted original box with `ONLY_FIRST`, and passes that movement shell plus the original box as `excludeBlock` into `getBlockCollisions`.
* **Old candidate route:** `WorldView.getBlockCollisions(shape, excludeBlock, checkWorldBorder)` enumerates floor(min)−1 through ceil(max)+1, suppresses cells on two or more shell boundary dimensions, checks loaded chunks/border, obtains each state collision shape, and drops a cell when the local `excludeBlock` overlaps that cell shape. Full unit cubes are accumulated in a bit set and emitted as one union; non-unit shapes are translated and emitted individually. The same old query/candidate list is then consumed through `calculateMaxOffset` on Y, X, Z in main movement and on the raised/expanded boxes of both step alternatives.
* **New mixed-vector route:** 1.14.4 `Entity.m_72373519` runs the main vector through `m_64271959`. When at least two vector components are nonzero, `m_64271959` appends `WorldView.getBlockCollisions(entity, box.expand(vector))` to the carried entity/border stream, then hands the stream to `m_79801352`, whose clip order is Y, then horizontal longer axis, then other horizontal axis. For the first step alternative `(requestedX, stepHeight, requestedZ)`, second alternative `(0, stepHeight, 0)` with horizontally expanded original box, and the raised horizontal continuation from the second alternative, each mixed-vector invocation creates its own query from that invocation's box/vector. The final downward correction is one-axis and does not call this block-candidate query.
* **New one-axis route:** if at most one component is nonzero, `m_64271959` routes to `m_73670363`; each nonzero axis clips with `VoxelShapes.m_10425781`. That walker scans the directional swept block range, applies the same corner/boundary category tests (`hasLargeCollisionShape` at a one-boundary coordinate; moving-block-only at two), fetches the collision shape under the entity `CollisionContext`, and immediately feeds `calculateMaxDistance` to the axis clip. It is a distinct provider-consumer route, not a `WorldView.getBlockCollisions` stream. Thus one-axis residuals cannot be closed by comparing the WorldView stream alone.

## Bounded no-effect witness

For a concrete one-axis witness, take `B=[0.2,0.8]×[0,1.8]×[0.2,0.8]`, one fixed full-cube provider at `[1,2]×[0,1]×[0,1]`, ordinary loaded chunks, border inactive, and vector `(0.5,0,0)`. The cube has no positive 3D overlap with the initial box, so old `excludeBlock` does not remove it; it positively intersects the old swept movement shell and the new directional X scan. Both clipper handoffs therefore contain the same full cube and the same starting box, giving an X gap of `1−0.8=0.2` and a clipped request of `0.2`. This proves only the one-axis fixed-cube candidate/clip result.

For mixed vectors, take a valid initial box with no initial overlap with any collision shape, ordinary loaded chunks, border inactive, and fixed unit-cube collision shapes in the tested cells. For any queried unit cube wholly in the movement-only portion of the old swept shell and positively intersecting the new expanded-box query, the old `excludeBlock` cannot overlap that cube because the initial box is disjoint from it; the old cell is therefore retained. If the cube positively intersects the new expanded query, it is also in the old expanded sweep (the new bounds are the same vector expansion, while old adds the 1e-7 envelope); the old movement-shell subtraction removes only points in the original-box region and the cube is disjoint from that region. Consequently the cube reaches the old candidate list and the new candidate stream. Given the same unit-cube shape and box at the clipper handoff, both axis clippers produce the same unit-cube axis gap; candidate membership contributes no delta in this witness. This is a query-membership/clipper-input result, not an assertion about resulting movement or step selection.

The same exclusion reasoning applies to each 1.14.4 per-vector query whose effective query box is disjoint from the collision cube at that invocation. For step alternatives this condition must be checked against the **raised/expanded invocation box**, not merely the original box. It does not imply old/new membership equality for arbitrary state shapes, border candidates, moving blocks, context-dependent providers, already-overlapping collision inputs, or chunk availability differences.

## Exact residuals

1. The old/new query-shell filters are not equivalent on arbitrary overlapping initial-box inputs: old explicitly subtracts the original box and applies `excludeBlock`; new `getBlockCollisions` includes collision shapes positively overlapping its vector-expanded box. No ordinary player movement witness where this exact membership difference changes a clip result was established here.
2. `hasLargeCollisionShape`, moving-block boundary categorization, changing/non-full provider shapes, and entity-specific collision contexts can change which shell cells are visited or whether a shape is emitted. Their provider/state pairing must supply the exact same effective shapes before extending the witness.
3. World-border treatment differs structurally: old passes a border flag and can substitute unit cubes outside the border; new seeds the border shape separately and checks it against the entity bounds. This report intentionally excludes that stream.
4. Old `isChunkLoaded` gating and new nonloading `getChunk(..., false)`/null behavior remain a separate chunk-validity condition.
5. One-axis new movement calls the block-state-aware `VoxelShapes.m_10425781` walker, not the mixed-vector stream. Its complete state/provider terminal coverage remains open under the existing provider and shape-context ledgers.
6. Main/step candidate order and the alternate old box selection have not been globally proven equivalent. This report closes only the exact routes and bounded disjoint-unit-cube membership case described above.

## Verdict

Bounded partial closure only. No independently accepted implementation claim is submitted. The exact branch identities above can be used as route crosswalk for follow-up provider/state pairing; the six residuals are concrete and should remain open.
