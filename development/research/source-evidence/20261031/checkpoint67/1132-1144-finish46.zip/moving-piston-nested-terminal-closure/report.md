# Moving-piston nested collision terminal closure: 1.13.2 → 1.14.4

## Verdict and boundary

The `MovingBlockEntity.getCollisionShape` wrapper is equal at both endpoints for equal moved state, block view/position, moving-entity fields, and `NOCLIP_DIR`. Its common nested moved-state provider families are compositional under the paired raw inputs in the reports listed below. Those pairings include known, already-closed output differences (beds and cauldron); they are version-specific nested results, not unpaired terminals.

One exact terminal remains outside finite-output closure: if `movedState` is itself `Blocks.MOVING_BLOCK`, the non-early-return branch calls the same `MovingBlockEntity.getCollisionShape` again through `MovingBlock.getCollisionShape` at the same world position. With a null or nonmatching no-clip direction this repeats without changing the queried entity or state, so no shape is returned before recursive exhaustion. This source-level recursive case is present in both releases. The assignment excludes proving a producer/trajectory for this `movedState`; therefore it cannot be classified as reachable or unreachable here.

**Freeze disposition:** a universal claim covering every arbitrary raw `movedState` remains blocked by this terminal until a separately authorized state-producer audit establishes that `moving_piston` cannot occur as the nested state, or the pair's scope explicitly excludes this nonterminating input. This is not a newly discovered endpoint difference and does not invalidate the closed wrapper or paired finite-output families. No trajectory result is claimed.

## Exact source identities

Canonical read-only trees: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Ornithe Feather Gen2 build 2.

| Endpoint | source manifest SHA-256 | ready-marker SHA-256 | provenance SHA-256 |
|---|---|---|---|
| 1.13.2 | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` |
| 1.14.4 | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` |

Full Java-file SHA-256 values, recomputed from those trees:

| Relative source | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |
| `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| registration (`net/minecraft/block/Block.java` old; `net/minecraft/block/Blocks.java` new) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

## Call chain and recursive witness

1. The ordinary collision route reaches the block provider from player/entity movement: 1.13.2 `Entity.move` obtains `WorldView.getCollisions`, whose block-cell loop calls `BlockState.getCollisionShape(world,pos)`; 1.14.4 movement obtains `WorldView.getBlockCollisions(entity,box)`, and its cell loop calls `BlockState.getCollisionShape(world,pos,CollisionContext.of(entity))`. The full caller routing and special admission of `Blocks.MOVING_BLOCK` are detailed in the paired `moving-piston-nested-shape-closure/report.md` (SHA-256 `d6033b942ad5c22cbf9eef4c109ef7a0d9116e69add337714ed56c66917fd640`).
2. `MovingBlock.getCollisionShape` at old `MovingBlock.java:108–111` and new `:104–107` looks up `world.getBlockEntity(pos)`. If it is a `MovingBlockEntity`, it delegates to that entity's `getCollisionShape(world,pos)`; otherwise it returns empty. The new collision-context argument is unused. `moving_piston` is `dynamicShape()` in both registrations (old `Block.java:951`; new `Blocks.java:333–334`), so the 1.14.4 static cache does not bypass this live lookup.
3. The entity wrapper bodies are operation-for-operation equal after the eight-line offset (old `MovingBlockEntity.java:324–352`; new `:332–360`). In the ordinary translated branch, old `:351` / new `:359` calls `blockState.getCollisionShape(world,pos).move(...)`. The nested call uses the same `world` and `pos`, with no new entity context. Old `BlockState.getCollisionShape(world,pos)` dispatches directly to its block (`BlockState.java:209–210`). New `BlockState.getCollisionShape(world,pos)` uses a state cache or the context overload with `CollisionContext.empty()` (`:197–203`); dynamic `moving_piston` has no static shape cache.
4. Choose matched inputs `movedState = Blocks.MOVING_BLOCK.defaultState()`, `extending=true`, `source=false`, `progress=0.5F`, and `NOCLIP_DIR=null` (or a direction other than `getMoveDirection()`). The early-return gate `progress < 1.0 && direction == getMoveDirection()` is false. The wrapper selects `movedState`; its collision query at `pos` reaches the same `MovingBlockEntity` again. Each invocation has the same branch inputs and repeats the call. The wrapper performs no state mutation before this recursion. Setting `NOCLIP_DIR` to `getMoveDirection()` takes the early return and yields the empty seed instead; that separate branch does not close the nonmatching-direction input.

This is a raw-state terminal witness only. It does not assert that a vanilla piston producer can create a moving entity whose `movedState` is a moving-piston state.

## Explicit provider-member roster

The complete direct shape/collision declaration roster is `providers/shape-provider-overrides.tsv` (93 rows at 1.13.2, 115 at 1.14.4; input hash below). The more specific dynamic/context roster and the nested terminal are:

| Member | Endpoint status for this nested path |
|---|---|
| `MovingBlock.getCollisionShape(BlockState, BlockView, BlockPos)` / `MovingBlock.getCollisionShape(BlockState, BlockView, BlockPos, CollisionContext)` | **Paired wrapper**: same block-entity lookup, type gate, delegation, and empty fallback. The ignored context does not affect output. This is the recursive dispatch edge when `movedState` is `MOVING_BLOCK`. |
| `MovingBlockEntity.getCollisionShape(BlockView, BlockPos)` | **Paired wrapper, terminal open only for recursive self-nesting**: same seed, no-clip/progress gate, synthetic piston-head selection, amount/translation, and union. Finite nested results compose under the table below; self-nesting above has no finite terminal. |
| `BlockState.getCollisionShape(BlockView, BlockPos)` | **Paired dispatch, different API/cache route**: old direct dispatch; new static cache or empty-context dispatch. For nested dynamic providers the cache is bypassed. |
| `ShulkerBoxBlock.getShape(BlockState, BlockView, BlockPos)` / context overload | **Paired under same block-entity input**. Since the nested query position contains the outer `MovingBlockEntity`, not a `ShulkerBoxBlockEntity`, both versions select the same full-cube fallback. Ordinary shulker-owned entity outputs for all 17 common registrations are separately paired; those are not the BE present at this same nested position. |
| `LiquidBlock.getShape(BlockState, BlockView, BlockPos)` / context overload | **Paired collision gate**: both water and lava registrations are `noCollision()`, so nested collision is empty before the world-sensitive outline provider can contribute. Outline differs but is not this collision terminal. |
| New-only `BambooBlock`, `BellBlock`, `ComposterBlock`, `GrindstoneBlock`, `LecternBlock`, `ScaffoldingBlock` direct shape/collision members | **Uncovered as common moved-state counterparts; excluded from the old-era paired-state roster** because none has a 1.13.2 common old-era block/provider registration. Scaffolding is the only direct context-reading 1.14.4 provider in the bounded dynamic/context inventory and is likewise new-only. |

For the remaining common state-only provider families, the cross-reference is registration exhaustive: `base-shape-registration-census/override-state-reconciliation.tsv` maps all 333 common registered IDs whose ancestry overrides shape/collision on either endpoint to named paired reports (310 in earlier rows plus the 23-ID residual closure). The residual 23 report enumerates all 551 common raw state tuples. The paired report hash index is `base-shape-registration-census/paired-report-sha256.tsv`. No common override registration is left without a named state/provider report in that reconciliation. This does not claim upstream production of every raw state or every world/block-entity input.

Already-paired compositional output families include the base block gate/cube; piston base and piston head; all enumerated stairs, slabs, trapdoors, doors, fence gates, fences, walls, panes, and snow; container/anvil families; chorus and shulker providers under their stated equal inputs; plants/crops and terrain/small colliders; rails/redstone/attachments; signs/skulls/banners/daylight detectors; special blocks; fluids and remaining 23 IDs. The paired-report index carries the member/state scopes and individual report hashes rather than duplicating their tables here.

Two previously paired common collision families are not equal-output compositions: **beds** remove lower collision volume in the new endpoint, and **cauldrons** subtract additional lower-interior volume. Their state tables/witnesses are already paired in `bed-shape-pairing/result.md` (SHA-256 `6d994a9b6650de912844eebd1a5f6da40e7b233e9b2cd4f1647d9ce2051a48ee`) and `cauldron-storage-shapes/result.md` (SHA-256 `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360`). They produce a known nested shape delta but are not unpaired provider terminals.

## Cross-referenced report hashes

| Input | SHA-256 |
|---|---|
| `providers/inventory.md` | `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480` |
| `providers/shape-provider-overrides.tsv` | `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad` |
| `moving-piston-nested-shape-closure/report.md` | `d6033b942ad5c22cbf9eef4c109ef7a0d9116e69add337714ed56c66917fd640` |
| `piston-shape-pairing/result.md` | `1f288c9c75a144a84b3ccbff70939114807e0add8c551586ce70659c1f46010e` |
| `dynamic-provider-movement-gap/result.md` | `82c9fe973c72442510236677b8a04193fd1b8a58781b5c17ff85933c965c3d01` |
| `base-shape-registration-census/override-reconciliation.md` | `c1a79be223fae45a3769dde887603307f660097c9dfde26a6ae2fff6f239d327` |
| `base-shape-registration-census/override-state-reconciliation.tsv` | `2acc1d339ab0e4a8e08d1bbcb16b17d52a0b96546a08455086809d3b0a5a9c17` |
| `base-shape-registration-census/paired-report-sha256.tsv` | `3837770774fdbdd6858d0739e4f8df2dd612b566b9bdac876bd7e2d81c6b6229` |
| `residual-23-provider-state-closure/result.md` | `3de5b5bddad70ac2aa02c6120c7bc4c47f885b1626ddc002ea5b01a7533bc111` |
| `bed-shape-pairing/result.md` | `6d994a9b6650de912844eebd1a5f6da40e7b233e9b2cd4f1647d9ce2051a48ee` |
| `cauldron-storage-shapes/result.md` | `f5cffa49d2d8cbf10dfed12bbb513123002abaec32c0c532825e39cf6de84360` |

No producer reachability, trajectory, rendering, product, wiki, backlog, Git, or runtime claim was evaluated. No source tree was written, regenerated, or decompiled; no build, test, game, TAS or server was run.
