# Addendum: matched recursive self-nesting terminal

This addendum refines the self-nesting disposition in `report.md`. It uses the same Feather endpoint pair and does not claim that a vanilla producer creates this raw state.

## Exact paired condition

Set `movedState` to the registered `Blocks.MOVING_BLOCK` state and use a `MovingBlockEntity` at the queried position. Select `NOCLIP_DIR == null` or any direction unequal to `getMoveDirection()`. The condition is matched at both endpoints. The `progress < 1.0 && direction == getMoveDirection()` early return is false; the source-piston seed is empty for `extending=true` (and otherwise the same seed is computed at both endpoints before that gate).

Both `MovingBlock.getCollisionShape` implementations perform the same lookup at the same position, test for `MovingBlockEntity`, then call that entity's `getCollisionShape(world,pos)`; otherwise they return empty. The registered moving-piston block is dynamic at both endpoints, so 1.14.4's static provider cache does not replace this live route. In both entity methods, the unmatched-direction branch selects `movedState`, computes the same extension translation from identical fields, and evaluates the nested `blockState.getCollisionShape(world,pos)` before the final union. With the selected self-state, that dispatch returns through `MovingBlock.getCollisionShape` to the same block entity with the same world, position, moved state, progress, flags, facing and no-clip direction. No field is mutated along the recursive collision-query path. Each call therefore repeats the same recursive input. Neither endpoint returns a finite shape for this matched raw condition.

The recursive route computes only collision-shape values. It performs no entity position, velocity, pose, or movement-flag write before recursive exhaustion. The movement caller cannot proceed to clipping or a movement write through this provider on this input. The permitted conditional disposition is consequently **equal non-result / no additional eligible movement result before failure**. It is not a claim that recursion is generally ignorable: the equal result depends on the exact matched no-clip gate, self-state, registered dynamic dispatch, same-position block-entity lookup, and unchanged recursive inputs above. The other no-clip branch, where `direction == getMoveDirection()` and `progress < 1.0`, takes the same early return at both endpoints and is not recursive.

## Primary source identity

Canonical read-only roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.

| Source | SHA-256 |
|---|---|
| 1.13.2 `net/minecraft/block/entity/MovingBlockEntity.java` | `6684ccc05adf8b29cac55f9796133405c6d4f6853051e651895303b657cd1c46` |
| 1.14.4 `net/minecraft/block/entity/MovingBlockEntity.java` | `e03c4123c06309c04dbc039c6f276f1bf988018a4f13cc329bd6d07acc6bc54a` |
| 1.13.2 `net/minecraft/block/MovingBlock.java` | `19b8a41104da7b13eac58e2c01704043f6ff7ac1eea33457833bd41ea5810d61` |
| 1.14.4 `net/minecraft/block/MovingBlock.java` | `6e3ec2d4c9712f8012bb2bcad5474125dacd1acf3d4b02bd8a5d8ea0c4bf4e6e` |

The exact entity-member bodies and recursive call chain are in `report.md`, section “Call chain and recursive witness.” Registration/cache-gate evidence and the wider provider roster are in that report, section “Explicit provider-member roster.”

No producer reachability, trajectory, or runtime behavior was checked. No canonical source was modified.
