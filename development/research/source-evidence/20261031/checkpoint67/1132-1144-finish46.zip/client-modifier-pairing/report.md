# 1.13.2 → 1.14.4 client attribute, effect, and equipment modifier pairing

## Scope and result

Paired the downstream client-local-player terminals for movement modifiers under equal packet values, preexisting attribute/effect state, and call order. Covered attribute packet application and speed aggregation; effect add, upgrade, and removal callbacks; equipment and inventory-slot writes; and item modifier evaluation/application. This report relies on the ordinary state/history comparison assumptions in `../ordinary-tick/source-review.md` and on the packet-handler inventory in `../client-response-pairing/report.md`. It does not establish packet-producer parity, intermediate-version cutovers, dependency closure, or full-pair freeze.

**No movement-modifier behavior difference was found in these paired terminals.** The source representation changes attribute operation indexes from integers to named enum values in 1.14.4; the values/order remain addition, multiply-base, multiply-total, and the movement-speed calculation order is unchanged.

## Exact source identity and integrity

Read-only source roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Both ready records identify exact versions, Ornithe Feather Gen2 build 2, Vineflower, Java 25; source counts are 2,711 and 3,250. Ready-marker hashes: `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` and `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77`. Provenance hashes: `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` and `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9`.

Source-manifest hashes: `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4). Artifact-manifest hashes: `fdcacd9150f98ea70acafc5cab754027ab1a09828ff0eaa8e542dd7890d9ce1e` and `308cc33ef6dffc047432ade6affc88eccc9de94a736ee9a98571fd92915c2970`. I independently recomputed the hashes below and confirmed each equals its exact source-manifest entry. The old ready record names its artifact manifest `artifacts.sha256`; the newer one names it `ornithe-feather.artifacts.sha256`.

| Relative source file | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| `net/minecraft/entity/living/player/PlayerInventory.java` | `aaa7aca61fc15557ec7b6fb04e5fd63c5d1b0f9c41bd697cb10068ec150e474d` | `7a23a36d8919a6e19a1a9050f2170aa1f3b9bc2eeaf9aaa05b56b006aacfb06a` |
| `net/minecraft/item/ItemStack.java` | `ab31c259964fdc7e8c4a6fdfd57371fca2146d8823eb6db6eae783e3eec89d66` | `e392bd2181b24a8386483d40f06567caab57b3f522f11ce13215b7a91974bf4b` |
| `net/minecraft/item/Item.java` | `25149bc5cc22fa4e39e9f4ac4928d800b9c8c305bf555271c96f3d29d48dcd82` | `ba876b88b116bf86cce2de66f8cd8e2131a93b7af23a6cfa0e69ab98ed0e264b` |
| `net/minecraft/item/ArmorItem.java` | `6c1e6ab9a7ee2dd389b83342d1370b120487aa9a80ce0e555c229598f85b3309` | `3d82c93f41d7b2cff2ddbbf77d99327b5082d0e9e9d1450f4b3316263c7ba1af` |
| `net/minecraft/item/HoeItem.java` | `ffc5cfead1acff60bea1f71678c2e3678ae0ddeade8e22f371d6e35b2a90e0d0` | `5ccd4ffea7d1695f0748f774b8853f04b8dc957f6a0b0db5a095ce2e848c7267` |
| `net/minecraft/item/MinerItem.java` | `f794fb022eb4d82c96d2ea7c3fe99b3ccf42bb7b771b5580b4e0def08691170c` | `c88d04d9d0b2e52468e8fe62e41f628726305e2992ccd696d794892462daee5c` |
| `net/minecraft/item/SwordItem.java` | `b40a4da99dd693320ccab1013bea75ccff1ab537b71d5efe40aae7c78e830dac` | `2a9878c2a33c9c54097b8905f6e26bbd8fd7ce1616a101b9dd8530bd1942d09a` |
| `net/minecraft/item/TridentItem.java` | `97e5b7c3a84ba25c0dd229b78f571c936d7370006585c531896d5c49c76437f3` | `6d28897aac9518f54a07fd3d0f81baa54d60f1f82b7dab6bb75dbab793525813` |
| `net/minecraft/entity/living/effect/StatusEffect.java` | `60cc53e7233d28413d3c93292fd216babe8ea9edeb70774141b68101c515c639` | `9648b2d33f1adefafff71e1c14fa6427194ad2cff4ff242a4b2db355daa71085` |
| `net/minecraft/entity/living/effect/StatusEffectInstance.java` | `4e32f77b5e656de2f07b8ec2851dde4c3ee107f773984d2c03774f0c24a33e93` | `4e32f77b5e656de2f07b8ec2851dde4c3ee107f773984d2c03774f0c24a33e93` |
| `net/minecraft/entity/living/effect/StatusEffects.java` | `d982a7e051da6014286e07dcbfd36fd62dd0faa4ae5218a1c2d89bff02a78d9e` | `46cf6a77e95de8be46feb39b258ef1eb4fd2d9f34538bd2d027bb9d58427500f` |
| `net/minecraft/entity/living/attribute/ModifiableEntityAttributeInstance.java` | `4eec5f0347baba347a84e4c66702321fb34157329f95e70e8ce541aeb4bf6b7a` | `4ff7dd1bf7a48e4894860cb048bc9c6a8adcc8b98b9c5d29ce28da2a15db8f69` |
| `net/minecraft/entity/living/attribute/AbstractEntityAttributeContainer.java` | `62d1b62a04daeb72335871435def3a7b1bcd30d7169ef68d9d24605d37895940` | `05c229e1a8462ef94dde0af269238c17ba218bf2b67431196576c16861e574a1` |
| `net/minecraft/entity/living/attribute/EntityAttributeContainer.java` | `63eac4b5c49e216a7bef6d03da42eba9737c6e2d215acbb6ee27c11dde89a506` | `63eac4b5c49e216a7bef6d03da42eba9737c6e2d215acbb6ee27c11dde89a506` |
| `net/minecraft/entity/living/attribute/EntityAttributes.java` | `19b33da74fcfbb08b98e80c15554929229b1c3b36d009215b1803190f2ff755d` | `e70c1eebe94cf368f3f0eb9bd5513cb2982049f6be9662d3b02b97c72490d20d` |
| `net/minecraft/entity/living/attribute/RangedEntityAttribute.java` | `558c98a1f7f8dd2624061344fb4f8b53383cf3469f3ee8f4bcefb32b1e1791b6` | `558c98a1f7f8dd2624061344fb4f8b53383cf3469f3ee8f4bcefb32b1e1791b6` |
| `net/minecraft/entity/living/attribute/AttributeModifier.java` | `1344f4552f37d8530e5e6df14f19c7e5cce2ab24183754ae3fd5ecd4f9467328` | `8dcb59bf00043beda44a4f69e1905dbb281219984c2725c1e269a95e0920b7d6` |

## Ordered paired terminals

### Attribute packet and movement-speed calculation

The packet inventory identifies `ClientPlayNetworkHandler.handleEntityAttributes` at 1.13.2 `:1934–1960` and 1.14.4 `:2083–2109`. Both resolve the packet entity by ID, set/create each supplied attribute instance, set its base, clear modifiers, then add the supplied modifiers. The local player is reachable by this route at both endpoints. Under the paired-input assumption, downstream attribute state receives the same base/modifier sequence.

`PlayerEntity.initAttributes` sets movement-speed base to `0.1F` in both versions (old `PlayerEntity.java:158–159`, new `:190–191`). `PlayerEntity.getSpeed` returns `(float) getAttribute(MOVEMENT_SPEED).get()` in both (old `:1488–1489`, new `:1425–1426`). `LivingEntity.setSprinting` performs the same sequence on both sides: call `super`, remove the known sprint modifier if present, then add it iff `sprinting` is true (old `LivingEntity.java:1349–1358`, new `:1640–1649`). The modifier remains amount `0.3F`, total-multiply (old `LivingEntity.java:96–98`, new `:114–117`).

`ModifiableEntityAttributeInstance.get()` retains the dirty-cache gate and lazy recomputation. `computeValue()` uses base, sums operation 0 additions, derives the multiply-base term from that subtotal, applies operation 1 modifiers, then multiplies each operation 2 factor, and clamps at the end (old `:138–164`; new `:132–158`). 1.14.4 names those same operations `ADDITION`, `MULTIPLY_BASE`, and `MULTIPLY_TOTAL`; its enum explicitly assigns `0, 1, 2` in that order (`AttributeModifier.java:86–91`). The movement-speed attribute still has default `0.7F` and clamp range `0.0–1024.0` (`EntityAttributes.java:19–21`); `RangedEntityAttribute.clamp` is byte-for-byte identical at both endpoints. The operation-type change is representational, not a math/order change.

### Status-effect add, upgrade, and removal

Local status-effect packet routes from the supplied inventory are `handleEntityStatusEffect` at old `:1396–1409` → new `:1453–1466`, and `handleEntityRemoveStatusEffect` at old `:1488–1494` → new `:1548–1554`. They resolve the entity ID and call `LivingEntity.addStatusEffect` / `removeStatusEffect`; neither excludes the local player.

The paired `LivingEntity.addStatusEffect` gates and ordering match (old `:665–681`, new `:765–781`): reject effects failing `canHaveStatusEffect`, insert and call `onStatusEffectApplied` when absent, otherwise combine and call `onStatusEffectUpgraded(instance, true)` only when the instance changes. `removeStatusEffect` removes first and calls `onStatusEffectRemoved` only for a prior instance (old `:703–710`, new `:803–810`). `StatusEffectInstance.combine` is byte-identical at both releases (`:54–84`): amplifier/duration priority and ambient/particle/icon updates are the same.

All three callback bodies match in movement-relevant gates and order (old `LivingEntity.java:713–734`, new `:813–835`). Each marks `effectsChanged`; add applies modifiers only when `!world.isClient`; upgrade reapplies only when `timerRanOut && !world.isClient`, removing then adding; remove removes only when `!world.isClient`. On the local client these callbacks therefore mutate effect-list/notification state but do not mutate the movement-speed attribute. The paired speed/slowness registrations retain the same UUIDs, `0.2F` / `-0.15F` amounts and total-multiply operation; declarations move from old `StatusEffect.java:213–221` into new `StatusEffects.java:14–25`. `StatusEffect.addModifiers` still removes the matching UUID before adding a new modifier with `modifier * (amplifier + 1)` (old `StatusEffect.java:169–198`, new `:141–170`). No effect callback delta found.

### Equipment, inventory slots, and item modifiers

The supplied handler inventory pairs entity equipment handling at old `ClientPlayNetworkHandler.java:1115–1121` → new `:1188–1194`, inventory slot/content at `:1006–1036` → `:1076–1108` and `:1055–1063` → `:1127–1135`, and selected slot at `:574–579` → `:606–611`. Those handlers resolve/write the local player’s equipment or menu/inventory state. The same upstream inventory identifies them as body-matched except the cursor-only creative-screen case, which does not change equipped attributes.

`PlayerEntity.setEquipment` has the same branches at old `:1741–1752` and new `:1678–1689`: play equip sound, then write main hand to `inventory.items[selectedSlot]`, off hand to slot zero, or armor to `inventory.armor[slot id]`. It does not evaluate or apply item attribute modifiers. `PlayerInventory.setItem` likewise maps the flat slot through compartments and writes the chosen `DefaultedList` directly (old `:399–414`, new `:400–415`); it contains no attribute update. Selected-slot updates only choose which hotbar entry is returned as main hand.

`ItemStack.getAttributeModifiers(slot)` is structurally the same (old `ItemStack.java:723–744`, new `:739–760`): parse per-stack `AttributeModifiers` entries when present; retain entries whose optional slot matches and whose UUID has nonzero upper and lower bits; otherwise delegate to `Item.getDefaultAttributeModifiers(slot)`. The base item getter returns an empty multimap. The paired vanilla overrides for armor, hoes, miner tools, swords, and tridents produce armor/armor-toughness or attack-damage/attack-speed entries; none supplies movement speed. Newer operations use named `ADDITION` where the old methods use integer `0`, preserving the source operation order shown above. The local equipment and inventory synchronization methods do not call the item getter or attribute-container add/remove methods, so a same-item packet change does not itself change local movement speed through this path.

`LivingEntity.writeCustomNbt` temporarily removes equipped-stack modifiers before serializing attributes, then reapplies them in slot order (old `:470–491`, new `:513–535`). That sequence is identical and restores the runtime attribute state; it is not an equipment synchronization callback.

## Pair disposition

No movement-modifier source difference found for the requested client-local-player effect/equipment terminals or movement-speed aggregation under paired raw inputs. Incoming attribute packets remain a separate direct mutation route and were not used to infer what a server sends. Ordinary state history and downstream movement consumers remain those of the permitted source-review assumption. No source tree was changed; no decompilation, product/wiki/backlog/Git-history inspection, runtime, build, or tests were performed. This report makes no pair-freeze claim.
