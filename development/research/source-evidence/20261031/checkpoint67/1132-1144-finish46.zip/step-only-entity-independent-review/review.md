# Independent review: step-only entity candidate terminal

## Verdict

**Accepted after correction.** I reviewed candidate SHA-256 `0D35292EE9B72894B49181D3C7A9619FAD37B4A30AE143D01838B0FFABC7D43A`. Its corrected account of the old alternatives now matches the exact source: the expanded alternative rises about `0.1000000477`, moves X `0.1999999881`, and descends to Y zero; the other alternative rises `0.6F`, moves X about `0.1`, and descends to Y zero. The first has greater progress than the second but ties ordinary movement, so the strict comparison restores ordinary movement. The new operation still returns `(0.7, 0.5, 0)` under the stated raw inputs, with the reported flags.

This is a direct source-operation comparison under the stated raw inputs. It does not establish a producer history or a runtime trajectory.

## Corrected old step path

Old `Entity.move` captures the initial requested `(0.7, 0, 0)`, resolves ordinary movement, then enters the step gate because the raw `onGround` input is true and ordinary X was clipped. It creates one collision-shape candidate list for the step query and uses it in both alternatives. The step candidate query sweeps to Y about `2.4`, so it contains the Boat; the ordinary query tops out near `1.8`, so it does not.

For the first alternative, old `Entity.move` computes `box4 = box3.expanded(x, 0, z)` before its upward clip. That X-expanded box intersects the Boat's XZ footprint. The player's original top is `1.7999999523162842`; the Boat starts at Y `1.9`, so the upward displacement is capped at about `0.10000004768371582`, not `0.6`. Once raised to that contact height, the epsilon-adjusted orthogonal overlap excludes the Boat from the horizontal clip. The slab clips X to `0.19999998807907104`; at that endpoint the same epsilon adjustment excludes the slab from the downward clip, so the player returns to Y zero. Its horizontal progress squared is therefore the same as ordinary movement, about `0.04`.

For the second alternative, the vertical pass starts from the unexpanded player box and can rise by the full `0.6F`. The subsequent horizontal pass overlaps the Boat vertically and X-wise, so Boat clips X to about `0.099999988079071`. At that X position the slab does not constrain descent; the player returns to Y zero. This alternative has horizontal progress squared about `0.01`.

Old code selects the first alternative (`0.04 > 0.01`) and then accepts a step only when its progress is **strictly greater** than ordinary movement. The equal `0.04` progress makes it restore ordinary movement. Thus the candidate's old final vector and collision flags still follow: old horizontal collision true, vertical false.

## New endpoint and fixture checks

The new operation queries entity and border candidates once from the original swept box and reuses that candidate stream for step attempts. Its entity query box ends below Boat `minY=1.9`, while mixed-axis resolution rebuilds block candidates. On the raised path the slab does not constrain horizontal movement, so the player travels X `0.7`; the final downward pass overlaps the slab and clips at its top, leaving Y `0.5`. This improves horizontal progress over ordinary movement and is returned. New flags are horizontal false and vertical true, consistent with the requested vector `(0.7, 0, 0)`.

The stated player box follows old player dimensions and `Entity.setPosition` float arithmetic. The Boat's dimensions and own-box collision shape, and the bottom slab shape, match the cited endpoint methods. The raw `onGround=true` bit is treated as an operation input; no producer claim is made.

## Source identity verification

I independently recomputed all **19** listed source SHA-256 values from the version-root `ornithe-feather` Feather trees. All match both the report table and their respective version-root `ornithe-feather.sources.sha256` manifest entries. The candidate `result.md` SHA-256 is `946D6AB45AFDE93649814FE457065F052908649514E20DC206953BC73A7EAAC5`, as assigned.

## Corrected candidate verification

The revised report SHA matches the assigned value. I recomputed all 19 listed source SHA-256 values from the read-only Feather trees and checked each against its version-root `ornithe-feather.sources.sha256` manifest; all match. The result remains a bounded source-operation witness for the same raw inputs, with producer validity and runtime trajectory outside the claim.
