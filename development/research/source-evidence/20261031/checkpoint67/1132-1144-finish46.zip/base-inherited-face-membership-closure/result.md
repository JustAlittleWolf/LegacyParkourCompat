# Inherited face-predicate closure for common base-shape registrations

## Result

The 262 common registry IDs that inherit both old/new base shape methods are now accounted for in the movement-facing face terminal. Of these, 252 inherit the old `Block.getFaceShape` default; their registered collision shape is the base cube for every raw state and context. Ten inherit a more specific old face provider from the concrete class or an ancestor and are referenced to the existing face-provider closures rather than re-enumerated.

For the 252 default-face registrations, the old and new horizontal helper results are state-invariant under the same raw block/fluid inputs and generated vanilla tag recipes:

| Old horizontal result | New horizontal result | IDs | Explanation |
|---|---|---:|---|
| true | true | 224 | Old base face is `SOLID`; no old helper exception applies; new collision face is the full unit face and the ID is not default `LEAVES`. |
| false | false | 8 | Six leaf IDs are rejected by both old leaf-class exception and default new `LEAVES`; `ice` and `frosted_ice` share the old/new `Material.ICE` early gate. |
| false | true | 20 | Old attachment exception suppresses `glass`, all 16 stained-glass IDs, `beacon`, `glowstone`, and `sea_lantern`; each keeps full-cube collision and is not in default `LEAVES`, so the new sturdy path returns true. These are conditional face-terminal formula differences already included in the pair's fluid-face dispositions; this report does not assert a fluid/player trajectory. |

All ten non-`Block` old face-provider registrations are also accounted for: `chorus_flower` (one direct `UNDEFINED` provider, collision cube, already covered as the accepted chorus-current face difference); `cobweb`, `end_gateway`, and `kelp_plant` (three direct `UNDEFINED` providers with empty collision); and `large_fern`, `lilac`, `peony`, `rose_bush`, `sunflower`, and `tall_grass` (six registrations inheriting `PlantBlock.getFaceShape=UNDEFINED` with empty collision). Their old and new horizontal helper results are false except chorus flower, whose new cube face is true. The exact provider outputs and state domains are in the existing `fluid-face-unpaired-closure/result.md`, `plant-crop-shapes-pairing/result.md`, and `face-inherited-census/result.md`.

These counts are for horizontal faces, the only directions sampled by the falling-fluid caller. For both endpoints, UP is the common early-true case unless the same-fluid gate fires; DOWN is not queried by that caller.

The machine-readable table has one row for each of the 262 registrations: `registration-face-results.tsv` (all raw registered states are covered because the paired base shape methods do not read state, direction-specific geometry, world, position, or collision context; the default-tag and material gates are registration-constant). There are no unresolved inherited/default face IDs in this 262-row slice. The 333 separate custom-shape registrations remain governed by their named provider reports or the residual-23 closure; this result does not close pair-wide collision/order/context inputs.

## Source path and exhaustive basis

The old falling-fluid caller queries horizontal neighbor faces and the same horizontal faces one cell above on its falling branch. Its `isSolidFace` order is: same-fluid rejection; UP early success; `Material.ICE` rejection; `Block.isExceptionForAttachment` / stairs rejection; then `BlockState.getFaceShape(...) == SOLID`. For IDs inheriting `Block.getFaceShape`, the returned `SOLID` value is constant. The 252 common registrations have the same default base shape and `hasCollision` gate at both endpoints; the registration census reports collision-enabled base cubes and `dynamicShape=false` for every one. The old helper's exception list and Material.ICE test are fixed by registered ID/material and do not read per-state properties.

The new caller preserves same-fluid, UP and `Material.ICE` gates, then asks `BlockState.isFaceSturdy`, which reaches `Block.isFaceSolid`: reject default `BlockTags.LEAVES`, then require a full boundary face of the collision shape. For each of the 252 default-face registrations, the new full-cube collision shape therefore gives true on every direction except the six default leaves; the two ice registrations are rejected earlier by the shared ICE gate. `BlockState`'s face cache cannot add a state/context branch here because all 262 base-shape registrations have `dynamicShape=false`, and the base shape methods ignore state/world/position/context. The paired default `TRAPDOORS` recipe contains seven registered IDs (six wooden and iron); none is in this 262-row set because each uses a custom trapdoor shape provider.

The ten old non-default face-provider IDs above were cross-referenced against the 65-row old direct face inventory and its ancestor census. Their exact source methods/state domains are not recounted here. The old/new default `LEAVES` recipes contain exactly the same six old-era leaf IDs; the default `TRAPDOORS` recipe is also paired and none of its registered members belongs to the 262 base-shape set. Active runtime tag replacement and tag/fluid/block/player production are excluded inputs.

## Exact inputs and hashes

Primary sources are the read-only 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 publications. I recomputed the relevant source hashes and matched each file against its endpoint `ornithe-feather.sources.sha256` manifest. Source-manifest SHA-256 values are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` (1.13.2) and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` (1.14.4).

| Release | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.13.2 | `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` |
| 1.13.2 | `net/minecraft/data/tag/BlockTagsProvider.java` | `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` |
| 1.13.2 | `net/minecraft/tag/BlockTags.java` | `61ece958afe7fb7faca880064fcc11edd6f07fbc9fb118f0de22b6de6d2e9143` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `net/minecraft/fluid/FlowingFluid.java` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0f0ef100c44fb8372d3e148ce` |
| 1.14.4 | `net/minecraft/data/tag/BlockTagsProvider.java` | `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |
| 1.14.4 | `net/minecraft/tag/BlockTags.java` | `dc59d07204b25e5d852d0384e849975367590a3cbc2b9a293396d0bf5637e52a` |

The 262-row registration input is `../base-shape-registration-census/inherited-common-registrations.tsv`, SHA-256 `44005de72f8e952c0dd72c19d0e6d037d5040f86d27482cd698d69c7b2d269af`; the old direct-face inventory is `../providers/fluid-face-shape-providers.tsv`, SHA-256 `dd6cebcfb8be7c4ccf51c2fa23a45115c3cd19b5aecaa64a2bdeaeef44038fb20`. Tag recipes and generated membership are independently source-verified in `../default-tag-provider-membership/result.md` (SHA-256 `869cea6924bf3e233cd1c1ad70d05c20b0bc6947a236f2c81e1b39109671d065`).

This closes a bounded registration/state-invariant face-predicate slice. It is not a new candidate finding, does not expand the accepted chorus claim, and makes no full-pair freeze or runtime trajectory claim. No product/wiki/backlog/Git information was read; no canonical source, build, test, or runtime operation was performed.
