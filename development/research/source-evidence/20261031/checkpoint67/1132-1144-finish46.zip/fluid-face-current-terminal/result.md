# Fluid face → current → player velocity terminal: 1.13.2 → 1.14.4

## Scope and verdict

Source-only continuation for the exact Ornithe Feather Gen2 build 2 pair. Inputs were limited to the assigned prior closure/inventory/pairing reports and the canonical read-only endpoint sources. This closes one default-vanilla, same-state stair fixture through `FlowingFluid.getFlow`, `Entity` body-fluid current accumulation, the velocity writer, and the local-player water-travel read. It assumes the same raw block/fluid snapshots and player position in both endpoints. It does not prove the fluid or player state was produced in a trajectory, fluid tag payload provenance, or pair freeze.

**Verdict:** the selected fixture returns different current vectors and, for the paired player query, writes a different player Y velocity (`-0.014` added only in 1.14.4). That is a direct source-level velocity difference for the query. The subsequent water-travel path consumes the changed velocity, but this report does not calculate the resulting position/trajectory or prove the paired snapshot is reachable.

## Concrete paired fixture

Coordinate the fluid cell as `P=(0,0,0)`. Raw logical state snapshot:

- At `P`, the same vanilla WATER flowing-fluid state in both versions: flowing `LEVEL=8, FALLING=true`; raw height is `8 / 9.0F`.
- At `P + SOUTH=(0,0,1)`, `minecraft:stone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]`.
- All other horizontal neighbors of `P` are air with empty fluid; their cells above and below are air/empty fluid. In particular there are no other horizontal-face-solid cells and no same-fluid states below an air neighbor. The stair cell has empty fluid.
- Active tag assumption: the fluid state matches `FluidTags.WATER`; use default vanilla tag membership. Custom/runtime tag replacements are out of scope.
- Local-player query position `(x,y,z)=(0.5,0.48,0.5)`, ordinary standing width/height `0.6 × 1.8`, and `hasLiquidCollision()==true`. Under the same box dimensions, `getShape().contract(0.001)` bounds are `[0.201,0.799] × [0.481,2.279] × [0.201,0.799]`, so the strict loops visit exactly x=0, y=0..2, z=0; only `(0,0,0)` contains tagged fluid. The area-loaded client gate is assumed true.

The common `stone_brick_stairs` registration and state properties are inventoried in the permitted provider report. For this south-facing straight bottom state, shape index 12 fills the SOUTH face. The generated vanilla `LEAVES` recipes on both endpoints include the six vanilla leaf blocks and omit stairs; custom/runtime tag replacements are excluded.

## Flow-vector branch and arithmetic

At `FlowingFluid.getFlow`, the horizontal gradient pass visits directions in `Direction.Plane.HORIZONTAL` order. Empty neighbor fluid states pass `canFlowInto`; each has raw height zero. Air allows its lower-neighbor check, whose fluid is empty; the stair neighbor blocks movement, so its lower-neighbor check is skipped. Thus every `g` remains `0.0F`, and the initial vector is `(0,0,0)`.

The state's `FALLING=true` gate runs the second horizontal pass. At the south stair, the old `isSolidFace` returns false because it explicitly rejects `StairsBlock` before its `FaceShape.SOLID` query. The new `isSolidFace` delegates after the same-fluid/UP/ICE gates to `BlockState.isFaceSturdy`; under the stated vanilla LEAVES recipe it returns true for this stair's full SOUTH collision face. Earlier north and east faces are air; the west face is checked after south only if south fails. Therefore 1.13.2 never enters the falling-wall response for this fixture and returns `normalize(0,0,0)=(0,0,0)`. In 1.14.4, the first matching face performs `normalize(0,0,0) + (0,-6,0)`, then the method's final normalize returns `(0,-1,0)`.

The fluid body scan sees one qualifying tagged cell. Its surface is `0 + 8/9`; contracted `box.minY=0.481`, so immersion depth is `max(8/9 - 0.481,0) ≈ 0.4078889`, not less than `0.4`; the per-cell flow is not depth-scaled. Contributor count is one. Player instances are not normalized by the entity scan. Old accumulated flow remains zero, so its `length()>0` writer gate is false. New accumulated flow is `(0,-1,0)`, so the writer adds `flow.scale(0.014)=(0,-0.014,0)` to existing velocity. Since paired prior velocity is an assumption, this establishes the exact delta, not an absolute resulting velocity. It is different for this player query.

`LivingEntity.baseTick` calls `super.baseTick`; `Entity.baseTick` calls the water-state refresh (`m_03231680` → `checkWaterState` → `m_69693160(FluidTags.WATER)`). `LivingEntity.tick` reaches `moveRelative` for ordinary local-player movement. In `LivingEntity.moveRelative`, the ordinary water branch is selected when `isInWater()` is true (the flying-player exception is not needed here). The branch reads the current velocity for `updateVelocity`, passes it to `move`, then damps it with the water friction (`x/z * f`, `y * 0.8F`); gravity and horizontal-collision handling follow. This connects the query's velocity write to a movement consumer while leaving subsequent trajectory effects unasserted.

## Exact paired source references and hashes

All hashes below are whole-file SHA-256; source paths are relative to each canonical root `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/ornithe-feather/`.

| Source | 1.13.2 lines / SHA-256 | 1.14.4 lines / SHA-256 |
|---|---|---|
| `net/minecraft/fluid/FlowingFluid.java` — `getFlow` and `isSolidFace` | `54–99`, `105–123` / `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` | `54–100`, `106–115` / `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |
| `net/minecraft/entity/Entity.java` — `hasLiquidCollision`, `m_69693160` | `2168–2170`, `2509–2571` / `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `2177–2179`, `2563–2622` / `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| `net/minecraft/entity/living/LivingEntity.java` — base tick and `moveRelative` water branch | `241–…`, `moveRelative` `1478`, water travel `1619–1653` / `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `272–…`, `moveRelative` `1786`, water travel `1884–1923` / `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `net/minecraft/block/StairsBlock.java` — state/shape tables | `33–36`, `39–105`, `330–331` / `b226eb255a3a1b0a69e137c15024a3b0a48f488e7205174dd476ffd64ca82761` | `33–36`, `39–105`, `283–284` / `b49cbd43a9be5e848623f25769dede5795f50435ba0e82bbdbbf571527396b9f` |
| `net/minecraft/block/Block.java` — old exclusion/new face-sturdy helper | `241–257` / `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `402–410` / `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| generated vanilla leaf recipe | not required for old predicate / provider hash `db7e0aa20a1e9429380328b64812bdff9d2d4b3b9d2016888cb7348d0ebafc7e` | `net/minecraft/data/tag/BlockTagsProvider.java:299–300` / `0bd051d11a0c85ecc61cd2202a6ed33923db97238da0b065a647b932132d1bfa` |
| `net/minecraft/util/math/Vec3d.java` — `normalize` | `25–28` / `6941a43536e8aefaa435a4e5f1731b0fa26a9d96503d1f4d07de8950c297f3c5` | `25–28` / `b69b990b768e52d6fac6b3ed82f60e7526e78d0837c868a61a4171ebca21040b` |
| `net/minecraft/block/state/BlockState.java` — face-sturdy query | not present / — | `326–327`, cache `412–416` / `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

Existing permitted pairing evidence records the exact stair's full-SOUTH-face result and old/new flow method hashes: `FlowingFluid.getFlow` old `5f087818428f5ee4a5a23175bc06cab7e475ec14db510446ac5ec001998f50ba`, new `bce8b1d7cc4f819b67bca47113be6ac06607c00e0af5e7bca77794dafb1c9f12`; `Entity.m_69693160` old `726db8f04f0d42a8d71c3ee6c212edd01d561b9605326919aacb5e60a23e0a73`, new `bd5e8e8455b520120b65b7a90ce215cdacad4367950d926fa1527a5b28cc53d7`. These method hashes use the prior report's source-text normalization (UTF-8, LF, final LF).

## Limits / next action

This closes only one static, default-vanilla fixture under identical snapshot/position assumptions. It does not show that a falling water state, exact stair arrangement, and player position arise from ordinary fluid ticks and player inputs; does not establish a complete state/packet/tag producer chain; and does not prove a full tick-level trajectory. Pair completion and independent full inventory audit remain open.
