# Non-oak slab and trapdoor shape pairing: 1.13.2 → 1.14.4

## Scope and evidence identity

Source-only comparison of exact 1.13.2 and 1.14.4 Ornithe Feather Gen2 build 2 source trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. This pass uses the canonical Feather pair only. The permitted existing `common-block-shape-pairing`, `fluid-face-slab-trapdoor-snow`, pane/snow/fence pairing, and provider inventory were used to avoid repeating already closed oak shapes and to reuse the established dispatch/tag contract. Endpoint source-file hashes, manifest hashes, ready-marker hashes, and provenance hashes are in [`source-hashes.tsv`](source-hashes.tsv).

This tranche pairs every common, non-oak registered `SlabBlock` and `TrapdoorBlock`: 18 slab IDs and 6 trapdoor IDs. Oak slab and oak trapdoor remain in the cited common report. Full Cartesian logical state domains are expanded in [`state-pairing.tsv`](state-pairing.tsv), 492 raw states total; the six-face fluid predicate expansion is in [`fluid-face-pairing.tsv`](fluid-face-pairing.tsv), 2,952 rows total. Exact common registration identities and source lines are in [`registrations.tsv`](registrations.tsv).

No block-state production history, state reachability, player trajectory, runtime tag payload, intermediate release, or full-pair freeze is claimed.

## Exact closed registrations and state domains

Each listed ID is registered with the same provider class at both endpoints. In 1.13.2 registrations are in `net/minecraft/block/Block.java`; in 1.14.4 they are in `net/minecraft/block/Blocks.java`. Exact source lines are in the registration TSV.

- Slabs (18): `acacia_slab`, `birch_slab`, `brick_slab`, `cobblestone_slab`, `dark_oak_slab`, `dark_prismarine_slab`, `jungle_slab`, `nether_brick_slab`, `petrified_oak_slab`, `prismarine_brick_slab`, `prismarine_slab`, `purpur_slab`, `quartz_slab`, `red_sandstone_slab`, `sandstone_slab`, `spruce_slab`, `stone_brick_slab`, `stone_slab`.
- Trapdoors (6): `acacia_trapdoor`, `birch_trapdoor`, `dark_oak_trapdoor`, `iron_trapdoor`, `jungle_trapdoor`, `spruce_trapdoor`.

Every slab definition adds the same `HALF × WATERLOGGED` properties, with `HALF ∈ {BOTTOM, TOP, DOUBLE}` and `WATERLOGGED ∈ {false,true}`: 6 states per ID. Every trapdoor adds the same `FACING × OPEN × HALF × POWERED × WATERLOGGED` properties, with `FACING ∈ {NORTH,EAST,SOUTH,WEST}`, booleans for `OPEN`, `POWERED`, and `WATERLOGGED`, and `HALF ∈ {BOTTOM,TOP}`: 64 states per ID. Values/order are supported by the identical `SlabType` and `StairHalf` source hashes and identical state-definition expressions; horizontal facing is the same inherited `HorizontalFacingBlock.FACING` property at both endpoints.

## Provider output results

The old slab provider is `SlabBlock.getShape(state,world,pos)` (1.13.2 lines 51–60); the new provider is `SlabBlock.getShape(state,world,pos,context)` (1.14.4 lines 46–55). Both select the same output by `HALF` alone: bottom `[0,0,0,16,8,16]`, top `[0,8,0,16,16,16]`, and double unit cube `[0,0,0,16,16,16]`. Neither provider reads world, position, waterlogged state, or collision context.

The old trapdoor provider is `TrapdoorBlock.getShape(state,world,pos)` (lines 45–62); the new provider is `TrapdoorBlock.getShape(state,world,pos,context)` (lines 47–64). Both first select closed top/bottom plate by `HALF`, or, when open, the vertical edge plate by `FACING`. `POWERED` and `WATERLOGGED` are not shape inputs; neither method reads world, position, or context. All six shape constants have the same bounds at both endpoints:

| Selector | Box in sixteenths |
|---|---|
| `CLOSED_BOTTOM` | `[0,0,0,16,3,16]` |
| `CLOSED_TOP` | `[0,13,0,16,16,16]` |
| `OPEN_NORTH` | `[0,0,13,16,16,16]` |
| `OPEN_EAST` | `[0,0,0,3,16,16]` |
| `OPEN_SOUTH` | `[0,0,0,16,16,3]` |
| `OPEN_WEST` | `[13,0,0,16,16,16]` |

Result: all 492 old/new raw-state pairs select the same outline shape and bounds. Collision selection also matches outline selection for every row at both endpoints. The old base collision method gates on `hasCollision` and then delegates to the state shape; the newer base collision method has the same gate and delegates to the state shape with empty context. New 1.14.4 static-state cache construction uses the same collision provider with empty context. These constructors use the default collision-enabled, non-dynamic properties; none of the common registrations calls `noCollision()` or `dynamicShape()`. The provider ignores context, so cached, empty-context, and passed-context selections agree for this family. No collision-versus-outline selector/result difference was found.

## Fluid face path and generated tag gates

The six-face expansion is also closed for the same raw states. The vanilla generated tag recipes in both `BlockTagsProvider` sources place all six wooden trapdoors in `WOODEN_TRAPDOORS` and compose `TRAPDOORS` from that tag plus `IRON_TRAPDOOR`. For each of the six non-oak trapdoors here, the old `FlowingFluid.isSolidFace` `TRAPDOORS` exception rejects the block before its direct `getFaceShape` result can be consumed. This masks the old closed-panel `SOLID` result on `DOWN`/`UP`. On the newer route, all six thin trapdoor panel shapes fail the full-face sturdy test. Both helpers retain the `UP` early-true gate, so their terminal results match for all six faces and all 384 non-oak trapdoor states. For slabs, both helpers agree for every face and state: bottom slabs are solid on `DOWN`, top slabs on `UP`, doubles on all faces, while the shared helper’s `UP` gate returns true in all slab states. The expanded outputs are in `fluid-face-pairing.tsv`.

Generated `SLABS` membership is not read by these shape providers or the paired fluid-face helper. `WOODEN_SLABS` contains the same six wooden slab IDs in both endpoint recipes; the newer `SLABS` recipe additionally includes the 16 1.14-only slabs listed below. This report treats data-generator recipes as source evidence only; it does not assert active runtime tag membership. The broader active tag caveat remains as documented by the permitted fluid-face report.

## Exact residual registrations

No old-only slab or trapdoor registration and no new-only trapdoor registration was found. Sixteen 1.14.4-only slab IDs remain outside the common-state comparison because they have no 1.13.2 registered counterpart: `andesite_slab`, `cut_red_sandstone_slab`, `cut_sandstone_slab`, `diorite_slab`, `end_stone_brick_slab`, `granite_slab`, `mossy_cobblestone_slab`, `mossy_stone_brick_slab`, `polished_andesite_slab`, `polished_diorite_slab`, `polished_granite_slab`, `red_nether_brick_slab`, `smooth_quartz_slab`, `smooth_red_sandstone_slab`, `smooth_sandstone_slab`, and `smooth_stone_slab`. Their exact new registration lines are in [`residual-registrations.tsv`](residual-registrations.tsv). Overall source registry counts: 1.13.2 has 19 slab and 7 trapdoor registrations; 1.14.4 has 35 slab and 7 trapdoor registrations. The 19 common slabs include the previously closed oak slab; the 7 common trapdoors include the previously closed oak trapdoor.

## Method and remaining boundaries

The paired registration constructors use `SlabBlock` or `TrapdoorBlock` directly. The shape formula is class-local and unchanged except for the newer unused `CollisionContext` parameter. The enumerated states do not claim every neighbor/state producer can create each tuple. The shape results are exact provider outputs for equal raw logical state values under these vanilla registrations. The inherited collision and face-sturdy paths follow the class outputs as summarized above; tag details are limited to the generated vanilla recipes and helpers inspected in exact source.

Sources were read-only. No product code, wiki inventories, backlog, Git history, build, tests, game/TAS/Gym/server launch, or decompilation was used or changed.
