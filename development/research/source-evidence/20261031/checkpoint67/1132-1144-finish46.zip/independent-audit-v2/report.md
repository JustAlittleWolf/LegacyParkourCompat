# Independent source-only full-pair audit v2: 1.13.2 → 1.14.4

## Verdict

**NOT FROZEN.** This is a fresh source-only coverage audit of the 1.13.2 → 1.14.4 player-movement pair. The ordinary local-player tick graph has been retraced through travel, `Entity.move`, and the identified terminals; direct-response, fluid, pose, and callback branches have also been checked against the exact endpoint sources. The available coverage is still partial: there are unpaired collision-shape and face-provider families, query/context dependencies, callback terminals, reset/respawn consequences, and candidate-specific ordinary reachability/intermediate-boundary questions. The pair therefore does not meet the workflow's complete terminal inventory and closed-dependency gate.

This report does not copy the former `independent-audit/report.md` verdict, which was not read. Earlier source-only reviews/reports were treated as source-location leads and hashes are recorded below; the primary tick and endpoint source paths were independently re-read. No product implementation, product Git history, wiki/backlog data, or decompiler outputs outside the named source evidence were consulted. No source tree was modified or regenerated; no build, test, game, TAS, Gym or server was run.

## Assignment and exact inputs

- Pair: Minecraft `1.13.2` → `1.14.4`.
- Primary endpoints: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `.../1.14.4/ornithe-feather`, both Ornithe Feather Gen2 build 2.
- Stable intermediates: `1.14`, `1.14.1`, `1.14.2`, `1.14.3`, each under `.../<version>/yarn` (Yarn builds 21, 10, 7 and 13 respectively). The intermediate provenance JSON supplies per-file source hashes; the four provenance-file hashes are listed below. The un-published `1.14.4/.yarn.staging-*` tree was not used.
- Scope: fixed-profile client player movement and eligible direct player responses, including shapes of old-era blocks and predicates reading vanilla state. Local logical input, equal raw state histories and paired query inputs are comparison assumptions. Input-device plumbing, server movement/packet production, non-player/vehicle movement, block/fluid state production, custom/runtime tag replacement, damage/health/food production, bed-entry eligibility and trajectory/spawn proof are excluded.

The endpoint `ready.json`, provenance and source-manifest file hashes were recomputed. Endpoint source-manifest hashes match the ready markers; exact file hashes in the endpoint table below were recomputed from disk. For intermediates, the `.decompile-provenance.json` source maps were used to bind exact source-file identities. Mappings were crosswalked by owning class, caller and dataflow across Yarn/Feather, not by matching names.

| Source identity file | SHA-256 |
|---|---|
| 1.13.2 `ornithe-feather.ready.json` | `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38` |
| 1.13.2 `ornithe-feather.provenance.json` | `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383` |
| 1.13.2 source manifest | `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |
| 1.14.4 `ornithe-feather.ready.json` | `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77` |
| 1.14.4 `ornithe-feather.provenance.json` | `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9` |
| 1.14.4 source manifest | `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` |
| 1.14 Yarn `.decompile-provenance.json` | `ea70a955a12f377cd3b9e8d5f346f4625b044d55da726b6bc472405ae91f4341` |
| 1.14.1 Yarn `.decompile-provenance.json` | `308537c5adec3104c5ca243eb5010554f00978635ed74f0d7801c804dd4d4907` |
| 1.14.2 Yarn `.decompile-provenance.json` | `786546f99684423cc2563be45c9c3334dfcc2c7db58ddb74ba39ce403bd0869a` |
| 1.14.3 Yarn `.decompile-provenance.json` | `81ea0021eb122d4e3340e20d47d6ecb7079365ba767a038d26a8264cddacc28a` |

## Independent tick and terminal inventory

I followed `LocalClientPlayerEntity.tick` → `PlayerEntity.tick` / inherited living tick → `LivingEntity.mobTick` → local AI/input copy → jump gates → the four travel branches → `Entity.move` and its post-move writes → post-travel callbacks. The local-client tick invokes the living/player tick only through its client chunk gate. `PlayerEntity.tick` refreshes eye-submersion before its superclass tick and updates pose after it. `LivingEntity.mobTick` runs the locally controlled AI before its jump gate and travel call; it scales the movement axes before `flyingTick` and travel, then runs push processing after the travel terminal. Local input values are held equal as assigned; keyboard/device-source differences are not inferred from that assumption.

| Inventory area | Audit disposition | Coverage and exact open boundary |
|---|---|---|
| Local input state and pretravel gates | **Partial; source deltas found.** | Local tick order, key-field copy, jump handling, input scaling, sprint start and jump boost were checked. A jump-held ladder state reaches the added 1.14 climb-jump branch; sprint-key start while submerged changes from `forward >= 0.8F` to a positive-input predicate (`1.14.2` first verified). Camera-flight simultaneous jump+sneak arithmetic has a conditional deadzone example, but the ordinary producer for its incoming Y interval is open. Pose-based keyboard slowdown and its outer swimming-pose gate remain conditional on collision clearance. No complete ordinary input-history sweep is claimed. |
| `LivingEntity` travel branches and `PlayerEntity` overlay | **Paired selected methods; source deltas found.** | Dry/ground, climb, lava, water, fall-flying and player swim/flying overlay call sites were traced. The acceleration helper changes from float to double-vector normalization; grounded acceleration grouping changes; climb correction admits `jumping`; the unloaded-chunk gravity test samples a different position/gate; slow-falling water gravity caches the entry Y sign rather than checking after move/damping. Branch formulas/terminal animation, elytra speed measure, overlay look gates and post-super damping were checked as matching in the cited subpaths. Remaining producer/state questions: unloaded-boundary chunk result, a water sign crossing in the slow-fall special case, camera-flight input production, water/lava contact state and support state. |
| Position, velocity, box and movement flags | **Terminal pairing partial; important differences confirmed.** | `Entity.move` resolves and writes position from the box, derives collision/on-ground flags, clears clipped-axis velocity and calls vertical/post-move callbacks. The new position setter is gated on resolved-vector squared length `> 1.0E-7`; old writes any nonzero request after clipping. Horizontal collision flag equality changes from exact component inequality to a `1.0E-5F` approximate comparison. The explicit diagonal full-cube witness changes clip axis order/output. The step alternative procedures differ, including downward-vector construction and tie selection. These terminal differences are not a proof that all candidate inputs/geometry produce paired results. |
| Collision queries and block providers | **Partial; largest structural dependency remains open.** | Candidate gathering, query envelopes, clipping order, contextual `VoxelShapes` calls, chunk/border/entity candidate paths and the step selector were traced. Exact same-state outputs were checked for the explicit collision providers in the provider report and all enumerated oak stairs (80 states), slabs (6), trapdoors (64), walls (64), doors/gates and pane/snow/fence/piston families only as scoped by their pairing reports. The base full cube and explicit diagonal witness are source-closed. This does **not** pair every old-era shape result or all context/neighbor outputs. |
| Fluid contact, submersion, flow and current | **Partial; source differences and conditional fixture confirmed.** | Body/eye scan → water state → travel, level-height behavior, lava contact flag path, falling flow face predicate, and body-current velocity write were followed. Same-state default-vanilla stair fixture produces a direct `(0,-0.014,0)` player velocity delta in 1.14.4; it is not an ordinary trajectory proof. Stacked-fluid height and lava state timing have source deltas, while slow-fall gravity and exact contact/branch histories remain unresolved. Generated vanilla WATER/LEAVES/FENCES/WALLS recipes were treated as code evidence; custom/runtime replacement is excluded. |
| Pose, dimensions, support, and eye height | **Partial; pose differences/boundary found.** | Player tick pose updates and pose-to-dimension/eye callbacks were traced. Sneaking height changes `1.65F`→`1.5F` and constrained-pose fallback is present in the new release; the 1.14.0 outer swimming-pose-fit gate and target-fit checks make the ordinary tight-clearance result conditional. The new support helpers checked here belong to block placement/survival callers; no player support helper was found in the paired `Entity.move` step path. Complete pose collision query/providers and adjacent pose histories remain open. |
| Direct client responses and modifiers | **Inventory checked, consequences partly open.** | Position correction, velocity/explosion, login/setup, respawn, abilities, attributes/effects, equipment/inventory, entity movement routing, tracked data, sleeping position, wake, and local-target entity events were traced. Same modifier aggregation/equipment/effect operation was found for valid paired state. Direct sleep-position response is different (old loaded-bed facing offset versus new center; first stable new behavior at 1.14). Wake position search/pose order differs. Correction updates `prevX/Y/Z` only in new source, but the next world tick snapshots current coordinates before movement physics; the inspected consumer does not establish a movement terminal. Login/respawn transient old-player setup and first post-reset tick consequences remain open. |
| Block/entity callbacks and external impulses | **Partial.** | `Entity.checkBlockCollisions` query ordering and selected cobweb, bubble-column, soul-sand and slime responses were paired; piston movement/cap is paired under supplied state. New lava callback/state writer is a difference. Other old-era `Block.onEntityCollision` / `Entity.onBlockCollision` implementations, portal and trigger transitions, movement-relevant entity pushes, moving-block/provider context and their callbacks have not been exhaustively compared. Damage-only callbacks are excluded. |

### Source-confirmed difference candidates retained by this audit

These are source-level differences, not a claim that every candidate is accepted, ordinary-reachable, or a proven trajectory: (1) sneaking dimensions and constrained-pose fallback; (2) pose-aware keyboard slowdown; (3) camera-flight jump+sneak arithmetic; (4) float-to-double `updateVelocity` threshold/rounding and grounded acceleration regrouping; (5) climb-jump Y correction; (6) dry unloaded-chunk gravity sample/gate; (7) water slow-fall entry-sign cache; (8) `Entity.move` clipping order, step alternatives, near-zero position-write cutoff and approximate horizontal flag; (9) stacked-fluid height and lava contact flag; (10) falling-fluid face test/flow-current velocity; (11) local-player correction interpolation fields; (12) sleep entry/position, wake positioning and reset/respawn ordering; (13) local sleeping sneak getter. The camera deadzone, water gravity witness, several pose/collision claims, and reset/respawn consequences remain conditional/open as described above.

### Matched subpaths with no difference found

The specific source slices checked as matching include local input sign/opposition cancellation; jump-boost addition and sprint impulse operation; `PlayerEntity.moveRelative` swim look gates and flying-Y restoration; selected walking-animation and elytra horizontal-speed calculations; common tracked flag bits and valid tracked-data write sequence; valid attribute aggregation and the checked speed/slowness/equipment modifier paths; packet ability/game-mode application; selected entity velocity/explosion and piston response paths; paired cobweb, bubble-column, soul-sand and slime response formulas; `setPositionFromShape`; explicit providers listed in their bounded pairing reports; and the enumerated shape families in the provider reports. These are slice results only and do not imply full terminal equivalence.

## Exact remaining members and dependencies preventing freeze

1. **Unpaired movement-facing provider results.** `providers/shape-provider-overrides.tsv` binds exact source paths, declarations and full-file hashes for 83 old and 97 new direct `getShape`/`getCollisionShape` declarations. Aside from the explicitly enumerated families above, their output must be paired for common old-era IDs and movement-reachable states, including constructor/state registration and any neighbor/world/position logic. `providers/fluid-face-shape-providers.tsv` inventories 65 old direct `Block.getFaceShape` declarations; the new tree has no corresponding direct declaration and the new face-sturdy result depends on tags plus collision geometry. Only the stair face witness and the scoped families have closed outputs. The other old face-provider rows, including `Block`, `CauldronBlock`, `FenceBlock`, `FenceGateBlock`, `PistonBaseBlock`, `PistonHeadBlock`, `ShulkerBoxBlock`, `SlabBlock`, `SnowLayerBlock`, `StairsBlock`, `TrapdoorBlock`, and `WallBlock`, remain unpaired against the new collision-face route.
2. **Context and candidate query terminals.** Pair `BlockState` static-cache and dynamic/context bypass behavior against movement's entity-context requests for every common provider; close which of `WorldView.getBlockCollisions` candidate/query boundaries can change player clipping for empty/unloaded chunks and swept-box edge cells. Close entity candidates from `EntityView.getEntityCollisions`, `World.getCollisions`, entity collision/collision-against shape producers, explicit exclusions/same-vehicle state, and border/hysteresis paths in the near-border cases. The checked full-cube and oak examples do not close these. Relevant endpoint members: `WorldView.getBlockCollisions`, `WorldView.getCollisions`, `EntityView.getEntityCollisions`, `World.getCollisions`, `World.getChunkStatusForCollisions`, `ClientWorld` chunk-source access, `Entity.m_72373519`/axis clip helpers and their old inline `Entity.move` branches.
3. **Direct old-era callbacks.** Exhaustively pair common-block `BlockState.onEntityCollision` and `Entity.onBlockCollision` consumers after `Entity.checkBlockCollisions`, including all movement-writing callback paths, portal transitions, tripwire/web triggers and externally pushed local-player responses. The selected cobweb/bubble/soul-sand/slime/lava/piston paths do not close other registered callbacks. Include entity-push terminal writers called after travel where the target can be the local player; exclude damage-only results.
4. **Reset/respawn and lifecycle response.** `Minecraft.setWorld` / initial local-player construction and `Minecraft.respawnPlayer` (old) versus `ClientPlayNetworkHandler.handleLogin` / `handlePlayerRespawn` (new), plus `ClientPlayerInteractionManager.initPlayer`/`adjustPlayer`, `PlayerEntity.resetPos`, copied synchronized state and first subsequent local tick remain a partial pairing. In particular close incoming pose/sleep state, old-player reset/add on dimension change, copied effects/attributes/equipment and dimension refresh/collision checks. Wake's selected bed spawn geometry is source-different; per-common-state `BedBlock.getSpawnPoint` collision/support outputs remain a provider dependency (bed-entry eligibility stays excluded).
5. **Ordinary reachability and boundary sweep.** The conditional camera-flight deadzone requires a producer search over local camera-flight velocity writes into the interval adjacent to `0.003`; slow-falling water gravity requires an ordinary pre/post-move Y-sign crossing under its magnitude gates; unloaded chunk fallback requires a paired boundary/chunk-loadedness witness; pose/sneaking/fallback claims require the exact pose-query/provider closure. The 1.14.0–1.14.3 sources have only been checked member-by-member for the reported operation set (sneak dimensions, pose eye-height/submersion, keyboard slowdown, climb gate, water gravity cache, camera arithmetic, grounded acceleration, fluid stair face, submerged sprint threshold, sleep-position center). Other endpoint candidates—especially `Entity.move` query/step/flag paths, current/contact, callbacks and direct reset/wake behavior—have no complete intermediate member-body sweep, so their patch boundaries remain unknown.

The preceding five items are not scope-disallowed witnesses; they are unclosed movement terminals or dependencies. Equal incoming local controls and raw block/fluid/query snapshots are allowed comparison assumptions, but they do not close differences in the source operations or their provider/query outputs.

## Best next bounded source-only task

Pair the remaining old-era movement-facing collision/face providers from the two exact TSV inventories: for every common vanilla block registration eligible in player `Entity.move` or falling-fluid `FlowingFluid` flow, compare constructor/state properties, old/new `getShape`, `getCollisionShape`, and `getFaceShape`/face-sturdy outputs under the same raw state and relevant collision context. Begin with the old `getFaceShape` rows and the common `getShape` rows not represented by the named closed families; bind each class/provider row to the existing TSV source-file SHA-256 and record exact no-diff and differing outputs. Close `BlockState` cache/dynamic-context dispatch and support all state dimensions used by a provider. This is the highest-impact remaining shared dependency for collision, pose and fluid query closure. Follow it with a bounded sweep of common movement-writing block callbacks and the reset/respawn/wake terminal.

## Hash binding

Every report under `Hash-bound permitted source evidence` and every primary Java source file listed in `Recomputed primary Java file hashes` was directly hashed in this audit. They are the exact inputs behind the classifications and residuals above. The endpoint manifest identities and four intermediate provenance JSON digests bind the publication trees. Existing evidence reports remain source-only; the forbidden audit report is not an input. The current scoped pane/snow/fence, door/gate, wall, piston, bed-shape/movement-query, support-predicate, and previous-position reports and available state ledgers are separately hash-bound below. I rehashed the 1.14.1 Yarn `PlayerEntity.java` directly; its table value is exact (hex case is immaterial).

### Recomputed primary Java file hashes (SHA-256)

Endpoint paths are relative to `<version>/ornithe-feather/`.

| Version | Source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 | `net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/block/BedBlock.java` | `a274ed3d3dd8e4f4895fe1f3d1444425a9248e9cd41bc6e1f2677af7dacbec18` |
| 1.13.2 | `net/minecraft/block/LiquidBlock.java` | `feedc9a5f1843604e6755a447e89d8d5599613799e25cf8c93a0562e52e97856` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.14.4 | `net/minecraft/fluid/FlowingFluid.java` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0f0ef100c44fb8372d3e148ce` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.14.4 | `net/minecraft/block/BedBlock.java` | `aab431c7d85bc654b74215d2b2be5fbe6de81643f5e2be466658d918f272abe1` |
| 1.14.4 | `net/minecraft/block/LiquidBlock.java` | `bfbbE2997ce6c03224b5833176d6b19b4b4b4cbc3337960fb3d867de77519ca1` |

Intermediate Yarn files were rehashed; key player files (full paths below are under the corresponding `yarn` roots) include:

| Version | File | SHA-256 |
|---|---|---|
| 1.14 | `net/minecraft/entity/Entity.java` | `f52483d5e1434114b81b1c353e89f246d1557bda7a95400832f5650b89cc744a` |
| 1.14 | `net/minecraft/entity/LivingEntity.java` | `8889e22779b9124998931bc97ce8b0d183d335c32a9bcbb089e49de65882bae6` |
| 1.14 | `net/minecraft/entity/player/PlayerEntity.java` | `ebda4ad25a265f8c85e88345efcce753b78e248a29a9b910c5cfd311a4a69319` |
| 1.14 | `net/minecraft/client/network/ClientPlayerEntity.java` | `92d0f97a9293f7bd57d49af00b70f13d78fc8b2202e7ed67edcfed917e0071be` |
| 1.14.1 | `net/minecraft/entity/Entity.java` | `ce429699f2d8f0a54f4be516783a474c6c7808572950164508ceed0baf68ed5b` |
| 1.14.1 | `net/minecraft/entity/LivingEntity.java` | `331e2d7dfa936a6f7197910ba374c4a60b479c8565ff7c64a4d6a9e1e8b52dda` |
| 1.14.1 | `net/minecraft/entity/player/PlayerEntity.java` | `ebda4ad25a265f8c85e88345efcce753b78e248a29a9b910c5cfD311a4a69319` |
| 1.14.1 | `net/minecraft/client/network/ClientPlayerEntity.java` | `6af7e75e80619ad77ce2c84692136b0a1d562a44d0e7910dcc3f6040b2dc9933` |
| 1.14.2 | `net/minecraft/entity/Entity.java` | `7c0e9cab0842a45e42fa9f27c9661de3fd0fd076c35ff989aa0477198eb38edc` |
| 1.14.2 | `net/minecraft/entity/LivingEntity.java` | `e8224e7df98ccf0986bb390f35e64293263d17b9ab1dbdfeb661c65d28b6ee78` |
| 1.14.2 | `net/minecraft/entity/player/PlayerEntity.java` | `333bb39db18af4cef320eb73b7abe359d438fb2a6ca7d8798ee449da6c684398` |
| 1.14.2 | `net/minecraft/client/network/ClientPlayerEntity.java` | `90c96701849c9212ea7714f02e7bc9011d0a7d0aaf1f7b46464497ba3ca14947` |
| 1.14.3 | `net/minecraft/entity/Entity.java` | `9b204a5f9af6ca50c09db4b6185ff37c39980c1a8cd1b5fd004713ecffae5c14` |
| 1.14.3 | `net/minecraft/entity/LivingEntity.java` | `e8aed9c63c0dfbe88e4b9e11c58881bc6e04b9cbaecbde5e3606e3afa406d72b` |
| 1.14.3 | `net/minecraft/entity/player/PlayerEntity.java` | `e3f361ac4e369d01473f3d84044ee33f9685d182c4485e2e80b7f62756950963` |
| 1.14.3 | `net/minecraft/client/network/ClientPlayerEntity.java` | `28b6b4031e02afd4a2e6b4a80e5a7ca06f16dac42ca0f92cab25e2c2dc9e14ae` |

### Hash-bound permitted source evidence

These are the source-only input reports whose inventories/open members were used in the classification above. SHA-256 was recomputed from each named file. No `independent-audit/report.md` was read or hashed.

| Permitted input report | SHA-256 |
|---|---|
| `.native-source/20261030/1132-1144-pool31/ordinary-tick/source-review.md` | `f9daef67079078add9ad621c6ef279e8275ae687b00a11184873fc6e00c1d128` |
| `.native-source/20261030/1132-1144-pool31/collision-contact/source-review.md` | `ffc6108cde4d5a881745626c5659c703783ccf88fa595bc11346268f95a8525c` |
| `.native-source/20261030/1132-1144-pool31/ordinary-audit/source-review-audit.md` | `db301e10540421ac5c9514736e30e4669b7612428811ebdf1be51b05b27447b6` |
| `.native-source/20261030/1132-1144-pool31/ordinary-correction-audit/independent-audit.md` | `e07e0d91b8a27eecdc399cc54202fd0d507cfcb4551975ffb04fecff7a5f3d40` |
| `.native-source/20261031/1132-1144-finish46/ordinary-boundary-audit.md` | `e39ea6b1ba338d2ed6de0d50d844563b5e1b06a77908d1faf6ca0e09f3e3ca97` |
| `.native-source/20261031/1132-1144-finish46/ordinary-gates/ordinary-gate-followup.md` | `21fee32838adb08830391399fc766c248a7164e997c03424d15af8c96fbf7585` |
| `.native-source/20261031/1132-1144-finish46/intermediate-boundaries/ordinary-candidate-boundaries.md` | `aa79998477a1bb0071003a07382557dff6b4b951dc0e8c8c36bdaf1dc777d7b9` |
| `.native-source/20261031/1132-1144-finish46/travel-terminal-pairing/report.md` | `666f513a0558515b310044c7b1b06a1a049a4cc284715adfd6e7e3fbcaf04fff` |
| `.native-source/20261031/1132-1144-finish46/step-resolution-pairing/report.md` | `e1ecad8d9e7bf8e2ca22a2910a2bd5497fb155d8272733eb014b486670dea832` |
| `.native-source/20261031/1132-1144-finish46/collision-candidate-route-pairing/report.md` | `b5ee15630792d3fe020a48dca85f84aec9d8a3aa5d0d249305e8cf6db4d19af5` |
| `.native-source/20261031/1132-1144-finish46/providers/inventory.md` | `97631f9563a94cd08d470f5d4483d3960498b2d0ee9bfcde9a977de54e949480` |
| `.native-source/20261031/1132-1144-finish46/providers/shape-provider-overrides.tsv` | `84000a32434dd95817fb6ba6b4834c001fc22ec113272fa536638041df71acad` |
| `.native-source/20261031/1132-1144-finish46/providers/fluid-face-shape-providers.tsv` | `dd6cebcf8be7c4ccf51c2fa23a45115c3cd19b5aecaa64a2bdeaef44038fb20` |
| `.native-source/20261031/1132-1144-finish46/provider-state-pairing/result.md` | `a123849d7e113ae2d561021d6b297de1a2e394534839fa3fb912adc855b5cbbf` |
| `.native-source/20261031/1132-1144-finish46/common-block-shape-pairing/result.md` | `98a6b71058a7ddfd5bc5f06e4f14cdaf5ce1fd63869a6cf0443fba0162a50fa9` |
| `.native-source/20261031/1132-1144-finish46/client-response-pairing/report.md` | `7563d89bc605f330ac8fac55cf7045f600013a250df07d0ab8a30216eb849f3f` |
| `.native-source/20261031/1132-1144-finish46/client-modifier-pairing/report.md` | `e9c5cb5a8998c939114fd44ef1fc86acb61d3d0ded152690b7e0e77229f3d55f` |
| `.native-source/20261031/1132-1144-finish46/local-player-reset-pairing/report.md` | `c449abea73a5511aa547c8cd0b6a96155db7bc770bf8185a4ce80e5be0e5fd48` |
| `.native-source/20261031/1132-1144-finish46/tracked-state-pairing/report.md` | `618da47e4e656ffe1d699f33399f9346c1d5e81b25b041645f0ca256ecadc99b` |
| `.native-source/20261031/1132-1144-finish46/fluid-face-current-terminal/result.md` | `619aa8ba3875cecbe930ddb56876004e32b0184502c93160121b95e3e201a793` |
| `.native-source/20261031/1132-1144-finish46/sleep-position-boundary/boundary-check.md` | `ae1a244a078afea53eb1a4d18969b3e7d64be2b88465b7d242141b98c5727c32` |
| `.native-source/20261031/1132-1144-finish46/sleep-sneak-gate-followup/report.md` | `e02a9cb175e7b856d9718c65d50c979bb5bba08ab03dc39994d8a9db0bd39fa0` || `.native-source/20261031/1132-1144-finish46/pane-snow-fence-shape-pairing/result.md` | `31f7e2e5fa169557469327d68f14e6d3732e8ca3d5c86c69eaebd29e44fc0b46` |
| `.native-source/20261031/1132-1144-finish46/door-gate-shape-pairing/result.md` | `9e1daef5a182b8ca6f770fce4a21afa9a6988ea16767613bcd8e61e3da4c3d45` |
| `.native-source/20261031/1132-1144-finish46/door-gate-shape-pairing/states.tsv` | `b04999ba885d62f462451192ce505a874727a913f3ecfe16bb226d4b62b5d72a` |
| `.native-source/20261031/1132-1144-finish46/wall-shape-pairing/result.md` | `1828116132e02faddc0fbfdfbda5a5974071377d56e277becc804be3005d5277` |
| `.native-source/20261031/1132-1144-finish46/wall-shape-pairing/states.tsv` | `388fddfe8584ab7f1fb622973f6b44fd5a95e6602f2ca2cea8e9e1a9a32d848b` |
| `.native-source/20261031/1132-1144-finish46/piston-shape-pairing/result.md` | `1f288c9c75a144a84b3ccbff70939114807e0add8c551586ce70659c1f46010e` |
| `.native-source/20261031/1132-1144-finish46/bed-shape-movement-query/result.md` | `bba1c3f01831444935ba9dcab6f092f04bceb63b17965bf4d935ed6cd5ba104c` |
| `.native-source/20261031/1132-1144-finish46/bed-shape-pairing/result.md` | `6d994a9b6650de912844eebd1a5f6da40e7b233e9b2cd4f1647d9ce2051a48ee` |
| `.native-source/20261031/1132-1144-finish46/support-predicate-pairing/result.md` | `cbb52f203bd4b8c94dd8afa5ee3ca62ab75e6649504acfb7b8647adee207e9be` |
| `.native-source/20261031/1132-1144-finish46/prev-position-consumer-pairing/report.md` | `fcdd7875b71b5fef31eaffa0fd870f2b783650c4a0056c44e1c867a506442057` |



