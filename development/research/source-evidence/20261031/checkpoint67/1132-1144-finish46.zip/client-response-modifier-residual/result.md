# Client response modifier and event residual

## Scope and result

Exact pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2. This source-only tranche rechecks the direct client handlers for entity attributes, equipment and status effects, their local-player terminal methods, attribute value aggregation, and the residual local-player entity-event route. Incoming packet values and same logical membership are treated as inputs; server production, damage/health, hunger/food production, and input-device history are excluded.

The modifier/equipment response dependency closes for the stated client inputs: status-effect add/remove callbacks do not add or remove attribute modifiers on the logical client, player equipment writes inventory slots without updating the attribute container, and the separate client attribute packet handler applies base values and modifiers identically at both endpoints. The attribute aggregation order is also identical. The paired local-player tracked-use callback also leaves the movement-input result equal. No new movement difference was found in these paths.

The residual entity-event dispatch has no movement-state write in the paired local-player overrides. Shared common flags remain same-value updates through `SyncedData.update`; 1.14.4 adds a new synchronized `Pose` attribute whose callback updates entity dimensions and the bounding box. That pose-to-box terminal is movement-relevant and remains an exact open edge for the complete pair. This report does not claim pair freeze or runtime parity.

## Direct modifier response

`ClientPlayNetworkHandler.handleEntityAttributes` (1.13.2 lines 1934–1960; 1.14.4 lines 2083–2109) has the same local entity lookup and update sequence: reject a non-living target, obtain its attribute container, find or register each named attribute instance, set its base, clear its old modifiers, and add packet modifiers in iteration order. The local player is included by the already verified client-world ID route. Under paired raw attribute entries, this handler does not produce an endpoint difference.

`handleEntityStatusEffect` (1.13.2 lines 1396–1409; 1.14.4 lines 1453–1466) and `handleEntityRemoveStatusEffect` (1488–1494; 1548–1554) are body-identical. They resolve the entity and invoke `LivingEntity.addStatusEffect` or `removeEffect`. `addStatusEffect` stores a new instance or combines an existing instance, then invokes the matching applied/upgraded callback. `removeStatusEffect` calls `removeEffect`, then invokes the removal callback when an instance existed. The endpoint `LivingEntity` bodies match at 672–733 and 772–833 respectively. Each callback marks `effectsChanged`; all three perform attribute modifier add/remove only behind `!world.isClient`. On the local logical client, therefore, status packet application changes the effect map/visual state but does not locally alter movement attributes. Any changed attribute value supplied by a separate attribute packet is covered by the direct handler above. This does not claim packet producer order or effect-history parity.

`ClientPlayNetworkHandler.handleEntityEquipment` (1.13.2 lines 1115–1121; 1.14.4 lines 1188–1194) is body-identical and calls `entity.setEquipment` for a resolved entity. The local `PlayerEntity.setEquipment` bodies (1.13.2 lines 1741–1756; 1.14.4 lines 1678–1693) both play the equip sound and store main hand in the selected hotbar slot, off hand in slot zero, and armor in the armor list. Neither applies or removes attribute modifiers. The client-side inventory and selected-slot handlers also do not call an attribute update; the attribute packet is the distinct movement-attribute writer. Server-side equipment-to-attribute production was not used.

The movement-relevant attribute calculation is semantically the same at `ModifiableEntityAttributeInstance.computeValue` (1.13.2 line 147; 1.14.4 line 141): add operation-0 modifiers to base, add operation-1 modifiers multiplied by that intermediate base, then multiply by each operation-2 modifier, and clamp. `AbstractEntityAttributeContainer.addModifiers`/`removeModifiers` have matching iteration and replacement behavior. The new enum names differ but preserve the three operation ordinals and order. Thus, given equal received base and modifier sets, this local value calculation adds no response-side difference.

## Synchronized data and local entity events

`SyncedData.update` (1.13.2 lines 234–247; 1.14.4 lines 236–249) iterates received entries in order, selects the registered entry by ID, copies the incoming value when present, calls `entity.onDataValueChanged(attribute)`, then marks the aggregate dirty. The only structural difference in the nearby lookup helper is exception-safe unlocking in the newer implementation; valid registered entries take the same update/callback path. The shared entity flag and living flag byte attributes retain the same use as movement inputs (including sprint/sneak/fall-flying and active-hand bits). `LocalClientPlayerEntity.onDataValueChanged` at both endpoints calls its superclass, reconstructs or clears local item-use state from the tracked living flags, and plays the same fall-flying sound response. The newer `LivingEntity` superclass performs an additional client-only `itemInUse`/duration reconciliation for that flag before the local-player override runs. The resulting local movement gate remains the same: both `LocalClientPlayerEntity.isUsingItem` methods return the local `usingItem` boolean, and both movement-input staging methods multiply forward/sideways inputs by `0.2F` when using an item and not riding. Thus the new superclass bookkeeping does not change the local-player movement-input result for matching tracked flags and item state.

The newer base `Entity` registers an additional `DataAttribute<Pose>` with default `Pose.STANDING`; the old endpoint has no pose attribute. New `Entity.onDataValueChanged` calls its pose-dimension updater when that attribute changes. The updater selects dimensions for the new pose and rewrites the box: narrowing width centers it at the existing position; otherwise it keeps the old minimum corner and installs the new width and height. Its additional compensating `move` runs only when width expands on a non-first server entity, so the local client receives the dimension/box rewrite without that server-only move. This is an eligible movement-state response and remains unpaired against the old era's non-pose size and sleep/wake paths. The newer living callback also reacts to a synchronized sleeping position on the client by moving to the derived sleep position; sleep position is handled in the separate sleep-response candidate. Do not use either fact as a bed-entry eligibility claim.

`ClientPlayNetworkHandler.handleEntityEvent` dispatches ordinary events to `entity.doEvent` after resolving the entity, so the local player can receive the override. Both `PlayerEntity.doEvent` bodies share event 9 (`consumeItem`) and debug-visibility events 22/23; 1.14.4 additionally handles event 43 by spawning cloud particles. The inherited `LivingEntity.doEvent` damage events update damage animation/timers or call damage/death methods (excluded); the newer berry-bush event is also damage-only, and the new portal/broken-equipment events are presentation updates. No paired event case directly changes eligible local movement state. Event 9 reaches `LivingEntity.consumeItem`, which is body-identical: emit use particles, finish the active item, write the returned item to the active hand, then clear active use. Movement-like item terminals checked here remain server-gated: both chorus-fruit implementations gate teleport behind `!world.isClient`, and potion/milk effect application/clearing is also behind that gate. Hunger/stat effects are excluded. This closes the checked common event-9 consumers without claiming general item-use producer or runtime history.

## Remaining exact edge

- Pair the new synchronized `Pose` → `Entity.onDataValueChanged` → dimensions/box write against all old local-player dimension/size and pose-like state routes. In particular, distinguish the accepted sleep-position response from non-sleep pose/dimension changes. This is the remaining movement-relevant terminal in this tranche; the producer of incoming synchronized values is excluded.
- Continue broader full-pair audit for other categories outside this bounded response/modifier slice. No full-pair freeze is claimed.

## Source identity and hashes

All listed hashes were recomputed from the read-only Feather trees and matched the version-root `ornithe-feather.sources.sha256` entries. Source roots and publication identities are recorded in the pair's source-only inventory.

| Version | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4F65502FBEE6476CEF0838563F03A66F07A1A9ED8C63E580F5338BA5FE274F11` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6C840580285C7C7D4617E895EDAC82D4EEBF8289DD4994E7B593CEBEB49B43EF` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495F3A02B4791AA036E6A8D354D7596C4984761969A0F29B29D8D9BF42BF` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708AF6A3880FB58B67BF4604A5509B351719A9C2A0C06A8EC261586435BF00CE` |
| 1.13.2 | `net/minecraft/entity/data/SyncedData.java` | `93177865E23BE0F8DB5741BD505B952DAEE03D33761838CA782BD10BCEB748E4` |
| 1.14.4 | `net/minecraft/entity/data/SyncedData.java` | `4D0C0BEE069994F64A31E1FF600AE59C3217EADB8678473E2256C2363E657E17` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `BB691358C9A43C9F46E85575BF4D0A4AD671D0EB912502ACC3A6A3F625E42F1C` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2CCCF4331CE9E62013EEB8E96163E5E146E1291619EB998CE9867DAA87C02B61` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ED22F6C5A3C55D67EED782070AC722201DF4D624ADBC90779F1FD29C2876633` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614DEB3B50D11F6CDF54D9E308703BF49CB53B72646B05253857E9557D657DF` |
| 1.13.2 | `net/minecraft/entity/living/attribute/ModifiableEntityAttributeInstance.java` | `4EEC5F0347BABA347A84E4C66702321FB34157329F95E70E8CE541AEB4BF6B7A` |
| 1.14.4 | `net/minecraft/entity/living/attribute/ModifiableEntityAttributeInstance.java` | `4FF7DD1BF7A48E4894860CB048BC9C6A8ADCC8B98B9C5D29CE28DA2A15DB8F69` |
| 1.13.2 | `net/minecraft/entity/living/attribute/AbstractEntityAttributeContainer.java` | `62D1B62A04DAEB72335871435DEF3A7B1BCD30D7169EF68D9D24605D37895940` |
| 1.14.4 | `net/minecraft/entity/living/attribute/AbstractEntityAttributeContainer.java` | `05C229E1A8462EF94DDE0AF269238C17BA218BF2B67431196576C16861E574A1` |
| 1.13.2 | `net/minecraft/item/ChorusFruitItem.java` | `BCF8051BBA60896C8FF011D2FC1999AEBB643AF46AB7A13391B240AC8EDBB314` |
| 1.14.4 | `net/minecraft/item/ChorusFruitItem.java` | `DF03089CF1171D8D013EEB6C44E98445FBFF7CEB9CE37ABF9FE53717B5F82233` |
| 1.13.2 / 1.14.4 | `net/minecraft/item/PotionItem.java` | `4AB507876ADD187DDC62FCA131E27C55434FB0D698298448E54FFFC43B824B13` |
| 1.13.2 / 1.14.4 | `net/minecraft/item/MilkBucketItem.java` | `F9BF4B4055F8DAAAB3A1BD3D1937C367102ACE7A846C8219A734739EF2B516BD` |
