# 1.13.2 → 1.14.4 tiny piston request terminal

## Bounds

Exact pair: Minecraft 1.13.2 → 1.14.4, Ornithe Feather Gen2 build 2, as identified in the supplied block-callback review. This is a source-only terminal follow-up using only that review, the supplied piston-shape pairing, and exact endpoint `Entity.java` / `Vec3d.java`. The paired input assumption is a direct `MoverType.PISTON` request to the player entity. No piston/world producer, world trajectory, product source, wiki/backlog/Git, server movement, or other endpoint source was examined. No source output, product code, build, test, or launch was produced. No pair freeze is claimed.

## Exact source path

- 1.13.2 `net/minecraft/entity/Entity.java:473–514`: `move(MoverType, double, double, double)`; on a non-noClip PISTON call it first resets `pistonMovementDelta` if the world tick changed, then selects the first nonzero axis in x/y/z order, clamps `request + storedDelta` to `[-0.51, 0.51]`, stores the clamp, and returns if the accepted axis delta has `abs(delta) <= 1.0E-5F`.
- 1.14.4 `net/minecraft/entity/Entity.java:444–458, 623–660`: `move(MoverType, Vec3d)` calls `m_19881916`; that helper returns the *unchanged input vector* immediately when `squaredDistanceToOrigin() <= 1.0E-7`, before reading world time, resetting the accumulator, clamping, or applying the component epsilon. The caller returns only if the resulting vector exactly equals `Vec3d.ZERO`.
- Both endpoint `net/minecraft/util/math/Vec3d.java` implement squared length as `x*x + y*y + z*z`; equality compares each double component with `Double.compare`, so any nonzero input returned by the short-vector branch is not equal to ZERO.

The newer squared-length branch is therefore a bypass of the piston accumulator and component epsilon, not a zero-vector return. For an x-only input the bypass domain is `abs(x) <= sqrt(1.0E-7)`, about `3.1622776601683795E-4`; the old epsilon is the float value represented by `1.0E-5F` (approximately `9.999999747378752E-6`). With zero accumulated x delta, any request strictly above the old epsilon and within the newer squared-length domain updates only the old endpoint's piston delta.

## Concrete paired witness

Assume both entities are non-noClip, use the same world tick as their `lastPistonMovementTicks`, have x piston accumulator `0.0` at the start of the tick, and receive the same raw vector `(2.0E-5, 0.0, 0.0)` as a direct PISTON move. Other axes are zero.

- 1.13.2: `clamp(2.0E-5 + 0.0, -0.51, 0.51) = 2.0E-5`; accepted x is `2.0E-5`, which is strictly greater than the float epsilon. It stores `pistonMovementDelta[X] = 2.0E-5` and does not take the epsilon return.
- 1.14.4: squared length evaluates to about `4.0000000000000007E-10 <= 1.0E-7`; `m_19881916` returns the raw vector before touching the accumulator. The caller's exact ZERO comparison is false. Thus the immediate player movement state differs in the piston accumulator: old x delta `2.0E-5`, new x delta `0.0`.

For a subsequent identical raw PISTON request `(0.51, 0.0, 0.0)` in the same tick, the squared-length guard is not taken. Old clamps `0.51 + 2.0E-5` to `0.51` and returns accepted x `0.50998`; new clamps `0.51 + 0.0` to `0.51` and returns `0.51`. So the changed prior accumulator produces a later accepted piston displacement difference of about `2.0E-5` before collision resolution (`0.51 - 0.50998` in the displayed decimal values; the binary64 difference is about `2.000000000002E-5`). This is a direct move-input/result difference; it does not assert a piston producer or a whole world/player trajectory.

No equal-output disposal applies: these branch combinations produce an explicit player piston-delta difference on the first call and a different accepted vector on the next call.

## Source hashes

SHA-256 of the complete examined endpoint files (all match the hashes in the supplied terminal-pairing review where listed):

| Endpoint | Relative source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 | `net/minecraft/util/math/Vec3d.java` | `6941a43536e8aefaa435a4e5f1731b0fa26a9d96503d1f4d07de8950c297f3c5` |
| 1.14.4 | `net/minecraft/util/math/Vec3d.java` | `b69b990b768e52d6fac6b3ed82f60e7526e78d0837c868a61a4171ebca21040b` |


