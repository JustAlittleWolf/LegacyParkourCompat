# Direct push-away response witness: 1.13.2 → 1.14.4

## Scope and source identity

This source-only follow-up checks the conditional `LocalClientPlayerEntity.pushAwayFrom` terminal identified in `callback-consumer-closure-followup/report.md`. It uses only the exact Feather Gen2 build 2 sources for Minecraft 1.13.2 and 1.14.4 at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather/`, plus that permitted prior source-only report. The prior report identifies the endpoint source-manifest SHA-256 values as `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. The source hashes below were recomputed from the read-only tree and match the hashes in that report where it had already listed the file.

No product implementation, wiki, backlog, Git history, block-state producer, or trajectory is used. No source was generated or edited. This is a direct-response witness, not a trajectory or pair-freeze claim.

## Common vanilla state route

The witness uses the same `REDSTONE_BLOCK` default state at `(0,0,0)` in each release, with air at the four horizontal neighbor positions and at the other scanned Y positions. The state has no block-specific properties: both `RedstoneBlock` classes only override redstone output and signal-source membership, not their state schema or shape.

- In 1.13.2, `Block.java:1298` registers `new RedstoneBlock(Block.Properties.of(Material.IRON, MapColor.LAVA).strength(5.0F, 6.0F).sounds(BlockSounds.METAL))` under `redstone_block`; `Blocks.java:958` resolves `REDSTONE_BLOCK` from that same registry key.
- In 1.14.4, `Blocks.java:948–950` registers the same block class, registry key, material, map color, strength and sounds.
- In each release, `RedstoneBlock.java:8–16` inherits normal block geometry and overrides `isSignalSource` to return `true`. `Block.java` supplies a full-cube default shape and both `Properties` classes default `hasCollision` to true. In 1.13.2 the default `Block.isCube` is true. In 1.14.4 `BlockState.isShapeFullBlock` tests the collision shape, and the inherited default collision shape is the full block. The state is thus a normal registered common block state, not a malformed or version-only state.
- In both `Material.java` files `Material.IRON` is built without disabling `blocksMotion`, `solid`, or `translucent`; builder defaults are true. The old `isSolidBlocking()` returns the translucent flag.

## Predicate result at the sampled center

The paired state dispatches and predicates are:

- 1.13.2 `BlockState.isSolid()` → `Block.isSolid(state)` (`BlockState.java:143–145`, `Block.java:264–267`): `isSolidBlocking && isCube && !isSignalSource`.
- 1.14.4 `BlockState.isViewBlocking(world,pos)` → `Block.isViewBlocking(state,world,pos)` (`BlockState.java:273–275`, `Block.java:274–276`): `material.blocksMovement && state.isShapeFullBlock(world,pos)`.
- Both `RedstoneBlock.isSignalSource(state)` implementations return true (`:14–16`), so old `isSolid` is false while new `isViewBlocking` is true for this common full-collision-cube state.
- Old `PlayerEntity.shouldSuffocate(pos)` is `!state.isSolid()` and `doesNotSuffocate(pos)` is `shouldSuffocate(pos) && !state(pos.up()).isSolid()` (1.13.2 `PlayerEntity.java:1479–1485`). New `shouldSuffocate(pos)` is `!state.isViewBlocking(world,pos)` (1.14.4 `PlayerEntity.java:1420–1422`).
- Old `LocalClientPlayerEntity.wouldCollideAt(pos)` returns `!shouldSuffocate(pos)` when swimming, else `!doesNotSuffocate(pos)` (1.13.2 `LocalClientPlayerEntity.java:453–455`). For redstone block at the center and air above, both branches return false: swimming gives `!true`; non-swimming gives `!(true && !false)`. New `wouldCollideAt(pos)` scans `y=floor(box.minY)` through `y<ceil(box.maxY)` and returns true on any view-blocking state (1.14.4 `LocalClientPlayerEntity.java:435–447`); it sees the redstone block and returns true.

## Four-corner direct write calculation

Use an equal fixed snapshot in both releases: `noClip=false`, player center `x=z=0.5`, width `0.6`, shape vertical bounds `[0.25,2.05]`, and initial velocity `(0,0,0)`. The queried world has the common redstone-block state at `(0,0,0)` and air at `(-1,0,0)`, `(1,0,0)`, `(0,0,-1)`, `(0,0,1)` and all other positions in the scanned columns for `y=0,1,2`. The four points are produced by the paired `mobTick` callsites, in this order:

1. `(0.29, 0.75, 0.71)` → `BlockPos(0,0,0)`, fractions `(g,h)=(0.29,0.71)`.
2. `(0.29, 0.75, 0.29)` → `BlockPos(0,0,0)`, fractions `(0.29,0.29)`.
3. `(0.71, 0.75, 0.29)` → `BlockPos(0,0,0)`, fractions `(0.71,0.29)`.
4. `(0.71, 0.75, 0.71)` → `BlockPos(0,0,0)`, fractions `(0.71,0.71)`.

The source uses the same `width * 0.35` expression, so for a float width of `0.6F` its exact binary fractions are symmetric around `0.5`; the displayed decimals are rounded. In the newer vertical scan, `floor(0.25)=0` and `ceil(2.05)=3`, so rows 0, 1 and 2 are sampled. The center returns true on row 0; each cardinal neighbor column is air throughout the scan and returns false. In the older implementation the center returns false from `wouldCollideAt`, so it never consults the neighbor candidates and performs no velocity write.

For 1.14.4, the neighbor distance comparisons are strict `<` and keep the first direction on ties. The four successful calls therefore select WEST, WEST, EAST, EAST: the two west calls write `x=-0.1`, followed by the two east calls writing `x=+0.1`; north/south tie candidates do not replace the earlier choice. Each setter passes the retained other components through `Entity.m_32166403` (`Entity.java:2654–2656`, which stores a new `Vec3d`). After all four calls, new velocity is `(0.1,0,0)`. Old velocity remains `(0,0,0)`. Later corner calls do not cancel the final write; they repeat the eastward write. This direct output difference is independent of the old swimming branch.

The call order is 1.13.2 `LocalClientPlayerEntity.mobTick` callsites `:717–721`; 1.14.4 uses `:645–651` and encloses the same four calls in `if (!noClip)`. The 1.13.2 method itself returns before any write when `noClip` is true (`:401–405`). Thus the witness uses the ordinary non-no-clip branch under both endpoints.

## Disposition and limits

This closes the requested **conditional direct local-player response witness**: a common, registered vanilla state makes the paired sampled predicates disagree and yields a non-cancelled horizontal velocity write under equal raw player/world inputs. It is independently useful source evidence for the push-away response residual.

The witness places a full-cube redstone block inside the player's vertical bounding-box column and therefore does not establish collision-free ordinary placement, how that snapshot was produced, or that an ordinary tick/packet trajectory reaches it. It does not claim that the state is produced by movement, server correction, chunk loading, profile change, or any other event. Position/state production, trajectory reachability and subsequent tick propagation remain outside this witness. No runtime parity is claimed.

## Exact source hashes

SHA-256, relative to each endpoint's `ornithe-feather/` root:

| Version | Source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.13.2 | `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` |
| 1.14.4 | `net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.13.2 | `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.13.2 | `net/minecraft/block/RedstoneBlock.java` | `7b7284efaae2873529bc9da2a5e817716c0bcd83eb45f1333cc5ad77bf0bc9e0` |
| 1.14.4 | `net/minecraft/block/RedstoneBlock.java` | `7b7284efaae2873529bc9da2a5e817716c0bcd83eb45f1333cc5ad77bf0bc9e0` |
| 1.13.2 | `net/minecraft/block/material/Material.java` | `9bf4fc6893e07f15b7db2b03cba7cba7850370a2499870c621f422c356cf3b4f` |
| 1.14.4 | `net/minecraft/block/material/Material.java` | `b976f0011b0cf0f05831a799f40632f2824a4c09019f75d29ef7d88f33f72acf` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
