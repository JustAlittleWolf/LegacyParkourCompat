# 1.13.2 → 1.14.4 ordinary local-player tick staging and movement entry

## Disposition and limits

This source-only slice closes the client-local-player call order from the client tick driver through the inherited entity tick and back to the movement writer. The endpoint comparison assumes the same ordinary local player, loaded/in-chunk state, raw logical input fields, and effective movement-state/block/fluid memberships at each paired operation. It does not prove those upstream histories, collision outcomes, a trajectory, an intermediate patch boundary, or full-pair freeze. Keyboard/device plumbing, server processing, and block/fluid state production are excluded. The lava-state dependency is called out because it changes the input sampled by a later travel operation.

Sources are exact read-only Ornithe Feather Gen2 build 2 trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Ready source-manifest digests are `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` and `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. Every source file hash below was recomputed from the read-only tree and matches the indicated manifest entry.

## Paired call graph and gates

```text
Minecraft.tick
  [world != null && !paused]
  └─ World.tickEntities (1.13.2) / ClientWorld.tickEntities (1.14.4)
      └─ tick ordinary local player if inChunk
          └─ LocalClientPlayerEntity.tick
              [current x/z chunk loaded]
              └─ PlayerEntity.tick
                  ├─ updateWaterSubmersion
                  └─ LivingEntity.tick
                      └─ Entity.tick → Entity.baseTick
                          ├─ update body-water/submerged-water/swimming caches
                          └─ isInLava (damage-side read)
                      └─ LocalClientPlayerEntity.mobTick (virtual dispatch)
                          ├─ stage logical input and local sprint/flight controls
                          └─ PlayerEntity.mobTick → LivingEntity.mobTick
                              ├─ virtual LocalClientPlayerEntity.serverTickAi
                              │   └─ copy raw input movement/jump fields
                              ├─ jump gates and velocity writes
                              ├─ movement-field scaling and flyingTick
                              └─ PlayerEntity.moveRelative → LivingEntity.moveRelative
                                  └─ Entity.move (SELF), collision/contact terminal
                  └─ PlayerEntity.updatePlayerPose (post-movement)
              └─ local packet/sound handlers (outside movement operation)
```

The exact ordinary gate sequence is paired as follows:

1. Both `Minecraft.tick()` methods call `world.tickEntities()` under the same `world != null && !paused` gate. On the client path, 1.13.2 `World.tickEntity(entity, true)` skips the area-load gate for players but still requires `entity.inChunk`; 1.14.4 `ClientWorld.m_07416577` admits players past the entity-ticking-chunk check and ticks a nonspectator only when `entity.inChunk`. Both reset the interpolation previous/last position fields before invoking `entity.tick()`.
2. `LocalClientPlayerEntity.tick()` has an identical full normalized body at both endpoints (including the X/Z chunk-loaded guard and the `super.tick()` call). The subsequent packet sends and ambient-sound loop are after the movement operation and are excluded here.
3. `PlayerEntity.tick()` performs spectator/no-clip and sleeping counters, refreshes the eye-submersion cache, calls `super.tick()`, then performs player post-tick work and `updatePlayerPose()` after inherited travel. The old-only `m_89205834()` call between sleep counters and submersion is a bubble-column sound bookkeeping scan; it does not write player position, velocity, collision flags, input, or movement branch state. The endpoint cache query itself changes from `isSubmergedIn(WATER)` to `isSubmergedIn(WATER, true)`; this is the already inventoried eye-fluid query dependency in `ordinary-method-hashes/method-hashes.md`. The loaded-chunk behavior is conditional on the same eye-block query and is not restated as a new finding.
4. `Entity.tick()` is body-identical. `Entity.baseTick()` records prior positions/rotations, executes water/contact-cache maintenance, then reaches `isInLava()` before `LivingEntity.tick()` proceeds into `mobTick()`.
5. `LivingEntity.tick()` calls virtual `this.mobTick()`, so dispatch enters `LocalClientPlayerEntity.mobTick()` first. The local override stages input and local controls before its `super.mobTick()` reaches `PlayerEntity.mobTick()` and then `LivingEntity.mobTick()`. Local input staging stays before local `serverTickAi()`. Both endpoint `LocalClientPlayerEntity.serverTickAi()` bodies are identical: after `super.serverTickAi()`, the camera-controlled local player copies `input.movementSideways`, `input.movementForward`, and `input.jumping` to the entity fields before jump handling and travel. `LivingEntity.mobTick()` then does its jump gates, scales sideways/forward input by `0.98F`, runs `flyingTick()`, calls the player movement overlay and inherited travel, and finally runs push handling.
6. Each ordinary living travel continuation dispatches to `Entity.move(SELF, …)`; the exact four dry/elytra/lava/water move routes and terminal comparisons are already paired in `travel-terminal-pairing/report.md`. Player pose/dimension application is after inherited movement on both endpoints; the 1.14.4 outer swimming-fit gate and pose fallbacks remain as narrowed in `ordinary-tick/correction-supplement.md` and dependent on the collision lane.

## Source-level branch/output differences in this staging slice

### Lava-state sampling boundary

In 1.13.2, `Entity.isInLava()` (`Entity.java:1053–1055`) performs a live material query over the current entity shape contracted by `(0.1F, 0.4F, 0.1F)`. `LivingEntity.mobTick()` reads it before travel, and `LivingEntity.moveRelative()` also reads it while selecting the travel continuation. In 1.14.4, `Entity.isInLava()` (`Entity.java:1058–1059`) returns a stored boolean. Each `Entity.move()` clears that flag immediately before `checkBlockCollisions()` (`Entity.java:541–543`); the new liquid-lava contact callback can set it during that callback scan (`Entity.java:1055`, `LiquidBlock` callback paired in `collision-contact/source-review.md`). Thus the next base-tick/travel branch reads the previous movement/contact terminal on the new path, while the old path queries the current contracted box. This is an exact state-source/timing dependency for the already documented lava branch, not an assertion that contact membership is equal or that a trajectory diverges. Vanilla fluid/block membership, callback reachability after external corrections, and raw state histories remain producer inputs outside this report.

### Sleep-pitch terminal

The 1.14.4 `LivingEntity.tick()` adds a final `if (isSleeping()) pitch = 0.0F` after `mobTick()` and post-movement bookkeeping (`LivingEntity.java:2120–2121`); the 1.13.2 method has no corresponding final assignment. This output difference is conditional on the incoming sleeping state. The exact sleep/wake paths and their applicability remain under the existing sleep reports; this report does not claim an ordinary non-sleeping movement delta from it.

### Paired order with no new gate claim

For ordinary nonsleeping local movement, the two tick call chains preserve the relevant staging order: local input first, then AI copy, jump handling, travel selection, movement/collision writer, and finally the player pose update. Known gate/math changes encountered inside these calls are already enumerated in `ordinary-gates/ordinary-gate-closure.md` and `travel-terminal-pairing/report.md`: climb-jump correction, submerged sprint-forward predicate, acceleration normalization/rounding, dry acceleration, chunk fallback, and the conditional water gravity sign gate. They are not duplicated here. The camera-flight simultaneous jump+sneak arithmetic remains separately conditional on incoming velocity as previously recorded.

## Exact source and normalized method hashes

Canonical method-body hash rule: extract the method body interior (excluding braces), remove Java block and line comments, remove all whitespace, encode UTF-8, SHA-256. Body hashes below were computed from the exact files identified by their endpoint manifest hashes.

| Member | 1.13.2 line(s) / body SHA-256 | 1.14.4 line(s) / body SHA-256 |
|---|---|---|
| `Minecraft.tick` | `1071–1194` / `fcc41c845aa3d6f48ce67a48e7aa32c9b5834240192646af3140000383a2bf89` | `1237–1356` / `b30a5be7db8f6433507dbfed0a8d65b064768d6d64238402c7482cb3f637a0a9` |
| `World.tickEntities` / `ClientWorld.tickEntities` | `World.java:958–1105` / `3cc0ea5a298157101ee1409cee16bcd510db9a91e3f063131c28ed2f8b7b3dee` | `ClientWorld.java:106–148` / `2f2dfe20ce2375cc84c748964db1d61e5da9f5cf244d987e48f8a437130b142c` |
| `LocalClientPlayerEntity.tick` | `181–199` / `b0bad511aa271f0cc3d695247e7ac89bd9311cfed164e28fbd85eacbb19d5746` | `178–196` / `b0bad511aa271f0cc3d695247e7ac89bd9311cfed164e28fbd85eacbb19d5746` |
| `LocalClientPlayerEntity.serverTickAi` | `635–646` / `09fa296c2a6bb741f52aab2b8b655e3960eba2409766e9bd88ecf22910aadbbe` | `601–612` / `09fa296c2a6bb741f52aab2b8b655e3960eba2409766e9bd88ecf22910aadbbe` |
| `LocalClientPlayerEntity.mobTick` | `653–842` / `384655b774facd0ebdd3639bf8282ef52b622d3b197c18f224a2be366567c2fc` | `619–778` / `2c45f9ee08d955f7818ee8406972d57da026dbe51c3cd4cc98dd4b88e82ab4c6` |
| `PlayerEntity.tick` | `176–255` / `ca97ed0f4060913e9c59f25eba33f5ff35262c6c57f84db86817b3613dfb0834` | `208–282` / `c25a1a980830a74715638d1a34df0406d1a1ec776a5d37ff8433051a1786d735` |
| `LivingEntity.tick` | `1689–1825` / `4d10387025059a96609d5b444914409333beedbc6e18250ec6dea7586bdc3530` | `1979–2123` / `ff78ea67a775733a7be197f112fd847a3e57134cd9391faa6cca70f6b4b9662f` |
| `LivingEntity.mobTick` | `1852–1936` / `2034a8d5c1ce8d3a57599977c1f712e3a6a531a49915c06e24cc1ef935b5ad01` | `2150–2237` / `389ebc6bc810c88af535cdc21070cb2591d037f875a8240885722d4f8caeb5ac` |
| `Entity.tick` | `332–338` / `b972832419fa0147a455e8bac88c5eb61571a3e030a0ca0a8653940d4dbb2ddd` | `331–337` / `b972832419fa0147a455e8bac88c5eb61571a3e030a0ca0a8653940d4dbb2ddd` |
| `Entity.baseTick` | `340–427` / `bbc8488d856a73799f77febe1c8cb1adaa132ecfea00e91f555f23fa03f80388` | `339–390` / `078c9a2b03e5fe0e002bcb6aa2441524ef950565a22ffb70f14695258d1cb9a6` |
| `Entity.checkWaterState` | `961–977` / `90dd39f0e9168c7431c9e65e934d28ac24e9764d58ecbc88d5b6522342c56d97` | `956–972` / `90dd39f0e9168c7431c9e65e934d28ac24e9764d58ecbc88d5b6522342c56d97` |
| `Entity.isInLava` | `1053–1055` / `a9c986e0cbb065bb237a276f462eae314220398e2c5786e486ba84b1c7119640` | `1058–1060` / `df4b6c0475ccdcca2e7630bb4030905e520b4ee6a67304eabdc123f0e1af3213` |

Full source-file SHA-256 values (all manifest-matched):

| Source file | 1.13.2 | 1.14.4 |
|---|---|---|
| `client/Minecraft.java` | `b1d35473cd12bdf38e87f9888b4ed6f620614cbe914cf7e7a40c601d4e284875` | `6a5d9fac7092e8ec89bb86dd545e083d20df27edd039e26d68a216442ed039b2` |
| `world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` | `498a72cdd4bd035cd731d2c49fce401bef439d6f92f498501577d9cfc59ab487` |
| `client/world/ClientWorld.java` | `bae1d6d653260e42d735b9652e5c89711f1bd78eacba7993e2460f2f2528640a` | `c4674cc7c6b322bef6a5a951aa73be2b405de4bc64804fb9b6bb96c1832b1768` |
| `client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| `entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54e9d308703bf49cb53b72646b05253857e9557d657df` |
| `entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| `entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |

## Remaining boundary

This closes the ordinary local-player tick-staging and entry-to-movement call-path edge. It does not close the remaining registered block/state/provider membership inventory, entity response terminals, callback lifecycle beyond the cited lava producer, or the independent full-pair audit. Existing operation reports remain authoritative for their bounded candidates and dependencies. No implementation, canonical research, wiki/product/backlog path, or source tree was changed. No build, test, game/server launch, or decompilation was run.
