# Chest, ender chest, hopper, and anvil collision-provider pairing: 1.13.2 → 1.14.4

## Scope and result

Paired the movement-facing collision shape providers for the common IDs `chest`, `trapped_chest`, `ender_chest`, `hopper`, `anvil`, `chipped_anvil`, and `damaged_anvil`. All raw state domains were checked (78 registered ID/state tuples total). The old and new providers produce the same geometric collision sets for every listed state. Chest and trapped-chest state `TYPE`/`FACING` select the same double-chest half; hopper `FACING` selects the same base/spout; anvil `FACING` selects the same axis-oriented composite. Chest waterlogging and hopper `ENABLED` do not affect these shapes. Ender-chest facing/waterlogging are both ignored. No world, position, block-entity, neighbor, or collision-context input is read by the shape methods.

This closes these provider results only under equal raw block states. It makes no state-producer, movement-history, trajectory, or full-pair claim.

## Dispatch and collision applicability

- 1.13.2 `BlockState.getCollisionShape(world,pos)` forwards to `Block.getCollisionShape(state,world,pos)`. The base provider returns the block state's shape when `hasCollision` is true and empty otherwise (`Block.java:393–395`).
- 1.14.4 `BlockState.getCollisionShape(world,pos,context)` forwards to `Block.getCollisionShape(state,world,pos,context)`; its base provider has the same `hasCollision ? state.getSHape(...) : empty` gate (`BlockState.java:201–203`, `Block.java:376–378`). That base gate obtains the state shape through the no-context accessor; all compared collision providers are inherited through this gate and their shape bodies depend only on the stated block properties. Thus neither the supplied entity context nor the static cache changes these outputs.
- Both endpoint `Block.Properties` initialize `hasCollision=true`; `.noCollision()` is the operation that flips it false (`Block.java:1898+` old; `:808+` new). The listed seven IDs register ordinary material/strength properties without `.noCollision()`. Their inherited collision gate is therefore open at both endpoints.
- The shape helper `Block.block(min…,max…)` divides each coordinate by 16 at both endpoints (`Block.java:136–138` old; `:154–156` new). Dimensions below are expressed in sixteenths of a block.

## Registration and complete state domains

Old registrations are made in 1.13.2 `net/minecraft/block/Block.java`; 1.14.4 registers the same IDs in `net/minecraft/block/Blocks.java`. The exact IDs and implementation classes are:

| ID(s) | 1.13.2 class | 1.14.4 class | State properties | Number of raw state tuples per ID |
|---|---|---|---|---:|
| `chest` | `ChestBlock` | `ChestBlock` | `FACING={N,E,S,W}` × `TYPE={SINGLE,LEFT,RIGHT}` × `WATERLOGGED={false,true}` | 24 |
| `trapped_chest` | `TrappedChestBlock extends ChestBlock` | `TrappedChestBlock extends ChestBlock` | same inherited three properties | 24 |
| `ender_chest` | `EnderChestBlock` | `EnderChestBlock` | `FACING={N,E,S,W}` × `WATERLOGGED={false,true}` | 8 |
| `hopper` | `HopperBlock` | `HopperBlock` | `FACING={DOWN,N,E,S,W}` × `ENABLED={false,true}` | 10 |
| `anvil`, `chipped_anvil`, `damaged_anvil` | `AnvilBlock` | `AnvilBlock` | `FACING={N,E,S,W}` | 4 each |

The shared `ChestType` enum and all three values are identical (`SINGLE`, `LEFT`, `RIGHT`; identical full-file hash below). Both `Properties.HOPPER_FACING` declarations exclude only `UP`, and both chest/anvil facing properties are horizontal. Counts above come from these property domains and the compared block state definitions; no other property is declared by these classes.

## Shape outputs by state selector

### Chest and trapped chest

`ChestBlock.getShape` is the same state-only switch at both endpoints (old `ChestBlock.java:93–109`; new `:132–148`). For `TYPE=SINGLE`, every facing and waterlogged value returns the central shape `[1,0,1]–[15,14,15]`. For `TYPE=LEFT` or `RIGHT`, the shared `getConnectedDirection` returns `FACING.clockwiseY()` for LEFT and `FACING.counterClockwiseY()` for RIGHT (old `:111–114`; new `:150–153`); that direction chooses the following shape at both endpoints:

| Connected direction | Output box in sixteenths |
|---|---|
| NORTH | `[1,0,0]–[15,14,15]` |
| SOUTH | `[1,0,1]–[15,14,16]` |
| WEST | `[0,0,1]–[15,14,15]` |
| EAST | `[1,0,1]–[16,14,15]` |

These formulae cover all 24 property tuples for each of `chest` and `trapped_chest`. Waterlogged does not appear in the shape body. The `trapped_chest` subclass adds no shape override; its full Java source is byte-identical at both endpoints.

### Ender chest

Every one of the eight `FACING × WATERLOGGED` tuples returns the constant `[1,0,1]–[15,14,15]`: old `EnderChestBlock.getShape` (`:40–42`) and new `getShape` (`:44–46`) return the same `SHAPE`. Neither property is read.

### Hopper

Both `HopperBlock.getShape` methods select the same constant by FACING (old `:54–70`; new `:56–72`). ENABLED is not read, so each output applies to both values:

| FACING | Collision-shape construction in both versions |
|---|---|
| DOWN | `BASE_SHAPE ∪ [6,0,6]–[10,4,10]` |
| NORTH | `BASE_SHAPE ∪ [6,4,0]–[10,8,4]` |
| SOUTH | `BASE_SHAPE ∪ [6,4,12]–[10,8,16]` |
| WEST | `BASE_SHAPE ∪ [0,4,6]–[4,8,10]` |
| EAST | `BASE_SHAPE ∪ [12,4,6]–[16,8,10]` |

`BASE_SHAPE` is `((TOP_SHAPE ∪ FUNNEL_SHAPE) minus Hopper.INSIDE)` in both endpoint bodies, with `TOP_SHAPE=[0,10,0]–[16,16,16]`, `FUNNEL_SHAPE=[4,4,4]–[12,10,12]`, and `Hopper.INSIDE=[2,11,2]–[14,16,14]`. The exact constants and Boolean operations match. The `Hopper.INSIDE` interface file is byte-identical across releases.

### Anvils

All four horizontal FACING values use the same selector at both endpoints (old `AnvilBlock.getShape`, `:71–76`; new `:62–67`): X-axis facing (EAST/WEST) returns `SHAPE_Z`; Z-axis facing (NORTH/SOUTH) returns `SHAPE_X`. Each composite is the union of the same four boxes:

- Shared base: `[2,0,2]–[14,4,14]`.
- `SHAPE_Z` adds `[3,4,4]–[13,5,12]`, `[4,5,6]–[12,10,10]`, and `[0,10,3]–[16,16,13]`.
- `SHAPE_X` adds `[4,4,3]–[12,5,13]`, `[6,5,4]–[10,10,12]`, and `[3,10,0]–[13,16,16]`.

Old spells each composite as nested `VoxelShapes.or` calls; new spells it as `VoxelShapes.m_19519917(base, parts…)`. The new Feather helper body reduces the listed parts with the same `VoxelShapes.or` operation (`VoxelShapes.java:115–117`); because OR denotes set union and both sides combine the same boxes, output occupied volume is equal for both axis variants. State identity, not damage level, chooses the provider; all three damage-stage IDs therefore share the result.

## Exact source hashes (SHA-256)

Hashes were recomputed from the read-only Feather Gen2 endpoint trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`.

| Relative source file | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/ChestBlock.java` | `483ed7dc673f8acb33fbac6d5d883c652db05de2314931c522e0bee482792541` | `0103ffd23c63903f57efb76de25caae999eb06fc840f363afaaa4fcb6b54a5e5` |
| `net/minecraft/block/TrappedChestBlock.java` | `ce2db33ed4b4e5dec67d757ad0211b78c9f92d406bee833485961a3a3ff611e8` | `ce2db33ed4b4e5dec67d757ad0211b78c9f92d406bee833485961a3a3ff611e8` |
| `net/minecraft/block/EnderChestBlock.java` | `12642f9af345dd70a0a1787af22c48f7ce9ae0f0c2ded1ae0fe6ba009bbff431` | `7c2ff5ddb905e1c3bd2a44b06d1579a6c532e7fa3598fa39c212f0c81601e010` |
| `net/minecraft/block/HopperBlock.java` | `c43588fd0bdf0c17ec7356090e67af8101335b5ee2a565088837d6d75a3a73ae` | `179c954e0c484ec1c613c9273b679725f5f352081a141540c31d8b20d6b03859` |
| `net/minecraft/block/AnvilBlock.java` | `156505373606a0cf2c0df329e170465c207b72b2ab59798272cbec389373092e` | `5edacda442a01ef963826463c4d5918eb699697e47eec4a073aed54c65fb918c` |
| Registration source: old `net/minecraft/block/Block.java`; new `net/minecraft/block/Blocks.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/block/HorizontalFacingBlock.java` | `7ce4cee45329c93352c8a1740d691b046c8cd573dbb9e4b6549924f07f2fe1ad` | `7ce4cee45329c93352c8a1740d691b046c8cd573dbb9e4b6549924f07f2fe1ad` |
| `net/minecraft/block/state/property/ChestType.java` | `f574a5477f7891b3bd769425e7c5fe1cfdfcb8a9051c6b03ceca7cb4302fd464` | `f574a5477f7891b3bd769425e7c5fe1cfdfcb8a9051c6b03ceca7cb4302fd464` |
| `net/minecraft/inventory/Hopper.java` | `875ea61c315306699ac6d0e9d4551037515d4f9408521a391f6140044218b820` | `875ea61c315306699ac6d0e9d4551037515d4f9408521a391f6140044218b820` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |

No source tree was modified or regenerated. No build, test, game/TAS/Gym/server launch, product implementation, wiki, backlog, or product Git was consulted.
