# 1.13.2–1.14.4 ordinary witness method hashes

This is source evidence for the assigned ordinary-witness candidates only. It does not establish acceptance, pair coverage, a patch-introduction boundary, implementation readiness, or a pair-freeze verdict.

## Inputs and hash validation

- Exact endpoint sources: Minecraft 1.13.2 and 1.14.4, Ornithe Feather mapping family. Read-only root: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\`.
- Mapping artifacts are the Feather Gen2 build.2 merged-v2 archives recorded by each endpoint's provenance manifest. The per-file SHA-256 values in `method-hashes.tsv` match each endpoint's `ornithe-feather.sources.sha256` entry; all endpoint files used here passed.
- 1.14–1.14.3 Yarn sources were consulted only to reconcile stable names and structural identity: 1.14.3 `PlayerEntity.updateSize` / `getActiveEyeHeight`, `LivingEntity.travel`, and `ClientPlayerEntity.tickMovement` / `method_20623` correspond to the 1.14.4 Feather candidates noted below. Those intermediate Yarn trees have no pinned source manifest at the shared root, so they are identity aids and not hash-validated endpoint evidence.
- Method hash canonicalization: extract the complete method body interior (excluding braces), remove Java block and line comments, remove all whitespace, encode UTF-8, then SHA-256. These are exact mapped-body fingerprints; mapped identifiers can differ across mapping families. The TSV records method and complete source-file hashes, endpoint identity, method line bounds, and canonicalization rule.

## Normalized body differences

### Pose update, sneaking dimensions, eye height, and submersion query

- 1.13.2 `PlayerEntity.updatePlayerPose` (lines 334–361) computes width/height from fall-flying, sleeping, swimming/spin-attack, sneaking, or standing; it constructs a replacement box and applies `setSize` only when `world.hasNoCollisions` passes. `PlayerEntity.getEyeHeight` (1859–1870) starts at `1.62F`, uses `0.2F` sleeping and `0.4F` for swimming/fall-flying/height `0.6F`, then subtracts `0.08F` for sneaking/height `1.65F` (sneaking eye height `1.54F`).
- 1.14.4 `PlayerEntity.updatePlayerPose` (343–371) runs only when the swimming pose would not collide, chooses a requested pose, then falls back to the sneaking or swimming pose when the requested pose cannot fit; pose assignment replaces direct size mutation. The paired dimension and eye-height bodies are `getDimensionsForPose` (1964–1966; Yarn identity `getDimensions`) and `m_86089714` (1802–1813; Yarn identity `getActiveEyeHeight`). The player pose table uses sneaking dimensions `0.6F × 1.5F`; active eye height for `Pose.SNEAKING` is `1.27F`.
- The water cache update changes from `isSubmergedIn(FluidTags.WATER)` to `m_69330161(FluidTags.WATER, true)` (`PlayerEntity.updateWaterSubmersion`, 1.13.2 lines 257–260; 1.14.4 lines 284–287). The entity query still samples `y + getEyeHeight()`, but the 1.14.4 two-argument query returns false when the eye block's chunk is not loaded and calls `fluidState.getHeight(world, blockPos)`; the 1.13.2 query has no loaded-chunk guard and calls `fluidState.getHeight()`.

Normalized snippets:

```text
1.13.2: sneaking -> height 1.65; getEyeHeight -> 1.62 - 0.08 = 1.54; update cached water via isSubmergedIn(WATER)
1.14.4: sneaking pose -> dimensions 0.6 x 1.5; active eye height -> 1.27; cached water via isSubmergedIn(WATER, true)
1.14.4 query: if (checkLoaded && !chunkLoaded(eyeBlock)) return false
```

### Climb-jump post-move gate

- 1.13.2 `LivingEntity.moveRelative(float,float,float)` (1478–1669) contains the full movement branch. Its climb clamp runs before `move`; after the move, upward `0.2` is assigned only when `collidingHorizontally && isClimbing()`.
- The 1.14.x Yarn identity is `LivingEntity.travel(Vec3d)`; the 1.14.4 Feather source retains the body under `moveRelative(Vec3d)` (1786–1942) and factors the pre-move ladder clamp into `m_19439509(Vec3d)` (1944–1959). After moving, the climb jump gate is `(collidingHorizontally || jumping) && isClimbing()` before writing `0.2` into the velocity Y component.

Normalized gate snippets:

```text
1.13.2 after move: collidingHorizontally && isClimbing() -> velocityY = 0.2
1.14.4 after move: (collidingHorizontally || jumping) && isClimbing() -> velocity.y = 0.2
```

The extra `jumping` branch can therefore raise the post-move climb velocity without horizontal collision.

### Submerged sprint-key start gate and input predicate

- 1.13.2 `LocalClientPlayerEntity.mobTick` (653–842) checks `movementForward >= 0.8F` in its sprint start gates, including the sprint-key branch gated by `(!isInWater() || isSubmergedInWater())`.
- 1.14.4 `LocalClientPlayerEntity.mobTick` (619–778) delegates the forward-input test to `m_03985577` (961–964; Yarn 1.14.3 identity `ClientPlayerEntity.method_20623`). The helper selects `input.m_49149051()` while the player is submerged and otherwise keeps the `movementForward >= 0.8` check. The paired `Input.m_49149051` body (lines 22–24; Yarn identity `Input.method_20622`) returns `movementForward > 1.0E-5F`.

Normalized predicate:

```text
1.13.2: forward >= 0.8F
1.14.4: submerged ? forward > 1.0E-5F : forward >= 0.8
```

This changes the sprint-start forward-input threshold underwater; the surrounding key, blindness, item-use, food/flying, and water-state gates remain in `mobTick` and are represented by its complete body hash.

## Machine-readable hashes

See `method-hashes.tsv` for full method-body SHA-256 fingerprints and matched source-manifest file hashes.
