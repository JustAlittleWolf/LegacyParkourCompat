# Full stair horizontal-face state closure: 1.13.2 → 1.14.4

## Result and scope

For all common-era stair registrations, the complete `FACING × HALF × SHAPE × WATERLOGGED` state domain is now paired against the movement-facing horizontal face predicate. Each registration has 80 raw property tuples: 4 horizontal facings × 2 halves × 5 shapes × 2 waterlogged values. The full family is 17 common IDs × 80 = 1,360 raw tuples.

Under equal valid raw block/fluid inputs, the old `FlowingFluid.isSolidFace` helper returns false for every horizontal stair face because it explicitly excludes every `StairsBlock`. The new helper reaches the state sturdy-face predicate when the same-fluid early return does not apply. With the default vanilla `LEAVES` recipes, none of these 17 stair registrations is a leaf, and the new predicate returns true exactly for the full horizontal collision faces in the matrix below. The result is independent of `HALF` and `WATERLOGGED`; `SHAPE` and `FACING` select it.

This closes the previously open **80 oak-stair states and new sturdy-face outputs**, and accounts for all 16 other common stair IDs using the already inventoried complete 80-row collision-state grid. It closes this face-output slice only. It does not establish fluid/block-state producer histories, active runtime tag replacement, flow-vector or player-trajectory results, neighbor-state reachability, or pair-wide freeze.

## Registration and raw-state coverage

The exact common IDs are:

`acacia_stairs`, `birch_stairs`, `brick_stairs`, `cobblestone_stairs`, `dark_oak_stairs`, `dark_prismarine_stairs`, `jungle_stairs`, `nether_brick_stairs`, `oak_stairs`, `prismarine_brick_stairs`, `prismarine_stairs`, `purpur_stairs`, `quartz_stairs`, `red_sandstone_stairs`, `sandstone_stairs`, `spruce_stairs`, and `stone_brick_stairs`.

I matched all 17 IDs against both exact endpoint registration sources. Each is constructed as `new StairsBlock(...)` in 1.13.2 `Block.java` or 1.14.4 `Blocks.java`; there is no per-species StairsBlock subclass or replacement shape provider. The 1.13.2/1.14.4 `StairsBlock` state definitions both add exactly `FACING`, `HALF`, `SHAPE`, and `WATERLOGGED`. Their domains are respectively the four directions from `Direction.Plane.HORIZONTAL`, `TOP/BOTTOM`, `STRAIGHT/INNER_LEFT/INNER_RIGHT/OUTER_LEFT/OUTER_RIGHT`, and boolean. Thus the state product is 80 at both endpoints.

The existing `remaining-collision-provider-tranche/states.tsv` contains 1,280 rows: each of the 16 non-oak IDs has 80 distinct raw tuples. I independently checked all 1,280 rows against the exact `StairsBlock.getShapeIndex` formula and `SHAPE_INDICES` constant: `get_shape_index = shape_ordinal * 4 + facing_horizontal_id`, and all 1,280 stored mask values match the constant. The table has all 20 shape/facing combinations; `HALF` and `WATERLOGGED` each repeat every combination four times. The oak registration is separately present on both sides and shares the same class/property definition; its remaining 80 tuples therefore add one more complete 20×4 grid.

`StairsBlock.getShape` selects `TOP_SHAPES` or `BOTTOM_SHAPES` by `HALF`, then the shared `SHAPE_INDICES` mask by `SHAPE` and horizontal facing. `WATERLOGGED` is not read by this method. Each shape is the matching half slab unioned with the mask-selected half-height quarter boxes. Both endpoints use the same mask constant and union table. On the 1.14.4 path, inherited `Block.getCollisionShape` supplies this state collision shape to `Block.isFaceSolid`; the StairsBlock-specific collision state geometry is identical to the paired old shape provider.

The 1.14.4 generated vanilla `LEAVES` recipe names the same six leaf blocks as 1.13.2 and omits all stairs. This closure assumes those equal default memberships; active/custom runtime tag replacement is excluded.

## Complete horizontal output matrix

Facing IDs are the exact horizontal IDs used by `getShapeIndex`: `0=SOUTH`, `1=WEST`, `2=NORTH`, `3=EAST`. The stair mask bit boxes are NW=`1`, NE=`2`, SW=`4`, and SE=`8`. A horizontal face is full when its two boundary quarter boxes are both present: north=`1+2`, east=`2+8`, south=`4+8`, west=`1+4`. The base slab supplies the opposite vertical half of that side face; `HALF` swaps which vertical half is the base but does not change whether the entire side is filled.

| `SHAPE` | `FACING=SOUTH` | `FACING=WEST` | `FACING=NORTH` | `FACING=EAST` |
|---|---|---|---|---|
| `STRAIGHT` | SOUTH | WEST | NORTH | EAST |
| `INNER_LEFT` | EAST, SOUTH | SOUTH, WEST | NORTH, WEST | NORTH, EAST |
| `INNER_RIGHT` | SOUTH, WEST | NORTH, WEST | NORTH, EAST | EAST, SOUTH |
| `OUTER_LEFT` | none | none | none | none |
| `OUTER_RIGHT` | none | none | none | none |

The paired `SHAPE_INDICES` masks in the exact source, grouped by the enum order above and facing IDs `SOUTH, WEST, NORTH, EAST`, are `[12,5,3,10]`, `[14,13,7,11]`, `[13,7,11,14]`, `[8,4,1,2]`, and `[4,1,2,8]`. Projecting each mask to its four horizontal boundary slices yields the table. `Block.isFaceFull` converts the selected collision shape face to its face slice and checks whether that slice is a full block; the mask test therefore enumerates all possible full horizontal faces for every state rather than sampling a witness.

## Old caller versus new caller

The old direct `StairsBlock.getFaceShape` method is not the final movement-facing predicate. Old `FlowingFluid.isSolidFace` first checks the queried fluid, returns early for UP and ICE, then computes `Block.isExceptionForAttachment(block) || block instanceof StairsBlock` and returns false when that expression is true. Stairs are excluded for every horizontal direction and every raw state before `getFaceShape` can contribute. The old final horizontal output is therefore false for all 4 directions across all 1,360 states. This remains true for raw old direct methods whose individual `getFaceShape` result would be `SOLID`.

In 1.14.4 the paired `FlowingFluid.isSolidFace` retains the same-fluid short circuit, UP case, and ICE case, then uses the state's face-sturdy output. For any horizontal query where that earlier same-fluid gate does not apply, the new outputs are the matrix above. Consequently, for each registration, 16 raw tuples (all straight configurations) have one sturdy horizontal face; 32 (inner configurations) have two; and 32 (outer configurations) have none. That is 48 tuples with at least one true face and 32 with none, or 80 true horizontal state-face outputs per stair registration. Across 17 registrations this is 1,360 true and 4,080 false new horizontal outputs (5,440 direction/state pairs total); the old helper yields 5,440 false outputs under the same non-same-fluid assumption.

When `WATERLOGGED=true` and the queried flow itself is water, the common same-fluid gate returns false before either face predicate; this report does not count those queries as reaching the matrix. Waterlogged states queried by a different fluid retain the same geometry-derived face output. This is only an abstract predicate result under equal valid membership/state inputs, not a claim about active water or lava production.

## Exact source and table identities

The following Java file SHA-256 values were recomputed from the read-only Feather endpoint trees and checked against their endpoint `ornithe-feather.sources.sha256` manifests. Manifest identities are recorded in `providers/inventory.md` (1.13.2: `2C8CFB646BF622FB26AC0CA0CB5E02A354FB512E29F8B1010F1AAACD509E1211`; 1.14.4: `717B468536348557F9DAE8CF57EDCCF80AD16EB65E5BEF6C60BDB5EA3C9F75BC`).

| Relative source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/block/StairsBlock.java` | `B226EB255A3A1B0A69E137C15024A3B0A48F488E7205174DD476FFD64CA82761` | `B49CBD43A9BE5E848623F25769DEDE5795F50435BA0E82BBDBBF571527396B9F` |
| `net/minecraft/block/Block.java` | `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` | `1F8EC3628F08E196C2793E91CA0B94FEACEA6BC3939E7FB770F0682A6E66F2C5` |
| `net/minecraft/block/Blocks.java` | — | `9C0323497B31F8A284456E5692898897B92B6F0817D0371FAE9A8AFB54C638F8` |
| `net/minecraft/fluid/FlowingFluid.java` | `2398D109DDC5785CB1BC8872B8C157319137DF8957FAF8A03581A8F68AFB1253` | `6AFB033D18E6D28FF6D7DEDA88F5F1432914903B0FEF100C44FB8372D3E148CE` |
| `net/minecraft/block/state/BlockState.java` | `0496FDA381628E90B3B3FF8AE376A5BAE24CBD662366F34D70991252FAB2FE70` | `6C6703C7C2F7203A7507D8A621BC83E1DAD613B32089394F5AF4FBD8636B165F` |
| `net/minecraft/block/state/property/StairShape.java` | `1F67C3FF79EDC82D93BE6AD553FD198CDD031277571FB7342A926C979F4236B3` | `1F67C3FF79EDC82D93BE6AD553FD198CDD031277571FB7342A926C979F4236B3` |
| `net/minecraft/block/state/property/StairHalf.java` | `EF1627DDD414BDF6CEEEBE634B56799B9A7203CA4D61F943A794F1AA1E4C7381` | `EF1627DDD414BDF6CEEEBE634B56799B9A7203CA4D61F943A794F1AA1E4C7381` |
| `net/minecraft/block/HorizontalFacingBlock.java` | `7CE4CEE45329C93352C8A1740D691B046C8CD573DBB9E4B6549924F07F2FE1AD` | `7CE4CEE45329C93352C8A1740D691B046C8CD573DBB9E4B6549924F07F2FE1AD` |
| `net/minecraft/state/property/Properties.java` | `3882C1B832AC8B2B16F5A83978DA441AB03CDFE66F053A873342758045827F4C` | `9B524AF5065100919C60667778E38986380C9DF954EF70A9D0AC0A739132DDCA` |
| `net/minecraft/util/math/Direction.java` | `6D5C496FF65377FEE9F00C826E48C7BE14D3889E5AE5191E110A464007549082` | `121F8B78EDA07640ECCBE369F40ACC7CCBDCB275DCB6ACA87C4495CD193B01C0` |
| `net/minecraft/block/shape/VoxelShape.java` | `D95B0607647DA11595E24E1E26E9615CB7DA7705EA7885908544362DF62275C1` | `8EFB68BF9D5EFDB0EC48E401D1852E90458C7094F8FA0C8E9AE418F268C40FDD` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968D4E5855B5EC380272B6ABABCC5849D478AB771926355912A8CB6AA9C95` | `51A09C297C7F01C8BAD9B66AF2A80900E95F33C6E3A250CE599F4817433587D9` |
| `net/minecraft/data/tag/BlockTagsProvider.java` | `DB7E0AA20A1E9429380328B64812BDFF9D2D4B3B9D2016888CB7348D0EBAFC7E` | `0BD051D11A0C85ECC61CD2202A6ED33923DB97238DA0B065A647B932132D1BFA` |

The existing state table `remaining-collision-provider-tranche/states.tsv` has SHA-256 `CD3BA2BF223DB827F6263A2032C57753BA7147FDAD82448C25912FF57AF9AB9C`; its 1,280 non-oak rows pass the independent source-formula consistency check described above. The registration crosswalk `base-shape-registration-census/excluded-custom-shape-registrations.tsv` has SHA-256 `318D1C87057113428529444D6A3DB3CBDA284ACD87C4CA07722D3AAF1A7B3F93`; I re-matched the 17 stair IDs against the primary registry files. No build, test, game/runtime run, decompilation, product/wiki/backlog/Git access, or source-tree write was used.
