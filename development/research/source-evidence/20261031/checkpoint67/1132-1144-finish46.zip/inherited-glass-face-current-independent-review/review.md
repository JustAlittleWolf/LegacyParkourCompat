# Independent review: glass-face fluid current witness

## Verdict

**ACCEPT, narrowly**, for the direct conditional player velocity-delta query under the candidate's exact paired snapshot and default vanilla tags. The source supports old `Δvelocity=(0,0,0)` versus new `Δvelocity=(0,-0.014,0)`. This is not a fluid/player producer-history, ordinary reachability, travel-result, or trajectory finding.

## Identity and source verification

Reviewed candidate SHA-256 `71347cb8388b31b7b4d085a8577acbde315fa1748c7d6997af26a7ba333419f6` and report SHA-256 `8ae3ca25a95eefddad07817d7e5c601d9879c25578c05e71eb86b0c4224ae1d7`; both match the assigned files. Recomputed each of the seven cited source-file SHA-256 values at both published Ornithe Feather endpoints and matched the corresponding rows in each `ornithe-feather.sources.sha256` manifest. The source manifest whole-file hashes recorded by the report also match.

## Independent source trace

- `1.13.2/.../FlowingFluid.java:54-99`: with the listed inputs, each horizontal neighbor has empty fluid. Glass blocks movement, so its lower-fluid fallback is skipped; the other lower samples are empty. The gradient remains zero. Falling-face iteration reaches east. At `:121-122`, `Block.isExceptionForAttachment(glass)` is true via `isExceptionForPlacement`, so the old glass face is rejected. No other queried face qualifies, leaving normalized flow zero.
- `1.14.4/.../FlowingFluid.java:54-99,106-115`: the gradient logic remains the same. East glass has empty fluid and is not ICE or UP, so the sturdy-face test is used. `Block.java:402-403` rejects default LEAVES then requires the collision shape to fill the face. The registered common GLASS block has the default collision-enabled, full-cube shape; glass is absent from both endpoint default LEAVES recipes. Therefore east is the first sturdy horizontal face; zero normalized plus `(0,-6,0)`, then final normalization, yields `(0,-1,0)`.
- The paired `FluidTagsProvider.java:19` default WATER recipes are identical and include both flowing and source water. `FlowingFluid.java:448` in 1.13.2 returns `LEVEL/9`; the 1.14.4 world-aware height at `:442-453` is one only when the fluid above is the same fluid, otherwise it returns the same level height. With air above, LEVEL 8 yields `8/9` at both endpoints.
- `Entity.java` contracts the local box by `0.001` before integer scan bounds (old `:2510`, new `:2564`). The stated dimensions and position therefore cover x=0,z=0 and y=0..2; only P is a WATER cell. `d=max(8/9-0.481,0)≈0.40789`, so the `<0.4` scale gate is false. The assumed `hasLiquidCollision()==true` enables collection. With one contributor, a player retains the unnormalized per-cell vector. Old accumulated flow is zero and skips the writer; new writes `.scale(0.014)` to velocity (`Entity.java:2608-2618`), yielding the claimed direct delta.

## Limits

The glass cell begins at x=1 while the contracted player box ends at x=0.799, so this witness does not depend on glass-player collision. The candidate's raw fluid/player/block snapshot, loaded area and liquid-collision flag are conditional query inputs; source review does not establish their production or ordinary reachability. The conclusion applies to the common `minecraft:glass` registration only, not every face-result-different block named in the wider closure report. No implementation recommendation or full-pair coverage verdict follows from this review.

