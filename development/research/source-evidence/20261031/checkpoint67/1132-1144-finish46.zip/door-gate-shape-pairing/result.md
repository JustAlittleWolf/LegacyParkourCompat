# Door and fence-gate same-state shape pairing

## Scope and evidence

Compared the exact read-only source trees at D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather and .../1.14.4/ornithe-feather (both Ornithe Feather mappings). This is a bounded provider/state pairing for registered oak_door and oak_fence_gate. Vanilla property states are taken from each block's buildStateDefinition; StateDefinition enumerates the Cartesian product of each registered property's values.

Source file SHA-256 identities:

| Version | Relative file | SHA-256 |
|---|---|---|
| 1.13.2 | net/minecraft/block/DoorBlock.java | e01782f96a2214be2bc48dffad8b062db9eda12c04aa4d7747f01575d0df019b |
| 1.13.2 | net/minecraft/block/FenceGateBlock.java | e251cbd1b5e06c42e856a1d537e4ba043f6760b8f54ea1388039428aa7c05164 |
| 1.13.2 | net/minecraft/block/Block.java | 735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4 |
| 1.13.2 | net/minecraft/block/Blocks.java | 3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303 |
| 1.13.2 | net/minecraft/block/state/BlockState.java | 0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70 |
| 1.13.2 | net/minecraft/state/StateDefinition.java | d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365 |
| 1.13.2 | net/minecraft/state/property/Properties.java | 3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c |
| 1.14.4 | net/minecraft/block/DoorBlock.java | 5c40e94e04427c8a16a301aad12f7d2efdef866f70b21acd830fc683099dcbcd |
| 1.14.4 | net/minecraft/block/FenceGateBlock.java | c6c869ac12993e09f4684798e843778b2b63b7d9766f9cac0894dae0f312a151 |
| 1.14.4 | net/minecraft/block/Block.java | 1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5 |
| 1.14.4 | net/minecraft/block/Blocks.java | 9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8 |
| 1.14.4 | net/minecraft/block/state/BlockState.java | 6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f |
| 1.14.4 | net/minecraft/state/StateDefinition.java | d7702c839e8d8181a49a24d9d81df69412f78253e9e66633bb5c6c03ef349365 |
| 1.14.4 | net/minecraft/state/property/Properties.java | 9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca |

Relevant source slices:

- Door properties and shape: 1.13.2 DoorBlock.java:32-67,265-267; 1.14.4 DoorBlock.java:33-68,255-257. Both register HALF,FACING,OPEN,HINGE,POWERED; both have the same four 3/16-thick cardinal slabs and the same facing/open/hinge switch. The 1.14.4 method adds CollisionContext context but does not read it.
- Fence-gate properties, outline and collision: 1.13.2 FenceGateBlock.java:18-82,154-156; 1.14.4 FenceGateBlock.java:21-85,150-152. The constants and selection conditions pair exactly. Outline depends on facing axis and IN_WALL; collision depends on OPEN and facing axis, with the same 24/16-high closed bar. POWERED does not affect either shape.
- Provider dispatch/registration: 1.13.2 Block.java:388-395,1004,1204, with the Blocks.WOODEN_DOOR and Blocks.FENCE_GATE aliases at Blocks.java:800,872. 1.14.4 registers oak_door and oak_fence_gate as DoorBlock and FenceGateBlock at Blocks.java:448,732.
- State creation: both StateDefinition.java files are byte-identical (same SHA-256) and create all combinations from every property's values. Door is 4×2×2×2×2 = 64 raw states; gate is 4×2×2×2 = 32.
- 1.13.2 collision dispatch: BlockState.java:209-211 calls the block's collision provider; Block.java:393-395 returns state.getShape(...) when collision is enabled. Door inherits this path, so its collision equals its outline. Gate overrides collision at FenceGateBlock.java:67-73.
- 1.14.4 context/cache dispatch: Blocks.java:1960-1964 calls cacheShape() for every registered state. BlockState.java:65-67 only skips caching for dynamic-shape blocks; oak door/gate are created with ordinary Block.Properties and no dynamic-shape flag. The cache constructs collision using CollisionContext.empty() (BlockState.java:408-412); context-free BlockState.getCollisionShape(world,pos) returns that cache (197-199), while the context overload dispatches to the block (201-203). Door inherits Block.getCollisionShape, which calls state.getSHape(world,pos) (Block.java:376-378); that uses the empty context. Door and gate shape methods ignore context, so this cached route yields the same per-state result as their explicit methods.

## Per-state pairing

[states.tsv](states.tsv) records all 96 raw property combinations, with normalized shape boxes in sixteenths of a block and SHA-256 hashes for each endpoint's outline and collision output. The hash input is the ASCII canonical box descriptor xmin,ymin,zmin,xmax,ymax,zmax; empty represents the empty shape. Each row's 1.13.2 and 1.14.4 descriptors and hashes match.

Summary of complete rows:

| Block | State rows | Distinct outline shapes | Distinct collision shapes | Paired rows |
|---|---:|---:|---:|---:|
| oak_door | 64 | 4 | 4 | 64/64 |
| oak_fence_gate | 32 | 4 | 3 | 32/32 |

Door output ignores HALF and POWERED; closed output depends only on FACING, while open output depends on FACING and HINGE. Fence-gate outline ignores OPEN and POWERED; collision ignores IN_WALL and POWERED. Across every raw state, neither outline nor collision geometry changes between endpoints. These are source-derived normalized outputs, not runtime-executed block instances.

No source difference or applicability gate remains within this assigned provider/state slice. No block-state producer history, custom/runtime state or tag replacement, or full-pair freeze is claimed.
