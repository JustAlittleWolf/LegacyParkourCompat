# Respawn-copy sleep state and first local tick: 1.13.2 → 1.14.4

## Result

A bounded client response difference remains under one explicit prior-state assumption: the outgoing local player is asleep, with old 1.13.2 `sleeping=true` and a bed `sleepingPos`, corresponding to new 1.14.4 `Pose.SLEEPING` plus `Optional<BlockPos>` sleeping position. Bed-entry eligibility and the server decision to send a respawn response are not assessed.

On either same-dimension or dimension-changing respawn, 1.13.2 constructs a replacement at the client world's spawn, copies the old entity's `SyncedData`, then resets its size/position. The sleep boolean/position are ordinary `PlayerEntity` fields, not synchronized entries; the replacement therefore starts awake and remains at the constructor spawn unless `Entity.resetPos` raises it for collisions. In 1.14.4 the handler constructs the replacement, copies tracked data before `resetPos`, and the copied sleeping-position accessor callback immediately writes the replacement position to the bed center. `PlayerEntity.resetPos` then changes the pose to STANDING but does not clear the sleeping-position accessor. On a collision-free spawn and bed-center fixture with `0 < y < 256`, old remains at the constructor spawn while new remains at the copied bed center.

This also changes the first ordinary client movement tick. In 1.14.4 `LivingEntity.isSleeping()` is `getSleepingPos().isPresent()`, so the reset replacement still reports sleeping even though its pose was set to STANDING. `PlayerEntity.isDead()` includes `isSleeping()`. The `LivingEntity.mobTick` dead branch therefore clears jumping and sideways/forward controls and does not call `serverTickAi`; the old replacement reports not dead and its locally controlled `serverTickAi` copies movement axes and jump from the equal local input. The new tick still proceeds into travel with the cleared controls. This is a direct client-response conditional movement difference; it does not claim the server emits this respawn while the player is asleep, or prove a general trajectory. A concrete downstream position delta additionally requires nonzero movement input and a collision/travel state in which it changes the resolved move.

## Ordered source trace

- 1.13.2 `handlePlayerRespawn` calls `Minecraft.respawnPlayer`. On dimension change it first calls `Minecraft.setWorld`; that older `setWorld` performs a transient `resetPos`/add/input/ability pass on the prior player. The handler runs on the packet thread (`PacketUtils.ensureOnSameThread`) and then immediately calls `respawnPlayer`; no local player tick is interleaved. The transient prior-player reset does not transfer its position or velocity to the replacement: `respawnPlayer` creates a fresh player at the current world spawn and transfers network ID, stats, recipe book, synchronized entries, dimension, server brand and reduced-debug flag. Its only movement-state data transfer is `SyncedData`.
- 1.14.4 `handlePlayerRespawn` similarly runs after `ensureOnSameThread`, captures the prior player's ID/brand, optionally installs the new world, creates a replacement and sets it as local player/camera, copies synchronized data, then calls `resetPos`. `Minecraft.setWorld` at this endpoint only installs world/render references; it does not reset/re-add the outgoing player.
- The old tracked entity/living/player registrations contain no sleeping boolean or sleeping position. Old `PlayerEntity.isSleeping()` returns the ordinary `sleeping` field. New `LivingEntity.registerSyncedData` adds optional sleeping position; its `onDataValueChanged` callback calls the bed-center position helper when this accessor is copied. New `LivingEntity.isSleeping()` reads only whether that optional position is present. New `LivingEntity.stopSleeping()` clears it, but neither respawn handler nor new `PlayerEntity.resetPos()` calls `stopSleeping`; the reset only sets `Pose.STANDING`, invokes the shared collision-based `Entity.resetPos`, heals and clears death ticks.
- Both endpoints' shared `Entity.resetPos` loop rebuilds the box at current `(x,y,z)` and current dimensions, stops if collision-free or increments Y and retries, then zeros velocity and pitch. Thus the fresh old replacement uses spawn coordinates, while the new callback-changed coordinates are the reset loop's starting point. The collision-free fixture removes that loop's conditional Y adjustment without relying on bed-spawn eligibility or bed collision shapes.
- Both local-player entity tick wrappers gate on the loaded chunk and call `super.tick()`. The first local `LivingEntity.mobTick` is reached from the living tick. In the old replacement `PlayerEntity.isDead()` is `health <= 0 || sleeping`; after construction/reset health is restored and the nontracked sleeping field is false. In new, `PlayerEntity.isDead()` delegates to `super.isDead() || isSleeping()`; reset restores health but leaves the copied optional sleeping position present. The existing `LivingEntity.mobTick` branch clears movement controls when dead; otherwise a locally controlled player reaches `LocalClientPlayerEntity.serverTickAi`, which copies input sideways/forward values and jump state. This establishes changed first-tick movement inputs under equal logical input, not a producer or movement trajectory.

## Exact source identity

Read-only primary roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`, Feather Gen2 build 2. The following full Java file SHA-256 hashes were recomputed from the canonical trees and match their endpoint source manifests:

| Version | Relative file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/client/Minecraft.java` | `b1d35473cd12bdf38e87f9888b4ed6f620614cbe914cf7e7a40c601d4e284875` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.14.4 | `net/minecraft/client/Minecraft.java` | `6a5d9fac7092e8ec89bb86dd545e083d20df27edd039e26d68a216442ed039b2` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

Permitted source-only context reports reread and rehashed:

| Report | SHA-256 |
|---|---|
| `local-player-reset-pairing/report.md` | `c449abea73a5511aa547c8cd0b6a96155db7bc770bf8185a4ce80e5be0e5fd48` |
| `client-response-pairing/report.md` | `7563d89bc605f330ac8fac55cf7045f600013a250df07d0ab8a30216eb849f3f` |
| `tracked-state-pairing/report.md` | `618da47e4e656ffe1d699f33399f9346c1d5e81b25b041645f0ca256ecadc99b` |

## Remaining limits

This closes the exact response-copy/reset path and the branch difference on the first local tick only for the paired sleeping-state assumption. Server respawn timing/eligibility and incoming-state producers remain excluded. Exact downstream displacement depends on local controls and world travel/collision inputs; no trajectory is asserted. Same-state histories outside the stated response, ordinary movement terminal coverage, and the intermediate patch boundary remain open. No source tree was changed or generated; no build, test, game, TAS, Gym, server, product, wiki, backlog, or product Git data was consulted.
