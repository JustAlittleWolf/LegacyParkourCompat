# Independent review: core axis clipping pair

## Verdict

**Accept the bounded fixed-candidate-list finding.** The report at `resolver-axis-clip-core-pairing/report.md` has SHA-256 `9EDCD4D1A7F3EEDC18FCD2FAE51A4E0BE313988E20D280F772BFCE160A5CC3F4`, matching the assigned artifact. I independently inspected the paired Feather source bodies and recomputed the one-cube witness. The per-axis clipping arithmetic is equal for an identical supplied shape occupancy/coordinate grid, box, axis, and signed request; the resolver order can change the resolved vector for that same list.

## Source identity and pairing

Both ready markers identify mapping `ornithe-feather`. The published source-manifest hashes recorded in their ready markers match the manifests on disk:

| Version | Manifest SHA-256 |
|---|---|
| 1.13.2 | `2C8CFB646BF622FB26AC0CA0CB5E02A354FB512E29F8B1010F1AAACD509E1211` |
| 1.14.4 | `717B468536348557F9DAE8CF57EDCCF80AD16EB65E5BEF6C60BDB5EA3C9F75BC` |

The six source-file hashes below match both the report and each version's source manifest:

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/block/shape/VoxelShape.java` | `D95B0607647DA11595E24E1E26E9615CB7DA7705EA7885908544362DF62275C1` | `8EFB68BF9D5EFDB0EC48E401D1852E90458C7094F8FA0C8E9AE418F268C40FDD` |
| `net/minecraft/block/shape/VoxelShapes.java` | `313968D4E5855B5EC380272B6ABABCC5849D478AB771926355912A8CB6AA9C95` | `51A09C297C7F01C8BAD9B66AF2A80900E95F33C6E3A250CE599F4817433587D9` |
| `net/minecraft/entity/Entity.java` | `1D6EC8B80F74635401745C2C027BF36555C85348CA5693764F2668363B17D269` | `7315A496C195DA767DE9D4936D3ADB6EFC3C419DC0F0E95D6F32781B0DA1BA55` |

## Independent source check

In `VoxelShape.calculateMaxDistance`, both versions use the same empty-shape and `1.0E-7` near-zero gates; inverse axis-cycle mapping; coordinate-index calls with `±1.0E-7`; transverse index ranges with the same margins and clamping; positive scan from `j + 1` and negative scan from `i - 1`; occupancy tests; face tolerances (`f >= -1.0E-7`, `g <= 1.0E-7`); and `min`/`max` clamps. The snippets correspond to 1.13.2 lines 184–243 and 1.14.4 lines 203–261. `getCoordIndex` uses the same binary-search predicate (1.13.2 lines 133–140; 1.14.4 lines 138–145). `VoxelShapes.calculateMaxOffset` also iterates the supplied stream and delegates each shape in the same way in both versions (1.13.2 lines 194–206; 1.14.4 lines 213–225).

The old entity resolver applies nonzero components Y, X, Z in that order (1.13.2 `Entity.java` lines 578–598), translating the working box between axes. The 1.14.4 list resolver applies Y first and, when `abs(dx) < abs(dz)`, Z before X (lines 708–738). For the supplied box `[0,0.6] × [0.25,2.05] × [0,0.6]`, one full cube `[1,2] × [0,1] × [1,2]`, and request `(0.5,0.01,0.6)`, Y remains `0.01`. Old X has no transverse Z overlap and remains `0.5`; then Z clips to `1−0.6=0.4`, yielding `(0.5,0.01,0.4)`. New Z first has no transverse X overlap and remains `0.6`; then X clips to `1−0.6=0.4`, yielding `(0.4,0.01,0.6)`. This confirms the report's vector values for the same one-shape candidate list.

## Scope boundary

Accept this as a core operation finding only under the report's fixed-list and equal-shape-representation assumptions. In 1.14.4, `Entity.m_64271959` builds a diagonal candidate stream by concatenating supplied candidates with `world.getBlockCollisions` (lines 692–705), and its `m_73670363` single-axis path calls the world-aware `VoxelShapes.m_10425781` wrapper (lines 741–771). That wrapper scans world blocks before consuming the supplied stream (`VoxelShapes.java` lines 227–291). Therefore this review does not establish a general old-list/new-world-aware candidate equivalence, world-query equivalence, or trajectory result. The report keeps those limitations correctly separate.

No implementation, wiki/backlog, runtime, build, test, decompile, or canonical/shared-root writes were used for this review.
