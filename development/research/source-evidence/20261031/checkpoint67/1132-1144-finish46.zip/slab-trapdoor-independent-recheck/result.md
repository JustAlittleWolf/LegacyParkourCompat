# Independent source recheck: non-oak slab and trapdoor shapes

## Result

The `non-oak-slab-trapdoor-shapes/state-pairing.tsv` table is independently verified against the exact 1.13.2 and 1.14.4 Ornithe Feather sources. All **492** enumerated raw state tuples and all old/new outline and collision selectors/box descriptors match the provider formulas. No omitted, extra, duplicated, or mismatched tuple was found.

The 24 common registrations in `registrations.tsv` resolve in the exact registry source lines to the same direct provider classes on both sides: 18 `SlabBlock` registrations with six states each, and 6 `TrapdoorBlock` registrations with 64 states each. I checked every TSV ID/class/source-line tuple against its corresponding `Block.java` or `Blocks.java` text. None of the matched registration constructor expressions calls `noCollision()` or `dynamicShape()`.

## Independent table reconstruction

I derived expected outputs from the paired class-local formulas, then compared those to each TSV row:

- Slabs: `HALF` alone selects bottom `[0,0,0,16,8,16]`, top `[0,8,0,16,16,16]`, or the unit cube `[0,0,0,16,16,16]`. The 18 IDs each include all three half values and both `WATERLOGGED` values. Both old and new methods ignore `WATERLOGGED`, world, position, and the newer `CollisionContext` argument.
- Trapdoors: when `OPEN=false`, `HALF=TOP` selects the top panel `[0,13,0,16,16,16]`; otherwise it selects the bottom panel `[0,0,0,16,3,16]`. When `OPEN=true`, `FACING` selects north `[0,0,13,16,16,16]`, east `[0,0,0,3,16,16]`, south `[0,0,0,16,16,3]`, or west `[13,0,0,16,16,16]`. `POWERED` and `WATERLOGGED` do not select shape. The 6 IDs each include every facing, open flag, half, powered flag, and waterlogged flag combination.

The state-definition methods in both endpoint `SlabBlock` files add `HALF,WATERLOGGED`; both `TrapdoorBlock` files add `FACING,OPEN,HALF,POWERED,WATERLOGGED`. The property definitions give the products listed above. A static reconstruction of all expected keys (`id|raw_state`) yields 492 unique expected tuples, exactly matching the 492 table keys. Each row was then independently checked for the eight old/new outline/collision selector and box fields, plus `result=MATCH`: **0 formula/field mismatches**.

Collision dispatch also matches the table's outline-to-collision inference. Old and new `Block.getCollisionShape` both return empty only when the block's collision flag is false, otherwise delegate to that state shape. Every verified registration retains the default `hasCollision=true`; the new context parameter does not affect these provider bodies. The new no-context cache construction and live collision query both reach this provider with a context it ignores. Static versus live provider evaluation therefore selects the same shape for these registrations.

## Independent checks and source identity

I recomputed all 28 release/source rows in the source lane's `source-hashes.tsv`: file SHA-256 values match, and every Java source row also matches its version-root `ornithe-feather.sources.sha256` entry. There were **0 hash mismatches**. The ready, provenance and source-manifest hashes in that table also match their exact on-disk artifacts.

The specific shape/dispatch sources include:

| Source | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/block/SlabBlock.java` | `2E7FF3FCFA5FAA83AA4AF7EA9B68F07AF8D8FE7047E08EE3A9D7D37B78C7128F` | `91F2EBC592E5CB07D5CE8A6FAA123EC0D4B7BF10AA6323D6ACEB343BC0F73A53` |
| `net/minecraft/block/TrapdoorBlock.java` | `26DD6911517029DAEF779CEF046E943953356644A76372F1D47B1323054629DA` | `129B1C0EDA5E1431FE3845EF129524DD96C4EB018B686E6D0E38B093E198B3A5` |
| `net/minecraft/block/Block.java` | `735030E8BB5FC7EAD2D6DBCB1B262A36A414B4349DAF197456337F460B444CD4` | `1F8EC3628F08E196C2793E91CA0B94FEACEA6BC3939E7FB770F0682A6E66F2C5` |
| `net/minecraft/block/state/BlockState.java` | `0496FDA381628E90B3B3FF8AE376A5BAE24CBD662366F34D70991252FAB2FE70` | `6C6703C7C2F7203A7507D8A621BC83E1DAD613B32089394F5AF4FBD8636B165F` |

Input artifacts: `state-pairing.tsv` SHA-256 `110CFD9D4050BCFFBFCA998A6A9AF2F7DA6147B6C4F0F270B174264940B7083B`; `registrations.tsv` SHA-256 `5D2B3D987056B5DEC42C47E994A746A82001305F2866C02785E716BBBE410DF6`; and `source-hashes.tsv` SHA-256 `8E3F1B0294107FE2BAA5E631164D85D23488D5D1A7C04880D7844ABCD1FECECD`.

## Scope

This independently verifies only these common non-oak slab/trapdoor provider outputs for equal raw state values and the listed registrations. It does not validate state production/reachability, runtime tags, fluid-flow outcomes, trajectories, or pair-wide source coverage. Fluid-face outputs are outside this recheck. No product, wiki, backlog, Git, build, test, runtime or decompilation inputs were used.
