# Residual common provider/state closure: 1.13.2 → 1.14.4

## Result and exact census

Closed the 23 common-ID residuals from `../base-shape-registration-census/override-reconciliation.md`: 16 colored stained-glass panes plus `bubble_column`, `cave_air`, `end_portal`, `lava`, `nether_portal`, `structure_void`, and `water`. All 551 paired raw block-state rows are enumerated in `state-coverage.tsv`; no common state tuple is missing. The source reads are exact Feather Gen2 build 2 endpoint publications. Source-file hashes and manifest matches are in `source-hashes.tsv`.

For all 23 IDs, the ordinary player **collision-shape** result and the movement-facing face-sturdiness result are paired under equal raw state and query inputs. No new collision-shape, support/full-face, or fall-damage-bottom-block difference was found in this tranche. Two outline-only differences remain explicit below: the legacy inherited bubble-column outline and legacy fluid-height outlines are not used as collision shapes because their registrations set `hasCollision=false`; both endpoints return empty from the movement collision provider for those IDs. These outline results are reported as source facts, not player movement findings.

The exact shared state-space count is:

| Family | IDs | Raw rows | Shared state inputs |
|---|---:|---:|---|
| Stained-glass panes | 16 | 512 | 4 horizontal connection booleans × `WATERLOGGED` boolean |
| Bubble column | 1 | 2 | `DRAG` false/true |
| Cave air | 1 | 1 | no properties |
| End portal | 1 | 1 | no properties |
| Lava and water | 2 | 32 | `LEVEL=0..15` for each ID |
| Nether portal | 1 | 2 | horizontal `AXIS=X/Z` |
| Structure void | 1 | 1 | no properties |
| **Total** | **23** | **551** | all listed properties have the same endpoint domains |

Every row in the TSV is a common state. The new waterlogged pane property is not new: it is present in the 1.13.2 `IronBarsBlock` state definition too. No new-only state is included or relied on.

## Paired provider outputs and movement dependencies

### Stained-glass panes

1.13.2 registers the 16 dye IDs as `StainedGlassPaneBlock` in `Block.java:1324–1378`; 1.14.4 registers the same 16 IDs as `StainedGlassPaneBlock` in `Blocks.java:1015–1061`. The old class extends `GlassPaneBlock`, which forwards to `IronBarsBlock`; the new class extends `IronBarsBlock` directly. Both constructors reach the same `IronBarsBlock`/`PaneBlock` shape parameters `(1,1,16,16,16)`. Color changes rendering tint only. Both state definitions inherit the same ordered five Boolean properties (`NORTH`, `EAST`, `WEST`, `SOUTH`, `WATERLOGGED`) from `IronBarsBlock` (old `:111–112`; new `:83–84`).

For each ID and each of the 32 tuples, old/new `PaneBlock.getShape` select the same 16-entry central-post-plus-connected-arms table, and old/new `getCollisionShape` select the same table. `getShapeIndex` reads only the four connection bits; waterlogged, world, position, and collision context do not affect geometry. The newly added state-index memoization stores that same bitmask. This is an exact color-family extension of the already paired `glass_pane` tables in `../pane-snow-fence-shape-pairing/result.md`: the colored registrations use the same inherited constructor shape parameters and inherited providers. New shape caching is static and context-independent.

The old `IronBarsBlock.getFaceShape` returns `MIDDLE_POLE_THIN` for horizontal directions and `CENTER_SMALL` for UP/DOWN (old `IronBarsBlock.java:116–118`), never `SOLID`. The new full-face test sees only a 2/16-wide post/arms on any boundary plane and returns false for every direction and mask. Thus the old and new fluid-face consumers both reject these pane faces as full/sturdy; no waterlogged value changes the result. The raw state connection bits are treated as paired inputs; this does not claim neighbor/state-producer equivalence.

The paired fluid-state terminal is also equal for the movement body/eye scans: `PaneBlock.getFluidState` returns source WATER exactly when `WATERLOGGED` is true, otherwise it delegates to the base getter (both endpoint files, `:122–124` old and `:121–123` new). Thus waterlogged panes expose the same source fluid for either Boolean value. This compares the provider for each paired raw state, not how its waterlogged state was produced.

### Bubble column and the direct movement callback

Both endpoints register the same `BubbleColumnBlock` with `Material.BUBBLE_COLUMN.noCollision()` (old `Block.java:1874`; new `Blocks.java:1850–1851`); both state definitions contain only Boolean `DRAG`. The old class inherits a full-cube outline; the new class returns an empty outline (`BubbleColumnBlock.java:170–172`). That outline difference does not reach collision: the base collision provider returns empty at the `hasCollision=false` gate on both endpoints. The old direct face method returns `UNDEFINED` (old `BubbleColumnBlock.java:187–189`); new collision-face sturdiness is false because its collision shape is empty.

The relevant direct client movement callback is present at both endpoints. For a same callback invocation and same above-cell `isAir()` result, the `DRAG` branch order and Y formulas match: surface drag uses `max(-0.9, vy-0.03)`, surface rise uses `min(1.8, vy+0.1)`; interior drag uses `max(-0.3, vy-0.03)`, interior rise uses `min(0.7, vy+0.06)`, then resets `fallDistance` to `0.0F`. The new vector setter preserves the old X/Z components. The bubble-column fluid-state provider returns source WATER on both sides. This closes the callback body and state output under equal direct inputs, not the independent spatial enumeration/timing of every block callback or any bubble-column producer history.

`BubbleColumnBlock.getFluidState` returns `Fluids.WATER.asSource(false)` in both endpoints for both `DRAG` states (old `:86–88`; new `:84–86`), so its body-fluid and eye-fluid input is paired under the same vanilla water membership.

### Cave air, end portal, nether portal, and structure void

These four IDs remain non-colliding by paired registrations: `cave_air` uses `AirBlock(...noCollision())`; `end_portal` uses `EndPortalBlock(...noCollision())`; `nether_portal` uses `PortalBlock(...noCollision())`; `structure_void` uses `StructureVoidBlock(...noCollision())`. Their movement collision provider therefore returns empty for each raw state at both endpoints. Their old direct face providers return `UNDEFINED` (Air `:47–49`, EndPortal `:76–78`, Portal `:239–241`, StructureVoid `:49–51`); new face-sturdiness calculation from the empty collision shape returns false. Thus none produces a solid/full support face in the ordinary falling-fluid face path. All shape providers are static and context-independent.

Their outline formulas are also paired: AirBlock is empty; EndPortalBlock returns its fixed full-footprint 12/16-high shape; NetherPortal returns the four-sixteenths-thick X or Z plane selected by its only state property; StructureVoid returns the centered `[5,11]×[5,11]×[5,11]` sixteenth-box. The latter three visible/query outline shapes do not pass their registration collision gate. End-portal dimension-transfer callbacks have a `!world.isClient` gate and are outside this logical-client movement closure.

### Water and lava

Both IDs are `LiquidBlock` instances with `noCollision()` and the same `LEVEL_15` state domain 0 through 15 (old `Block.java:829–830`, `LiquidBlock.java:184–185`; new `Blocks.java:89–93`, `LiquidBlock.java:153–154`). This gate makes collision empty for every level at both endpoints. The old direct face result is `UNDEFINED` (`LiquidBlock.java:189–191`); the new collision-derived sturdy-face result is false. Their default WATER/LAVA recipes are source-verified in `../default-tag-provider-membership/result.md`; active runtime tag payload/history remains outside this source comparison.

The outline provider itself changes: old `LiquidBlock.getShape` returns full-block outline when the fluid above has the same liquid, otherwise a box from Y=0 to the queried state fluid height (old `:89–96`); 1.14.4 returns empty unconditionally (`:86`). This is outline-only because both registered collision gates are false. The old query's dependencies on the equal `LEVEL`-derived fluid state and upper fluid state are listed on each raw row in `state-coverage.tsv`. The 1.14.4 lava post-move callback's movement-route effect is separately represented by `../liquid-callback-movement-terminal/result.md`; this report does not re-review that candidate or infer a producer history. The 1.14.4 liquid callback tests the LAVA tag, so default Water has no lava-contact branch under the paired vanilla tag recipe.

The direct fluid-state mapping used by player fluid queries remains paired: both constructors build the same table (LEVEL 0 maps to source, 1–7 to `asFlowing(8-i,false)`, 8 to `asFlowing(8,true)`), and `getFluidState` selects `min(LEVEL,8)` (`LiquidBlock.java:39–70` old; `:37–67` new). Thus every common LEVEL row selects the same liquid-state variant for the same effective `LEVEL`; subsequent fluid flow math is a separate consumer already covered by the current-fluid source tranche.

## Query dispatch and scope

1.13.2 `Block.getCollisionShape` returns empty when `hasCollision` is false and otherwise asks the block state for the shape. 1.14.4 `Block.getCollisionShape` uses the same gate and the context overload; `BlockState` caches only static shapes built with the empty context. The pane providers ignore world/position/context and their registration is not dynamic; the seven no-collision registrations short-circuit before their outline providers can enter collision. Thus cache/context dispatch does not alter any paired collision tuple here.

The ordinary movement resolver, pose-clearance checks, support checks, and falling-fluid face path consume collision shapes or face/full-support predicates, not the outline-only results listed above. The face comparison is exact under the paired same-state membership inputs. Default tag recipes are source-verified separately; custom/runtime tag replacement, neighbor/state producers, server logic, bed-entry eligibility, arbitrary callback history, trajectories and pair freeze are not claimed. Non-player/vehicle callbacks and portal dimension transfer are excluded.

## Exact source identity

Primary read-only source roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather` and `.../1.14.4/ornithe-feather`, Ornithe Feather Gen2 build 2. Ready/provenance/source-manifest identities are the exact records already verified in `../providers/inventory.md`: 1.13.2 ready `1d1c644c1deb05c02d11dc575ad834f4f72489124701d9b2b90357f43dc37b38`, provenance `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383`, source manifest `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 ready `bf8c9399e3a36ddd7edc78d98413319000895f49e88db224335f62b2baf21e77`, provenance `7167b135e0222fcf58ff5f36a36fbb604d5068f63a59165c8c4d18ce7d9b21c9`, source manifest `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. All 31 listed Java file/hash entries in `source-hashes.tsv` were recomputed and matched their endpoint source-manifest entry (old `GlassPaneBlock.java` is old-only).

No decompilation, build, test or game launch was run; no canonical source tree or file outside this owned lane directory was changed.
