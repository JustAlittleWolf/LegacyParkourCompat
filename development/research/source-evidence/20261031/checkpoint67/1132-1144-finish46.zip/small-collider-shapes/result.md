# Small collider-shape provider pairing: 1.13.2 → 1.14.4

## Scope and evidence

Paired the common registrations, raw block-state properties, outline providers, and collision outputs for `lily_pad`, `turtle_egg`, `flower_pot` and its common potted variants, and `cactus`. This is a bounded shape-provider comparison, not a trajectory or full-pair claim. Block states and movement collision geometry are in scope; the state/interaction producers and effects listed below are not evaluated as movement changes.

Sources are Ornithe Feather Gen2 build 2 for 1.13.2 and 1.14.4, under `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Publication and mapping identity are the paired source inventory in `../providers/inventory.md`. I recomputed the hashes below from the exact files. `Block.block(x0,y0,z0,x1,y1,z1)` divides each sixteenth-unit coordinate by 16 in both endpoints (`Block.java:136–138` old, `154–156` new).

## Registration and dispatch

- `minecraft:lily_pad`, `minecraft:turtle_egg`, and `minecraft:cactus` resolve to the corresponding named block class in both registries. The old IDs are registered in `net/minecraft/block/Block.java` (lily pad line 1208, cactus 1070–1071, turtle egg 1755–1757); 1.14.4 registrations are in `net/minecraft/block/Blocks.java` (lily pad 741, cactus 565–567, turtle egg 1653–1655).
- All 22 old `FlowerPotBlock` registrations have the same ID and provider in 1.14.4: `flower_pot`, `potted_oak_sapling`, `potted_spruce_sapling`, `potted_birch_sapling`, `potted_jungle_sapling`, `potted_acacia_sapling`, `potted_dark_oak_sapling`, `potted_fern`, `potted_dandelion`, `potted_poppy`, `potted_blue_orchid`, `potted_allium`, `potted_azure_bluet`, `potted_red_tulip`, `potted_orange_tulip`, `potted_white_tulip`, `potted_pink_tulip`, `potted_oxeye_daisy`, `potted_red_mushroom`, `potted_brown_mushroom`, `potted_dead_bush`, and `potted_cactus`. They are registered in old `Block.java:1242–1263` and new `Blocks.java:798–862`. New-only potted IDs (`potted_cornflower`, `potted_lily_of_the_valley`, `potted_wither_rose`, `potted_bamboo`) have no old state to pair and are excluded.
- In 1.13.2 `BlockState.getCollisionShape(world,pos)` dispatches to `Block.getCollisionShape(state,world,pos)` (`BlockState.java:209–210`); the base block returns empty only when `hasCollision` is false, otherwise returns the state outline (`Block.java:393–395`). These four providers are registered without `.noCollision()`.
- In 1.14.4 registry bootstrap calls `cacheShape()` for every registered raw state (`Blocks.java:1959–1964`); `cacheShape()` creates a cache for blocks without `hasDynamicShape()` (`BlockState.java:65–68`). These four registrations use the default static shape property (block properties default dynamic shape to false at `Block.java:819`) and so their raw states receive collision caches. `BlockState.getCollisionShape(world,pos)` uses that cached collision result, otherwise delegates with `CollisionContext.empty()`; the contextual overload dispatches to the block (`BlockState.java:197–202`). The cache calls the block collision provider with the empty context (`BlockState.java:410`). Base `Block.getCollisionShape` gates on `hasCollision` and returns `state.getSHape`, which means an empty-context outline (`Block.java:376–378`; `BlockState.java:189–195`). Default properties have collision enabled (`Block.java:811`), and none of these registrations sets `.noCollision()`. Cactus has a direct contextual collision override. None of the four providers reads its context, world, position, or any neighbor while producing these shapes; cache and direct contextual dispatch therefore agree for the paired results.

## Paired raw-state outputs

`Block.block` coordinates below are sixteenth units. The resulting normalized cuboids are identical at both endpoints.

| Common registration/provider | Raw state domain in both versions | Outline output in both versions | Collision output in both versions |
|---|---|---|---|
| `lily_pad` / `LilyPadBlock` | No declared block properties | Constant cuboid `(1,0,1)–(15,1.5,15)` (`LilyPadBlock.java:15,30–32` old; `:16,31–33` new) | Inherited base collision path returns that outline cuboid. |
| `turtle_egg` / `TurtleEggBlock` | `HATCH=0..2`, `EGGS=1..4`; default `(0,1)`; both endpoints add properties in order `HATCH, EGGS` | `EGGS=1`: `(3,0,3)–(12,7,12)`; `EGGS=2..4`: `(1,0,1)–(15,7,15)`. `HATCH` does not affect shape (`TurtleEggBlock.java:28–35,152–165` old; `:28–35,137–145` new). | Inherited base collision path returns the same state-selected outline. |
| `flower_pot` and common potted IDs / `FlowerPotBlock` | No declared block properties; content is a constructor field, not a state property | Constant cuboid `(5,0,5)–(11,6,11)` (`FlowerPotBlock.java:22–35` old; `:23–36` new) | Inherited base collision path returns that outline cuboid. |
| `cactus` / `CactusBlock` | `AGE=0..15`; default `AGE=0`; both endpoints add only `AGE` | Constant cuboid `(1,0,1)–(15,16,15)` for every age (`CactusBlock.java:21–28,64–67,112–115` old; `:22–29,65–68,108–111` new). | Explicit provider returns constant cuboid `(1,0,1)–(15,15,15)` for every age (`CactusBlock.java:59–62` old; `:60–63` new). This independently matches the previously reported cactus collision-provider result. |

## Movement relevance and exclusions

These providers supply player collision geometry, so they are eligible movement inputs. The paired geometry and raw state domains show no collision/outline difference for these common registrations. Turtle-egg hatch/egg-count state production and trampling, cactus age growth and damage callback, flower-pot content/interactions, and lily-pad boat callback are excluded producers or non-player interactions here. New-only potted registrations are not old-profile blocks. No movement trajectory, state-production history, or behavior outside these four provider families is claimed.

## Source-file SHA-256

Hashes are of complete Java files.

| Relative file | 1.13.2 | 1.14.4 |
|---|---|---|
| `net/minecraft/block/Block.java` (old registration/base provider; new base provider/registry helpers) | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | `3e128c9a4f6b53e1037fb85269c4d00bc85112ae52fe48f9534232e13ee2a303` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| `net/minecraft/block/state/BlockState.java` | `0496fda381628e90b3b3ff8ae376a5bae24cbd662366f34d70991252fab2fe70` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| `net/minecraft/state/property/Properties.java` | `3882c1b832ac8b2b16f5a83978da441ab03cdfe66f053a873342758045827f4c` | `9b524af5065100919c60667778e38986380c9df954ef70a9d0ac0a739132ddca` |
| `net/minecraft/block/LilyPadBlock.java` | `741784cff408619ec5f262366b481c92bd5892d329fc2f77393e3faeae6397eb` | `044fb0551c40490da3507e21ebcc2af81b82f6f5477df324681b07635f9875e5` |
| `net/minecraft/block/TurtleEggBlock.java` | `555e7263053f773dfce7d13c94c6dc1d043e26eea929a5b7cafddc6aa3189cf8` | `164fae7dc599eaf0ca63217178a755d15006e2ed6def947a28cd495868f3cb66` |
| `net/minecraft/block/FlowerPotBlock.java` | `7b958c584124459e209b4e626e0268bf5e479ea4cb190fd4ce7afb6940f4f529` | `15c602804adb2bdd5c2d61df859770592f3e0ae6f945a6ec59c5ccc1ebc7fdb4` |
| `net/minecraft/block/CactusBlock.java` | `d337d776966b6a50070a5ed79ec8cbabb064e15b7b2d6b8e4992a66ccea5e8c9` | `3e5d6d42cef91cd8bab1a2a96589f80f6d164fea8f0b286a0589cbf211d2f67b` |
