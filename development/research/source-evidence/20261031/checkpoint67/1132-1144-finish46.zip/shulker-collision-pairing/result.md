# Shulker collision and face-result pairing: 1.13.2 → 1.14.4

## Scope and evidence identity

Source-only continuation using the frozen provider inventory and provider-state pairing, with exact source roots `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Both sides are Ornithe Feather Gen2 build 2. Paired provider bodies were read from those trees; the prior inventory records and verifies both ready-marker, source-manifest, provenance, and listed source-file hashes. Hashes for files directly used here are repeated below. No source tree was written or generated.

Compared the common uncolored and 16 dye-colored shulker registrations, six `FACING` values, all four raw animation stages, and matched raw `progress`/`lastProgress` query inputs for valid `ShulkerBoxBlockEntity` instances. Color is constructor data only and is not read by either collision or face provider. The block-state input has only `FACING`; animation values come from the block entity. Custom/runtime block or tag replacements are excluded. This does not establish block-state production histories or a player trajectory.

## Collision shape: same output for same inputs

1.13.2 `ShulkerBoxBlock.getShape(state, world, pos)` (lines 210–213) and 1.14.4 `getShape(state, world, pos, context)` (lines 226–229) both fetch the block entity and return `VoxelShapes.block(blockEntity.getShape(state))` for a shulker entity, otherwise the full block shape. The new overload does not inspect `CollisionContext`.

The paired entity methods are output-equivalent for the same facing and raw animation fields:

- Old `getShape(BlockState)` delegates to `getShape(Direction)`; new code does the same (old `ShulkerBoxBlockEntity.java:90–103`; new `:91–101`).
- Both use `VoxelShapes.block().bounds().expanded(0.5F * progress * facing.offsetX, 0.5F * progress * facing.offsetY, 0.5F * progress * facing.offsetZ)`. New code stores `getProgress(1.0F)` in a local float before the same expression; old code inlines that call in each component. Both `getProgress(1.0F)` calls interpolate from `lastProgress` to `progress` at delta 1, so the returned value is the raw `progress` float. No operation changes the float expression, cast, or result for matched inputs.
- All 17 registrations on both endpoints opt into `.dynamicShape()` (old `Block.java:1615–1642`; new `Blocks.java:1458–1500`). In 1.14.4 this makes `BlockState.cacheShape()` leave `cache` null, so collision and face queries dispatch to the live provider rather than caching a dummy-world shape (`BlockState.java:65–68`).

Therefore the dynamic collision output matches for every common registered color, facing, raw progress value, and context, including non-stage-consistent raw values. The result concerns the provider output only; it does not pair block-entity progress production or synchronization.

## Old `FaceShape` versus new face-sturdy result

The old direct provider is `ShulkerBoxBlock.getFaceShape` (1.13.2 `:311–318`). It reads `FACING` and `getAnimationStage()`: `CLOSED` returns `SOLID` on all six faces; `OPENING` and `CLOSING` return `UNDEFINED` on all faces; `OPENED` returns `UNDEFINED` on `FACING` and its opposite and `SOLID` on the other four.

There is no corresponding new `getFaceShape` declaration. New `BlockState.m_87223014(world,pos,face)` dispatches to `Block.isFaceSolid` when the dynamic block state has no cache (`BlockState.java:326–327`). The helper returns `!state.is(BlockTags.LEAVES) && isFaceFull(state.getCollisionShape(world,pos), face)` (`Block.java:402–408`). Under the stipulated default vanilla tags, shulker boxes are not leaves.

For the shulker collision box, `VoxelShapes.getFaceShape` checks whether the requested outer boundary is exactly the unit-cell boundary and selects the boundary slice (`VoxelShape.java:170–200`; `VoxelShapes.java:317–334`). The facing-direction side has been expanded beyond that boundary whenever `progress > 0`, so it returns empty / not sturdy. The opposite side and the four perpendicular sides still cover their unit-cell boundary slice and are sturdy. At `progress == 0`, the shape is exactly the full block and all six sides are sturdy. This gives the following paired outputs for each facing:

| Matched raw block-entity context | 1.13.2 face provider | 1.14.4 face-sturdy result |
|---|---|---|
| `progress == 0`; ordinarily `CLOSED` | `SOLID` all six | `true` all six |
| `progress > 0`, stage `OPENING` or `CLOSING` | `UNDEFINED` all six | `false` on `FACING`; `true` on opposite and four perpendicular sides |
| `progress > 0`, stage `OPENED` (ordinary endpoint progress is 1) | `UNDEFINED` on `FACING` and opposite; `SOLID` on four perpendicular sides | `false` on `FACING`; `true` on opposite and four perpendicular sides |

The table is a direct provider-output comparison for the requested matched inputs. It does not claim stage and progress are always coupled; in particular, with raw mismatched values the old result still follows stage while the new result follows progress.

## Movement-facing caller gate

This provider difference reaches the fluid face helper, but its caller behavior must be stated separately. In 1.13.2 `FlowingFluid.isSolidFace` rejects `Block.isExceptionForAttachment(block)` before asking `getFaceShape == SOLID` (`FlowingFluid.java:105–123`); the old exception method explicitly includes every `ShulkerBoxBlock` (`Block.java:241–257`). Thus the old fluid helper returns false for shulker boxes regardless of the direct `FaceShape` result. In 1.14.4 `FlowingFluid.isSolidFace` has no equivalent shulker exclusion and delegates the non-ice case to the face-sturdy result (`FlowingFluid.java:106–115`). Its falling-fluid flow branch consults this helper and, on a true result, normalizes the vector and adds `-6.0` vertical flow (`FlowingFluid.java:81–97` in both endpoints).

So under default vanilla tag membership, the actual fluid helper changes from always false for a shulker to the live geometry-based result above. This is a changed input to the falling-fluid vector calculation (`FlowingFluid.java:90–92` in both endpoints), not evidence of a resulting player trajectory. No block-state producer or animation producer evidence was examined. Fluid state history, runtime state production, tag replacements, and intermediate releases remain outside this pairing.

## Exact source-file SHA-256

All paths below are relative to `decompiled_minecraft/`.

| Endpoint | File | SHA-256 |
|---|---|---|
| 1.13.2 | `ornithe-feather/net/minecraft/block/ShulkerBoxBlock.java` | `9d2652c2944cc8faf1a277349fbf2015170a4799ad882f876d24ee1d7f344fb8` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/ShulkerBoxBlock.java` | `016487146bc14aba8de02272e0bf5c76b4dff16c276abf30bf92cfa3061593df` |
| 1.13.2 | `ornithe-feather/net/minecraft/block/entity/ShulkerBoxBlockEntity.java` | `d123b08d4d3562ccb972a4433ec5a743cdd6877c59c5b6aa20d06af2063fa5ed` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/entity/ShulkerBoxBlockEntity.java` | `58b5e9f68831f6e3a3d293ae29c8c0c55628fc5a8d941e18286eb10ec7c0ba73` |
| 1.13.2 | `ornithe-feather/net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/Block.java` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/state/BlockState.java` | `6c6703c7c2f7203a7507d8a621bc83e1dad613b32089394f5af4fbd8636b165f` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |
| 1.14.4 | `ornithe-feather/net/minecraft/block/shape/VoxelShapes.java` | `51a09c297c7f01c8bad9b66af2a80900e95f33c6e3a250ce599f4817433587d9` |
| 1.13.2 | `ornithe-feather/net/minecraft/fluid/FlowingFluid.java` | `2398d109ddc5785cb1bc8872b8c157319137df8957faf8a03581a8f68afb1253` |
| 1.14.4 | `ornithe-feather/net/minecraft/fluid/FlowingFluid.java` | `6afb033d18e6d28ff6d7deda88f5f1432914903b0fef100c44fb8372d3e148ce` |

No product, wiki, backlog, or Git data was read or changed. No freeze, build, test, or game was run.
