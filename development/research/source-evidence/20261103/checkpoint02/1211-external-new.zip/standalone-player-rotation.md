# Server rotation packet directly sets local player angles

1.21.1, Mojmap: `net/minecraft/client/multiplayer/ClientPacketListener.java` has no `handleRotatePlayer` method and no `net/minecraft/network/protocol/game/ClientboundPlayerRotationPacket.java`.
1.21.2 and 1.21.3, Mojmap: `net/minecraft/client/multiplayer/ClientPacketListener.java`, `handleRotatePlayer`, lines 738–745; `net/minecraft/network/protocol/game/ClientboundPlayerRotationPacket.java`; sender `net/minecraft/server/level/ServerPlayer.java`, `forceSetRotation`, lines 1087–1089.

Difference: 1.21.2 adds a packet path that writes packet yaw and pitch to the player, calls `setOldRot()`, then sends a rotation response to the server. The server's `forceSetRotation` sends this packet. The 1.21.1 source has no corresponding packet handler.

Movement meaning: when the server forces a player's rotation, the modern client changes the local player's current and old yaw/pitch immediately without a position correction. The new angles become the view/input orientation used by subsequent movement ticks.
