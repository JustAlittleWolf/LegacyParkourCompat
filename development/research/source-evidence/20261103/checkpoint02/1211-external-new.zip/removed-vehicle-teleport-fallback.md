# Removed local vehicle teleport is applied to the player

1.21.1, Mojmap: `net/minecraft/client/multiplayer/ClientPacketListener.java`, `handleTeleportEntity`, lines 535–550; no `removedPlayerVehicleId` fallback or `setValuesFromPositionPacket` helper.
1.21.2 and 1.21.3, Mojmap: `net/minecraft/client/multiplayer/ClientPacketListener.java`, `handleTeleportEntity`, lines 581–600, and removal tracking at lines 476–477 and 697; `setValuesFromPositionPacket`, lines 717–735.

Difference: 1.21.1 ignores a teleport if the entity ID no longer resolves. From 1.21.2, when that ID equals the remembered ID of the player's just-removed vehicle, the handler applies the packet's relative position, delta movement and rotation fields to the local player, then sends its updated position/rotation. The remembered ID is set during vehicle removal and cleared when the entity removal callback identifies the same ID.

Movement meaning: if a player-controlled vehicle is removed and a teleport for that vehicle arrives afterward, the 1.21.2+ client changes the player's own position, velocity and/or rotation using that final packet. This path is newly reachable specifically under the removed-player-vehicle ID gate.
