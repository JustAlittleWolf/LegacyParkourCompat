# Respawn can retain player velocity and rotation

1.21.1, Mojmap: `net/minecraft/client/multiplayer/ClientPacketListener.java`, `handleRespawn`, lines 1127–1143; `shouldKeep((byte)2)` copies non-default entity data, then the handler unconditionally calls `resetPos()` and sets yaw to `-180.0F`.
1.21.2 and 1.21.3, Mojmap: `net/minecraft/client/multiplayer/ClientPacketListener.java`, `handleRespawn`, lines 1175–1196; under `shouldKeep((byte)2)`, it copies non-default entity data, delta movement, yaw and pitch; otherwise it calls `resetPos()` and sets yaw to `-180.0F`.

Difference: the entity-data keep branch now also copies the old player's `getDeltaMovement()`, `getYRot()` and `getXRot()` into the replacement player. `resetPos()` and the default yaw assignment moved into the opposite branch.

Movement meaning: for a respawn packet whose keep mask includes bit 2, the new local player starts with the previous player's velocity and both view angles rather than the reset/default spawn state. Other keep-mask behavior is not claimed to differ here.
