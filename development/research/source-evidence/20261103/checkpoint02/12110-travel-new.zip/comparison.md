# 1.21.10 → 1.21.11 source comparison: travel and collision terminal slice

## Source identity

- Both sides are exact `1.21.10` / `1.21.11`, Mojang-mapped (`mojmap`) decompilations in `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/`.
- Each side's `mojmap.provenance.json` and `mojmap.ready.json` identifies the exact version and the same batch run (`--versions=1.21.8,1.21.10,1.21.11 --mappings=mojmap`, Vineflower 1.12.0, Java 25.0.3+9-LTS, Gradle 9.7.1, Mapping IO 0.9.1, Tiny Remapper 0.14.1, ASM 9.10.1, Gson 2.14.0). The markers report 6,386 / 6,622 source files and client SHA-256 `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482` / `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd` respectively.
- Recomputed hashes for `Entity.java`, `LivingEntity.java`, `Player.java`, `VoxelShape.java`, `Shapes.java`, `CollisionGetter.java`, and `BlockCollisions.java` match each version's `mojmap.sources.sha256` entry.

## Examined

- `LivingEntity.travel`, `travelInAir`, `travelInFluid`, `travelFallFlying`, `travelFlying`, `getEffectiveGravity`, `handleRelativeFrictionAndCalculateMovement`, `getFrictionInfluencedSpeed`, `getSpeed`, `getJumpPower`, `getJumpBoostPower`, and the player movement-attribute consumers in `Player.java`.
- `Entity.move`, `maybeBackOffFromEdge`, `isAboveGround`, `canFallAtLeast`, support-block recording, `collide`, candidate step-up height collection, `collideBoundingBox`, `collectAllColliders`, `collectColliders`, `collideWithShapes`, and `moveRelative`.
- `CollisionGetter.noCollision`, block/entity/border collision composition, `getBlockCollisionsFromContext`, `findSupportingBlock`, `BlockCollisions`, `Shapes.collide`, `VoxelShape.collide` / `collideX`, and axis-order dispatch in `Entity.collideWithShapes`.

## Differences observed

1.21.11 extracts the existing fluid selection predicate into `LivingEntity.shouldTravelInFluid(FluidState)`, the former water and lava branches into `travelInWater` / `travelInLava`, and the shared collision escape into `jumpOutOfFluid`. For an ordinary player these preserve the old branch gate and the same movement calls, constants, types, and order: fluid move first; water/lava drag and falling adjustment in the previous order; then the same horizontal-collision clearance query and `0.3F` vertical assignment.

1.21.11 additionally calls `floatInWaterWhileRidden` after the water branch. It adds `0.04F` Y velocity only when the current entity type has `CAN_FLOAT_WHILE_RIDDEN`, the entity is a vehicle, and water height is greater than the fluid-jump threshold. The 1.21.11 decompiled `EntityTypeTagsProvider` lists only horse, zombie horse, mule, donkey, camel, and camel husk for that tag; player is not included. No player movement difference is established from this addition.

1.21.11 changes `LivingEntity.onClimbable`: while fall-flying, a block state in `CAN_GLIDE_THROUGH` returns false before the existing `CLIMBABLE` check. The new block tag includes vine, twisting/weeping vine plants, and cave vines, all of which remain in `CLIMBABLE`. `travelFallFlying` still switches to `travelInAir` and stops Elytra flight when `onClimbable()` is true. Thus a player Elytra-flying inside one of these block states now remains on the Elytra path rather than switching to ordinary air travel. Draft: `findings/elytra-glide-through-climbables.md`.

`Entity` adds finite-value guards to `setDeltaMovement(Vec3)`, `addDeltaMovement(Vec3)`, `push(Vec3)`, and `push(double,double,double)` in 1.21.11. The 1.21.10 paths accept the input without these guards. This could change behavior for non-finite externally supplied player velocity, but no ordinary vanilla player path or valid input witness was established in this slice; retain as an applicability question, not a source-accepted finding.

`CollisionGetter.noCollision` is decomposed in 1.21.11 into `noBlockCollision`, `noEntityCollision`, and `noBorderCollision`. The former evaluation order remains block shapes, entity shapes, then border; short-circuit results and the `null`-entity branch remain equivalent for the player edge guard. `Entity.move`/collision clipping, axis order and comparisons, step candidate collection, 0.05 edge-backoff loops, support-block epsilon and fallback, `findSupportingBlock`, `BlockCollisions` traversal, `Shapes.collide`, and `VoxelShape.collideX` show no behavioral changes in their compared method bodies. `BlockCollisions` changes only nullability annotations for `cachedBlockGetter` and `getChunk`.

`Shapes.rotate` and the rotation-map helpers are refactored around permutation/flipping APIs in 1.21.11 (`makeAxis` becomes `flipAxisIfNeeded`; `rotateAll` / `rotateHorizontal` gain group overloads). This is a possible provider dependency for historical block collision shapes, but this terminal slice did not compare the full set of extant-block shape providers and therefore makes no shape-parity claim from it.

## Partial / unexamined

- The full registration and shape-provider inventory for every block existing in the profile was not closed here. Follow up the rotation-helper refactor through each in-scope block provider and its collision-shape callback before closing shape math/callback coverage.
- No tick/input/pose/outer-tick paths reviewed; those are assigned to the separate tick owner.
- Non-finite velocity input has no concrete ordinary vanilla player witness yet.

## Finding drafts

- `findings/elytra-glide-through-climbables.md`: source difference with a concrete player path and unchanged `travelFallFlying` consumer.
- The fluid-water rider addition is inapplicable to player type under the listed tag contents. The velocity finite guards and shape rotation refactor remain dependency/applicability questions.
