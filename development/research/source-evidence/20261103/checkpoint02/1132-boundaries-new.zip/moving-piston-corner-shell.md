# Moving-piston corner-shell clipping cutover

1.13.2, Ornithe Feather Gen2 build 2: `WorldView.getBlockCollisions` prunes a movement-shell cell that lies on two boundary axes before the block state and shape provider are evaluated. See the accepted source review and terminal draft inputs recorded in `../1132-1144-finish46/corner-shell-clip-independent-review/review.md`.

1.14.0, Ornithe Feather Gen2 build 2: `VoxelShapes` axis clipping scans candidate cells and allows the `s == 2` case for `Blocks.MOVING_BLOCK` (`net/minecraft/block/shape/VoxelShapes.java:~250–300`, guard at 287). The moving-block state therefore reaches shape offset clipping in the accepted raw fixture.

1.14.1, Yarn 1.14.1+build.10; 1.14.2, Yarn 1.14.2+build.7: `VoxelShapes.method_17944` retains the same `s == 2` exception through `Blocks.field_10008` (`net/minecraft/util/shape/VoxelShapes.java:224–291`, guard 272). In each exact `Blocks.java:343–345`, `field_10008` registers `moving_piston` as a `PistonExtensionBlock`; this resolves the field through source, not name coincidence.

1.14.3, Yarn 1.14.3+build.13: `VoxelShapes.method_17944` retains the same exception with the renamed `Blocks.MOVING_PISTON` symbol (`net/minecraft/util/shape/VoxelShapes.java:228–291`, guard 272).

Cutover finding: the admitted dynamic corner-shell candidate is present already in 1.14.0 and persists in all checked patches through 1.14.3. Intermediate inspection does not move the first accepted source version later than 1.14.0. The reviewed clip amount remains conditional on the raw moving-block entity fields and the stated absence of other blockers; ordinary producer/trajectory reachability is open.
