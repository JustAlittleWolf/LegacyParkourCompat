# 1.14 intermediate source cutover comparison

Scope: exact 1.14.0, 1.14.1, 1.14.2 and 1.14.3 sources for the three accepted conditional 1.13.2→1.14.4 terminals. This comparison determines whether any intermediate patch changes the accepted local mechanism or delays the first observed cutover. It does not establish full ordinary-tick reachability.

## Conclusions

All three accepted terminals are already represented in 1.14.0 and remain materially present through 1.14.3. The source evidence therefore bounds each first cutover to 1.13.2→1.14.0 at the inspected fixed inputs; it does not select an intermediate patch later than 1.14.0.

- **Moving-piston wall corner-shell clip:** 1.14.0 `VoxelShapes.java:287` admits two-boundary cells when the state is `MOVING_BLOCK`; the same guard exists in 1.14.1 and .2 as `field_10008` and in .3 as `Blocks.MOVING_PISTON`. Each release has the axis resolver that fetches that cell's collision shape. The field in .1/.2 is independently identified as the registered `moving_piston` `PistonExtensionBlock` in each exact `Blocks.java:343–345` source.
- **Oak-fence `excludeBlock`:** 1.14.1–.3 movement clipping does not accept or apply the old original-box exclusion. In .1/.2 the resolver queries block states by swept-axis cell and clips their shapes directly (`VoxelShapes.method_17944`); in .3 the movement stream is built from the stretched movement box (`ViewableWorld.method_20812`) and clipped with `Entity.method_20737`. Those routes preserve the accepted fixture's exclusion removal. There is no new intermediate reintroduction of `excludeBlock`.
- **Redstone push-away four-corner predicate:** 1.14.0 uses view-blocking/full-cube predicate in the client player response. In .1–.3 the client uses `cannotFitAt` → `PlayerEntity.doesNotSuffocate` → `Block.canSuffocate`, whose predicate is `material.blocksMovement() && full collision cube`; this retains the redstone result because it does not reject signal sources. The `noClip` gate, four sample order, strict direction ties and write remain in each version.

## Exact source identities

All sources came from the read-only published canonical tree at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft`. SHA-256 is over the complete cited Java file. For .1–.3 every cited Java SHA below was independently matched against that release's hidden `.decompile-provenance.json` `sources` entry. The provenance sidecar itself is hashed below and binds the exact client, intermediary and Yarn artifacts; mapping coordinates/hashes are listed in `source-hashes.tsv`. The 1.14.0 Feather source hashes were checked against `ornithe-feather.sources.sha256`; its provenance resolves Feather Gen2 `1.14+build.2`.

The .1/.2 field name `Blocks.field_10008` is not presumed from equal symbols: in both exact `Blocks.java` files its registration id is `moving_piston`, constructed as `PistonExtensionBlock`. The source retains the same MOVING_BLOCK special-case admission as .3's named constant.

## Immutable conditional-input revisions

- Corner-shell moving-piston candidate: SHA-256 `6d11b353978b17392da13bb130b36646870ba65954dbb062de7dfdedfd371478`; independent review binds it to that candidate and report SHA `8fe19e62c3c5d4152ffcbf2024917e2d7e418b68da82ccb158a2f323a4583ed7`.
- Oak-fence `excludeBlock` candidate reviewed in renewal 2: SHA-256 `1174ac51022d5c4658d6961ebdbeb049e39e8bd14a56bd543c2af37c1f18781b`.
- Push-away revised candidate: SHA-256 `AE6FA929B0F60929F7FC7D57B3E33693E892EDB84781BBEE318DE66C90F61B87`.

## Applicability boundary

These comparisons bind the three already-reviewed conditional fixed-input movement terminals to an earliest inspected new source version, 1.14.0. They do not prove the moving-piston raw entity fields are ordinarily produced, how the oak-fence intersecting box arises, a redstone snapshot's collision-free history, or ordinary-tick trajectory reachability. Push-away remains a direct-client-response witness. No claim of complete pair/tick coverage follows.
