# Oak-fence overlap exclusion removal cutover

1.13.2, Ornithe Feather Gen2 build 2: the movement-specific `WorldView.getBlockCollisions(VoxelShape,VoxelShape,boolean)` receives the original player shape as `excludeBlock`; an intersecting fence candidate is suppressed. The accepted fixture and renewed review are in the source-only finish46 evidence set.

1.14.0, Ornithe Feather Gen2 build 2: `Entity` routes movement through per-axis `VoxelShapes` clipping (`net/minecraft/entity/Entity.java:~640–720`); `WorldView.getCollisions` enumerates block shapes against the movement query and exposes only entity exclusions, not an original-box exclusion (`net/minecraft/world/WorldView.java:127–190`).

1.14.1–1.14.2, Yarn: `Entity.method_17833` calls `VoxelShapes.method_17945` for each nonzero axis (`Entity.java:688–718` in .1; `690–720` in .2). `VoxelShapes.method_17944` fetches and clips each block-state collision shape on its scan (`VoxelShapes.java:228–287`); the method has no `excludeBlock` input or original-box overlap filter. The fence fixture's block candidate is thus not removed by the old exclusion.

1.14.3, Yarn: multi-axis movement builds a reusable stream with `ViewableWorld.method_20812(arg, arg3.stretch(arg2))` before clipping (`Entity.java:689–731`); `ViewableWorld.method_20812` emits translated block shapes overlapping the swept query (`ViewableWorld.java:133–186`) without the old original-box exclusion.

Cutover finding: old `excludeBlock` filtering is absent by 1.14.0 and remains absent through each checked patch. The oak-fence arithmetic is a reviewed conditional fixed-input result; the initial box intersects the fence, and ordinary state/box or trajectory reachability is not established.
