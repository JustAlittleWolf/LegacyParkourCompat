# Redstone four-corner push-away predicate cutover

1.13.2, Ornithe Feather Gen2 build 2: local-client `pushAwayFrom` tests `wouldCollideAt`; the fixed redstone block returns non-solid under the old predicate, so the accepted response witness leaves velocity unchanged.

1.14.0, Ornithe Feather Gen2 build 2: `LocalClientPlayerEntity.pushAwayFrom` calls `wouldCollideAt`, whose vertical scan reads `BlockState.isViewBlocking` (`LocalClientPlayerEntity.java:389–447`); the four ordered response probes are invoked at `648–651`. The base full-cube predicate is `material.blocksMovement() && isShapeFullBlock(...)` (`Block.java:264–265`) and does not exclude signal sources.

1.14.1–1.14.3, Yarn: the four callsite samples and order remain in `ClientPlayerEntity.java:633–640` for .1–.2 and `635–639` for .3. `pushOutOfBlocks` uses `cannotFitAt`, which scans `floor(minY)` through `< ceil(maxY)` and tests `PlayerEntity.doesNotSuffocate` (`ClientPlayerEntity.java:375–432`; `PlayerEntity.java:1401–1403` in .1–.2 and `1403–1405` in .3). `Block.canSuffocate` remains `material.blocksMovement() && isShapeFullCube(collisionShape)` (`Block.java:270–271` in .1; `269–270` in .2; `268–270` in .3). This predicate has the same redstone answer as 1.14.0 view-blocking: redstone is a full-collision cube with movement-blocking material, and the 1.13.2 solid predicate alone additionally excludes signal sources.

Cutover finding: the redstone predicate change is already present in 1.14.0 and the equivalent suffocation predicate remains in all three checked patches. The four-corner direct response is bound to the reviewed raw overlapping snapshot; no collision-free history or ordinary trajectory is claimed.
