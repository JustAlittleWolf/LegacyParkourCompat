# Tick and land/air comparison notes

## Input path

1.21.4 `KeyboardInput.tick` writes independent `leftImpulse` / `forwardImpulse` values from the boolean key pairs (`client/player/KeyboardInput.java:22–34`). `LocalPlayer.serverAiStep` copies them to xxa/zza (`client/player/LocalPlayer.java:607–618`); `LocalPlayer.aiStep` scales the input axes for item use and slow movement (`:643–681`); then `LivingEntity.aiStep` applies the 0.98 input decay before travel (`world/entity/LivingEntity.java:2765–2771`). `Entity.getInputVector` normalizes vectors with squared length over 1 (`world/entity/Entity.java:1429–1438`).

1.21.5 `KeyboardInput.tick` builds a normalized `Vec2` (`client/player/KeyboardInput.java:23–36`). `LocalPlayer.applyInput` passes that vector through `.98F`, item-use and slow-movement scales, then `modifyInputSpeedForSquareMovement` before writing xxa/zza (`client/player/LocalPlayer.java:608–658`). `LivingEntity.aiStep` calls `applyInput` before jump/travel (`world/entity/LivingEntity.java:2712`). `Entity.getInputVector` is unchanged. The diagonal witness is documented in `findings/keyboard-diagonal-input-rounding.md`; the vanilla keyboard digital route is covered, while other input-device plumbing remains excluded by product scope.

## Jump and flight

`LocalPlayer.aiStep` retains the jump-to-flight double-press toggle, on-ground jump impulse, fall-flying request, water descent, and vertical ability-flight delta operation order. The sprint section changed (draft finding). `LivingEntity.jumpFromGround` and `getJumpPower` are equal. The `MobEffects.JUMP` → `JUMP_BOOST` references in jump boost and auto-jump are symbol changes: both constants register the same `jump_boost` effect and same safe-fall-distance modifier in this pair.

Auto-jump still requires enabled, nonpositive autoJumpTime, grounded, not on a standing surface, not riding, nonzero input and block jump factor at least one. `updateAutoJump` has the same geometry/math and gates except the effect constant name; block collision shapes and providers for that scan are owned elsewhere. `isMoving` changes from two nonzero-component checks to `lengthSquared() > 0`; for the vanilla keyboard path the vector is zero or normalized, but subnormal/custom vector behavior is not closed here.

## Ordinary land/air travel order

`LivingEntity.travel` retains fluid → fall-flight → air priority. The 1.21.4 local-authority gate encloses its dispatch. In 1.21.5, `LivingEntity.aiStep` gates the travel call with `canSimulateMovement`, which delegates to local-instance authority; the local-player authority overrides match the old local-player true gate. `Player.travel` and `LivingEntity.travelInAir` bodies are equal. The ordinary air helper order remains: find block below; choose ground friction or air factor; relative movement, climbable handling and move; compute gravity/levitation; choose discard-friction or scaled horizontal/vertical movement. Block friction, collision and direct-state providers are external dependencies.

Changed air-helper dependency: `handleRelativeFrictionAndCalculateMovement` replaces a direct current `getInBlockState().is(POWDER_SNOW)` check after movement with `wasInPowderSnow`. The `wasInPowderSnow` latch still rolls from `isInPowderSnow` at Entity tick start in both versions. This branch can affect the 0.2 vertical collision/jump response; the state/query timing and powder-snow collision provider require reconciliation with the assigned block/state lane.
