# 1.21.4 → 1.21.5 ordinary player tick source comparison

## Exact source identity

Both sides are complete, ready Mojmap/Vineflower decompilations from the exact batch recorded in each side's `mojmap.provenance.json`: Gradle `decompileMinecraft --versions=1.21.1,1.21.3,1.21.4,1.21.5 --mappings=mojmap`, Vineflower 1.12.0, Java 25.0.3+9-LTS, mapping I/O 0.9.1. The root is `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft` and is read-only here.

| Side | Ready marker | Client jar SHA-256 | Source manifest SHA-256 | Source count |
| --- | --- | --- | --- | ---: |
| 1.21.4 Mojmap | Ready, `versionId=1.21.4` | `c17c450c6e72cc51297daa57ce38f800aa01cf022b743daa21a0512d326d894e` | `f90b61197928632e061ea877955a19055c92ae6f357c2daf1bc646172c6f51f0` | 5,744 |
| 1.21.5 Mojmap | Ready, `versionId=1.21.5` | `522672ad20b460c02c2e39b6c5035ef6a849af28eb11ab2ac7eb293d395a8c11` | `365cc2d22446ceba0e36f46aa1c95ce4cc31514dbd657505680fb660f3adefd9` | 5,921 |

Readiness, provenance, and per-source manifests agree. Checked file SHA-256 values against each side's `mojmap.sources.sha256`:

| Mojmap source | 1.21.4 SHA-256 | 1.21.5 SHA-256 |
| --- | --- | --- |
| `net/minecraft/client/player/LocalPlayer.java` | `145686ebdc7f0d12a64070309073665eb8695b7e09911a723e86113a77d04611` | `f1fcfed4a938732361e7ad951f93e9b73b02320ee56f0b219e2b3c7acdbfa2ef` |
| `net/minecraft/client/player/ClientInput.java` | `0f2e4d03749ab7495e386af05aa77a0414b5d1c3ef76256db2b514f42cc6e3c4` | `597a44339a99f1bce1b081614c7c2984ca03e255b40e9d247675a31b6f810d78` |
| `net/minecraft/client/player/KeyboardInput.java` | `c885bcc709e445c3ff91f03bf37acf9320e17fc9daf1bd2ba46ba20487f1d9ed` | `d5cb0e93df7f66755172d74e028225012ee33c6e4f0d510a1d8e25ba5497c0a3` |
| `net/minecraft/world/entity/player/Input.java` | `1c0c12af07da1f90651c3a7c4eb19bab6486b6391dcbfdd2926f06e3f36c2f06` | same |
| `net/minecraft/world/entity/player/Player.java` | `c45f41b9784ce50a88a498e84a13edcef0a23e175233d726ed7f90940f19ebc1` | `8fc187f33999db9dfc49251e95e92a17645a50adab16ca0f93f4948209f62036` |
| `net/minecraft/world/entity/LivingEntity.java` | `e62ce650af0a5ac97e4d0a2ba7cad4ba68a8d098525609f8b5b6976a8ab0ae30` | `a8aed863d4fdc515c751dd2878a8bb9c13179228cb8dbb50edf1d19cd5404271` |
| `net/minecraft/world/entity/Entity.java` | `05f18ef2ec0413fc010230407c812a11553eb5123b68d21b5d7b2c0c175698ad` | `fc177733e9cc4b2d5cf2562e5529d0f4e0b9c3690f081fbd58aa9119eb173dc4` |

## Examined slices

* `LocalPlayer.tick`, `serverAiStep` (1.21.4), `applyInput` and its input modifiers (1.21.5), all of `LocalPlayer.aiStep`, sprint helpers and gates, jump-to-fly toggle, Elytra start request, and auto-jump gate/trajectory probe. The tick's network reporting and riding packet paths were read; vehicle movement itself is outside this lane.
* `ClientInput`, `KeyboardInput`, and the shared `Input` record: key capture, impulse construction, movement vector, forward-impulse predicate and synthetic jump. `Input.java` is byte-identical by manifest hash. The input-device conversion is examined as a dependency; input-device plumbing is excluded by project scope.
* `Player.tick`, `Player.aiStep`, `Player.travel`, pose chooser/fallback, pose dimension table and fit query; `LivingEntity.jumpFromGround`, jump power/effect lookup, travel dispatch, ordinary `travelInAir`, and `handleRelativeFrictionAndCalculateMovement`.
* `Entity.getInputVector` and movement authority/pose/dimension entry points; checked the local player authority override and the powder-snow old/new latch fields/reset.

## Terminal slices and disposition

* **Difference drafts:** sprint lifecycle; player horizontal-velocity deadzone; pose priority for coexisting sleep/fall-flight state. See `findings/`.
* **Partial, block dependency open:** `LivingEntity.handleRelativeFrictionAndCalculateMovement` now consults `wasInPowderSnow` rather than the post-move `getInBlockState()`. The branch is reached only on horizontal collision or jumping and when the climbable alternative is false. Determining which powder-snow state/shape is returned at each movement point belongs to the separately assigned block/state-provider lane; no duplicate provider census is included here.
* **Difference draft:** keyboard diagonal normalization precision. The source operations and exact float/double witness are in `findings/keyboard-diagonal-input-rounding.md`; only the normal digital keyboard route is covered. `Input.java` is identical.
* **No travel-order delta found:** `LivingEntity.travelInAir` and `Player.travel` method bodies are equal. Fluid and fall-flight travel implementations are outside the assigned ordinary land/air slice. `LivingEntity.travel` retains fluid → fall-flight → air branch priority; its local-authority check moved to the `aiStep` call site. In the local-player tick, 1.21.4 `LocalPlayer.isEffectiveAi()` returns true, while 1.21.5 `Player.isLocalClientAuthoritative()` delegates to `isLocalPlayer()` and `canSimulateMovement()` uses that authority; this preserves the local-player travel reachability gate. Entity collision response and block friction/shape providers remain other-lane dependencies.
* **Jump effect rename only:** `MobEffects.JUMP` becomes `JUMP_BOOST`, but both sides register the same `jump_boost` holder with the same effect and safe-fall-distance modifier. `getJumpBoostPower` and auto-jump height selection differ by symbol only; this is not recorded as a behavior finding. Ground jump math (`jumpFromGround`, `getJumpPower`) is equal.
* **Pose dimensions themselves:** Player `POSES`, `getDefaultDimensions`, `LivingEntity.getDimensions`, `Entity.setPose`, and `Entity.refreshDimensions` show no dimension formula/table delta. Collision feasibility still depends on the block/entity collision query owned by another source lane.

## Unexamined or out of assigned scope

This lane did not inventory water/lava, fall-flight movement math, passenger/vehicle movement, other entities, block implementations/registrations/tags/shapes, every external movement impulse source, or rendering/health/food/damage behavior. No wiki/product/history sources were read; no implementation, tests, game launch, or runtime work was done.
