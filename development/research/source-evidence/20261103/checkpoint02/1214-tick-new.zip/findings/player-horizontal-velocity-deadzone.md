# Player horizontal velocity deadzone

1.21.4, Mojmap: `1.21.4/mojmap/net/minecraft/world/entity/LivingEntity.java`, `aiStep` (lines 2691–2726).
1.21.5, Mojmap: `1.21.5/mojmap/net/minecraft/world/entity/LivingEntity.java`, `aiStep` (lines 2669–2710).
Difference: for player entity type, 1.21.4 independently sets x and z to zero when `abs(component) < 0.003`. 1.21.5 instead sets both to zero only when `horizontalDistanceSqr() < 9.0E-6`; the non-player branch retains independent component thresholds. Y still uses the same absolute threshold.
Movement meaning: a player with horizontal components x=z=0.0029 loses both components in 1.21.4 but retains both in 1.21.5 because the squared horizontal magnitude is greater than `9.0E-6`. The retained velocity can then enter ordinary travel and displacement on that tick.
