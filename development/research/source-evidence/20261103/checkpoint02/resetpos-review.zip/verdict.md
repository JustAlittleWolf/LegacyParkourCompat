# 1.13.2 → 1.14.4 resetPos / climb witness review

## Immutable verdict

**REJECT this report revision as a valid conditional movement witness.** Reviewed report: `.native-source/20261103/1132-climb-new/climb-resetpos-collision-preserving-witness/report.md`, SHA-256 `e335f9ef4b1d6f34058f5db908fd418aa88c205d451dc376c18f1c47f47206f1`.

The reset/climb/velocity difference is source-supported, and the coordinates produce the stated reset loop outcome. The described shulker/vine world snapshot is not a valid persistent attachment setup as written. This verdict is bound to that report hash; it does not reject a corrected witness.

## Independently verified source path

Exact read-only roots:

- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.13.2/ornithe-feather`, ready marker mapping `feather-gen2-1.13.2+build.2`, source-manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`.
- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.14.4/ornithe-feather`, ready marker mapping `feather-gen2-1.14.4+build.2`, source-manifest SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

Reviewed source SHA-256 values:

| Version | Relative source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.14.4 | `net/minecraft/entity/Entity.java` | `7315a496c195da767de9d4936d3adb6efc3c419dc0f0e95d6f32781b0da1ba55` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeB8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.14.4 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `6c840580285c7c7d4617e895edac82d4eebf8289dd4994e7b593cebeb49b43ef` |
| 1.13.2 | `net/minecraft/block/VineBlock.java` | `54638df0418f19e3e37e343acb17124cf5d1777d789c7dcc75ef64418e9f02ea` |
| 1.14.4 | `net/minecraft/block/VineBlock.java` | `6032f7a16ae3bf2f1ce4d70401086075b9f679fb92a7f6f6de1a3cb7ff4543cd` |
| 1.13.2 | `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` |
| 1.14.4 | `net/minecraft/world/EntityView.java` | `3822844ced53882c52f0523a1bd714baaa3cd9bb9dab38a5e2c53051c7b1590e3` |
| 1.13.2 | `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `35d3f858f7e06c035ee66b74b08420b678665dcdff9e4cf0619d68570966afa5` |
| 1.14.4 | `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `cea369aa7057a6adf8ec84e238458a83fe4762fa0b3ad8b230bdf5531bd1b8c` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.14.4 | `net/minecraft/block/shape/VoxelShape.java` | `8efb68bf9d5efdb0ec48e401d1852e90458c7094f8fa0c8e9ae418f268c40fdd` |

Source findings:

1. Both `Entity.resetPos()` loops test `0 < y < 256`, call `setPosition` (which synchronizes stored position and box), and increment only stored `y` after a failed collision probe. At input y=254, the two probes use boxes with minY 254 and 255; after both fail, stored y is 256 while the box remains minY 255. Both worlds treat Y=256 as outside build height and return `VOID_AIR`.
2. `Entity.baseTick()` snapshots `lastX/Y/Z` but does not resynchronize position and box. Neither compared `PlayerEntity.tick()` nor `LocalClientPlayerEntity.tick()` calls `setPosition` before the movement consumer. The next tick therefore still presents `y=256` and box minY 255 to the paired climb consumers.
3. 1.13.2 `LivingEntity.isClimbing()` floors `getShape().minY`; 1.14.4 `m_83221421()` constructs `BlockPos(this)` from stored position. On the stated vine coordinate, the old query sees block Y=255 and the new query reads Y=256.
4. The paired velocity packet handlers divide each integer component by `8000.0` and call `lerpVelocity`; paired entity methods store the values directly. A packet `(-2400,0,0)` reaches the next movement path as X velocity -0.3. The dry non-flying path checks/clamps for climbing before calling self `Entity.move`, yielding -0.15 in 1.13.2 and preserving -0.3 in 1.14.4 when the new predicate reads outside-height air.
5. The 1.13.2 and 1.14.4 shulker type dimensions are 1×1 and `getCollisionShape()` returns the live entity box. Both entity-collision streams include intersecting entity collision shapes, so a correctly placed shulker box can make both reset probes fail.
6. For the report's player box X range `[0.2,0.8]`, a closed shulker box at X `[0,1]` does not reduce either requested negative-X displacement. However, the report's explanation that no occupied voxel lies before player minX=0.2 is inaccurate: the shulker voxel spans X `[0,1]`. The negative-axis distance loop examines the overlapping voxel but computes its near edge offset as `1 - 0.2 = 0.8`, which is positive and does not constrain a negative request. The full -0.15/-0.3 displacements and resulting player centers 0.35/0.20 remain consistent with this geometry.

## Rejection gates and correction path

- `VineBlock.canBePlaced` requires at least one supported face. `VineBlock.canSurvive` checks an adjacent full face (1.13.2 lines 102–123; 1.14.4 lines 91–113). The report states no solid support for vine `(0,255,0)`, so this is not an established valid stable vine state.
- A shulker at `(.5,255,.5)` has block position `(0,255,0)`, the same cell as the vine. Its tick reads that non-air state and calls `tryTeleport()` (1.13.2 lines 177–210; 1.14.4 lines 183–216). Thus the report does not establish a fixed attached shulker collision through the next tick. It also omits the solid block required on the shulker's attached face.
- Preserve the reset/climb geometry only with an exact, valid entity/block snapshot. The vine needs a supported face; the shulker needs an air block at its stored position and a solid attach-face neighbor. Any relocated entity or added support block changes the collision set and must be rechecked against both reset probes, the player's post-reset box, the complete negative-X collision query, and tick order before the revised report can be accepted.

No product, wiki, backlog or Git history was consulted. No source tree was written or regenerated. No build, test, gameplay launch or runtime validation was performed.
