# 1.21.4 → 1.21.5 block shape-provider coverage

## Inputs

Canonical sources were read from `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap`. Both `mojmap.ready.json` files say `ready`, identify their exact version, and report successful `decompileMinecraft` output. Provenance files identify one 1.21.1/1.21.3/1.21.4/1.21.5 Mojmap batch, Vineflower, Java 25, and the mapping/decompiler tool versions.

| Release | Source-manifest SHA-256 | Client artifact SHA-256 |
| --- | --- | --- |
| 1.21.4 | `f90b61197928632e061ea877955a19055c92ae6f357c2daf1bc646172c6f51f0` | `c17c450c6e72cc51297daa57ce38f800aa01cf022b743daa21a0512d326d894e` |
| 1.21.5 | `365cc2d22446ceba0e36f46aa1c95ce4cc31514dbd657505680fb660f3adefd9` | `522672ad20b460c02c2e39b6c5035ef6a849af28eb11ab2ac7eb293d395a8c11` |

## Paired inventory

`provider-and-writer-inventory.csv` is the line-addressed inventory of paired `world/level/block/*.java` files. It records shape-provider, shape-state callback, placement/fluid accessor declarations and waterlogged state-write locations on both sides. Query scope was direct block declarations of `getShape`, `getCollisionShape`, `getBlockSupportShape`, `getVisualShape`, `getInteractionShape`, `getOcclusionShape`, and `getEntityInsideCollisionShape`, plus `updateShape`, `neighborChanged`, related neighbor update methods and waterlogged writers.

There are 130 shared block classes with at least one direct shape-provider declaration on both sides. Direct declaration search found 171 shape-provider declarations in 132 classes in 1.21.4 and 176 in 137 classes in 1.21.5. New direct-provider declarations include the shared `BushBlock` helper and 1.21.5 classes such as `FlowerBedBlock`, `DryVegetationBlock`, `LeafLitterBlock`, and dry-grass blocks. The 1.21.4-only declarations include `PinkPetalsBlock` and `DeadBushBlock`; the same registered `PINK_PETALS` and `DEAD_BUSH` identifiers now construct `FlowerBedBlock` and `DryVegetationBlock`. Both affected registrations use `.noCollission()`, so their outline-only shape changes do not yield player collision. Registration and inheritance still need to be considered before treating any relocated method as a movement delta.

`BlockBehaviour` dispatch is unchanged for ordinary collision: default `getShape` returns `Shapes.block()`, default `getCollisionShape` returns the state's outline when `hasCollision` and empty otherwise, and `BlockState.getCollisionShape` uses cached empty-context collision shape or calls the block with the supplied collision context. `Block.getShapeForEachState(Function)` changes from an immutable state-to-shape map to a function backed by the same map. Its new property-filtering overload precomputes states with selected properties fixed at their first values, then normalizes those properties before lookup. The 1.21.5 call sites found by search are inventoried in the CSV; uses of this overload pass properties intentionally omitted from the shape formula, including `WATERLOGGED` for `WallBlock`/`MultifaceBlock` and `POWERED` for `LeverBlock`.

Direct neighbor shape-state inputs include the recomputed facing/side state used by fences, gates, panes, walls, rails, stairs, doors/trapdoors, and multi-face blocks. Their provider and `updateShape` declarations, plus the `WATERLOGGED` write locations, are indexed per class in the CSV. The waterlogged property occurs in 59 block-source files at both endpoints. The writer search found 104 state-write/copy references in 1.21.4 and 102 in 1.21.5; the count difference is the removal of the two duplicate `WATERLOGGED` variants from `WallBlock`'s precomputed shape map, now handled by the property-filtered shape cache. Direct placement/default/update writes remain represented by the paired line inventory. `SimpleWaterloggedBlock` remains the shared fluid writer; generic bucket interactions and world-state production are inventoried, not emulated.

## Movement-relevant provider finding

The candidate source difference is in `PowderSnowBlock`'s inside-contact provider, recorded separately in `findings/powder-snow-inside-contact-shape.md`. In 1.21.4 `BlockBehaviour` supplies a full-block inside-contact shape and Powder Snow inherits it. In 1.21.5 the entity-inside path passes the moving entity and Powder Snow returns that entity's collision shape, falling back to a full block only when that shape is empty. For fall distance greater than 2.5, that provider is `Shapes.box(0.0, 0.0, 0.0, 1.0, 0.9F, 1.0)`, so the inside-contact gate can delay `entityInside` (which applies `makeStuckInBlock`) while a falling player crosses the upper roughly tenth of the block. `PowderSnowBlock` remains registered with collision enabled at both endpoints. The precise tick-level trajectory is not verified here.

Other directly compared apparent collision-method changes include a placement-context guard in `ScaffoldingBlock`/`PowderSnowBlock` and an upper-half branch rewrite in `PitcherCropBlock`. The former is placement-context-only; `PitcherCropBlock` is registered `.noCollission()` at both endpoints, so its inherited upper-half collision is empty on both sides. These are not movement findings.

## Limits / next bounded action

This is not a pair freeze or independent coverage audit. The inventory does not establish exact geometric equivalence of every 1.21.5 shape-table reconstruction against its 1.21.4 constants, nor exhaustively close all block registrations, neighbor-state producers, direct player state predicates, or inherited providers. The broad refactor candidates needing geometric trace include stair, wall, fence/gate, cross-collision, multiface, cached orientation/age shapes, and vegetation replacements. Retain the Powder Snow item as a source-supported candidate for independent review and exact movement-route parity work.
