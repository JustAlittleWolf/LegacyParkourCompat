# Contained and waterlogged block-state writer inventory

The paired `provider-and-writer-inventory.csv` records every direct source occurrence matching `WATERLOGGED` plus state-writing forms (`setValue(WATERLOGGED, ...)`, property-qualified equivalents and `copyWaterloggedFrom`/`withWater`). The property occurs in the same 59 block source files in both endpoint trees. The file contains each occurrence's line for manual trace to its enclosing constructor, placement, neighbor update, or fluid method.

Writer groups found in the paired source:

| Writer route | Examples | Movement relevance |
| --- | --- | --- |
| Default state/property definition | `AmethystClusterBlock`, `FenceBlock`, `StairBlock`, `SlabBlock`, rails, `LeavesBlock`, waterlogged plants | Defines legal vanilla state combinations; keep vanilla state behavior. |
| Placement state from clicked-position fluid | `getStateForPlacement` in signs, lantern, chain, stairs, slab, rail, coral, etc.; generic `DoublePlantBlock.copyWaterloggedFrom` | Player placement/state production is not a historical movement hook. The resulting state can select a later vanilla shape. |
| Neighbor/scheduled shape update | `updateShape` in waterlogged shape families; state-property neighbor updates in `FenceBlock`, `WallBlock`, `StairBlock`, rails, multiface blocks | Indexed because state changes can select another collision provider; do not emulate the block-state writer under the keep-vanilla-block-states invariant. |
| Bucket fluid writers | `SimpleWaterloggedBlock.placeLiquid` / `pickupBlock`; overrides in `BarrierBlock`, `SlabBlock`, `SeagrassBlock`, etc. | Interaction and block-state production; outside movement emulation. |
| Fluid reads | `getFluidState` methods and the `SimpleWaterloggedBlock` path | Indirect shape/state dependency; movement consumers must use the unchanged vanilla state. |

`SimpleWaterloggedBlock` has the shared direct fluid insertion/removal operations on both sides. Placement signatures in some implementations migrate from `Player` to `LivingEntity`; those are interaction APIs, not changed waterlogged shape providers. The state write occurrences are indexed in the CSV.

One paired state-producer change surfaced while checking neighbor dependencies: `MultifaceBlock.updateShape` returns `Blocks.AIR.defaultBlockState()` in 1.21.5 when the last face is removed, where 1.21.4 returns `getFluidState(state).createLegacyBlock()`. This changes what the world state producer leaves behind, and is excluded from movement emulation. The new shape cache also fixes `WATERLOGGED` to a canonical value while caching `MultifaceBlock` geometry; the geometry formula only reads the face properties, so this is a cache-key reduction, not a waterlogged-dependent shape.

`WallBlock` likewise removes the duplicate cached entries for `WATERLOGGED=false/true`; the new function cache normalizes `WATERLOGGED` and computes the same formula from wall-side properties. Its placement, waterlogged defaults, and neighbor-derived connection properties remain visible as separate CSV entries. No waterlogged property is rewritten by historical movement code in this assignment.
