# Piston movement bypasses stuck multiplier
1.21.8, Mojmap: `net/minecraft/world/entity/Entity.java`, `move(MoverType, Vec3)` (663 onward), branch guarded by `stuckSpeedMultiplier.lengthSqr() > 1.0E-7` (around 680).
1.21.9 and 1.21.10, Mojmap: `Entity.java`, `move(MoverType, Vec3)` (670 onward), same branch (around 687).
Difference: 1.21.8 multiplies the requested movement vector by `stuckSpeedMultiplier` for every mover type before clearing that multiplier and setting delta movement to zero. From 1.21.9, the multiplication is skipped when `MoverType.PISTON`; clearing the multiplier and zeroing delta movement still occur.
Movement meaning: When a player with a nonzero stuck multiplier receives piston movement, the piston displacement is no longer scaled by that multiplier, though the same branch still clears the multiplier and velocity. This changes the player position response to a piston in the same tick.
