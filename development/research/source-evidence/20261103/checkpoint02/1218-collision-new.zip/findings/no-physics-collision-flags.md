# No-physics movement clears collision flags
1.21.8, Mojmap: `net/minecraft/world/entity/Entity.java`, `move(MoverType, Vec3)` (663), `noPhysics` branch.
1.21.9 and 1.21.10, Mojmap: `Entity.java`, `move(MoverType, Vec3)` (670), `noPhysics` branch.
Difference: In 1.21.8 the `noPhysics` branch only updates position by the requested vector. From 1.21.9, after updating position it also sets `horizontalCollision`, `verticalCollision`, `verticalCollisionBelow` and `minorHorizontalCollision` to false.
Movement meaning: A no-physics player movement leaves no stale collision flags from an earlier colliding move, changing later movement predicates and collision-state responses on that path. The `onGround` field itself is not reset by this branch.
