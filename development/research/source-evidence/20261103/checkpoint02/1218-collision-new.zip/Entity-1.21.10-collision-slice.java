        float $$0 = this.level().getBlockState(this.blockPosition()).getBlock().getJumpFactor();
        float $$1 = this.level().getBlockState(this.getBlockPosBelowThatAffectsMyMovement()).getBlock().getJumpFactor();
        return $$0 == 1.0 ? $$1 : $$0;
    }

    protected float getBlockSpeedFactor() {
        BlockState $$0 = this.level().getBlockState(this.blockPosition());
        float $$1 = $$0.getBlock().getSpeedFactor();
        if (!$$0.is(Blocks.WATER) && !$$0.is(Blocks.BUBBLE_COLUMN)) {
            return $$1 == 1.0 ? this.level().getBlockState(this.getBlockPosBelowThatAffectsMyMovement()).getBlock().getSpeedFactor() : $$1;
        } else {
            return $$1;
        }
    }

    protected Vec3 maybeBackOffFromEdge(Vec3 $$0, MoverType $$1) {
        return $$0;
    }

    protected Vec3 limitPistonMovement(Vec3 $$0) {
        if ($$0.lengthSqr() <= 1.0E-7) {
            return $$0;
        }

        long $$1 = this.level().getGameTime();
        if ($$1 != this.pistonDeltasGameTime) {
            Arrays.fill(this.pistonDeltas, 0.0);
            this.pistonDeltasGameTime = $$1;
        }

        if ($$0.x != 0.0) {
            double $$2 = this.applyPistonMovementRestriction(Direction.Axis.X, $$0.x);
            return Math.abs($$2) <= 1.0E-5F ? Vec3.ZERO : new Vec3($$2, 0.0, 0.0);
        } else if ($$0.y != 0.0) {
            double $$3 = this.applyPistonMovementRestriction(Direction.Axis.Y, $$0.y);
            return Math.abs($$3) <= 1.0E-5F ? Vec3.ZERO : new Vec3(0.0, $$3, 0.0);
        } else if ($$0.z != 0.0) {
            double $$4 = this.applyPistonMovementRestriction(Direction.Axis.Z, $$0.z);
            return Math.abs($$4) <= 1.0E-5F ? Vec3.ZERO : new Vec3(0.0, 0.0, $$4);
        } else {
            return Vec3.ZERO;
        }
    }

    private double applyPistonMovementRestriction(Direction.Axis $$0, double $$1) {
        int $$2 = $$0.ordinal();
        double $$3 = Mth.clamp($$1 + this.pistonDeltas[$$2], -0.51, 0.51);
        $$1 = $$3 - this.pistonDeltas[$$2];
        this.pistonDeltas[$$2] = $$3;
        return $$1;
    }

    public double getAvailableSpaceBelow(double $$0) {
        AABB $$1 = this.getBoundingBox();
        AABB $$2 = $$1.setMinY($$1.minY - $$0).setMaxY($$1.minY);
        List<VoxelShape> $$3 = collectAllColliders(this, this.level, $$2);
        return $$3.isEmpty() ? $$0 : -Shapes.collide(Direction.Axis.Y, $$1, $$3, -$$0);
    }

    private Vec3 collide(Vec3 $$0) {
        AABB $$1 = this.getBoundingBox();
        List<VoxelShape> $$2 = this.level().getEntityCollisions(this, $$1.expandTowards($$0));
        Vec3 $$3 = $$0.lengthSqr() == 0.0 ? $$0 : collideBoundingBox(this, $$0, $$1, this.level(), $$2);
        boolean $$4 = $$0.x != $$3.x;
        boolean $$5 = $$0.y != $$3.y;
        boolean $$6 = $$0.z != $$3.z;
        boolean $$7 = $$5 && $$0.y < 0.0;
        if (this.maxUpStep() > 0.0F && ($$7 || this.onGround()) && ($$4 || $$6)) {
            AABB $$8 = $$7 ? $$1.move(0.0, $$3.y, 0.0) : $$1;
            AABB $$9 = $$8.expandTowards($$0.x, this.maxUpStep(), $$0.z);
            if (!$$7) {
                $$9 = $$9.expandTowards(0.0, -1.0E-5F, 0.0);
            }

            List<VoxelShape> $$10 = collectColliders(this, this.level, $$2, $$9);
            float $$11 = (float)$$3.y;
            float[] $$12 = collectCandidateStepUpHeights($$8, $$10, this.maxUpStep(), $$11);

            for (float $$13 : $$12) {
                Vec3 $$14 = collideWithShapes(new Vec3($$0.x, $$13, $$0.z), $$8, $$10);
                if ($$14.horizontalDistanceSqr() > $$3.horizontalDistanceSqr()) {
                    double $$15 = $$1.minY - $$8.minY;
                    return $$14.subtract(0.0, $$15, 0.0);
                }
            }
        }

        return $$3;
    }

    private static float[] collectCandidateStepUpHeights(AABB $$0, List<VoxelShape> $$1, float $$2, float $$3) {
        FloatSet $$4 = new FloatArraySet(4);

        for (VoxelShape $$5 : $$1) {
            for (double $$7 : $$5.getCoords(Direction.Axis.Y)) {
                float $$8 = (float)($$7 - $$0.minY);
                if (!($$8 < 0.0F) && $$8 != $$3) {
                    if ($$8 > $$2) {
                        break;
                    }

                    $$4.add($$8);
                }
            }
        }

        float[] $$9 = $$4.toFloatArray();
        FloatArrays.unstableSort($$9);
        return $$9;
    }

    public static Vec3 collideBoundingBox(@Nullable Entity $$0, Vec3 $$1, AABB $$2, Level $$3, List<VoxelShape> $$4) {
        List<VoxelShape> $$5 = collectColliders($$0, $$3, $$4, $$2.expandTowards($$1));
        return collideWithShapes($$1, $$2, $$5);
    }

    public static List<VoxelShape> collectAllColliders(@Nullable Entity $$0, Level $$1, AABB $$2) {
        List<VoxelShape> $$3 = $$1.getEntityCollisions($$0, $$2);
        return collectColliders($$0, $$1, $$3, $$2);
    }

    private static List<VoxelShape> collectColliders(@Nullable Entity $$0, Level $$1, List<VoxelShape> $$2, AABB $$3) {
        Builder<VoxelShape> $$4 = ImmutableList.builderWithExpectedSize($$2.size() + 1);
        if (!$$2.isEmpty()) {
            $$4.addAll($$2);
        }

        WorldBorder $$5 = $$1.getWorldBorder();
        boolean $$6 = $$0 != null && $$5.isInsideCloseToBorder($$0, $$3);
        if ($$6) {
            $$4.add($$5.getCollisionShape());
        }

        $$4.addAll($$1.getBlockCollisions($$0, $$3));
        return $$4.build();
    }

    private static Vec3 collideWithShapes(Vec3 $$0, AABB $$1, List<VoxelShape> $$2) {
        if ($$2.isEmpty()) {
            return $$0;
        }

        Vec3 $$3 = Vec3.ZERO;

        for (Direction.Axis $$4 : Direction.axisStepOrder($$0)) {
            double $$5 = $$0.get($$4);
            if ($$5 != 0.0) {
                double $$6 = Shapes.collide($$4, $$1.move($$3), $$2, $$5);
                $$3 = $$3.with($$4, $$6);
            }
        }

        return $$3;
    }

    protected float nextStep() {
        return (int)this.moveDist + 1;
    }

    protected SoundEvent getSwimSound() {
        return SoundEvents.GENERIC_SWIM;
    }

    protected SoundEvent getSwimSplashSound() {
        return SoundEvents.GENERIC_SPLASH;
    }

    protected SoundEvent getSwimHighSpeedSplashSound() {
        return SoundEvents.GENERIC_SPLASH;
    }

    private void checkInsideBlocks(List<Entity.Movement> $$0, InsideBlockEffectApplier.StepBasedCollector $$1) {
        if (this.isAffectedByBlocks()) {
            LongSet $$2 = this.visitedBlocks;

            for (Entity.Movement $$3 : $$0) {
                Vec3 $$4 = $$3.from;
                Vec3 $$5 = $$3.to().subtract($$3.from());
                int $$6 = 16;
                if ($$3.axisDependentOriginalMovement().isPresent() && $$5.lengthSqr() > 0.0) {
                    for (Direction.Axis $$7 : Direction.axisStepOrder((Vec3)$$3.axisDependentOriginalMovement().get())) {
                        double $$8 = $$5.get($$7);
                        if ($$8 != 0.0) {
                            Vec3 $$9 = $$4.relative($$7.getPositive(), $$8);
                            $$6 -= this.checkInsideBlocks($$4, $$9, $$1, $$2, $$6);
                            $$4 = $$9;
                        }
                    }
                } else {
                    $$6 -= this.checkInsideBlocks($$3.from(), $$3.to(), $$1, $$2, 16);
                }

                if ($$6 <= 0) {
                    this.checkInsideBlocks($$3.to(), $$3.to(), $$1, $$2, 1);
                }
            }

            $$2.clear();
        }
    }

    private int checkInsideBlocks(Vec3 $$0, Vec3 $$1, InsideBlockEffectApplier.StepBasedCollector $$2, LongSet $$3, int $$4) {
        AABB $$5 = this.makeBoundingBox($$1).deflate(1.0E-5F);
        boolean $$6 = $$0.distanceToSqr($$1) > Mth.square(0.9999900000002526);
        boolean $$8 = this.level instanceof ServerLevel $$7
