# 1.21.5–1.21.8 resource and tag movement slice

Scope: neighboring block predicates, tag keys and consumers, vanilla block-state registrations, resource tag defaults, and their movement-relevant dependencies. This is a bounded S5.4 slice, not a complete pair freeze.

## Source identities

All four source trees are Mojmap/official-mapped sources under the canonical read-only `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft` publication. Exact client SHA-256 values recorded by the source publication are:

| Release | Client SHA-256 | Source publication evidence |
| --- | --- | --- |
| 1.21.5 | `522672ad20b460c02c2e39b6c5035ef6a849af28eb11ab2ac7eb293d395a8c11` | `1.21.5/mojmap.ready.json`, `mojmap.sources.sha256` |
| 1.21.6 | `9592df8587d6d3ec0334c873ad432dc76006d6129afdce9a7eac52638339a24a` | `1.21.6/mojmap/.decompile-provenance.json` |
| 1.21.7 | `6d0aa64c6a0aee3270253317f51e9e816f94cd3b16b44f5d605615c39fc62fb9` | `1.21.7/mojmap/.decompile-provenance.json` |
| 1.21.8 | `ea74e9c5e92d01f95f3d39196ddb734e19a077a58b4c433c34109487d600276f` | `1.21.8/mojmap.ready.json`, `mojmap.sources.sha256` |

For 1.21.6 and 1.21.7, the provenance source maps both record the same SHA-256 for `net/minecraft/world/entity/Entity.java` (`c403e6176d27b5bfd6aaa0dea3735ffa4fcf80dbae58766661dd84453b7e9704`). The adjacent exact Mojang client mapping files are separately pinned in their provenance (`client.txt` hashes `2ff82b34ce5f849aaafdff51e23b9448c4263881238b780a441fe1061a6fc261` and `328f2c5849c7c5fc4f2b1eae4f74a7cfe6bb337c7938242ac5c4f9eac89b1e50`).

## Compared slices and result

| Boundary | Checked movement dependencies | Result |
| --- | --- | --- |
| 1.21.5 → 1.21.6 | `world/entity/Entity.java`: `move`, block-speed factor, collision/inside-block traversal, climbable and fluid queries; `LivingEntity.java`: travel, jump, fluid response, block-speed factor; `client/player/LocalPlayer.java`; block/tag consumers and movement block registrations | No changed movement math or effective movement tag predicate found. `Entity.move` contains local-variable renaming and a new horizontal-collision movement-emission/sound side effect; inspected collision, fall, block-speed and clipping operations retain their order and expressions. `checkSlowFallDistance` is renamed to `checkFallDistanceAccumulation`; this is fall-distance bookkeeping, not a tag/resource dependency. `LocalPlayer` changes in this comparison concern input packet representation and UI/sound additions. |
| 1.21.6 → 1.21.7 | Same movement callers/dependencies; tag defaults in all `data/minecraft/tags/**/*.json` entries inside the exact client jars | No movement source changes in the checked classes. Of 589 vanilla tag JSON entries on each side, only `data/minecraft/tags/painting_variant/placeable.json` differs (painting variants; rendering/placement content, no player movement predicate). |
| 1.21.7 → 1.21.8 | Same movement source and block/tag declaration slices | No movement-source delta in the checked classes or movement-relevant block classes. Exact 1.21.8 client resource archive was not present in the canonical cache, so resource-default equivalence for this boundary is unverified. |

Between 1.21.5 and 1.21.6, tag declaration identifiers change as follows:

| Tag family | Added | Removed/renamed |
| --- | --- | --- |
| `BlockTags` | `happy_ghast_avoids`; `triggers_ambient_desert_sand_block_sounds`; `triggers_ambient_desert_dry_vegetation_block_sounds`; `triggers_ambient_dried_ghast_block_sounds` | `plays_ambient_desert_block_sounds` |
| `EntityTypeTags` | `can_equip_harness`; `followable_friendly_mobs` | — |
| `FluidTags`, `ItemTags` | — | — |

The new block tags are consumed by Happy Ghast avoidance and ambient-block-sound logic; the entity tags are consumed by harness eligibility and friendly-mob sensing. Those consumers do not influence the local player's movement predicates or state. The renamed desert tag is likewise used for ambient sound. Existing movement predicates such as `BlockTags.CLIMBABLE`, `FENCES`, and `WALLS`, plus water/lava `FluidTags`, retain their IDs and use sites in the checked slices. Tag declaration order changes do not change the tag keys' string IDs.

Checked vanilla block registration/source candidates included `Blocks.java`, `BlockTypes.java`, `Block.java`, `BlockBehaviour.java`, `BlockState.java`, `BlockStateBase.java`, and neighboring block implementation classes. The 1.21.5 → 1.21.6 set of changed block classes is limited to cauldrons, rails, dry vegetation/signs, portals, sand, sculk spreader, test blocks and supporting registration/type/sound files; movement-relevant slipperiness, friction, climbable, collision-shape and fluid block registrations inspected in `Blocks.java` are unchanged. No block implementation class changed from 1.21.6 → 1.21.7 or 1.21.7 → 1.21.8.

## Evidence limits and residuals

- The exact 1.21.6 and 1.21.7 `client.jar` files are available locally and have pinned source-publication identities; their full default-tag comparison was performed directly from those archives.
- The exact 1.21.5 and 1.21.8 publication source manifests and decompilation identities are present, but their client resource jars were not present in the canonical cache. Therefore, tag membership/default-resource equivalence for 1.21.5 → 1.21.6 and 1.21.7 → 1.21.8 remains open. Java tag-provider source was inspected where available, but that does not substitute for the exact packaged resource comparison.
- This slice does not close other tick paths, every tag consumer, or the complete 1.21.5–1.21.8 pair inventory. No complete-pair freeze is claimed.
