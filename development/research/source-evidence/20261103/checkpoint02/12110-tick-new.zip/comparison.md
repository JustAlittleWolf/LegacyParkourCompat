# 1.21.10 to 1.21.11 LocalPlayer tick/input comparison

Source identity: exact pair `1.21.10` → `1.21.11`, Mojmap, Vineflower, Java 25; both source sets were emitted by the same recorded `decompileMinecraft` run (`1.21.8,1.21.10,1.21.11`, Mojmap; staging batch `mojmap-1.21.8-to-1.21.11-9a8c76419cd14660b88f9fc90225e127`). Provenance records are `decompiled_minecraft/<version>/mojmap.provenance.json`; ready records identify source manifest SHA-256 `4be26049350c1b314a0b198022cb1e7ab1e745e104047de7a5c7d099a9d7b7e1` (1.21.10) and `0c4d83fef84c101d9db88f331acec7960f3c8346228c28995e6cf57bbfcae555` (1.21.11). The cited LocalPlayer, ClientInput, KeyboardInput, Player and LivingEntity files were individually SHA-256 checked against their respective `mojmap.sources.sha256` manifests.

## Item-use movement input speed

1.21.10, Mojmap: `net/minecraft/client/player/LocalPlayer.java`, `applyInput`/`modifyInput`, lines 612–643. For a nonempty movement vector, `modifyInput` scales it by `0.98F`, then when using an item and not riding scales by hard-coded `0.2F`; crouch speed scaling and square-movement normalization follow.

1.21.11, Mojmap: same file, `applyInput`/`modifyInput`, lines 653–684; `itemUseSpeedMultiplier`, lines 530–532. The same sequence now multiplies by the active stack's `USE_EFFECTS.speedMultiplier()` (default `0.2F`) instead of fixed `0.2F`.

Difference: the item-use factor is data-driven per used stack, still applied after `0.98F` and before crouch speed and square-movement normalization. For a forward-moving local player using an item with a multiplier other than `0.2F`, movement input magnitude differs before travel; e.g. multiplier `1.0F` leaves the pre-crouch factor at `0.98F` instead of `0.196F`. Riding skips this item-use scaling in both versions.

Applicability closure: no older vanilla item has a different value. 1.21.11's `DataComponents.COMMON_ITEM_COMPONENTS` supplies `UseEffects.DEFAULT` (`canSprint=false`, `speedMultiplier=0.2F`) to ordinary items. The only vanilla override found is `Item.Properties.spear`, which assigns `new UseEffects(true, false, 1.0F)`; its seven `*_SPEAR` registrations occur in 1.21.11 `Items.java` lines 1897–1917, with no corresponding item registrations or `USE_EFFECTS` references in 1.21.10. Thus this difference is exercised only by newly introduced spear items and is a modern-only capability for this pair; it is not an eligible historical finding.

## Item-use sprint eligibility

1.21.10, Mojmap: `net/minecraft/client/player/LocalPlayer.java`, `aiStep` line 722, `canStartSprinting` lines 1062–1068, and `modifyInput` lines 627–643. Any active item use resets `sprintTriggerTime` (except the passenger guard for this reset) and `canStartSprinting` rejects all item use.

1.21.11, Mojmap: same file, `isSlowDueToUsingItem` lines 526–528, `aiStep` line 763, `canStartSprinting` lines 1102–1108. The new predicate means item use is sprint-slowing only when `USE_EFFECTS.canSprint()` is false; its default is false (`net/minecraft/world/item/component/UseEffects.java`, `UseEffects.DEFAULT`). The same predicate controls sprint-trigger reset and start eligibility.

Difference: on foot, a player using an item whose `USE_EFFECTS.canSprint()` is true can now initiate/continue sprinting subject to the unchanged forward-input, mobility, food, water, flight and slow-movement gates. In 1.21.10 every item use blocks sprint start. The allowed item-use state is a direct player movement gate.

Applicability closure: the only vanilla item override enabling `canSprint` is the 1.21.11 spear property above. Existing vanilla items resolve to `UseEffects.DEFAULT`, whose `canSprint` value is false, matching 1.21.10's unconditional item-use sprint prohibition. No older vanilla item has a changed sprint permission; this candidate is modern-only for the pair, not an eligible historical finding. Do not use arbitrary modded component data as a witness.

## Checked no-difference slices

- `ClientInput.java` (`tick`, `getMoveVector`, `hasForwardImpulse`, `makeJump`) and `KeyboardInput.java` (`tick`, impulse construction and normalization) have identical paired file hashes and bodies.
- `LocalPlayer.applyInput` still gates on controlled camera, dispatches `modifyInput` on the same vector, copies its x/y into `xxa`/`zza`, and captures jump input; changes are limited to the item-use multiplier above. The fixed `0.98F`, crouch scale and square-movement operation order are unchanged.
- `LocalPlayer.aiStep` crouching conditions and pose-fit calls are unchanged. `Player.updatePlayerPose`, `getDesiredPose`, and `canPlayerFitWithinBlocksAndEntitiesWhen` retain identical bodies (Player.java lines 352–383); `LivingEntity.getDimensions`/`getDefaultDimensions` retain identical bodies (1.21.10 lines 3429–3434; 1.21.11 lines 3561–3566). No pose or dimension delta found in these slices.
- The outer `LocalPlayer.tick` still gates the movement tick on client-loaded state, runs `super.tick()` before sending input/movement, and sends local-player position afterward. The 1.21.11 wrapper additionally calls `tickClientLoadTimeout()` and routes through `hasClientLoaded()`; connection lifecycle behavior was not traced and this is not treated as a movement finding.
- `LocalPlayer.aiStep` flight uses `isAlwaysFlying()` in 1.21.10 and `isSpectator()` in 1.21.11 for force-enable/ground-disable gates. The paired `MultiPlayerGameMode` methods both compare the local mode to `GameType.SPECTATOR`, so these gates are equivalent. 1.21.11 also guards flight toggle while mounted on a non-jumpable vehicle; this mounted-player branch is outside the ordinary on-foot lane and remains unresolved for scope applicability.

## Coverage boundary

Examined: exact paired LocalPlayer outer tick, input scaling/application, jump/autojump input dispatch, sprint initiation and reset, flight/spectator gates, and player pose/dimension selection gates listed above. No independent yaw-relative movement-vector transform was examined because travel/collision owns that slice. S1/S2 terminal areas remain unexamined. This is partial lane coverage only; dependencies beyond the cited item-use component and spectator-mode identity, all yaw-relative/travel/collision paths, and the other pair terminal slices remain open. No pair freeze or independent audit is claimed.
