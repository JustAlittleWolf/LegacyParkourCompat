# 1.21.5–1.21.8 source comparison: ordinary travel slice

## Exact inputs

Canonical read-only source root: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap/`.

All four trees use Mojmap names. The `.6` and `.7` trees have hidden `.decompile-provenance.json` files at their mapping roots; their recorded inputs include the exact version metadata/client jar and client mappings text. Entity/LivingEntity/Player/LocalPlayer source hashes checked against those manifests match the live files. The `.5` and `.8` trees have root provenance and source manifests; their ready markers identify exact IDs 1.21.5 and 1.21.8, Mojmap, Vineflower, and pinned client hashes. All sources were read directly; none were regenerated.

## Compared slice and result

| Player movement slice | Evidence and comparison | Result |
| --- | --- | --- |
| Local-player tick and AI step | `client/player/LocalPlayer.java`: `tick()` differs in .5→.6 only around networking shift state versus sending `ServerboundPlayerInputPacket`; `aiStep()` body hash is identical in all four. `world/entity/player/Player.java`: `tick()`, `aiStep()`, `canSimulateMovement()`, and `isEffectiveAi()` bodies are identical in all four. | No change to local travel math/input consumption found. Network input packet handling changed, but is outside this local movement operation. |
| Jump | `LivingEntity.jumpFromGround()` and `jumpInLiquid(TagKey<Fluid>)`, .5 lines 2173–2211; .6/.7/.8 lines 2205–2243. Method-body hashes match across all four. | No difference. |
| Gravity and ordinary drag | `Entity.getGravity()`, `Entity.applyGravity()`, and `LivingEntity.travelInAir(Vec3)`; method-body hashes match across all four. | No difference. |
| Water/lava travel and fall-flying | `LivingEntity.travel`, `travelInFluid`, `travelFallFlying`; all method-body hashes match. `travelFlying` is a generic helper newly added in .6, but is excluded from this player lane and is not called by the player path checked here. | Player path unchanged. |
| Relative input, friction and climb | `LivingEntity.handleRelativeFrictionAndCalculateMovement()` and `handleOnClimbable(Vec3)` hashes match across all four. | No difference. |
| Fall-distance accumulation | `Entity.checkSlowFallDistance()` in .5 is renamed `checkFallDistanceAccumulation()` in .6; body hashes match. `LivingEntity.updateFallFlying()` differs only in calling the renamed method. | No numeric change. |
| Collision/edge core | `Entity.collide(Vec3)`, `collideBoundingBox(...)`, `axisStepOrder(Vec3)`, and `maybeBackOffFromEdge(...)` method-body hashes match across all four. `Entity.move(MoverType, Vec3)` changes its movement recording (below), while its collision result still comes from the same `collide(...)` call. | Core clipping math checked here is unchanged. Full collision dependency closure remains partial. |
| Pose/dimensions and abilities | `Entity.setPose`, `getDimensions`, and `refreshDimensions`; `Player.getAbilities`; `LocalPlayer.aiStep`: method-body hashes match across all four. | No difference in checked pose/ability path. |

## Source difference observed

`Entity.move(MoverType, Vec3)` in 1.21.5 (approximately lines 636–733) records each nonzero axis component of the already-collided movement as its own `Movement` segment, ordered by `axisStepOrder`. In 1.21.6–1.21.8 (approximately lines 682–742), it records the resolved vector as one `Movement(from,to,true)` segment. `checkInsideBlocks` then decomposes an axis-independent segment using the same `axisStepOrder` before scanning block/fluid intersections, preserving the ordinary one-move segment order.

The recorder also changes from a list of movement batches to a capped deque. At 100 recorded segments, `addMovementThisTick` merges the first two into one segment with `axisIndependant=false`. For more than 100 movement segments before effects are applied, the merge can make the oldest path segment straight instead of axis-sequential, changing which block/fluid inside callbacks are considered along that sampled path. The source proves this sampling difference; I did not establish a normal player tick that reaches the cap. Treat the movement-callback consequence and player applicability as unresolved rather than as a confirmed trajectory change.

`checkInsideBlocks` is split into a segment wrapper and segment scanner in .6; the scanner's alive check can stop block iteration early. This affects callback scanning after an entity is removed and does not alter the resolved position or velocity in the compared `move` method.

## Ordered coverage and residuals

- Compared exact versions in order: 1.21.5 → 1.21.6 → 1.21.7 → 1.21.8. The inspected movement methods are byte-identical in .6/.7/.8 where stated; `.7` and `.8` do not add a change in these methods.
- Checked no-difference terminal operations: player/local-player outer tick and AI step (with the input-networking note above), jump methods, gravity, ordinary air/fluid/fall-flying travel, friction/input acceleration, climb handling, fall-distance accumulation, pose/dimensions and player abilities.
- Found one source change in movement-segment recording and inside-block/fluid callback traversal. Its ordinary segment order is replayed with the prior axis order; the capped-merge case has unresolved player reachability/applicability.
- Partial: exact travel state writes and thresholds beyond the checked methods; complete `Entity.move` threshold/gate path; step-up and edge cases; supplied collision shapes and their block/state providers; all dependencies of movement callbacks/effects; externally triggered direct player movement responses. No terminal claim for the broader tick/inventory or pair.
- Patch boundary is only established as introduced sometime between 1.21.5 and 1.21.6 for the segment recording change; no stronger patch cutoff is inferred.
