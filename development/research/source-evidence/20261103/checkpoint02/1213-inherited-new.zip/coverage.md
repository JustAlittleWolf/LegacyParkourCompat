# 1.21.3 → 1.21.4 inherited collision-provider census

## Bound and evidence identity

This comparison is limited to the client block collision-shape route from registered block field to runtime block class, inherited `getCollisionShape` / `getShape` implementation, and `LocalPlayer` consumers. It does not freeze the pair or establish runtime parity.

Canonical source root: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`, read-only. Both sides are `mojmap`.

| Version | Provenance and source identity |
|---|---|
| 1.21.3 | `versionId=1.21.3`, `namespace=mojmap`; `.ready` client SHA-256 `25190c556bc56d11070638ccab3b3c6efd76bb9684c92a2680a4de01c3c7138b`; source-manifest SHA-256 `d673bb5464853e3a2a92ed9b1ffe1789d4e62c097bb884f67c336fcbb3b178ce`; artifact-manifest SHA-256 `0587668e5c70bb06dacf3496a4442f66dc9cdcab23f2350b844f14259cc40dcf`. |
| 1.21.4 | `versionId=1.21.4`, `namespace=mojmap`; `.ready` client SHA-256 `c17c450c6e72cc51297daa57ce38f800aa01cf022b743daa21a0512d326d894e`; source-manifest SHA-256 `f90b61197928632e061ea877955a19055c92ae6f357c2daf1bc646172c6f51f0`; artifact-manifest SHA-256 `1a0929ca8c88cfe7874f323918dfa3b044964007d3ff0d3943317bdb35caf841`. |

The provenance manifests identify the exact paired run `1.21.1,1.21.3,1.21.4,1.21.5`, Mojmap, Vineflower 1.12.0, and Java 25. The ready-marker source-manifest and artifact-manifest hashes match the actual manifests. A read-only verification hashed every Java source: 1.21.3 has 5,655/5,655 matching entries and 1.21.4 has 5,744/5,744 matching entries, with no missing, extra, or changed-hash files. `Blocks.java`, `Block.java`, `BlockBehaviour.java`, and `LocalPlayer.java` are included in those complete checks. The pinned client artifact SHA is present in each artifact manifest; the cache location recorded by provenance is not present locally, so the original JAR bytes could not be independently re-hashed in this checkout.

Feature eligibility is tracked separately from source identity. The 1.21.3 source registers 1,084 block fields, 23 gated by `FeatureFlags.WINTER_DROP`; `FeatureFlags.DEFAULT_FLAGS` is `VANILLA_SET`, which contains only `VANILLA`. The 1.21.4 registry has 1,095 fields and no Winter Drop gates, adding 11 fields relative to the 1.21.3 registry. Those gated registrations remain in the CSV so the registry census is exhaustive; their historical applicability is not inferred from source presence alone.

## Exhaustive registry and inheritance paths

[`registry-provider-census.csv`](registry-provider-census.csv) has one row for every 1.21.3 `Blocks` registry field (1,084 rows). It records both releases' constructor classes, the full superclass path to the nearest `getShape` and `getCollisionShape` provider, and provider-body SHA-256 values. The census includes the piston subpackage and the `BlockBehaviour` default provider. Every inheritance path resolves to a provider in both versions.

There are 125 distinct old/new `getShape` provider pairs and 23 distinct old/new `getCollisionShape` provider pairs across the 1,084 old-side fields. The two shared registry IDs whose concrete class changes are `CHERRY_LEAVES` (`CherryLeavesBlock` → `ParticleLeavesBlock`) and `PALE_OAK_LEAVES` (`LeavesBlock` → `ParticleLeavesBlock`); each resolves to the same inherited shape and collision providers on both sides.

Body comparison results:

- `getShape`: only `ShulkerBoxBlock#getShape` differs. This overlaps the already bounded Shulker/box source area from the assignment. The remaining provider bodies are hash-identical, including `BlockBehaviour#getShape`.
- `getCollisionShape`: zero differing provider bodies, including `BlockBehaviour#getCollisionShape` and the dynamic piston provider.
- The `VoxelShape` declarations/definitions in provider classes also match, except for no new provider-level field change beyond the already bounded Shulker area.

## Context and terminal callers

No `getShape` or `getCollisionShape` provider body reads a neighboring `BlockState` directly. Neighbor-dependent outlines are carried by block-state properties and their update paths. I compared `updateShape` and `getStateForPlacement` declarations throughout `world/level/block/`; the only changed `updateShape` declarations are `GlowLichenBlock`, `MultifaceBlock`, and `SculkVeinBlock`. Their `getShape` path resolves through `MultifaceBlock`; those registrations use `noCollission()`, so `BlockBehaviour#getCollisionShape` returns the empty shape before using their outline provider. This is outside the collision provider delta. The waterlogged final-face removal behavior is a separate fluid/state-transition candidate and is not accepted or adjudicated in this bounded collision pass.

The only direct `LocalPlayer` shape consumer is `LocalPlayer#updateAutoJump` in both versions (`LocalPlayer.java`, 1.21.3 lines 892–988; 1.21.4 lines 922–1018). Its method-body SHA-256 is identical (`f90bdb8d9803725e49921b8087f97d531d59308974c4eec214b5a8bee5d59fa6`); it contains four `BlockState#getCollisionShape(level, pos, CollisionContext.of(player))` calls and one `level.getCollisions(player, box)` call. Thus all registry collision providers reached by those calls are covered by the CSV; auto-jump call order and gates have no new difference in this slice.

Dynamic dependency closure was checked for the two non-state-only provider paths:

- `MovingPistonBlock#getShape` and `#getCollisionShape` call into the moving-piston block entity path. Their bodies and `PistonMovingBlockEntity#getCollisionShape(BlockGetter, BlockPos)` are hash-identical across the pair. Piston collision work is overlap with the already bounded piston source area from the assignment.
- `ShulkerBoxBlock#getShape` reaches `ShulkerBoxBlockEntity#getBoundingBox`; that dependency differs across the pair and overlaps the already bounded default-scale Shulker/box source area from the assignment. `Block.box` and `Shapes.create` bodies are identical.

## Finding disposition and open gates

No new independent collision-shape finding emerged from this provider census. The changed Shulker provider/dependency is an overlap with the prior bounded slice; the changed Multiface neighbor updater is disabled for collision by `noCollission()` and remains only a separate fluid/state-transition candidate. This work does not audit other tick paths, intermediate release boundaries, or the complete pair inventory; independent coverage review and pair freeze remain open.
