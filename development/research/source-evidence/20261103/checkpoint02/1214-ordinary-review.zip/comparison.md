# Blind ordinary movement claim review: 1.21.4 → 1.21.5

## Source identity and preparation

Read-only sources are at `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{1.21.4,1.21.5}\mojmap\`. Each side's `mojmap.ready.json` identifies the exact release, `mojmap.provenance.json` records the common Mojmap/Vineflower run (Vineflower 1.12.0, Java 25.0.3+9-LTS, mapping I/O 0.9.1), and `mojmap.sources.sha256` matches the selected source files byte-for-byte. Ready IDs and client hashes:

* 1.21.4: client SHA-256 `c17c450c6e72cc51297daa57ce38f800aa01cf022b743daa21a0512d326d894e`; source-manifest SHA-256 `f90b61197928632e061ea877955a19055c92ae6f357c2daf1bc646172c6f51f0`.
* 1.21.5: client SHA-256 `522672ad20b460c02c2e39b6c5035ef6a849af28eb11ab2ac7eb293d395a8c11`; source-manifest SHA-256 `365cc2d22446ceba0e36f46aa1c95ce4cc31514dbd657505680fb660f3adefd9`.

The supplied comparison's source identity and source-file SHA table match these markers and manifests. I did not use wiki/product/history inputs or inspect implementations.

## Independent member roster

* Input creation: `KeyboardInput.tick` → `ClientInput` move-vector semantics. In 1.21.4, `KeyboardInput.tick` fills `Input` key presses and separate `leftImpulse` / `forwardImpulse`; in 1.21.5 it fills a normalized `Vec2` move vector.
* Local-player consumption: 1.21.4 `LocalPlayer.aiStep` calls `input.tick`; `LocalPlayer.serverAiStep` copies input impulses into `xxa` / `zza`. 1.21.5 `LocalPlayer.aiStep` calls `input.tick`; `LivingEntity.aiStep` reaches `LocalPlayer.applyInput`, which runs `modifyInput` and writes `xxa` / `zza` for the controlled camera.
* Player layer: `Player.tick` calls `super.tick` and then `updatePlayerPose`. `Player.travel` is the player-specific movement dispatch above `LivingEntity.travel`.
* Living-entity consumers: `LivingEntity.aiStep` applies the 1.21.4 `0.98F` axis decay and reaches travel; in 1.21.5 it calls `applyInput` and contains the player horizontal deadzone. `LivingEntity.travel` / `travelInAir` consume the axes and velocity. `LivingEntity.setSprinting` applies the sprint movement-speed modifier. `LivingEntity.readAdditionalSaveData` independently restores fall-flight and sleep state in each release.

## Verdicts bound to immutable draft SHA-256

### Local-player sprint lifecycle — `f0bc30c5a89f3f125db2bcab177718e70bc60453893feb659df557201e3cc6e5`

**ACCEPT.** The 1.21.4 `shouldStopSprinting` pre-input gate (LocalPlayer.java:816–822) clears sprint for fall-flight, blindness, slow movement, non-camel passenger, and item use outside underwater movement. In 1.21.5 the active-sprint branch at :736–744 checks separate run/swim predicates at :837–852; run-stop omits fall-flight, slow movement and item use, while `canStartSprinting` at :1065–1074 is separately guarded by `!isSprinting()`. For swimming, 1.21.4 gates the food/forward test with `!onGround && !shift`; 1.21.5 places the insufficient-food test outside that subexpression. The stated source-level outcomes follow when the other stop gates are false and forward impulse remains present. Input attenuation does not itself clear the sprint flag in 1.21.5. This accepts the source claim only; it does not establish end-to-end runtime parity.

### Player horizontal velocity deadzone — `a6aee0952c3ac7dc36761906ae61c922dd3a24a0321d42e5127bb088af3ce326`

**ACCEPT.** 1.21.4 `LivingEntity.aiStep` independently zeros x and z below `0.003` (:2708–2724). 1.21.5 branches on exact player type and zeros both only when horizontal squared magnitude is `< 9.0E-6` (:2686–2709); the non-player component checks and y threshold remain separate. For x=z=0.0029, the old x/z checks zero both; the new squared magnitude is `1.682E-5`, so both are retained. Ordinary movement can then consume the retained velocity subject to the remaining travel gates. This is a source/math witness, not a runtime parity result.

### Player pose priority — `43ff812dd40a001d6874328e9e137d4cb3c7bc2697af0a3f0534c267d31d2903`

**REJECT THIS REVISION; GATE REQUIRED.** Priority order changed as claimed: 1.21.4 tests fall-flight before sleep (`Player.updatePlayerPose`, :434–460), while 1.21.5 `getDesiredPose` chooses sleep before swimming and fall-flight (:465–477). Both readers restore fall-flight and sleep state independently. But the movement witness omits the 1.21.5 desired-pose fit gate: after the initial swimming-fit gate, `updatePlayerPose` accepts the desired pose only if spectator/passenger or `canPlayerFitWithinBlocksAndEntitiesWhen(desired)` succeeds; otherwise it may choose crouching or swimming (:449–461). Revise the witness to require that gate (or the spectator/passenger branch) before claiming the 0.2×0.2 sleep pose. The initial swimming-fit gate alone is insufficient. Collision-provider applicability remains open.

### Keyboard diagonal normalization precision — `3dad70c87b0d5a3bd41aac8bac302e4560aab4b56be7a1d18d486e5b523ee8c3`

**ACCEPT.** 1.21.4 sends `(1,1)` through `LivingEntity.aiStep`'s float `0.98F` decay, then unchanged `Entity.getInputVector` normalizes the resulting vector in double precision. 1.21.5 normalizes the key vector in `Vec2.normalized`, scales by `0.98F`, then performs the square-movement float reciprocal/length sequence in `LocalPlayer.modifyInputSpeedForSquareMovement`; the resulting float component is `0.7071067094802856`, with squared length below one, so unchanged `Entity.getInputVector` does not normalize it. The old double component is `0.7071067811865476`. The source-level digital-keyboard path is valid when the controlled camera is the local player and item-use / slow-movement modifiers are absent. I independently reproduced the float rounding from the stated Java operations; no test or runtime launch was performed. This does not establish runtime parity.
