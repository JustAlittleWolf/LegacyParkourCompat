# Independent claim renewal: 1.16.1 to 1.16.2

This bounded review covers the current 11 non-rain/Riptide draft claims. The `in-rain-riptide-client-movement-gate.md` claim is outside this renewal because it has a fresh separate review. Verdicts below bind to each exact draft SHA-256. They renew the endpoint claim and its stated applicability only; they do not close pair coverage or establish a full-pair freeze.

## Source identity

The canonical inputs are read-only Mojmap trees at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.16.1/mojmap` and `.../1.16.2/mojmap`, with pair source-manifest SHA-256 `76fdd121070c2012f48cbdf5cf0c78490116afc94117c30b0858eedcd6ab9754` and `10d312ca29ee48e25f4727adafb9fcfbd741dcebe81b343d3dcffa071952a7a7`. Those identities match the pair coverage record. I independently rehashed the cited high-impact source files; all matched the pair inventory. Their relevant source identities include:

| Source file | 1.16.1 SHA-256 | 1.16.2 SHA-256 |
|---|---|---|
| `client/player/LocalPlayer.java` | `ee20523adfdb82f3753fa43312af170f34c4f4aa78570631c61bc8c0820dfb8b` | `6011569e766bb1568609147be9aa14e9c08c51948e3d3a60fd066e848f6a8c2b` |
| `world/entity/Entity.java` | `27e3bb01b5d03c09161891e717c16477899768333082e81ebfaac4e525616576` | `f9a9a073fe3105a0aa53d0f21ec72e59084e8d21a14c1cd3be75703865ee2666` |
| `world/entity/LivingEntity.java` | `b6ea2b9b037b79fc3ea6e1f6bcd2c4c1d89d4a96315968a8f247641f6c335f26` | `b5d8a1a3c80f85d5d545b5a777e9e2a915dc002a7e31b5f5ad12bf7e285d7a88` |
| `world/entity/player/Player.java` | `a849960d47bf00a2cddfb6636c78c518532a11967ba08829f19c5ebced08681` | `d2e26589bdb6a20dc914266db06aa48f50811efc792d6e63b3008c9199914960` |
| `client/multiplayer/ClientPacketListener.java` | `466d11a2b628c80e17885a0e85f25fee2ee6a05de33d9e71f309b8bc233a549d` | `4d043b866c970910ef079334b0d506f7bc0f78f679e5225f11a0418bab7a72f9` |
| `client/multiplayer/MultiPlayerGameMode.java` | `6be55796cb04dc2a1c33ddd1aca2c0004070a80555ea2115b73306b83990fec7` | `80d1b28891b33de967cbc26e13acec097fb94091bbc226f92ad5ba2750015b66` |
| `world/level/block/Blocks.java` | `61f18f903f7d96731bbc3cac544a8614f55fddac872dc0b0fee5a53511c313a9` | `3b39d5cc4cd22f146ed3195aa30cbb9fdfca49f63783fabf9924a6ce7795fa12` |
| `world/level/block/ChainBlock.java` | `3f05483f3f4053910f658fb951b93b1dc85022594520bff77aa36ae7d5edfdcb` | `6a7fed55ffa892a3781b64849d9f42fb85a125eeb023a23171bc8880bf67fb6e` |
| `world/level/block/LiquidBlock.java` | `e7b138668f426eaf7c2f89b34dd0448f6ba0eb133963929ebf12d64840f22fb3` | `24f1cfbd036cca77ec99d855a028194ed39f583699ce91bc2a4c61957ff22fb7` |
| `world/level/block/BedBlock.java` | `47fff9ab0073a8970ffd0a0db3120903b43e4246bf0f932687bdee9e6e6de063` | `32cff55596d10fb86bb8bd3fb9769df0df9826b8bd449fd4d70fb4d6f3868ced` |
| `world/entity/vehicle/DismountHelper.java` | `1eba299fa5aac4613ff1331dda00523e1bfa13cef0fe1dc42526909c08dfd3f1` | `c066d3d65a1dd25294159fef4081c341059e32afa49ce474cbcd8718fc1528e8` |
| `world/level/Level.java` | `5f6be38c6b3e11e1ca00a9067f676151d1288f19d8cd817a3bbd1cc91b8eaa19` | `e9a23488863fd43a7d8975efc23f4c7cf4af874554bab5b76eaa2c79f028db80` |
| `world/level/dimension/DimensionType.java` | `afcefce1879cf139294bfd5db3a192049617b176170486635b30964249dc0954` | `e2f87508c846871ce9a302509e5057e925ab242fa0a5c1bb953fb2b8bfb20dac` |
| `network/protocol/game/ClientboundMoveEntityPacket.java` | `7bf671557d36296789f53e8b0b1d576bf946543b0d3388926bebffa2174099ec` | `c787f142b1621edfa211b7293f851171562ca79d32299e76718593052a354db7` |
| `world/level/CollisionSpliterator.java` | `19ab959c469b8edb5c371ff737a59a61b8a80bf397eff1db280064342094d297` | same |

## Independently derived member roster

I filtered the pair's changed-method inventory for changed movement/player tick, direct response, support, collision/provider and helper members, then retained the relevant members and their terminal callers for this bounded claim set:

- Local-player suffocation probes: `LocalPlayer.aiStep`, old `checkInBlock`/`blocked`, new `moveTowardsClosestSpace`/`suffocatesAt`; `Player.freeAt`; `CollisionGetter.noBlockCollision`; `BlockBehaviour.BlockStateBase.isSuffocating`; `Blocks` state predicates.
- Sneak edge and support: `Player.maybeBackOffFromEdge`/`isAboveGround`; `Entity.move`; `LivingEntity.onSoulSpeedBlock`; old `Entity.getBlockStateOn`/`getOnPos`; new `Entity.getBlockPosBelowThatAffectsMyMovement`; `getBlockSpeedFactor`/`tryAddSoulSpeed` consumers.
- Fluids and eye predicates: `Entity.tick`, `checkBlockCollisions`, `updateFluidOnEyes`, `updateInWaterStateAndDoFluidPushing`, `updateFluidHeightAndDoFluidPushing`, `isInLava`; old `LiquidBlock.entityInside`; `LivingEntity.travel`; `Player.tick`/`updateIsUnderwater`; `LocalPlayer.aiStep` sprint gates.
- Wake response: `LivingEntity.stopSleeping`; old/new `BedBlock.findStandUpPosition` helpers; new `DismountHelper.findSafeDismountLocation` path.
- Direct packet and acknowledgement responses: `ClientPacketListener.handleTeleportEntity`/`handleMoveEntity`; `ClientboundMoveEntityPacket` coordinate helpers; `Entity.setPacketCoordinates`, `isControlledByLocalInstance`, interpolation sink; `MultiPlayerGameMode.sendBlockAction`/`handleBlockBreakAck`; `Entity.isColliding`.
- Collision inputs: `ChainBlock` state definition/`getShape`; `BlockBehaviour.getCollisionShape`; chain registration; `Level` border wrapper/center; `DimensionType` coordinate scale; unchanged `CollisionSpliterator.worldBorderCheck`.

This roster is a claim-review roster, not the pair's complete movement inventory or freeze audit.

## Claim verdicts

Verdicts bind to the exact current draft bytes identified by SHA-256. `ACCEPT` means the stated pair delta and conditional player applicability are supported by the paired source and cited route; it does not mean runtime parity has been tested.

| Draft | Immutable claim SHA-256 | Verdict |
|---|---|---|
| `bed-exit-position-and-facing.md` | `3aebfe238895fb8c926d5519506549b845715b3173dd919e5aeae7d22c2a433e` | **ACCEPT**, conditional on waking from a bed. The angle-directed search, safe-dismount gates and position-then-yaw/pitch writes are supported. Server respawn use remains outside the claimed client movement response. |
| `boat-passenger-eye-water-sprint-gate.md` | `a8724e8003c6770685266d34cd275e00ace6a8a9330426d7c0835ebc922307ee` | **ACCEPT**, conditional on the stated boat eye-height/fluid/input state. The horizontal containment check becomes an inclusive vertical-range test; `Player`'s cached underwater update ordering makes this a next-tick local sprint-state input. |
| `chain-collision-axis-shape.md` | `0772c6e57df83624090f26321c3a0f7838afc039de71f91d7ec411f40f83ce6d` | **ACCEPT**, conditional on an X/Z-axis chain state. Registration retains collision; Y shape matches the old rod while horizontal axes use horizontal bars. |
| `client-teleport-near-coordinate-fallback.md` | `05a28ee31bbdb94704cbc3d0dbcbcB4caa52f2173f0c653bc65c0674a9f97447` | **ACCEPT**, conditional on an existing entity admitted by the shared control gate. The old per-axis near-coordinate target fallback is removed and the queued target is the packet position. |
| `dimension-scaled-world-border-collision.md` | `1fd6cae3d8f23f371d98cbf31b1bada7f778a17c5cc49b02b08d90710764c77b` | **ACCEPT**, conditional on a supplied nonstandard coordinate scale and border-adjacent movement. The wrapped center divides by that exact scale; the collision consumer is unchanged. |
| `lava-pushing-in-water.md` | `68cbfcb21722890575bd25c632f9728e3ab6e31df74ef881c8e9dc9f7b9fa208` | **ACCEPT**, conditional on supplied overlapping fluid state. Old callback lava state and water-first return differ from new lava-height sampling before the water return; travel reads the changed lava inputs. The old callback condition is transcribed as shown in the source. |
| `local-player-suffocation-escape.md` | `5bbdaf0cad2f703f945dcafe6d926d5b8cecd4c3afc773fad507b747ee56a589` | **ACCEPT after correction**, conditional on local client tick with physics enabled and the described suffocation/shape state. Review found the original draft overstated which `Blocks` predicates were newly added; see correction below. |
| `rejected-block-action-player-rollback.md` | `941644d0ab9e228e5c5849332e2687b0fc08d791183f813daa247641907825bf` | **ACCEPT**, conditional on a rejected block-action correction with the restored state overlapping the player in the same client level. New rollback is position-only and gated by same-level plus collision intersection. |
| `relative-move-zero-delta-coordinate-retention.md` | `bebfda256500cd1d2e4c7eb4dbb428e6cd089223c9368533aeeacf40d8c6ce03` | **ACCEPT**, conditional on a relative position packet admitted by the common client control gate. Zero-delta axes retain raw stored doubles while old code quantizes all three accumulated coordinates. |
| `sneak-edge-backoff-near-ground.md` | `020f0291b4eccdfb4a88a9bef534e02ac3363c040b6431e4a9c22c7d187b9391` | **ACCEPT**, conditional on sneaking self/player movement, non-flying state, and the new shallow-descent support predicate. The 0.05 clipping loop stays in the same order. |
| `soul-speed-support-position.md` | `7d3d5e78e079076d58a7d6ae5009c26c0666bbdc63ccf89d609be953cc3bdfdf` | **ACCEPT**, conditional on Soul Speed equipment/tag and non-flying state. The Soul Speed lookup changes to the movement-support block position; the helper's offset is preserved. |

## Correction made

The prior suffocation draft said 1.16.2 added suffocation predicates for farmland, soul sand, grass path, shulker boxes and piston states. Exact `Blocks.java` comparison shows the new registrations relevant to this claim are farmland, soul sand and grass path; the shulker-box and piston-state suffocation predicates are already present in 1.16.1. The draft has been corrected to name only the three added families and explicitly mark shulker/piston as pre-existing. Its SHA above binds the corrected claim; the prior draft SHA was `e605f68c1c2ca0cb3174fab01885e77ef8bde0fd9a189c949ff108a4308b8953` and is not accepted as written.

## Reused comparison evidence and limits

I reused prior independent exact-source comparison notes for the unchanged-to-this-review claims after verifying the current source identity hashes above. I did not redo the complete tick/collision/provider graph. Rain/Riptide is excluded from this review and remains bound to its separate fresh review. These per-claim verdicts do not resolve the recorded pair-wide changed-provider census gap, establish full pair freeze, determine intermediate patch cutovers, or assert runtime parity.
