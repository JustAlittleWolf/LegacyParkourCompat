# AutoJump boundary and callback witness follow-up

## Verdict

The first checked exact release with the per-block collision candidate stream is **1.14.1**. Exact 1.14 still has the full-cube `BitSetVoxelSet`/`IntVoxelShape` aggregation; 1.14.1, 1.14.2, 1.14.3, and 1.14.4 use ordered per-block shapes. The three-stone scheduled-state difference is therefore absent at 1.14 and present by 1.14.1. Exact checked boundary: 1.14 → 1.14.1.

The previously reported callback values can be made coherent with the ordinary `ClientPlayerEntity.move` caller. A narrower ordinary movement setup below replaces the initial arbitrary `dx=0.6F` / “forward input” values. It has callback position `x=-0.3`, `dx=+0.03F`, with old X `-0.33`, and positive sideways input at yaw zero. `ClientPlayerEntity.move` snapshots old X, calls `super.move`, and passes `(float)(this.x-oldX)` to AutoJump, so position and delta are consistent. AutoJump uses nonzero measured displacement only as the above-threshold direction; at `0.03F`, its squared length is `0.0009F <= 0.001F`, so the same sideways input correctly supplies the fallback +X direction.

## Exact source comparison

- **1.14** is the previous negative onset point: Ornithe Feather Gen2 `1.14+build.2`; `WorldView.getBlockCollisions` accumulates `VoxelShapes.block()` in `BitSetVoxelSet` and appends `IntVoxelShape` (112–152). The three-stone L therefore gives the merged lower `[0,2]×[0,1]×[0,1]` box and above-center lookup `(1,1,0)`.
- **1.14.1**: Yarn `1.14.1+build.10`; `ViewableWorld.getCollisionShapes(Entity, BoundingBox, Set)` (129–185) enumerates blocks and emits each translated collision shape immediately when it overlaps the query; `CuboidBlockIterator.step` starts at its minimum and increments X, then Y, then Z. AutoJump is `ClientPlayerEntity.method_3148` (846–941), called by `move` (835–839). The first probe-intersecting block candidate is `(0,0,0)`, center floor `(0,0,0)`, then `t=1` reads air at `(0,1,0)` and writes `field_3934 = 1`.
- **1.14.2** has byte-identical `ViewableWorld.java` and `CuboidBlockIterator.java` to 1.14.1 (source hashes below), with the same callback sequence and terminal (`method_3148`, 845–940).
- **1.14.3**: Yarn `1.14.3+build.13`; the per-block provider is now `ViewableWorld.method_20812(Entity, Box)` (133–179), still using the X-first `CuboidBlockIterator`; AutoJump remains `ClientPlayerEntity.method_3148` (845–940) and consumes the same first lower block, above-center air, and scheduling interval.
- **1.14.4** retains per-block ordered candidates: Feather Gen2 `1.14.4+build.2`; `WorldView.getBlockCollisions` (133–180), `C_29205863` cursor (15–57), and `LocalClientPlayerEntity.autoJump` (857–955).

These intermediate checks close the exact onset for this collision-query/output behavior; they do not close the complete 1.13.2–1.14.4 movement pair or unrelated provider branches.

## Ordinary callback witness

Use standing player dimensions `0.6 × 1.8`, movement speed `0.1F`, yaw zero, no jump boost, AutoJump enabled, cooldown `<= 0`, and input sideways `+1` / forward `0` (left input in the 1.14.1 Yarn `KeyboardInput` source). Put full-cube stone at `(0,0,0)`, `(1,0,0)`, `(1,1,0)`, plus one support stone at `(-1,-1,0)`; other nearby cells are air. The support block touches the player from below without overlapping AutoJump's query box (which starts at feet Y=0). The player center starts at `(-0.33,0,0.5)`, with downward velocity, no sneak, and no vehicle. Its AABB has X max `-0.03`, so it begins clear of the obstacle at X=0 while standing over the support.

On an ordinary grounded travel, the `+X` sideways input at yaw zero gives positive X motion. With stone slipperiness `0.6F` and movement speed `0.1F`, `LivingEntity.method_18802` gives `0.1F * 0.21600002F / (0.6F³) ≈ 0.1F`; the horizontal move into the full cube at `(0,0,0)` clips to about `+0.03`. The negative Y request is clipped to zero by the support block, and `Entity.move` sets `onGround = verticalCollision && requestedY < 0`. The post-move callback therefore has current center X `-0.30` and measured `dx=+0.03F` from old X `-0.33`. The body ends touching the obstacle, not inside it. This gives an ordinary reachable callback gate setup; the bounded finding remains about AutoJump's conditional callback output.

AutoJump geometry at that callback:

1. `g=(float)(0.03F²)=0.0009F`, so the `g <= 0.001F` fallback runs. Input sideways `+1`, speed `0.1F`, yaw zero yields fallback vector `(+0.1F,0,0)`; its squared length is `0.01F`. The normalized direction is +X and faces the obstacle (`dot` with yaw-zero horizontal facing is `0`, passing the `m < -0.15F` rejection).
2. With no jump boost, `o=1.2F`; `p=max(speed*7.0F,1/l)=max(0.7F,about 0.1F)=0.7F`. `vec3d2.x=-0.30+0.03=-0.27`, so the endpoint is `-0.27+0.7=0.43`.
3. Width `q=0.6F` gives lateral offsets `±0.3` and probe Z coordinates `0.2` and `0.8`; both raised Y probes are at `0.51`. They intersect the lower stone at X=0 only. The query box expands X by `0.6F` around `[-0.30,0.43]`, reaching X=1.03, so its provider scan includes all three witness stones.
4. In 1.13.2, the extra support full cube at `(-1,-1,0)` decomposes into a separate non-probe-intersecting box; it is edge-diagonal to the L and cannot merge with the lower X row. The first probe hit remains the lower merged box `[0,2]×[0,1]×[0,1]`; center `(1,0.5,0.5)` floors to `(1,0,0)`. At `t=1`, `(1,1,0)` is stone, so `s=2`, `s-minY=2>1.2F`, and AutoJump returns without setting cooldown.
5. In 1.14.1+ the support does not overlap the query box and is not emitted. X-first per-block enumeration first supplies the unit cube at `(0,0,0)`; center `(0.5,0.5,0.5)` floors to `(0,0,0)`. At `t=1`, `(0,1,0)` is air; `u=1` satisfies `0.5F < u <= 1.2F` and schedules the next-tick jump input.

“Schedules” here remains the exact cooldown field write; this does not claim the jump action has already occurred.

## Exact identities and hashes

Canonical read-only roots: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/`. The 1.14.1–1.14.3 `.decompile-provenance.json` files identify exact client jars and pinned Yarn artifacts; each source hash below agrees with its provenance source map.

| Release | Source publication and mapping | Source identity |
|---|---|---|
| 1.14 | exact 1.14, Ornithe Feather Gen2 `1.14+build.2`; manifest SHA-256 `68bc39e38bc501e7c9af315de4678263e1a64606b0b9780099187c7984ccbc98` | Client source identity retained in the preceding immutable review. |
| 1.14.1 | exact 1.14.1, Yarn `1.14.1+build.10`; client jar SHA-256 `7194d1326cf796f62ac55f3cb56f851c232895639ae27510f3207d5a73f91814`; Yarn artifact SHA-256 `f9462af25135abeb22cbdec829cc8618b1a8dd902f17259abfbe7399a222a630` | provenance SHA-256 `308537c5adec3104c5ca243eb5010554f00978635ed74f0d7801c804dd4d4907`; `ViewableWorld.java` `67e88826a77d5ed6dbdf7701acab287bd6b34f1e394625a6a701c1181556fd2e`; `ClientPlayerEntity.java` `6af7e75e80619ad77ce2c84692136b0a1d562a44d0e7910dcc3f6040b2dc9933`; `CuboidBlockIterator.java` `d80701350196f78ee8ffd6083f9d53d53b9734825201a085c6b6e62a459edf1c`. |
| 1.14.2 | exact 1.14.2, Yarn `1.14.2+build.7`; client jar SHA-256 `9b740c9fd4955981125ebd3cd086baa8b4392963d043a3480b5b942a96637c25`; Yarn artifact SHA-256 `3c91c928d10797ba688b1f7e61063fd4bc56a3ee0f66fa2609ef960ec08b239b` | provenance SHA-256 `786546f99684423cc2563be45c9c3334dfcc2c7db58ddb74ba39ce403bd0869a`; same `ViewableWorld.java` and iterator hashes as 1.14.1; `ClientPlayerEntity.java` `90c96701849c9212ea7714f02e7bc9011d0a7d0aaf1f7b46464497ba3ca14947`. |
| 1.14.3 | exact 1.14.3, Yarn `1.14.3+build.13`; client jar SHA-256 `4063062677433988e012fba53e42e4c21adb6919ac7f061f19f3c6e75b334e07`; Yarn artifact SHA-256 `ad9e77f907cfc6780fb348ad4b3a948ffc8cea3bfe50abcc792428645e49e06e` | provenance SHA-256 `81ea0021eb122d4e3340e20d47d6ecb7079365ba767a038d26a8264cddacc28a`; `ViewableWorld.java` `3e6f183c66c98206cef362551c53dbf8ea7ac11e44123060c640da09c944d29d`; `ClientPlayerEntity.java` `28b6b4031e02afd4a2e6b4a80e5a7ca06f16dac42ca0f92cab25e2c2dc9e14ae`; `CuboidBlockIterator.java` `e6116622cce046ec313f2926f7eb78048f59f1b0aaf813a0fd9dc66e6eedde5d`. |
| 1.14.4 | exact 1.14.4, Ornithe Feather Gen2 `1.14.4+build.2`; source manifest SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc` | source file hashes retained in the preceding immutable review. |

## Narrow reviewed locations

- 1.14 `WorldView.getBlockCollisions`: 112–152.
- 1.14.1 and 1.14.2 `ViewableWorld.getCollisionShapes(Entity, BoundingBox, Set)`: 129–185; `CuboidBlockIterator.step`: 26–50.
- 1.14.3 `ViewableWorld.method_20812(Entity, Box)`: 133–179; `CuboidBlockIterator.step`: 26–50.
- 1.14.1 `ClientPlayerEntity.move` / `method_3148`: 835–839 / 846–941; `Input.getMovementInput`: 18–20; `Entity.move` ground write: 462; `LivingEntity.travel` / movement factor: 1763–1843 / 1938–1940; `Entity.movementInputToVelocity`: 1009–1021.
- 1.14.4 `WorldView.getBlockCollisions`: 133–180; `C_29205863` cursor: 15–57; `LocalClientPlayerEntity.move` / `autoJump`: 846–851 / 857–955.

This remains a bounded AutoJump finding and exact onset check. No full-pair inventory or runtime claim is made.

