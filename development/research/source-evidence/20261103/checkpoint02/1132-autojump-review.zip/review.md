# AutoJump three-stone witness independent source review

## Verdict

**Accept, bounded and conditional.** For the stipulated `autoJump` entry values and the shared vanilla state with `STONE` at `(0,0,0)`, `(1,0,0)`, `(1,1,0)` and air elsewhere in the callback's relevant area, source order yields different scheduled-jump state: 1.13.2 and exact 1.14 return before writing `ticksToNextAutojump`; 1.14.4 writes `ticksToNextAutojump = 1`. The difference is caused by 1.13.2's aggregation of base full-cube collision voxels into an `IntVoxelShape` versus the per-block collision candidate stream in 1.14.4, followed by AutoJump's first intersecting box and above-center clearance query.

This accepts only the conditional endpoint callback/output witness. Exact 1.14 is a negative onset check: the same three-stone setup does not schedule there. The source introduction point is unknown within `(1.14, 1.14.4]`. It does not establish that the given callback state is produced by a complete ordinary movement tick, that the player can reach it with all stipulated gates, an actual jump impulse in that tick, or full-pair coverage. “Scheduled jump” means the private cooldown field is set to `1`; the next local-player tick consumes it by setting the input jumping flag.

## Independently derived source route

From the exact 1.13.2 Feather source, the bounded path is `LocalClientPlayerEntity.move` → `super.move` → `autoJump(float,float)` → `WorldView.getCollisions(Entity,Box)` → `WorldView.getBlockCollisions` → (1.13.2) accumulated `BitSetVoxelSet`/`VoxelSet.forEachBox`/`IntVoxelShape`, or (1.14.4) ordered block-collision enumeration; exact 1.14 still uses the aggregate full-cube path → `Box.intersects` first-hit branch → above-center `BlockState.getCollisionShape` → the `ticksToNextAutojump = 1` write. The callback also reads local-player position/shape, input, yaw, speed, jump effect, and world block states. Its later scheduled-state consumer is `LocalClientPlayerEntity.mobTick`.

This roster was derived before consulting prior draft material. The review then read the pending three-stone candidate and its adjacent callback/query reports to check claims and provenance only.

## Witness calculation

Use the candidate's conditional raw callback values: current callback X/Z `(-0.4, 0.5)`, callback displacement `(0.6F, 0.0F)`, feet Y `0`, standing shape minY `0`, width `0.6F`, height `1.8F`, speed `0.1F`, yaw/pitch `0`, nonzero forward input, AutoJump enabled, cooldown `<= 0`, grounded, not sneaking/riding, no jump boost, interior loaded world, and no entity collision candidates. The callback's headroom queries at its feet-position-derived block and the block above see air. These are stipulated source inputs, not a trajectory proof.

The callback's normalized direction is +X. It produces end probe X `0.9`; the raised probe segments at Y `0.51` and Z `0.2`/`0.8` hit the lower stone at `(0,0,0)` but not the stone at `(1,0,0)`; the top stone at `(1,1,0)` is above the probe. The broad query box, extended by the callback's movement/search distance and `0.6` width, contains all three stones.

In 1.13.2, `WorldView.getBlockCollisions` accumulates exact `VoxelShapes.block()` results in a `BitSetVoxelSet` and appends one `IntVoxelShape` after the per-block stream. `VoxelSet.forEachBox` visits the lower `(0,0,0)` cell first and merges its occupied X run through `(1,0,0)` into `[0,2] × [0,1] × [0,1]`; the upper `(1,1,0)` remains a later separate box because `(0,1,0)` is air. The first merged box intersects the probe, has top `s=1`, and center `(1,0.5,0.5)`, converted to `BlockPos(1,0,0)`. Since no jump boost, the `for (t = 1; t < 1.2F; t++)` loop executes only at `t=1`; the above-center query hits stone `(1,1,0)`, raises `s` to `2`, and returns because `s-minY > 1.2F`. No cooldown write occurs.

Exact 1.14 is a checked negative onset point: its `WorldView` still imports `BitSetVoxelSet`, `VoxelSet`, and `IntVoxelShape`; `getBlockCollisions` accumulates exact full cubes and appends the resulting `IntVoxelShape`. The three-stone fixture therefore takes the same merged-box route as 1.13.2: center `(1,0.5,0.5)` floors to `(1,0,0)`, `t=1` clearance hits `(1,1,0)`, raises `s` to `2`, and returns without a cooldown write. The 1.14 local-player terminal is otherwise the same relevant branch. In exact 1.14.4, `C_29205863` advances X before Y before Z and `WorldView.getBlockCollisions` emits per-block translated shapes. The first probe-intersecting candidate is the unit cube at `(0,0,0)`, with top `s=1` and center `(0.5,0.5,0.5)`, converted to `(0,0,0)`. At `t=1`, `(0,1,0)` is air, so `s` remains `1`; rise `u=1` passes the strict interval `u > 0.5F && u <= 1.2F` and schedules `ticksToNextAutojump = 1`. Thus the endpoint behavior difference is present by 1.14.4, but the exact introduction point within `(1.14, 1.14.4]` is not established.

All three stone states use the common full-cube collision shape in the compared base-block implementation. Air's shape is empty. This is a shared provider setup, not a statement about contextual or custom collision providers.

## Exact identities and hashes

Canonical read-only source location: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/`.

- 1.13.2: exact source publication 1.13.2, Ornithe Feather Gen2 `1.13.2+build.2`; source manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`.
- 1.14 onset check: exact source publication 1.14, Ornithe Feather Gen2 `1.14+build.2`; source manifest SHA-256 `68bc39e38bc501e7c9af315de4678263e1a64606b0b9780099187c7984ccbc98`.
- 1.14.4: exact source publication 1.14.4, Ornithe Feather Gen2 `1.14.4+build.2`; source manifest SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`.

| Release | Relevant source file | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.14 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2b1ad3b3416949a9da2607a3ec2251aa69b2d9eebd76638c92e20749d625338f` |
| 1.14.4 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.14 | `net/minecraft/world/WorldView.java` | `1a9d57363b8123e48334065c363c5610e83dd353fe66edc2f08fed3ec09ddcb0` |
| 1.14.4 | `net/minecraft/world/WorldView.java` | `fcdf8dc98f97781f4639c4b8cda8a238edf834f3963e401e6eeef6cb475c4909` |
| 1.13.2 | `net/minecraft/block/shape/VoxelSet.java` | `fe39ea60ac27e595280627a4d15ea93a69292da5870b5ef34a1d7d7283a267c6` |
| 1.14.4 | `net/minecraft/unmapped/C_29205863.java` | `d15373ef21f58ed67755269d32b2dd5ff65eb33dd4eea33e854b505b9ac9afdb` |

Primary member ranges: 1.13.2 `LocalClientPlayerEntity.move` 871–876 and `autoJump` 882–980; 1.14/1.14.4 `move` 846–851 and `autoJump` 857–955; 1.13.2 `WorldView.getBlockCollisions` 112–152; 1.14 `WorldView.getBlockCollisions` 150–195; 1.14.4 `WorldView.getBlockCollisions` 133–180; 1.13.2 `VoxelSet.forEachBox` 200–252; 1.14.4 `C_29205863` iterator 15–57. The exact 1.14 source is a negative onset check: it retains full-cube aggregation and the AutoJump terminal; the endpoint change is not present there.

## Limits

Candidate order remains relevant: the accepted calculation relies on the first probe-intersecting block being `(0,0,0)` in the newer query and the old full-cube set yielding the stated merged box first. The result is scoped to the named bounds, base stone/air providers, and no entity/border candidate. It does not close differing shape-context behavior, missing-chunk behavior, other collision providers, or candidate sets/order generally. No runtime, test, full-pair inventory, or intermediate patch-boundary conclusion was made.



