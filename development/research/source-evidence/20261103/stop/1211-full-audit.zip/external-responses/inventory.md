# Independent inventory: 1.21.1 → 1.21.3 external player responses

## Scope and exact inputs

Three exact source roots, Mojmap:
- `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.21.1\mojmap`
- `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.21.2\mojmap`
- `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.21.3\mojmap`

Inventory formed before consulting any claim projection. Scope is externally triggered direct player position/velocity/rotation responses and vanilla-state predicates; includes client packet correction, server-side player response producers as context, collision response, respawn/carryover, status effects/attributes/equipment, explosion/knockback, fall/flying/flight gates. Excludes vehicle/non-player movement and damage calculation.

## Initial source inventory and coverage states

| Slice | Candidate exact source families (all three releases) | Initial status |
|---|---|---|
| Client authoritative player updates | `client/multiplayer/ClientPacketListener`, `client/player/LocalPlayer`; clientbound move/teleport/respawn/explosion/entity-event packet classes | Partial; inspect handler call order, relative flags, pending teleport, velocity/explosion and respawn paths |
| Player movement state/writers | `world/entity/player/Player`, `world/entity/LivingEntity`, `world/entity/Entity`, `world/entity/PositionMoveRotation`; pose, abilities, attributes/effects | Partial; inspect player-reachable direct response methods and vanilla-state predicates |
| Server-originated player responses | `server/network/ServerGamePacketListenerImpl`, `server/level/ServerPlayer`, packet send call sites | Partial; context only, verify server-produced correction payload and gates |
| Collision response | `Entity` movement/collision/step/shape methods; `world/phys/shapes`, block collision/shape accessors | Partial; inspect player collision response paths and gates, ignore other entity physics |
| Teleport/correction | clientbound player position packet + `ClientPacketListener` / `LocalPlayer`; serverbound movement validation/correction | Partial; inspect correction eligibility, relative flags and direct client mutation |
| Respawn/carryover | clientbound respawn handler, `ServerPlayer` respawn transfer and `Player` copy/state fields | Partial; inspect position/velocity/rotation carryover and effects/abilities |
| Effects and attributes | `LivingEntity` effect add/remove/tick; `AttributeMap`/`AttributeInstance`; movement effect/attribute registries; player equipment modifiers | Partial; inspect only movement-relevant player predicates/modifiers and response changes |
| Explosion and knockback | clientbound explosion packet/listener; `LivingEntity`/`Entity` knockback; player-eligible direct response paths | Partial; inspect exact float/double operations and protection/eligibility gates, exclude damage computation |
| Fall/flying/flight gates | `LivingEntity`, `Player`, `LocalPlayer`, abilities and relevant effect/attribute accessors; server player packet predicates as context | Partial; inspect direct player state predicates that gate movement responses |
| Block/event initiated responses | player collision/contact callbacks, piston/block entity event packet handling, world/client event dispatch | Partial; inspect direct player writers and exact state conditions; exclude rendering and non-player simulation |

## Source identity recording

The requested source roots are present. I am recording SHA-256 identities for the principal paired files during detailed comparison. 1.21.2 has `.decompile-provenance.json` in the source root; its exact `sources` hashes and top-level input identity will be read for evidence integrity. Root inventories for 1.21.1 and 1.21.3 are not yet independently attested by metadata in this initial inventory.

## Next action

Audit the listed source families and their call-site/dependency closure, including exact 1.21.2 methods whenever an endpoint differs. Then mark each row examined, partial, or unexamined with paired members and gates before reading source-only claims.

## Independent closeout after source-only claim review

See `review.md` for source identities, paired method refs, claim verdicts and reasons. The original pre-claim table above is preserved as the initial inventory. Final coverage is:
- **Examined listed method paths:** client position correction, removed-vehicle teleport, standalone rotation, client respawn carryover, explosion packet precision.
- **Partial:** velocity packet codec/producers; full effect/attribute movement consumers and payload producers; entity metadata/abilities/events; server respawn permanent modifier carryover candidate; collision resolver/contact order; equipment modifiers; complete external writer/callback inventory.
- **Unexamined:** full block/contact callback and shape/provider dispatch beyond the traced piston call; all block-event dispatch.

Selected major client/player/entity/server files were hashed; 1.21.2 and 1.21.3 hashes match for those inspected files. Exact local hashes and all scope limitations are in `review.md`. The pair is not frozen by this slice review.

## Follow-up closure (per master request)

`review.md` now includes exact paired refs for the additional player-rider position sync/teleport snap paths; fall-flying state validation; piston-to-Entity.move response; generic push and knockback no-difference; and effect/attribute payload and client-consumer no-difference. Coverage upgraded for those bounded methods. Remaining partial/unexamined areas and candidate disposition are listed at the end of `review.md`; full pair freeze remains out of scope.

