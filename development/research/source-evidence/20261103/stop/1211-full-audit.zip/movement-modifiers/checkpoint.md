# Movement modifiers checkpoint — 1.21.1–1.21.3

Scope: bounded source-only checkpoint. Sources are exact-release Mojmap trees in `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{1.21.1,1.21.2,1.21.3}\mojmap`; 1.21.2 is included. No product history or implementation material was consulted.

## Source identity

- 1.21.1: ready pin says Mojmap, client SHA-256 `499f6897d1837516680f3114072d8106e11c9adcd933fe5cf051b551089b0c99`, source manifest SHA-256 `900f956e00f6fc1300bb3d689ea49df2b1a57bcaa54617344ef456d95d47cb48`.
- 1.21.2: `.decompile-provenance.json` contains per-file source hashes; the pinned cached client jar matched its embedded input SHA-256 `613091da0f62426ae8dcf9afb30eb639485f493b81cda3a2b96b1fb8a6b9976c`. Provenance file SHA-256 `00f399407dc447737ea83e3e46562418f8c712f66e3f51cb85d46afa2ecac575`.
- 1.21.3: ready pin says Mojmap, client SHA-256 `25190c556bc56d11070638ccab3b3c6efd76bb9684c92a2680a4de01c3c7138b`, source manifest SHA-256 `d673bb5464853e3a2a92ed9b1ffe1789d4e62c097bb884f67c336fcbb3b178ce`.

Relevant source SHA-256 values (1.21.1 / 1.21.2 / 1.21.3):

- `world/item/enchantment/Enchantments.java`: `7848a2cd677aa0700434f85de37d8a0c47597741d2d1f26c8dc270f73d65b266` / `fbe415832202d8ad96a472eff2e7f7f401ee6c397311790e04493a9169e31bda` / same as 1.21.2.
- `world/entity/LivingEntity.java`: `324a3eee8496caab57cfaf5101ef576f1ae3c60c40e3857e96f35f3af9a3a0d8` / `087390495f4fdfd14b9e12230e7aea4fdc50913bb4d1d91119e72892881cfc52` / same as 1.21.2.
- `world/entity/Entity.java`: `b81905c7879e2cc5c5063a41d865c4164ad919f156306705be791d1017b99850` / `a93719c302a0381a972af75ea360465e2e3551708dd07c34d4d40b7e5173c2b9` / same as 1.21.2.
- `world/effect/MobEffects.java`: `35d97c1741ec1379b05f41b8452229870c87a75633d312cd0b20d7fd901b4d08` in all three.
- `world/item/enchantment/effects/AllOf.java`: `846644b29fba0330b27ee604cebe8b5d2e941998b920f755a0412718b835c34d` in all three.

## Candidate difference: Soul Speed efficiency modifier condition

- 1.21.1 Mojmap, `net/minecraft/world/item/enchantment/Enchantments.java`, `SOUL_SPEED`, lines 431–522: `MOVEMENT_SPEED` uses the compound active/airborne condition (lines 453–505); `MOVEMENT_EFFICIENCY` is a separate `LOCATION_CHANGED` effect with only `movementAffectedBy(SOUL_SPEED_BLOCKS)` (lines 506–522).
- 1.21.2 Mojmap, same member, lines 432–512: both attribute effects are wrapped in one `AllOf.locationBasedEffects(...)` under the former speed effect's compound condition (lines 440–511). 1.21.3 has the same file hash and body.
- The compound condition's active branch allows an already-active effect to remain active when the entity is not flying and `onGround == false`, even when `movementAffectedBy(SOUL_SPEED_BLOCKS)` no longer matches. `AllOf.LocationBasedEffects` forwards the composite activation/deactivation to both nested effects (`effects/AllOf.java`, `LocationBasedEffects.onChangedBlock` and `.onDeactivated`). The candidate consequence is that `MOVEMENT_EFFICIENCY +1` can remain while airborne away from soul-speed blocks in 1.21.2+, whereas the separate 1.21.1 efficiency effect deactivates as soon as its block condition fails.
- Reachable movement dependency: `EntityPredicate` evaluates `movementAffectedBy` at `getBlockPosBelowThatAffectsMyMovement()` (`EntityPredicate.java` lines 127–130); `Entity.getBlockSpeedFactor()` reads that movement block when needed (`Entity.java` lines 861–868); `LivingEntity.getBlockSpeedFactor()` lerps that factor toward `1.0F` using `MOVEMENT_EFFICIENCY` (`LivingEntity.java` lines 500–503); `Entity.move()` multiplies post-move horizontal velocity by the returned factor (`Entity.java` lines 696–697). A player with active Soul Speed boots jumping from soul sand and crossing above a non-soul-speed block with a non-unit speed factor is a concrete candidate path.
- The location-effect updater is server-owned: `LivingEntity.onChangedBlock(ServerLevel, BlockPos)` calls `EnchantmentHelper.runLocationChangedEffects`; 1.21.1 tracks active location effects per enchantment, while 1.21.2 tracks them per equipment slot (`Enchantment.java`, `runLocationChangedEffects`, 1.21.1 lines 407–439; 1.21.2 lines 407–443). The client movement dependency is the resulting synchronized attribute state. `ServerEntity` constructs `ClientboundUpdateAttributesPacket` from syncable/dirty attributes; the exact self-player application/timing path was not closed in this checkpoint.
- Soul-speed tag checked in the pinned 1.21.1, 1.21.2, and 1.21.3 client data: `data/minecraft/tags/block/soul_speed_blocks.json` contains `minecraft:soul_sand` and `minecraft:soul_soil` in all three.

## Checked no-difference slices / precise incompleteness

- `LivingEntity.getJumpPower(float)` and `getJumpBoostPower()` retain the attribute/effect expression; `LivingEntity.getEffectiveGravity()` in 1.21.2 extracts the previous slow-falling/downward-velocity cap from `travel` without changing that expression. Water movement efficiency and Dolphin's Grace formulas in the fluid travel path retain their values. `MobEffects.java` source hash is identical across the pair endpoints.
- Depth Strider (`Enchantments.java`, `DEPTH_STRIDER`) retains its `WATER_MOVEMENT_EFFICIENCY` `ADD_VALUE` modifier of `0.33333334F` per level. Swift Sneak retains `SNEAKING_SPEED` `ADD_VALUE` of `0.15F` per level; `LocalPlayer.aiStep` still reads `Attributes.SNEAKING_SPEED` into `input.tick(...)`. The remaining surrounding client input edits were not audited as a full tick slice.
- 1.21.2 renames built-in attribute registry paths/translation keys in `Attributes.java`; the reviewed movement attribute values, ranges and syncability are unchanged. This is recorded as a registry-name migration, not a proven vanilla player movement delta.
- A separate consumer change was noticed for tick-core reconciliation: `LivingEntity.jumpFromGround()` writes jump power directly into Y in 1.21.1 (line 2060), but uses `Math.max(jumpPower, previousY)` in 1.21.2 (line 2142). This is outside the modifier provider itself and was sent to the master.
- This checkpoint does **not** close the complete modifier inventory: all equipment-component producers/application and their every equip/unequip/respawn path, all player tick callers and reachability gates, full attribute packet handling for the owning client player, and every changed modifier-adjacent method remain unexamined. The Soul Speed candidate needs those dependencies and independent blind review before acceptance. No tests, build, runtime, decompile, or implementation were performed.
