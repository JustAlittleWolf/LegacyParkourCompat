# Respawn attribute modifier audit (1.21.1–1.21.3)

Scope: exact Mojmap source trace of replacement `ServerPlayer` attribute restoration, respawn keep flags, attribute sync/pairing, and the replacement local player's movement consumers. This is a supplemental bounded slice, not a full-pair inventory or freeze.

## Source identities

Sources read from `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{version}\mojmap`.

- 1.21.2's `.decompile-provenance.json` SHA-256: `00f399407dc447737ea83e3e46562418f8c712f66e3f51cb85d46afa2ecac575`. Its pipeline is `lpc-decompile-v1`; the pinned client input is `https://piston-data.mojang.com/v1/objects/c7ac2d0d86f4ca416cab9064ff8a281852ad0c7b/client.jar` (SHA-256 `613091da0f62426ae8dcf9afb30eb639485f493b81cda3a2b96b1fb8a6b9976c`) and Mojmap input `client.txt` at object `ce0ed2eb99175df9ec5166324e3fdd1f87cee827` (SHA-256 `e37560e4889168916a73dbc4922c563002eff70fbecfe1cf5c50a7b222f451b2`). The manifest's `sources` map pins each listed 1.21.2 source hash below.
- 1.21.1 and 1.21.3 have adjacent version-root `mojmap.provenance.json`, `mojmap.ready.json`, `artifacts.sha256`, and `mojmap.sources.sha256` manifests. For each endpoint, the actual source/artifact manifest SHA-256 values match the `sourceManifestSha256` and `artifactManifestSha256` fields in its ready marker, and all 16 cited source-file hashes below match that endpoint source manifest. 1.21.1 provenance/ready marker SHA-256: `6f84a596ea944a1d40c79b53ead9d2cdd2b3c726d710a977758d15b5578ce7a9` / `988b38ac59491f9430d5bd1968db0fdaacb777a63fef745ca3e20342237a0310`; source/artifact manifest hashes: `900f956e00f6fc1300bb3d689ea49df2b1a57bcaa54617344ef456d95d47cb48` / `09ced418cbc7530a1d6d8802ee10c05cd576b217a2129655a71f30a2ae38f486`. 1.21.3 provenance/ready marker SHA-256: `24093437c0cd41d807ab0829068ef97828b65bbb95b38dfdc4f706883a8483d7` / `72385aa99d249a56d742b9c07823c1155c74c39dda1fbc6eacc12c980cd12e02`; source/artifact manifest hashes: `d673bb5464853e3a2a92ed9b1ffe1789d4e62c097bb884f67c336fcbb3b178ce` / `0587668e5c70bb06dacf3496a4442f66dc9cdcab23f2350b844f14259cc40dcf`. The cited 1.21.3 source bytes also match the corresponding 1.21.2 manifest source hashes.

| Source file | 1.21.1 SHA-256 | 1.21.2 manifest / 1.21.3 endpoint source SHA-256 |
|---|---|---|
| `server/level/ServerPlayer.java` | `ccdac581288507aae64bd844beefe9ac2e174f316458e181f23ce5631a4b1ba7` | `f6c58a668916857a2aa28f27b4b20d711b5f703aa19fad24875c129ae9ca712c` |
| `server/players/PlayerList.java` | `a045ffbe41a9895e1812555d79dcff672b429ef61d0515b9994501b2c71624ae` | `c1ca527da947b7a02c1b16e695aa30dc6ff30430c796adf97cfac0f6e39c238e` |
| `server/network/ServerGamePacketListenerImpl.java` | `cc73bb8fab95346aea10f7018ba7de6c723cde8a52a4ae40629b5370b6ff6d10` | `e4ad1ac2fa3236f659220c44dd4d5f63d9ef2ab5791bdabbfa2d229b14452a38` |
| `world/entity/ai/attributes/AttributeMap.java` | `91bae9479619334d3f7adc4e2216db73a74ab9a09d4e6f4e1b535d132e512db5` | `2df2650d77076950b33ac682bda0ba0974ecbb8f8bf41179064156a4c68b1a68` |
| `world/entity/ai/attributes/AttributeInstance.java` | `16a79843c53aabf5ae34b3230596995c70932197223482ad998085d6031ffee0` | `2a5ed44096b45b3b050a8df947cd44c788e6a35d51eb81d4c023f331f6f62870` |
| `server/level/ServerEntity.java` | `0994216505c8df7cc67a7a068ae8e71d1f023dbef5dc1dc31360e3e5bdc2ce14` | `c45400e92eb0ad334212bda63549050259ca1cab74dd9a50ec2f2738f86fa3a6` |
| `network/protocol/game/ClientboundUpdateAttributesPacket.java` | `a62a937338270df1ce0ec2b195fdbefcc5bc35b3db31bfcdd868baa1e27c1fdf` | `a62a937338270df1ce0ec2b195fdbefcc5bc35b3db31bfcdd868baa1e27c1fdf` |
| `client/multiplayer/ClientPacketListener.java` | `822e00d89e8def4cf7a8c22fdfefba3b9dc2135a7630e4ebe561a9d547d7f79d` | `169e1edaf666ebeb4ad736323565e28935a247748fecb67333dd5db53f24fb8a` |
| `client/player/LocalPlayer.java` | `c555e68ac3c63ab9b4f9a9e31933e263b96350a2bc599d11a0de5928bc24b583` | `fbd40f1f47adfa66dda9b15188e5dce82af3e8e8d7c3dd0543e602a354ad3fe0` |
| `world/entity/LivingEntity.java` | `324a3eee8496caab57cfaf5101ef576f1ae3c60c40e3857e96f35f3af9a3a0d8` | `087390495f4fdfd14b9e12230e7aea4fdc50913bb4d1d91119e72892881cfc52` |
| `server/level/ChunkMap.java` | `079b7c5e3d5bcdfff8b18a69513c93aaca56dfd739bde642c2ece79d127c5088` | `97ef42537faec0e4f0ec65bd887800c7b75c8921bca155e6abe037a9e99606df` |
| `server/level/ServerLevel.java` | `a87ef1125c53a0ada419f583d17e841402235ca569994220ec8a63baa5457181` | `c664c8ff5807eed64b5f627afd6908f5baccf4acab504ef4dab6e42ad2fef00d` |
| `network/protocol/game/ClientboundRespawnPacket.java` | `5db6493f12dc52df5ecfbe30c951f8b8c3697debc78fb5de3495bb5ba278a904` | `5db6493f12dc52df5ecfbe30c951f8b8c3697debc78fb5de3495bb5ba278a904` |
| `world/entity/ai/attributes/Attributes.java` | `a9a19f556bb77fc218b5b2f4831eb6b285f4398c24fa2a3519009ca8dad2db7c` | `14bcc5821d0f67f41fdc3e512556181823cff5c43f84fc1007e51d25f413a3ea` |
| `world/entity/player/Player.java` | `ed32b88c3c7c8418b83db41823520f2b6b0b49a98610306ef26e9681dc925c71` | `a803203e92aa4729d5f5c9b16085b6a43ce51d9907d309eb96736e9c7c1340de` |
| `server/commands/AttributeCommand.java` | `78bac6ba4f4bb0fd7665b97dd063f63e078c67f6a95e224799113d052c2be256` | `78bac6ba4f4bb0fd7665b97dd063f63e078c67f6a95e224799113d052c2be256` |

## Exact path and result

1. **Reachable server replacement gate.** In all three versions, `ServerGamePacketListenerImpl.handleClientCommand` reaches `PlayerList.respawn(player, true, CHANGED_DIMENSION)` only in the `PERFORM_RESPAWN` / `player.wonGame` branch (1.21.1 lines 1540–1553; 1.21.2/1.21.3 lines 1574–1591). Otherwise it returns while health is positive, and calls `respawn(player, false, KILLED)` after death. Ordinary portal dimension transfer is not this replacement path.

2. **Server-side state writer delta.** `PlayerList.respawn` constructs a new `ServerPlayer`, reuses the old connection, and calls `restoreFrom(old, keepAll)` before sending `ClientboundRespawnPacket` (1.21.1 `PlayerList.java:427–435,451–454`; 1.21.2/3 `PlayerList.java:403–411,427–431`). In 1.21.1, `ServerPlayer.restoreFrom:1330` calls only `assignBaseValues` before the `keepAll` branch; neither branch copies modifiers. In 1.21.2/3, `ServerPlayer.restoreFrom:1517–1535` copies base values and, only when `keepAll` is true, calls `assignPermanentModifiers` immediately after base values. The false/death branch still copies bases only. The new `AttributeMap.assignPermanentModifiers:120–127` iterates source attribute instances and adds each source `getPermanentModifiers()` item; 1.21.1 has no such assignment method.

3. **Keep byte and client replacement order.** `PlayerList.respawn` writes `(byte)(keepAll ? 1 : 0)` into the respawn packet. `ClientboundRespawnPacket.shouldKeep(bit)` is a bit test. In `ClientPacketListener.handleRespawn`, a fresh `LocalPlayer` is created and installed first; bit 1 causes `assignAllValues(oldLocalPlayer.attributes)`, otherwise it calls `assignBaseValues` (1.21.1 lines 1134–1138; 1.21.2/3 lines 1189–1193). Bit 2 separately controls preservation of sprint/sneak metadata and motion (1.21.1 lines 1106–1129; 1.21.2/3 lines 1161–1187). Thus the server keep boolean's value 1 is the client attribute-preservation bit; this client-side copy already preserves all old local modifiers on the End-victory branch in all three versions.

4. **How the replacement gets server corrections.** The new player is added to the destination level after the respawn packet and effect/info sends (`PlayerList.respawn`, 1.21.1 lines 454–463; 1.21.2/3 lines 430–442). Player tracking explicitly excludes an entity from pairing to itself (`ChunkMap.TrackedEntity.updatePlayer`, 1.21.2 lines 1267–1285; 1.21.1 lines 1229–1247). So the self-client does not get its initial attribute state via the observer pairing packet. Instead, `AttributeInstance.setBaseValue` dirties the attribute only if the base actually changes (both versions, lines 48–53); permanent modifier add/remove always dirties it (`AttributeInstance.java:105–108,125–134)). `AttributeMap.onAttributeModified` queues client-syncable attrs (1.21.2 lines 31–35; same mechanism in 1.21.1). During entity update, `ServerEntity.sendDirtyEntityData` sends an `UpdateAttributes` packet for that queue and clears it; `broadcastAndSend` also sends directly to the entity's own `ServerPlayer.connection` (1.21.1 lines 314–337; 1.21.2/3 lines 345–368). Observer pairing separately sends the complete syncable-attribute snapshot (`sendPairingData`, 1.21.1 lines 239–255; 1.21.2/3 lines 270–286).

5. **Packet fields and client application.** `ClientboundUpdateAttributesPacket` captures attribute holder, base value and `getModifiers()` (all three versions lines 30–36). On receipt, `ClientPacketListener.handleUpdateAttributes` finds the entity by ID, sets the received base, removes every local modifier, then re-adds the packet modifiers as transient (1.21.1 lines 2062–2085; 1.21.2/3 lines 2156–2180). Permanent-vs-transient classification is therefore not replicated, but the effective modifier set and values are.

6. **Movement relevance and reachable permanent writer.** `Attributes.MOVEMENT_SPEED`, `GRAVITY`, and `JUMP_STRENGTH` are explicitly client-syncable in 1.21.2/3 (`Attributes.java:41–46,63–65); `Player.aiStep` sets movement speed from `MOVEMENT_SPEED` (`Player.java:555–556)); `LivingEntity.getJumpPower` reads `JUMP_STRENGTH` (`LivingEntity.java:2129–2130)); `getDefaultGravity` reads `GRAVITY` (2168–2171). The permission-level-2 vanilla `/attribute` command adds permanent modifiers (`AttributeCommand.java:40–45,272–284`) and removes by modifier ID (`287–300`), so a player can have a movement-relevant permanent modifier during the true gate. Both operations dirty the syncable attribute and are observable by the connected client before replacement.

## Bounded conclusion / remaining gate

The source-confirmed 1.21.2 change is server-side permanent-modifier carryover on the reachable End-victory replacement path; 1.21.3 is byte-identical for the examined files. It does not carry modifiers across death respawn. The same true flag makes the client copy its entire old `LocalPlayer` attribute map in all three versions.

Therefore an immediate local movement-value change on that branch is **not established** merely by the server copy delta: the 1.21.1 client already carries the old modifier locally. Server and client can diverge in 1.21.1 after replacement. Whether/when a subsequent dirty packet corrects that divergence depends on the exact post-restore mutations to the same attribute: e.g. an unchanged base alone does not dirty it; a same-attribute effect restoration or a changed base does. In 1.21.2/3 the permanent copy itself dirties the attribute and the authoritative update packet resends it. A concrete tick-level movement difference is thus gated on a later same-attribute server sync in 1.21.1 and must be kept distinct from the confirmed server-state writer change.

Checked slice only: respawn/attribute assignment, replacement packet mask, attribute synchronization/pairing, and speed/gravity/jump consumers. No full movement-tick audit, tests, builds, or runtime checks were performed.






