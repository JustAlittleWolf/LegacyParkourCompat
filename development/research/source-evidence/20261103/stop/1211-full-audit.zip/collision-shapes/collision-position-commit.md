# Tiny resolved movement commits
1.21.1, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, lines 598–629.
1.21.3, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, lines 619–651; the exact 1.21.2 `Entity.java` body is identical.
Difference: 1.21.1 applies the resolved displacement to the entity position only when its squared length exceeds `1.0E-7`. 1.21.2 applies it when either that threshold is exceeded or `requested.lengthSqr() - resolved.lengthSqr() < 1.0E-7`.
Movement meaning: for a small unobstructed displacement whose resolved length squared is at most `1.0E-7`, the 1.21.1 position write is skipped, while the 1.21.2 condition permits it because the resolved vector is approximately the request. For small blocked displacements, the second gate can still skip the position write when the squared-length difference reaches the threshold. Exact positional advancement therefore changes around this threshold.
