# Independent source-coverage audit: 1.21.1 → 1.21.3

This is an independent bounded audit of the authorized source-only projections against exact Mojmap roots, including 1.21.2. It is not a pair freeze. It excludes product source, history, wiki/backlog, other lanes, tests/build/runtime/decompile, and uses only the authorized source outputs and exact source/resource inputs.

## Independent verdicts on source-only movement claims

| Claim / source slice | Verdict | Exact source evidence and limits |
|---|---|---|
| Ground jump vertical velocity | Confirmed | `LivingEntity.jumpFromGround`: 1.21.1 `LivingEntity.java:2056–2068` replaces Y with jump power; 1.21.2/3 `:2138–2150` uses `Math.max(jumpPower, currentY)`. Direct inherited player movement writer. |
| Small collision-resolved position gate | Confirmed; duplicate claims | `Entity.move`, 1.21.2/3 tests requested-vs-resolved movement squared difference `< 1.0E-7` before position commitment. Same operation appears in tick-core and collision-shapes outputs; count once. |
| Flying-player fall-distance reset timing | Confirmed | Paired `Player` paths: 1.21.1 performs reset in flight travel; 1.21.2/3 moves reset to `aiStep` before `super.aiStep`. Direct player state timing differs. |
| Flying bubble-column response | Confirmed | 1.21.2/3 `Player` overrides bubble-column callbacks and bypasses base response while flying. Gate is player flight ability. |
| Swept/deferred inside-block callbacks | Confirmed; duplicate claims | 1.21.1 callbacks run inline through `Entity.move`; 1.21.2/3 `LivingEntity.aiStep` applies block effects after travel and sweeps the traveled interval. Tick-core and collision drafts overlap; collision adds piston ordering context, not another finding. |
| Block-speed factor moved outside emission gate | Confirmed | 1.21.2/3 `Entity.move` applies block speed factor after the conditional emission path. Distinct from the small-move position gate. |
| Slow-fall clamp before fluid travel | Confirmed | `LivingEntity.travel` refactor: .1 clamp is within fall-flying branch after fluid branches; .2/3 calls `updateFallFlying` / `checkSlowFallDistance` before fluid travel. Player-reachable predicate/order change. |
| Flight no longer clears glide flag | Confirmed | 1.21.1 player flight travel clears the flag; .2/3 no longer does so, and `Player.canGlide` now gates on `!abilities.flying`. |
| Honey slide vertical conversion | Confirmed | Paired `HoneyBlock` direct velocity conversion differs; callback/vertical writer, not shape geometry. |
| Existing block collision shape geometry | Confirmed only for sampled scan; not exhaustive | Collision report's signature/changed-line sweep found no changed era-existing block `getShape` / `getCollisionShape` formula. The “examined” status is valid for sampled families/helpers, but cannot close all registered provider overrides without exhaustive enumeration and call closure. |
| Sweet berry bush | Confirmed no player movement delta in sampled methods | Stuck-movement multiplier is the same; changed threshold branch is server-side damage. Bounded no-difference, not global berry/provider closure. |
| `noCollision(entity, box, true)` | Confirmed excluded gate | Only explicit usage found is .2 `ServerPlayer.java:398`, server-only; not a logical-client movement query. |

## External-response and state-writer projection

The external review's paired verdicts are supported for its bounded paths: player correction (`ClientPacketListener.handleMovePlayer` and `PositionMoveRotation.calculateAbsolute`), stale removed-vehicle teleport handling (`handleRemoveEntities`, `handleAddEntity`, `handleTeleportEntity`), forced rotation packet handling, respawn mask handling, and explosion float-to-double packet precision. These are confirmed source differences subject to their reported packet and callsite gates.

Incoming velocity handling is a confirmed no-difference at the client consumer: `ClientPacketListener.handleSetEntityMotion` does `ensureRunningOnSameThread`, finds the entity, then calls `lerpMotion(packet xa,ya,za)` identically in 1.21.1 `:517–523`, 1.21.2/3 `:537–543`. This closes that handler only, not packet encoding or all producers.

The external report's generic player push/knockback no-difference, effect/attribute packet consumer no-difference, and piston path are bounded method conclusions. Its own coverage table correctly leaves payload/producers, metadata/events, equipment, other callback dispatch, and full writer inventory partial/unexamined. Server respawn modifier carryover is a confirmed server-state writer delta on the keep-all/End-victory path but is not established as a player movement difference: the client already carries old attributes on keep bit 1 in .1, and whether later server sync corrects divergence requires the post-restore same-attribute mutation path. Keep candidate/partial, not accepted movement delta.

## Exact resource and tag audit

The earlier inventory note that resources were unavailable is superseded by the parent-provided exact inputs. Client JARs match embedded pins: .1 SHA-256 `499f6897d1837516680f3114072d8106e11c9adcd933fe5cf051b551089b0c99`; .2 `613091da0f62426ae8dcf9afb30eb639485f493b81cda3a2b96b1fb8a6b9976c`; .3 `25190c556bc56d11070638ccab3b3c6efd76bb9684c92a2680a4de01c3c7138b`. The extracted resource manifest fully validates all 534 .1 and 562 .3 entries (no missing/hash mismatch). Direct archive inspection finds 534, 562, 562 tag/dimension JSON entries respectively. The .2→.3 resource/tag payloads have no differences. The 36 .1→.2 tag/dimension path differences are chiefly new/modern-only data; the existing movement-relevant block/fluid/item/entity-type tags inspected have unchanged contents across all three versions: climbable, fences, walls, fall-damage-resetting, inside/combination-step/crystal sound blocks, fire, portals, ice, soul speed, water, lava, freeze-immune wearables, and powder-snow-walkable mobs. This closes these named tag families, not every registry/resource-driven movement dependency.

### `no_knockback` / Ender Pearl

The .1→.2 `damage_type/no_knockback.json` change adds `minecraft:ender_pearl`, preserving the existing `fall` entry. Exact producer path: .1 `ThrownEnderpearl.onHit` teleports a ServerPlayer (dimension transfer where required), resets fall distance, then hurts it using `damageSources().fall()`; .2/3 teleports with relative `ROTATION|DELTA` and `Vec3.ZERO`, resets fall distance, then uses `damageSources().enderPearl()`. .2/3 register `DamageTypes.ENDER_PEARL` with `"fall"` damage effect and add it to `is_fall`; .1 already had fall tagged `is_fall`. In `LivingEntity.hurt` (.1 `:1174ff`) / `hurtServer` (.2 `:1191ff`) the tag gates the knockback call. Since the replacement source type is newly included in `NO_KNOCKBACK`, the tag delta preserves the no-knockback gate; no effective knockback writer delta is established here.

Per the assigned scope ruling, pearl teleport and hurt are server-side production/state generation and are not emulated. The eligible incoming local-client motion response was checked directly: `ClientPacketListener.handleSetEntityMotion` is identical in all three versions (`lerpMotion` only), so there is no client velocity-handler difference tied to this tag. Disposition: tag is a damage/teleport producer detail, not a source-confirmed local-player movement delta. Server `hurtMarked`/motion packet generation is outside the assigned emulation boundary.

Other changed damage tags: `bypasses_armor` and `is_fall` add Ender Pearl (damage classification/fall handling); `is_player_attack` adds `mace_smash` (modern-only combat); `can_break_armor_stand` rewrites player-attack membership via `#is_player_attack` (armor-stand break eligibility); `panic_causes` follows that tag (mob AI, non-player). New `mace_smash` damage type/tag is modern-only. These have no identified direct local-player movement writer or consumer in audited paths; damage calculation, health/food, armor-stand behavior, mob AI and modern-only mechanics are excluded. No movement claim follows from tag differences alone.

## Coverage verdict and remaining gates

The source-only projections' individual claims above are mostly confirmed for their bounded methods, with overlaps deduplicated. Their “examined” labels are accepted only for those named method paths. The full reachable source graph remains **partial**, and no pair freeze is justified.

Open gates are concrete: exhaustive tick order from the client tick driver through LocalPlayer/Player/LivingEntity/Entity and post-tick writers; full inherited setter/writer caller search; exhaustive callback and provider enumeration including every pre-existing block's movement shape/effect/contact methods and helper dependencies; complete effects/attribute/equipment/pose/dimension and packet-producer closure; all packet payloads and direct client state writers; registry/tag/resource dependencies beyond named checked tags; and independent review of the complete resulting graph. Exact resource inputs now exist, but the comparison here closes only the listed payloads and categories.

The .2→.3 “unchanged” verdict applies to methods/files whose per-source hashes and relevant bodies were checked. The entire source tree differs by seven paths; none is on the ordinary player tick path (the `Salmon` change is non-player). Do not generalize sampled file identity into full movement dependency closure.

