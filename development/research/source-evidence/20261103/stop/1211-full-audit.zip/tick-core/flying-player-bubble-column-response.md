# Flying players ignore bubble-column velocity responses
1.21.1, Mojmap: `net/minecraft/world/entity/Entity.java`, inherited `onAboveBubbleCol` and `onInsideBubbleColumn`, lines 2357–2378; no corresponding `Player` override.
1.21.2, Mojmap: `net/minecraft/world/entity/player/Player.java`, `onAboveBubbleCol` and `onInsideBubbleColumn`, lines 355–365; base implementations remain in `Entity.java`, lines 2455–2476.
Difference: 1.21.1 players inherit the base bubble-column Y-velocity adjustment in both callbacks, with `onInsideBubbleColumn` also resetting fall distance. 1.21.2 adds both `Player` overrides and delegates to the base only when `!getAbilities().flying`.
Movement meaning: a flying player exposed to either bubble-column callback keeps its Y velocity instead of receiving the base upward/downward adjustment; the inside-column callback also no longer clears that player's fall distance.
