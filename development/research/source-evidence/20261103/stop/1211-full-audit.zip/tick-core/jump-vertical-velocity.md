# Ground jump preserves stronger upward velocity
1.21.1, Mojmap: `net/minecraft/world/entity/LivingEntity.java`, `jumpFromGround`, lines 2056–2069.
1.21.2, Mojmap: `net/minecraft/world/entity/LivingEntity.java`, `jumpFromGround`, lines 2138–2150.
Difference: after the positive-jump-power gate, 1.21.1 writes `getJumpPower()` directly to Y velocity. 1.21.2 writes `Math.max(getJumpPower(), currentYVelocity)`; sprint horizontal impulse and the remaining gates are unchanged. `Player.jumpFromGround` calls this implementation through `super` in 1.21.1; the override is absent in 1.21.2, so player ground jumps use the changed base operation.
Movement meaning: if a reachable player ground-jump call has current upward velocity greater than jump power, 1.21.2 retains that larger velocity while 1.21.1 clamps it down to jump power.
