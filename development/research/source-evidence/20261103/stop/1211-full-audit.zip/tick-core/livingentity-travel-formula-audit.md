# LivingEntity.travel formula and helper audit

Scope: exact Mojmap source for local-instance `LivingEntity.travel` water, lava, fall-flying, air/ground branches and directly called movement helpers, 1.21.1→1.21.2→1.21.3. The local-player ordinary path reaches this method through `Player.travel`/`LivingEntity.travel`; vehicle-specific `travelRidden` and non-player behavior are excluded.

## Source identity

- 1.21.1 Mojmap: `decompiled_minecraft/1.21.1/mojmap`; ready marker identifies version 1.21.1, Mojmap, Vineflower, Java 25; `mojmap.sources.sha256` SHA-256 `900f956e00f6fc1300bb3d689ea49df2b1a57bcaa54617344ef456d95d47cb48`; `LivingEntity.java` SHA-256 `324A3EEE8496CAAB57CFAF5101EF576F1AE3C60C40E3857E96F35F3AF9A3A0D8`.
- 1.21.2 Mojmap: hidden `.decompile-provenance.json` source-manifest identity SHA-256 `00F399407DC447737EA83E3E46562418F8C712F66E3F51CB85D46AFA2ECAC575`; used its `sources` object and `exactRun` metadata as authoritative identity; `LivingEntity.java` SHA-256 `087390495F4FDFD14B9E12230E7AEA4FDC50913BB4D1D91119E72892881CFC52`.
- 1.21.3 Mojmap: ready marker identifies version 1.21.3, Mojmap, Vineflower, Java 25; `mojmap.sources.sha256` SHA-256 `d673bb5464853e3a2a92ed9b1ffe1789d4e62c097bb884f67c336fcbb3b178ce`; `LivingEntity.java` has the same SHA-256 as 1.21.2. The compared movement core is byte-identical from 1.21.2 to 1.21.3.

## Paired branch comparison

### Dispatch order and common gate

- 1.21.1 `LivingEntity.travel(Vec3)`, lines 2091–2216: first requires `isControlledByLocalInstance()`, then computes gravity and the falling/slow-falling gate, reads the block-position fluid, and dispatches in priority order: water, lava, fall-flying, otherwise air/ground.
- 1.21.2 and byte-identical 1.21.3 `LivingEntity.travel(Vec3)`, lines 2178–2189: same local-instance gate and branch priority. It combines water/lava dispatch, but `travelInFluid` selects water first and otherwise lava. It no longer computes gravity at the dispatcher; `getEffectiveGravity()` (lines 2173–2176) is called inside the selected branch.
- The gates `isAffectedByFluids()`, `!canStandOnFluid(fluidState)`, `isFallFlying()`, and the local control gate are preserved. A player who can stand on the fluid falls through to fall-flying/air in both versions.

### Water

- 1.21.1 `travel`, lines 2099–2130; 1.21.2/1.21.3 `travelInFluid`, lines 2216–2245.
- Same sprint-vs-water-slowdown (`0.9F` vs `getWaterSlowDown()`), base input acceleration `0.02F`, water-efficiency float cast and airborne `*=0.5F`, efficiency interpolation order, Dolphin's Grace override, `moveRelative`, `move(SELF, deltaMovement)`, horizontal-collision+climbable Y override to `0.2`, X/Y/Z drag (`slowdown`, `0.8F`, `slowdown`), and fluid-fall adjustment.
- Old writes the dragged vector with `setDeltaMovement` before calling `getFluidFallingAdjustedMovement`; new passes the same local dragged vector directly to that helper and performs one final setter. For ordinary Player/LocalPlayer, `setDeltaMovement` is not overridden and the helper reads only its arguments plus gravity/sprint state; no observable arithmetic or gate change is established by this extraction.
- Effective gravity and the `deltaMovement.y <= 0.0` falling bit are sampled before `move` in both versions. The new helper orders the falling-bit read before gravity; old reads gravity before the bit. Those are reads only on the ordinary player path.

### Lava

- 1.21.1 `travel`, lines 2131–2150; 1.21.2/1.21.3 `travelInFluid`, lines 2246–2265.
- Same input acceleration `0.02F`, move, threshold comparison `fluidHeight(LAVA) <= fluidJumpThreshold`, low-lava component-wise `(0.5, 0.8F, 0.5)` multiply followed by fluid-fall adjustment, high-lava whole-vector `scale(0.5)`, nonzero-gravity subtraction `-gravity/4.0`, and horizontal-collision free-space probe with `y + 0.6F - currentY + initialY` followed by Y velocity `0.3F`.
- The helper computes effective gravity and the falling bit before movement, equivalent to the old dispatcher snapshot. Both branches keep lava's same high/low-fluid split and final collision response.

### Fall-flying

- 1.21.1 `travel`, lines 2151–2190; 1.21.2/1.21.3 `travelFallFlying`, lines 2268–2302.
- Same initial horizontal-speed sample; look vector and pitch; lift/gravity term; negative-Y look-directed correction; negative-pitch dive term; horizontal-speed alignment; final `(0.99F, 0.98F, 0.99F)` scaling; then one `move(SELF, deltaMovement)`.
- The old lift factor is `cos(pitch)^2 * min(1.0, lookVector.length()/0.4)` (old travel lines 2154–2161); the helper version is `Mth.square(cos(pitch))` (new `updateFallFlyingMovement`, lines 2279–2302). `getLookAngle()` delegates to `calculateViewVector` in both `Entity` sources (old lines 2099–2101; new 2192–2194), whose view vector has unit direction, so its length is far above `0.4`; the old cap is therefore 1 for ordinary vanilla player view vectors. The multiply-by-one and explicit square have the same double multiplication. No reachable player numeric delta established from this extraction.
- Collision-damage gate and calculation are unchanged: horizontal collision, server only; compare initial and post-move horizontal speed, `(difference*10.0 - 3.0)` float cast, then positive-only sound/damage. Old lines 2178–2186; new `handleFallFlyingCollisions`, lines 2304–2313.
- Slow-fall-distance clamping moved out of this branch: old `checkSlowFallDistance()` occurs immediately on entering fall-flying at line 2152; new `LivingEntity.aiStep` calls `updateFallFlying()` before `travel`, and that helper calls `checkSlowFallDistance` (new lines 2758–2760, 2814). This is an ordering/callback-path change already tracked in the separate tick finding, not a glide formula difference here.
- `getEffectiveGravity()` is read before the glide move in the new helper; old cached the same value at travel entry. No movement write occurs between these reads on this branch.

### Air / ground

- 1.21.1 `travel`, lines 2191–2212; 1.21.2/1.21.3 `travelInAir`, lines 2191–2214.
- Same below-position friction source, on-ground block-friction choice vs `1.0F`, friction multiplier `*0.91F`, call to relative-friction movement, levitation equation `(0.05*(amplifier+1)-y)*0.2`, client unloaded-chunk gravity fallback, and `shouldDiscardFriction` split. In non-discard path, X/Z multiply by friction*0.91; Y multiplies by `0.98F` (or friction*0.91 for FlyingAnimal). Float-vs-double operation types and order are the same.
- Difference: old samples effective gravity at travel entry (lines 2093–2097), before the `move` inside `handleRelativeFrictionAndCalculateMovement` (old helper lines 2252–2263). New samples `getEffectiveGravity()` only after that helper has called `move` (new lines 2195–2202; helper lines 2351–2361). Since `getEffectiveGravity()`'s SLOW_FALLING condition reads `deltaMovement.y <= 0.0`, new air/ground travel can choose `Math.min(getGravity(), 0.01)` based on post-move vertical velocity while old chooses based on pre-move velocity. The ordinary floor path changes a negative Y velocity to zero and leaves the gate true in both versions. A concrete reachable sign-changing witness is a slow-falling LocalPlayer landing on an unsuppressed bed or slime block: Entity.move marks the downward collision/on-ground state and calls the fall-on movement callback; BedBlock/SlimeBlock bounce negative vertical velocity positive before travelInAir reads effective gravity. LocalPlayer is a local controlled instance, and unsuppressed means shift is not held. The old snapshot sees pre-move `y < 0` and uses `min(gravity, 0.01)`; new `getEffectiveGravity()` sees positive bounced Y and uses full gravity. With default gravity `0.08`, their next vertical velocities differ by `(0.08 - 0.01) * 0.98F` after the existing Y friction (new is lower). Both ordinary non-bouncing floor impacts, where the base Block handler sets Y to zero, keep the `<= 0` condition true, so this is a concrete gated case rather than an unconditional path delta.
- The unloaded-client fallback compares `getY() > getMinBuildHeight()` in old travel and `getY() > getMinY()` in new. `LevelHeightAccessor` renamed its minimum-height API; both `create(min,height)` implementations return the identical passed minimum, so this is an API rename rather than a threshold shift for the compared levels.

## Helper closure checked

- `handleRelativeFrictionAndCalculateMovement`: old public `LivingEntity` method lines 2252–2263, new private method lines 2351–2361. Body/order is the same: relative input using friction-influenced speed; `handleOnClimbable`; move; sample post-move delta; if collision or jumping and climbable/powder-snow condition then replace Y with `0.2`; return vector.
- `getFluidFallingAdjustedMovement`: old lines 2265–2278; new lines 2364–2377. Same nonzero-gravity and non-sprinting gate; same precise slow-fall epsilon condition and `-gravity/16.0` fallback; same vector construction.
- `handleOnClimbable`: old lines 2280–2295; new lines 2379–2394. Same climbable gate; fall-distance reset; `float 0.15F`; X/Z clamp; Y max with `-0.15F`; Player ladder/suppression/scaffolding Y stop.
- `getFrictionInfluencedSpeed`: old lines 2297–2299; new lines 2396–2398. Same on-ground formula `speed * (0.21600002F / (friction^3))`; otherwise `getFlyingSpeed()`.
- `getFlyingSpeed`, `getSpeed`, and `setSpeed`: same logic. New helper access modifiers are private where appropriate; ordinary Player/LocalPlayer callers use the same inherited implementation.

## Finding / resolved applicability

Air/ground travel changes the effective-gravity SLOW_FALLING sign sample from pre-move to post-move. A concrete reachable witness is a non-swimming, non-flying LocalPlayer with SLOW_FALLING, falling onto an unsuppressed bed or slime block, with shift not held and no other overlapping callback blocks. In both releases the controlled local move reaches the fall-on movement handler; those handlers bounce downward Y positive before the gravity read. Old travel uses the pre-move negative-Y cap; new travel sees positive bounced Y and uses full gravity. The next Y differs by `(gravity - min(gravity, 0.01)) * 0.98F` when gravity exceeds `0.01` (default `0.08`). Base solid-floor handling only zeros Y, so the gate remains true there. Other water, lava and fall-flying formula/helper extractions preserve ordinary player math and gates. 1.21.2→1.21.3 has no change in this slice (source file hashes identical).

## Resolved SLOW_FALLING sign-gate witness

- `Player.travel` reaches `super.travel` for non-passenger, non-flying ordinary movement (1.21.1 Player lines 1455–1477; 1.21.2 lines 1445–1467). LocalPlayer’s `isLocalPlayer()` returns true (1.21.1 LocalPlayer lines 348–351; 1.21.2 lines 346–349); Entity’s `isControlledByLocalInstance()` uses that result for a local Player (1.21.1 Entity lines 2995–2997; 1.21.2 lines 3149–3151). Thus both travel’s control gate and 1.21.2’s fall-on callback gate pass.
- A normal downward collision sets `verticalCollisionBelow = verticalCollision && requestedY < 0.0` and passes it to `setOnGroundWithMovement` before the callback (1.21.1 Entity lines 634–648; 1.21.2 lines 656–671). The resolved Y differs from requested Y, so old `move` calls `updateEntityAfterFallOn` (1.21.1 Entity lines 657–660); new `move` calls `updateEntityMovementAfterFallOn` only for the controlled local instance (1.21.2 Entity lines 682–686). For the LocalPlayer landing witness, this sets on-ground and enters the block hook in both.
- Base `Block` sets vertical delta to zero on fall-on (1.21.1 lines 376–378; 1.21.2 lines 369–371); this common floor case does **not** reverse the sign predicate: negative-before and zero-after both satisfy `<= 0`.
- `BedBlock` has identical handler semantics under the renamed method: unless `isSuppressingBounce()`, it calls `bounceUp`; if current y is negative, `bounceUp` writes `-y * 0.66F * 1.0` for LivingEntity (1.21.1 BedBlock lines 140–153; 1.21.2 lines 142–155). `SlimeBlock` likewise calls `bounceUp` unless suppressing; negative y becomes `-y * 1.0` for LivingEntity (1.21.1 SlimeBlock lines 35–48; 1.21.2 lines 33–46). The remaining `getBlockSpeedFactor` multiply in `Entity.move` scales only x/z, preserving bounced Y (old lines 705–707; new lines 696–697).
- Suppression is a real player gate: `Entity.isSuppressingBounce()` returns `isShiftKeyDown()` in both versions (1.21.1 Entity lines 2212–2214; 1.21.2 lines 2306–2308). LocalPlayer reads the input shift state (1.21.1 LocalPlayer lines 593–596; 1.21.2 lines 587–590). Therefore use the unsuppressed branch with shift not held. Both blocks’ bounce callbacks write positive Y while the initial travel velocity is negative; for the isolated landing witness, subsequent in-move bookkeeping only scales x/z and does not alter Y before `handleRelativeFrictionAndCalculateMovement` returns and `travelInAir` applies gravity. Bed's bounce factor is `0.66F`; slime's is `1.0`.
- The default gravity attribute is `0.08` in both exact sources (Attributes.GRAVITY: 1.21.1 lines 50–52; 1.21.2 lines 41–43); Player.createAttributes() inherits LivingEntity.createLivingAttributes(), which adds GRAVITY (Player: 1.21.1 lines 222–227 / 1.21.2 lines 226–231; LivingEntity: 1.21.1 lines 304–317 / 1.21.2 lines 318–331). This exceeds the slow-falling cap `0.01`. With SLOW_FALLING active, the old code snapshots falling=true before move and subtracts `min(0.08,0.01)` after the bounce. New code checks the now-positive bounced Y after move and subtracts `0.08`. Both then apply the same `0.98F` Y friction. The resulting vertical movement differs by `0.068 * 0.98F` (new lower), so the air/ground gate candidate is concrete and reachable on ordinary player paths. Slime/bed callback bodies and operation names are paired unchanged across these endpoints; the difference is when effective gravity samples velocity.



