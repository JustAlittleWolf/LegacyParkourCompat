# Small collision-resolved moves can update position
1.21.1, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, lines 598–641.
1.21.2, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, lines 619–664.
Difference: after `collide`, 1.21.1 applies the resolved displacement only when its squared length is greater than `1.0E-7`. 1.21.2 applies it when that condition holds **or** requested squared length minus resolved squared length is below `1.0E-7`.
Movement meaning: a player whose collision resolution leaves a nonzero displacement of squared length at most `1.0E-7` can now have that resolved displacement written to position when the lost squared displacement is also below the new tolerance. For example, requested length `0.0004` resolved to `0.0003` meets the new second condition but fails the old resolved-length gate. This is a source-level reachable collision path; trajectory frequency is unmeasured.
