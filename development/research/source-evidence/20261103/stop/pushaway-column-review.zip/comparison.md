# Independent source comparison: local-player push-away vertical scan

## Scope and verdict

Reviewed the local-client `serverTickAi` → block push-away → suffocation query → velocity write → `LivingEntity.mobTick`/`travel` route for Minecraft 1.13.2 and 1.14.4. I also checked the same bounded old helper/predicate bodies in exact stable releases 1.13 and 1.13.1, plus 1.14–1.14.3 for the new-probe boundary. The conditional raw-input terminal is confirmed: for the stated stone-column witness, the checked 1.13 stable releases leave velocity unchanged while 1.14 and later write the directional push vector. This confirms a source difference for this witness; it does not assert an ordinary movement trajectory or close pair coverage.

## Exact source identity

The shared source checkout is read-only at `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/`.

| Release | Mapping identity | Identity check |
|---|---|---|
| 1.13 | Ornithe Feather Gen2 build 2 | `.sources.sha256` manifest SHA-256 `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a`; local-player source SHA-256 `a188e1bc87831dd9da1ec1366a49acc4104c18e6979129097d02d5d3617e6a08`; PlayerEntity `4a57ce65405436aeb211d7a04a9a9f6ae1a661d033fd3ba2424909bfb42b8acd`. |
| 1.13.1 | Ornithe Feather Gen2 build 2 | `.sources.sha256` manifest SHA-256 `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba`; local-player source SHA-256 `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf`; PlayerEntity `4c1b14b4727116071b1ba9e3eeae84b8077f3d767e10e49b6a68a2556da32272`. |
| 1.13.2 | Ornithe Feather Gen2 build 2 | `.sources.sha256` manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; local-player source SHA-256 `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf`; PlayerEntity `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633`. |
| 1.14.4 | Ornithe Feather Gen2 build 2 | `.sources.sha256` manifest SHA-256 `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`; local-player source SHA-256 `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce`; PlayerEntity `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df`. |
| 1.14 | Yarn 1.14+build.21 | `ClientPlayerEntity.java` and `PlayerEntity.java` hashes match the embedded `.decompile-provenance.json` source rows; provenance-file SHA-256 `ea70a955a12f377cd3b9e8d5f346f4625b044d55da726b6bc472405ae91f4341`. |
| 1.14.1 | Yarn 1.14.1+build.10 | Both relevant file hashes match the embedded provenance rows; provenance-file SHA-256 `308537c5adec3104c5ca243eb5010554f00978635ed74f0d7801c804dd4d4907`. |
| 1.14.2 | Yarn 1.14.2+build.7 | Both relevant file hashes match the embedded provenance rows; provenance-file SHA-256 `786546f99684423cc2563be45c9c3334dfcc2c7db58ddb74ba39ce403bd0869a`. |
| 1.14.3 | Yarn 1.14.3+build.13 | Both relevant file hashes match the embedded provenance rows; provenance-file SHA-256 `81ea0021eb122d4e3340e20d47d6ecb7079365ba767a038d26a8264cddacc28a`. |

The intermediate Yarn source trees embed exact client, mapping, tool/runtime, and generated-source hashes in `.decompile-provenance.json`. Recomputed `ClientPlayerEntity.java` and `PlayerEntity.java` hashes match those rows for all four versions. The compared symbol names differ at the Yarn/Feather boundary; the bodies and predicates below are paired by behavior, not by equal names.

### Bounded old-release aliases

The exact-source declaration-span hashes (signature through closing brace) for `pushAwayFrom`, `wouldCollideAt`, `doesNotSuffocate`, and `shouldSuffocate` are respectively `f658e04902c1e965f6dd43ad9a98812b09d60c0b19905c2754178d9c6676bd43`, `465999c2e3a76ae4b32631cfe1c5573a1a9b5c571a5ae02e4e956747306da5b7`, `71690ed18303b391003b9d134e317d44b111fc2b0fbcc985c514811e5e2a43e7`, and `134fd6c2b2063cbaf2f6db9871889c59717779bb6fb42f4eb0d872f18774cd5e` in each of 1.13, 1.13.1, and 1.13.2. I checked those spans against exact source trees whose whole-source-manifest hashes are listed above. The four caller invocations keep the same order (`1.13:714–717`, `1.13.1:718–721`, `1.13.2:718–721`). The whole `LocalClientPlayerEntity.java` hash differs in 1.13; the alias claim is limited to the named method spans and caller order, not the rest of that class or release.

The cached exact Mojang release catalog `D:/Javastuff/LegacyParkourCompat/.minecraft-decompile-cache/version_manifest_v2.json` has SHA-256 `ac37f92737df1a9d7660047136fedd3edebd90bd6e552f53ddc3f222079bc8fa`. Its stable release IDs in this interval are `1.13`, `1.13.1`, `1.13.2`, then `1.14`; there is no stable release between 1.13.2 and 1.14. Snapshot/pre-release IDs are out of scope. Thus 1.14 is established as the first stable release with the new probe among stable versions in this interval.

## Caller and gates

In 1.13.2, `LocalClientPlayerEntity.serverTickAi` calls `pushAwayFrom` four times in this order (`:718–721`), with samples at `(x−0.35w, minY+0.5, z+0.35w)`, `(x−0.35w, minY+0.5, z−0.35w)`, `(x+0.35w, minY+0.5, z−0.35w)`, then `(x+0.35w, minY+0.5, z+0.35w)`. It does not guard the calls with `noClip`; old `pushAwayFrom` returns before queries when `noClip` is true (`:401–404`).

From 1.14 through 1.14.3, the same four calls are inside `if (!noClip)` in `ClientPlayerEntity.tick` (`1.14:633–640`, `1.14.1:633–640`, `1.14.2:632–639`, `1.14.3:632–639`). 1.14.4 likewise guards the four calls in `LocalClientPlayerEntity.serverTickAi` (`:645–651`); its helper has no internal `noClip` test. Thus for `noClip=true`, both sides preserve velocity, though the gate moved from helper to caller. The stone witness explicitly uses `noClip=false`, so all four calls run on both sides. It is non-swimming, so the old swimming-specific query branch is not taken.

The local-player override runs during `LivingEntity`'s locally controlled AI stage before `mobTick`; both 1.13.2 (`LivingEntity:1896–1900`) and 1.14.4 (`:2197–2201`) then call `mobTick` (`:1852+` and `:2150+`), whose local-player path reaches travel. Therefore the post-callback velocity is a direct same-tick input to the later movement path. No `Entity.move` output is needed to establish the velocity terminal.

## Raw witness and arithmetic

Use a local player with current box `[0.16,0.76] × [0.8,2.6] × [0.2,0.8]`, center `(x,z)=(0.46,0.5)`, width `0.6`, incoming velocity `(0.25,0.3,0.4)`, `noClip=false`, and `isSwimming=false`. The default player dimensions are 0.6×1.8 in 1.13.2 (`PlayerEntity:450`) and 1.14.4 (`PlayerEntity:109`). Let `(0,0,0)` be a vanilla stone block and the four horizontally adjacent columns be air at Y=0,1,2. Assume these cells are loaded and in border. The box overlaps stone by 0.2 on Y and 0.6 on each horizontal axis.

The four sample coordinates are `(0.25,1.3,0.71)`, `(0.25,1.3,0.29)`, `(0.67,1.3,0.29)`, and `(0.67,1.3,0.71)`. Each floors to sampled cell `(0,1,0)`; floating representation does not change these floors.

- **1.13.2:** `new BlockPos(sample)` selects Y=1. `wouldCollideAt` is `isSwimming ? !shouldSuffocate(pos) : !doesNotSuffocate(pos)` (`LocalClientPlayerEntity:453–455`). For the non-swimming witness, `doesNotSuffocate(pos)` is `shouldSuffocate(pos) && !isSolid(pos.up())` (`PlayerEntity:1479–1485`). At `(0,1,0)`, both Y=1 and Y=2 are air, so this is true and `wouldCollideAt` is false. Every call stops before direction selection; final velocity remains `(0.25,0.3,0.4)`. The bottom stone at Y=0 is never inspected.
- **First new stable release, 1.14:** `ClientPlayerEntity.pushOutOfBlocks` delegates to `cannotFitAt`; `cannotFitAt` scans `i=floor(box.minY)` through `i<ceil(box.maxY)` and returns true on `!doesNotSuffocate(mutable)` (`ClientPlayerEntity:375–433`). The exact loop is present in 1.14 and remains in 1.14.1, 1.14.2, and 1.14.3 (`:421–433` in the first three source files). Their `PlayerEntity.doesNotSuffocate` tests `!state.canSuffocate(world,pos)` (`:1401–1403`; 1.14.3 `:1403–1405`). For stone, the current vertical column query includes Y=0 and detects the stone; adjacent air columns do not collide. At 1.14.3 only the box type name has changed from `BoundingBox` to `Box` in the helper.
- **1.14.4:** `wouldCollideAt` scans the same half-open box Y range and returns true when `!shouldSuffocate(mutable)` (`LocalClientPlayerEntity:435–447`); `PlayerEntity.shouldSuffocate` is `!state.isViewBlocking(world,pos)` (`:1420–1422`). Stone is view-blocking and air is not, so the same root/neighbor answers result for this witness. The 1.14.4 predicate is not claimed equivalent to 1.14's `canSuffocate` predicate for every block state.

For each new-version call, the nearest open horizontal side is: WEST, WEST, NORTH, SOUTH. This follows strict-less-than replacement in the source order WEST, EAST, NORTH, SOUTH: distances are `(0.25,0.75,0.71,0.29)`, `(0.25,0.75,0.29,0.71)`, `(0.67,0.33,0.29,0.71)`, `(0.67,0.33,0.71,0.29)`. Each write replaces only its horizontal velocity axis and preserves the other components. The sequence ends at `(-0.1,0.3,0.1)` on the 1.14 path. This is a direct source result, not a claim about subsequent clipped position.

This is a statically valid raw callback input: finite player coordinates/dimensions, a valid box, a local player, and ordinary vanilla block states satisfy the method's source preconditions; the callback specifically handles a player column that cannot fit. The current box/block overlap is intentional in the witness. It is not represented as a collision-free trajectory or attributed to an excluded producer, and no prior producer trajectory is needed for this conditional callback comparison.

## Boundary and limitations

The vertical-column probe is present in exact stable release 1.14 and in each checked patch release 1.14.1–1.14.3. The cached exact release catalog has no stable release between 1.13.2 and 1.14, so 1.14 is the first stable release with this probe in the interval; snapshots are out of scope. The 1.14–1.14.3 `canSuffocate` predicate and 1.14.4 `isViewBlocking` predicate should not be collapsed into a universal block-state equivalence claim. No full-pair coverage or runtime parity is claimed.
