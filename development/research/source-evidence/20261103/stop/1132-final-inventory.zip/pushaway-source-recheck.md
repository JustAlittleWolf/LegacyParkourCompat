# Local-client push-away source recheck (1.13.2 → 1.14.4)

This is a source-only recheck of the conditional `LocalClientPlayerEntity.pushAwayFrom` candidate in `tick-collision/report.md`. I inspected the exact caller, helper, and suffocation predicates from the manifest-identified Feather Gen2 build 2 endpoints after the candidate was written. It confirms the stated raw-input terminal, not an ordinary trajectory or full-pair acceptance.

## Matched raw inputs

- Local camera player enters ordinary `LocalClientPlayerEntity.serverTickAi`; `noClip=false`, not swimming.
- Current box is `[0.16,0.76] × [0.8,2.6] × [0.2,0.8]`, center X/Z `(0.46,0.5)`, velocity `(0.25,0.3,0.4)`. This is a width-0.6, height-1.8 player box at feet Y `0.8`.
- `Blocks.STONE` is the only blocking/view-blocking cell at `(0,0,0)`; the four horizontal neighbor columns are air at Y `0,1,2`. Query cells are loaded and in-border; collision shape/world producers are held fixed.

## Caller and terminal check

Old `LocalClientPlayerEntity.serverTickAi` invokes all four corner `pushAwayFrom` calls unconditionally (old `:717–721`). New `serverTickAi` wraps those calls with `if (!noClip)` (new `:645–651`). With `noClip=false`, both reach the helper at the same four points. Old `pushAwayFrom` itself also returns on `noClip` before any state query (`:401–404`); the new helper has no such internal gate, but the caller gate makes both preserve velocity for `noClip=true`.

For the first ordinary sample `(x,y,z)=(0.25,1.3,0.71)`, both endpoints construct cell `(0,1,0)`. Old non-swimming `wouldCollideAt` checks only that cell through `!doesNotSuffocate`; old `doesNotSuffocate(p)` is `shouldSuffocate(p) && !isSolid(p.up())`, and old `shouldSuffocate(p)=!isSolid(p)`. Cells `(0,1,0)` and `(0,2,0)` are air, so old concludes no collision and does not search or write. The same is true of the other three corners, which all floor to `(0,1,0)` for Y and `(0,0)` for X/Z.

New `wouldCollideAt` scans `i=floor(box.minY)=0` through `i<ceil(box.maxY)=3` at the sampled X/Z column. New `PlayerEntity.shouldSuffocate(p)=!p.isViewBlocking(world,p)`, so the stone at `(0,0,0)` makes the current vertical query return true; the air-only horizontal neighbor columns each return false. For samples in call order, distances select WEST, WEST, NORTH, SOUTH (strict `<` ties preserve the earlier candidate). The axis writes yield final velocity `(-0.1,0.3,0.1)`. Old leaves the input `(0.25,0.3,0.4)` untouched. The raw solid overlaps the current player box by `0.2` on Y and positively on X/Z, so this is an explicit collision-response input rather than a claim of collision-free history.

The direct changed terminal is the local player's current velocity before the same tick's jump/travel path. It does not depend on the following `Entity.move` candidate stream. This validates the conditional method result under the stated local-player caller and raw world predicates. It does not establish how the overlapping position or block arrangement is produced, and it does not independently accept a repository finding or freeze the pair.

For `noClip=true`, old helper returns before its state-dependent writes and new caller skips all four calls; both preserve the incoming velocity.

## Exact source identities

The following complete Java-file hashes were recomputed and match the corresponding row in each exact endpoint source manifest:

| Relative path | 1.13.2 SHA-256 | 1.14.4 SHA-256 |
|---|---|---|
| `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` | `708af6a3880fb58b67bf4604a5509b351719a9c2a0c06a8ec261586435bf00ce` |
| `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
