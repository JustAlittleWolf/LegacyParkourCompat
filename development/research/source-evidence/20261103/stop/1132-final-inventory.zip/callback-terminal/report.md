# Callback registration and runtime-dispatch terminal census

Read-only exact-source continuation for 1.13.2→1.14.4. Source identity is the existing manifest-pinned pair: 1.13.2 manifest `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`; 1.14.4 manifest `717b468536348557f9dae8cf57edccf80ad16eb65e5bef6c60bdb5ea3c9f75bc`. Existing `callback-provider/report.md` records the full callback declaration roster and paired method body/gate classifications; this addendum closes the vanilla registration-to-dispatch layer and narrows the remaining runtime boundary.

## Vanilla registration closure

The endpoint vanilla block registries are centralized in old `net/minecraft/block/Block.java` (its static registration section) and new `net/minecraft/block/Blocks.java`. A constructor-registration search for every callback-declaring class in the existing census resolves its vanilla instances there. This includes inherited callback subclasses `PressurePlateBlock` and `WeightedPressurePlateBlock` (both extend `AbstractPressurePlateBlock` in both endpoints), the many aliases constructed with one `BedBlock`/`StairsBlock` class, and the paired common callback classes. Old-only `TntBlock` and new-only `LiquidBlock`, `CampfireBlock`, `BerryBushBlock`, `WitherFlowerBlock`, `WheatBlock` are likewise directly registered in their corresponding endpoint initializer. There is no callback declaration in the block package left without a vanilla registration or an explained inherited/default role in the pre-existing census.

The inherited default `Block` methods are dispatched on registered instances that do not override them. `StairsBlock.onSteppedOn` delegates to the configured base block's `onSteppedOn`; this is an explicit callback alias edge and its terminal is classified in the existing report. Pressure plates inherit the `AbstractPressurePlateBlock` contact method. Static registry aliases therefore do not create a separate callback implementation or movement terminal; they resolve to the same constructed callback object/class body and are covered by the method census.

## Runtime dispatch closure for vanilla local-player movement

Paired caller chain is `Entity.move` → movement callbacks, then `Entity.checkBlockCollisions` → `BlockState.onEntityCollision` → virtual block callback. The exact movement/callback ordering and bounds are in `callback-provider/report.md` under “Extended callback census and downstream routing.” Caller-side gates are:

- `beforeCollision`: requested vertical displacement differs from the resolved vertical displacement.
- `onSteppedOn`: the paired `makesSteps`, on-ground, player/sneak, and riding conditions hold.
- `onFallenOn`: resolved movement lands and accumulated fall distance is positive.
- `onEntityCollision`: after position resolution, the entity box inset by 0.001 passes the loaded-area check; every enumerated cell dispatches entity collision before block collision. No client-side suppression exists on this dispatch chain.

For local-player movement writers, every vanilla callback declaration is classified in the existing report: equal bounded direct or deferred movement response (`BedBlock`, `SlimeBlock`, `BubbleColumnBlock`/Entity consumer, `CobwebBlock`/Entity and Player consumers, `SoulSandBlock`, inherited base callbacks); existing conditional lava route; or explicit damage/state/inventory/entity/server/new-only exclusion. This addendum found no second unclassified registered vanilla callback path. Callback registration and direct terminal coverage are complete for the vanilla endpoint registries under the paired movement caller inputs; global collision candidates, input-state reachability, repeated callback timing, and all-state/provider output combinations remain separate open source gates.

## Runtime coverage boundary

The two vanilla static initializers establish the vanilla block-ID-to-instance assignments represented by these exact client sources. They cannot establish third-party/mod registration aliases, live registry replacement, runtime data-pack effects, world-generation/provider state production, or the actual ordering/reachability of arbitrary callbacks during a game session; no runtime launch or registry snapshot was authorized. Treat those as external/unexamined inputs, not as evidence that the exact vanilla declaration/registration census is incomplete. The report's fixed-input callback equivalences and conditional witnesses are not promoted to full movement-trajectory parity.

## Exact registry source hashes

Recomputed endpoint Java digests match their source manifest rows:

| Relative source | 1.13.2 | 1.14.4 |
| --- | --- | --- |
| `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` | `1f8ec3628f08e196c2793e91ca0b94feacea6bc3939e7fb770f0682a6e66f2c5` |
| `net/minecraft/block/Blocks.java` | absent (registration source is `Block.java`) | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |

## Disposition

- **Examined / closed:** vanilla callback override declaration roster (existing report), inherited callback classes and aliases, exact vanilla registration initializer mapping, paired vanilla runtime dispatch order/gates, immediate callback movement-writing terminals and exclusions under their stated inputs.
- **Partial / open:** callback dispatch outcomes for unmatched collision/query/provider inputs; callback-induced repeated-cell/tick sequences; unlisted world/block-entity/context values; full local-player writer-to-next-tick graph; runtime third-party registrations or registry mutation (not represented in vanilla source endpoints).
- **Not claimed:** pair freeze, runtime parity, movement candidate graph closure, or acceptance of conditional source candidates beyond the independently recorded verdicts.
