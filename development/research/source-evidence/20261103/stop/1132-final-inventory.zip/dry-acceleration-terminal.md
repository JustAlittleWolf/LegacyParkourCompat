# 1.13.2 → 1.14.4 dry ground acceleration terminal

Read-only exact-source closure of the remaining grounded acceleration arithmetic gate. It does not establish a full tick trajectory, post-move slipperiness equality, resolver parity, or pair acceptance.

## Source identity

The exact Feather source roots are `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/{1.13.2,1.14.4}/ornithe-feather`. Recomputed Java hashes match the supplied endpoint source manifests:

| Release | Source | SHA-256 |
|---|---|---|
| 1.13.2 | `net/minecraft/block/Block.java` | `735030e8bb5fc7ead2d6dbcb1b262a36a414b4349daf197456337f460b444cd4` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.14.4 | `net/minecraft/block/Blocks.java` | `9c0323497b31f8a284456e5692898897b92b6f0817d0371fae9a8afb54c638f8` |
| 1.14.4 | `net/minecraft/entity/living/LivingEntity.java` | `2cccf4331ce9e62013eeb8e96163e5e146e1291619eb998ce9867daa87c02b61` |
| 1.14.4 | `net/minecraft/entity/living/player/PlayerEntity.java` | `2614deb3b50d11f6cdf54d9e308703bf49cb53b72646b05253857e9557d657df` |

## Exact method result

For old `LivingEntity.moveRelative(float,float,float)` (`:1538–1558`), grounded acceleration forms `t = slipperiness * 0.91F`, then `u = 0.16277137F / (t*t*t)`, then `v = getSpeed() * u`, and passes that scale to `Entity.updateVelocity` before the later movement and damping. New `LivingEntity.moveRelative(Vec3d)` (`:1840–1846`) reads slipperiness once and calls `m_70235197(v)`; that helper (`:1961–1963`) returns `getSpeed() * (0.21600002F / (v*v*v))` on ground. These are distinct binary32 operation sequences.

The exhaustive vanilla registration search over old `Block.java` and new `Blocks.java` found only four old-era slipperiness literals: default `0.6F`, slime `0.8F`, ice/packed/frosted ice `0.98F`, and blue ice `0.989F`. No new-era block registration changes the value for these common blocks. With IEEE-754 binary32 rounding after each Java float operation, the grounded multiplier `u` and concrete local-player scale (`getSpeed() = 0.1F`, no sprint/effect modifiers) are:

| Raw slipperiness | Old `u` | New `0.21600002F/(v³)` | Old scale at speed 0.1F | New scale at speed 0.1F | Result |
|---:|---:|---:|---:|---:|---|
| `0.6F` | `0.9999998807907104` | `1.0` | `0.09999998658895493` | `0.10000000149011612` | different |
| `0.8F` | `0.4218750298023224` | `0.4218750298023224` | `0.04218750447034836` | `0.04218750447034836` | equal |
| `0.98F` | `0.22949624061584473` | `0.22949621081352234` | `0.022949624806642532` | `0.022949621081352234` | different |
| `0.989F` | `0.22328777611255646` | `0.22328774631023407` | `0.022328777238726616` | `0.022328775376081467` | different |

`PlayerEntity` sets the movement-speed attribute base to `0.1F` at old `:159` and new `:191`; `LivingEntity.getSpeed()` returns its stored speed field. The local-client grounded dry method has the ordinary locally-controlled route described in `tick-collision/report.md`. For a fixed pure-forward input with zero incoming horizontal velocity and yaw zero, the differing acceleration scales become differing velocity components before `Entity.move`; its later movement result is not needed to establish this direct terminal. The no-sprint/no-effect raw speed is bound to the common player base attribute. This is a conditional method-level direct velocity witness, not proof of the raw support blocks' prior placement or of an ordinary repeated-tick trajectory.

## Closure boundary

This closes the float-rounded acceleration subgate: the old/new outputs are equal for the listed vanilla slime value, and differ for default, ice, and blue-ice values at the stated speed input. It replaces only the previous report's uncertainty about whether any listed raw slipperiness values produce a distinct multiplier. Old post-move support resampling versus new pre-move reuse remains a separate conditional input difference; support collision/candidate outputs, movement input/yaw/state history, exact downstream clipping, and cross-tick trajectory remain open. The accepted post-move chunk-gravity witness and immutable corner-shell witness are unaffected.
