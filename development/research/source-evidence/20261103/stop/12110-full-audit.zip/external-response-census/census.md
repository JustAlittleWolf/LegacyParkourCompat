# 1.21.10 to 1.21.11 direct player response census

## Evidence identity

- Source: Mojmap, exact source manifests `1.21.10/mojmap.sources.sha256` SHA-256 `4be26049350c1b314a0b198022cb1e7ab1e745e104047de7a5c7d099a9d7b7e1` and `1.21.11/mojmap.sources.sha256` SHA-256 `0c4d83fef84c101d9db88f331acec7960f3c8346228c28995e6cf57bbfcae555`. The matching `mojmap.ready.json` entries pin client SHA-256s `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482` and `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd`.
- Resources: `.native-source/20261103/resource-inputs/{1.21.10,1.21.11}/resource-manifest.json` identify the same versions and client hashes as the ready markers and checkpoint copies. All listed files verified against their manifest hashes: 616/616 for 1.21.10, 629/629 for 1.21.11.
- Sources were consumed read-only from `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\{1.21.10,1.21.11}\mojmap`.

## Direct-response roots and caller roster

The local client executes packet callbacks through `ClientPacketListener`; the player position and velocity packet paths were compared including their packet and entity callees.

| Root / terminal | 1.21.10 | 1.21.11 | Reachability and result |
|---|---:|---:|---|
| `ClientPacketListener.handleSetEntityMotion` | 592–598 | 604–610 | For an existing entity ID, calls `Entity.lerpMotion(packet movement)`. Paired method body unchanged. Server-produced impulse/knockback arrives as authoritative motion; the client does not run the server's knockback calculation. |
| `ClientPacketListener.handleMovePlayer` and `setValuesFromPositionPacket` | 764–793 | 776–805 | Local player is changed only when not riding. The routine calculates absolute relative position/rotation/motion; it either interpolates or writes position, velocity, angles, and old position. Bodies unchanged. These are server corrections/teleports. |
| `ClientPacketListener.handleRespawn` | 1204–1280 | 1216–1292 | Recreates local player; copies entity data, velocity and rotation when keep flags permit, otherwise resets spawn position and yaw; restores attributes and portal state. Movement writes unchanged. 1.21.11 adds only `setClientLoaded(false)` before level waiting, unrelated to movement. |
| `ClientPacketListener.handleExplosion` | 1298–1316 | 1311–1329 | Plays effects then adds optional packet `playerKnockback` to local velocity. Call is unchanged; see the finite-vector guard below. Knockback vector is calculated and sent by the server. |
| `ClientPacketListener.handleDamageEvent` / `handleEntityEvent` | 1181–1187; 1155–1177 | 1193–1199; 1167–1189 | Dispatch damage/status events to the addressed entity. No local knockback calculation is added here; paired dispatch logic is unchanged. |
| `ClientPacketListener.handleSetEntityData` | 601–607 | 613–619 | Assigns synchronized entity data. `Entity.onSyncedDataUpdated` refreshes dimensions for the pose accessor; paired behavior unchanged. This covers synchronized pose/flags including crouch, swimming, fall-flying and sleeping state. |
| `ClientPacketListener.handleUpdateMobEffect` / `handleRemoveMobEffect` | 1701–1715; 1879–1887 | 1719–1733; 1897–1905 | Effect packets call `LivingEntity.forceAddEffect` / `removeEffect`. Paired packet handlers and effect mutation methods are unchanged in behavior. Effect attribute modifiers are maintained on the server; relevant client attribute values arrive through the attribute packet path below. |
| `ClientPacketListener.handleUpdateAttributes` | 2213–2235 onward | 2231–2253 onward | Applies supplied base values and transient modifiers to `LivingEntity` attributes; paired method unchanged. `LivingEntity.onAttributeModified` refreshes dimensions for `Attributes.SCALE` on both versions (1.21.10: 1098–1124; 1.21.11: 1094–1126). |
| `ClientPacketListener.handleSetEquipment` | 1444 onward | 1462 onward | Applies equipment packet stacks to the addressed entity; checked paired method, no movement-write change. Movement-relevant attribute sync remains the separate attribute packet above. |
| `PistonMovingBlockEntity.moveEntityByPiston` / `moveStuckEntities` -> `Entity.move(MoverType.PISTON)` | 185–217 | 185–217 | Client-side moving piston block entities call the same piston move for eligible entities and then the same block-effect callback. `PistonMovingBlockEntity.java` source hash is identical across the pair. `Entity.move` and `limitPistonMovement` retain the same piston-axis ordering, per-tick ±0.51 clamp and 1e-5 cutoff (1.21.10: 678–684, 985–1018; 1.21.11: 693–699, 1004–1037). `PistonBaseBlock` changed only a nullability annotation on `setPlacedBy`; no player response change. |
| Entity/block contact and fall callbacks -> `Entity.applyEffectsFromBlocks`, `onInsideBlock`, `BlockState.entityInside`, `fallOn`, `updateEntityMovementAfterFallOn` | `Entity.java` 801–854, 1199–1253, 1399 onward; `BlockBehaviour.java` 355, 744–745 | `Entity.java` 816–869, 1218–1272, 1418 onward; `BlockBehaviour.java` 354, 741–742 | Same movement-record traversal and callback dispatch; changed line numbers reflect surrounding additions. Piston callback is included above. Checked callback implementations for `BedBlock`, `SlimeBlock`, `HoneyBlock`, `BubbleColumnBlock`, `PowderSnowBlock`, `WebBlock`, `BigDripleafBlock`, `NetherPortalBlock`, `EndPortalBlock`, and `EndGatewayBlock`; no concrete player-response difference found among the unchanged implementations. `HoneyBlock` only has package relocation imports in this pair. |
| Portal processing / teleport | `Entity.java` 2450–2505, 2900–3020, 3156 onward | `Entity.java` 2473–2528, 2921–3041, 3176 onward | The server-side entity dimension transfer remains authoritative; client side tracks portal contact/effect and receives position/respawn packets above. Cross-dimension `teleport` changes only nullability annotations. `NetherPortalBlock`, `EndPortalBlock`, and `EndGatewayBlock` callback code is checked with no response delta. |
| Local entity collision push -> `Entity.push(Entity)` | `Entity.java` 1720–1758 | `Entity.java` 1738–1783 | Collision pushes are reachable from entity overlap. Scalar direction/magnitude calculation is unchanged; vector application gained finite-value guards (detail below). |
| Inherited `LivingEntity` environmental movement/predicates | `LivingEntity.travel`, `travelInFluid`, `onClimbable` | `LivingEntity.travel`, `travelInFluid`, `travelInWater`, `travelInLava`, `onClimbable` | Fluid implementation is extracted into helpers; terminal water/lava movement math retains the same constants and operation sequence. `onClimbable` has the concrete fall-flying predicate change below. |

## Concrete differences / dispositions

### Fall-flying entities skip climbable handling in glide-through blocks

1.21.10 Mojmap: `net/minecraft/world/entity/LivingEntity.java`, `onClimbable`, lines 1662–1678. After rejecting spectators, it tests `BlockTags.CLIMBABLE`, then the usable-trapdoor ladder case.

1.21.11 Mojmap: same file/member, lines 1669–1687. Before those tests, it returns false if `isFallFlying()` and the current block state is in `BlockTags.CAN_GLIDE_THROUGH`.

Resource dependency: 1.21.11 `data/minecraft/tags/block/can_glide_through.json` contains vines, twisting/weeping vines and `#minecraft:cave_vines`; this tag file is absent from the 1.21.10 resource set. The inherited player movement predicate therefore stops treating those blocks as climbable while fall-flying. It changes the `onClimbable` response used by fall-flying travel (and other callers); this is a bounded concrete movement difference. Whether it should be retained for a particular older profile depends on profile applicability and the lane's policy for this newer gliding interaction.

### Finite guards on direct velocity additions

1.21.10 `Entity.addDeltaMovement(Vec3)` at lines 3623–3625 unconditionally adds its argument. `Entity.push(Vec3)` and `push(double,double,double)` at 1751–1758 unconditionally add and set `hasImpulse`.

1.21.11 `Entity.addDeltaMovement(Vec3)` at lines 3649–3653 first requires `Vec3.isFinite()`. `Entity.push(Vec3)` at 1769–1772 requires `isFinite()`, and the scalar overload at 1775–1780 requires all three doubles finite; accepted input still adds the same components, and sets `needsSync` rather than `hasImpulse`.

Reachable callers include the local explosion packet response (`ClientPacketListener.handleExplosion` above) and overlap collision pushes (`Entity.push(Entity)`). For finite server-produced explosion vectors and finite entity positions, numerical motion is unchanged. The explicit delta is rejection of a non-finite impulse; whether malformed/non-finite packet data is in the target contract is unresolved. The changed impulse/sync bookkeeping is a server synchronization flag, not a client-side motion calculation.

### Lunge attack hook is new and server-only

1.21.11 adds `LivingEntity.lungeForwardMaybe()` at lines 1655–1659, called from `MultiPlayerGameMode.java:504` and `Player.java:1004` attack handling. `Player.lungeForwardMaybe()` at `world/entity/player/Player.java` lines 1571–1574 gates on enough food or mayfly before delegating. The inherited implementation calls `EnchantmentHelper.doLungeEffects` only when `level()` is a `ServerLevel`; no client-local lunge impulse is applied. This is new post-1.21.10 enchantment behavior, and authoritative resulting motion is server-produced. Disposition: no historical client response delta for this census.

### Server knockback calculations are not client-local movement

`LivingEntity.getKnockback` in 1.21.11 divides the computed enchantment-modified value by 2 (1.21.10: lines 1509–1511; 1.21.11: lines 1512–1514). `LivingEntity.knockback` also changes its impulse marker and random source, while retaining the same vector operation. The callers calculate damage/knockback on the logical server; the resulting player velocity is delivered through the unchanged `ClientboundSetEntityMotionPacket` path. Per project invariants, these server physics changes are not client historical movement and are not accepted as a local-response finding.

## Checked no-diff terminals

- Packet writes: position correction, direct motion packet, explosion knockback handoff, respawn/keep flags, synced pose/data, effect add/remove, attribute snapshots and equipment slots. No changed packet callback movement arithmetic or ordering.
- Piston push: `PistonMovingBlockEntity` byte hash identical; `Entity.move(MoverType.PISTON)` and piston restriction helper preserve their procedure; piston base difference is annotation-only.
- Environmental response methods: `BedBlock.fallOn`/`updateEntityMovementAfterFallOn`, `SlimeBlock.fallOn`/`updateEntityMovementAfterFallOn`, honey slide/fall callbacks, bubble column, powder snow, web, big dripleaf, nether portal, end portal and gateway. No changed callback body affecting the local player's position/velocity in this pair. Their callers remain `Entity.move`, `Entity.applyEffectsFromBlocks` and the block/fluid inside-callback traversal.
- Portal and dimension response: packet-position and respawn paths unchanged in their writes; `Entity.teleport` signatures only gain nullability annotations and the transfer path is server-side.
- Effect/attribute/equipment/pose synchronizers: event handlers and client effect installation unchanged. Attribute scale still refreshes dimensions; pose accessor still refreshes dimensions. No extra local movement delta found.
- Collision push: finite guards only change handling of non-finite input. Valid finite collision inputs retain the old motion addition.

## Open dependency

The finite-vector guard's exceptional non-finite input policy has not been traced through all packet codecs/modded runtime inputs. Vanilla server-generated explosion impulses and collision positions are finite. No server movement implementation, client runtime launch, game test, or gameplay scenario was used to infer broader reachability.
