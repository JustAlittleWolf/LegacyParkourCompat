# 1.21.10 → 1.21.11 source audit: player input, outer tick, pose, velocity gates

## Inputs and source identity

- Older: Minecraft 1.21.10, Mojmap, exact decompiled source root `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.21.10\mojmap`. Ready manifest SHA-256 `4be26049350c1b314a0b198022cb1e7ab1e745e104047de7a5c7d099a9d7b7e1`; client SHA-256 `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482`.
- Newer: Minecraft 1.21.11, Mojmap, exact decompiled source root `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.21.11\mojmap`. Ready manifest SHA-256 `0c4d83fef84c101d9db88f331acec7960f3c8346228c28995e6cf57bbfcae555`; client SHA-256 `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd`.
- Ready metadata matches the assigned versions/mapping family and the supplied manifest/client identities. Sources were read only.

## Ordered coverage roster and tick path

1. `client/Minecraft.runTick` runs the client tick path; with a level, `ClientLevel.tickEntities` ticks the local entity. `LocalPlayer.tick` then calls superclass player/living/entity ticks when the loaded gate passes.
2. `client/player/KeyboardInput.tick`, `ClientInput.tick`, and `world/entity/player/Input` input state record/normalize device input. Paired source bodies are unchanged. Keyboard/device event plumbing was not otherwise audited (out of scope).
3. `LocalPlayer.tick` sends input and movement after the player tick; this ordering is unchanged after the load gate. `LocalPlayer.applyInput` dispatches controlled-camera input to `modifyInput`; the input scaling code has the differences below.
4. `LocalPlayer.aiStep` updates crouch, ticks input, handles sprint triggers and flight toggles, then delegates through `Player.aiStep` to living travel. The two listed pre-travel differences were inspected in context; unrelated attack, item, rendering, damage and network logic was excluded.
5. `Player.tick` invokes `updatePlayerPose`; desired pose ordering and fit tests are unchanged. `Entity.refreshDimensions`, `fixupDimensions`, `fudgePositionAfterSizeChange`, `getDimensions`, `EntityDimensions` and `LivingEntity.getDimensions` were compared; no difference found in this slice.
6. `LivingEntity.onClimbable` feeds living travel's climb handling. Changed gate is listed below. General `travel` math/fluids/collisions and block shape providers belong to other discovery slices and are not claimed closed here.
7. `Entity.setDeltaMovement`, `addDeltaMovement`, `push`, and `setPosRaw` were compared as player-reachable velocity/position writers. The first three changed as listed; `setPosRaw` is unchanged. `hasMovedHorizontallyRecently` and `getKnownSpeed` are new generic accessors/bookkeeping; a source-wide search found no player movement consumer for `hasMovedHorizontallyRecently` and no additional local input/pose consumer. Other event writers and downstream collision/shape consumers are outside this slice.

## Concrete source differences

### Item-use movement multiplier and sprint eligibility

- 1.21.10: `net/minecraft/client/player/LocalPlayer.java`, `modifyInput`, lines 627–643: nonzero move input is scaled by `0.98F`, then by fixed `0.2F` while using an item and not a passenger; `canStartSprinting`, lines 1062–1069, rejects any item use; `aiStep`, lines 722–724, clears sprint trigger during any non-passenger item use.
- 1.21.11: same file, `modifyInput`, lines 669–686: item-use scaling uses `UseEffects.speedMultiplier()`; new `isSlowDueToUsingItem` tests active use and `!UseEffects.canSprint()`. `aiStep`, lines 762–765, and `canStartSprinting`, lines 1102–1109, use that predicate.
- Difference: item-use penalty and sprint suppression now depend on item `USE_EFFECTS` data; the former fixed 0.2 and blanket sprint rejection are gone. With an active item whose multiplier differs from 0.2, input magnitude changes. With `canSprint=true`, item use no longer clears the sprint trigger or prevents sprint start. Passenger exclusions remain in the input/sprint-trigger conditions as shown. The food condition was also traced: 1.21.10 `hasEnoughFoodToSprint` requires food `> 6.0F` or mayfly (with passengers accepted); 1.21.11 routes non-passengers through `Player.hasEnoughFoodToDoExhaustiveManoeuvres` → `FoodData.hasEnoughFood`, also `getFoodLevel() > 6.0F`, or mayfly, while passengers require the same vehicle-sprint gate. That refactor has no food-threshold difference.

### Flight toggle while riding

- 1.21.10: `LocalPlayer.java`, `aiStep`, lines 758–770: after the jump double-tap window, a mayfly player toggles flight when not swimming, without checking vehicle type.
- 1.21.11: same method, lines 799–811: toggling additionally requires `getVehicle() == null || jumpableVehicle() != null`.
- Difference: a mayfly player pressing the toggle sequence while mounted on a non-`PlayerRideableJumping` vehicle no longer changes flight state. Spectator always-flying gate is behaviorally equivalent: 1.21.10 `MultiPlayerGameMode.isAlwaysFlying` returns `localPlayerMode == SPECTATOR` (line 512); 1.21.11 `isSpectator` returns the same expression (line 520).

### Fall-flying climbable predicate

- 1.21.10: `net/minecraft/world/entity/LivingEntity.java`, `onClimbable`, lines 1662–1677: after the spectator gate, `BlockTags.CLIMBABLE` is tested first, then open ladder-backed trapdoors.
- 1.21.11: same file, `onClimbable`, lines 1669–1687: before those same branches, fall-flying entities in a `BlockTags.CAN_GLIDE_THROUGH` state return false.
- Difference: when a player is fall-flying and its current in-block state belongs to `CAN_GLIDE_THROUGH`, it can no longer enter climb handling even if the state is also climbable or is a ladder-backed trapdoor. This changes the pre-travel climb slowdown/velocity handling. The precise runtime overlap of the two tags is not established by these Java source roots; tag membership remains a dependency for the concrete block set.

### Finite velocity writers

- 1.21.10: `net/minecraft/world/entity/Entity.java`, `push(Vec3)` lines 1751–1753 and `push(double,double,double)` lines 1755–1758, unconditionally forward/write velocity and mark impulse. `setDeltaMovement(Vec3)` / `addDeltaMovement(Vec3)` lines 3619–3625 unconditionally store/add.
- 1.21.11: same methods at lines 1776–1780 and 3643–3653: `push(Vec3)` requires finite input; scalar push requires each component finite; `setDeltaMovement(Vec3)` and `addDeltaMovement(Vec3)` require `Vec3.isFinite()` before writing. `setDeltaMovement(double,double,double)` still constructs a `Vec3` and delegates.
- Difference: non-finite values supplied through these writers are ignored in 1.21.11 rather than stored/added. Any player path reaching one of these writes with NaN or infinity therefore retains the prior finite velocity (and push does not mark sync) instead of propagating the invalid component. Ordinary finite writes preserve their operation order. This is a generic entity writer used by players; source caller enumeration outside local-player/living movement remains unclosed.

### Local player loaded gate / outer tick

- 1.21.10: `net/minecraft/client/player/LocalPlayer.java`, `tick`, lines 195–219 calls `tickClientLoadTimeout()` then runs player logic if `hasClientLoaded()`. The inherited `Player` state/methods at `net/minecraft/world/entity/player/Player.java`, lines 155–156 and 1875–1889, release the gate on the loaded packet or after the 60-tick timer expires.
- 1.21.11: `LocalPlayer.tick`, lines 211–234, runs only if `connection.hasClientLoaded()`. `net/minecraft/client/multiplayer/ClientPacketListener.java`, lines 2740–2746, is a plain boolean; there is no timeout fallback in this gate. Packet notification is at lines 2661–2665.
- Difference: if the loaded notification is delayed or absent for more than 60 ticks, 1.21.10 starts local player ticks via timeout and 1.21.11 continues to suppress `super.tick`, movement packet updates, and ambient handlers until notification. This is a reachable startup/tick gate; normal packet timing is outside source-only proof.

## Checked no-difference slices

- `client/player/KeyboardInput.java`, `ClientInput.java`, `world/entity/player/Input.java`: paired file diffs empty; input normalization and button-state representation unchanged.
- `LocalPlayer.applyInput` controlled-camera/noncontrolled-camera dispatch and square-normalization helper: unchanged apart from the item-use multiplier described above. The sprint food predicate refactor in `Player.hasEnoughFoodToDoExhaustiveManoeuvres` / `FoodData.hasEnoughFood` is behaviorally equivalent to the old `> 6.0F` check and mayfly exception.
- `Player.tick` movement-related order (`noPhysics`/on-ground setup, superclass tick, pose update), `Player.updatePlayerPose`, `getDesiredPose`, and `canPlayerFitWithinBlocksAndEntitiesWhen`: unchanged. The 1.21.11 `itemSwapTicker` increment is unrelated to movement.
- `Entity` position writer `setPosRaw`, pose dimensions refresh/reposition path, and paired `EntityDimensions.java`: no movement-relevant difference found.
- `LocalPlayer.sendPosition` coordinate/rotation/status thresholds and packet selection are unchanged; only its entry remains behind the loaded gate above.
- `MultiPlayerGameMode.isAlwaysFlying` → `isSpectator` rename is behaviorally equivalent (same mode equality expression), and no behavior difference was counted.

## Dependency closure and limits

- Source identities are verified and all listed methods were paired with complete enclosing gates/ordering. Input → LocalPlayer tick → Player/LivingEntity pre-travel → pose/dimensions and core velocity writer coverage is closed for this assignment.
- `BlockTags.CAN_GLIDE_THROUGH`/`CLIMBABLE` runtime memberships are not included as Java source declarations here, so block-level overlap for the climbing finding needs data/tag verification by the coordinating audit.
- Generic writer call sites beyond player/living/local movement, block/shape providers and callbacks, fluids, equipment/effect modifiers other than the new `UseEffects` access, and all remaining player movement/travel slices are explicitly not audited by this lane worker.
- This is discovery evidence only; no implementation, testing, game launch, or parity claim was made.

