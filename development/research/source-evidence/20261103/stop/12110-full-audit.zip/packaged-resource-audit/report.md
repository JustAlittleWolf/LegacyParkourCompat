# Packaged resource audit: 1.21.10 → 1.21.11

## Scope and identity

Read-only comparison of exact packaged vanilla client resources for block tags and built-in dimension types relevant to the assigned movement-resource slice. No decompiled code, product implementation, wiki, or project history was consulted.

Inputs: `.native-source/20261103/resource-inputs/1.21.10/client.jar` and `.../1.21.11/client.jar`, with extracted `data/minecraft/tags/` and `data/minecraft/dimension_type/` trees and per-version `resource-manifest.json` files.

The client JAR SHA-256 values match the manifest source-publication pins:

| Version | Manifest `clientSha256` | Actual `client.jar` SHA-256 | Result |
|---|---|---|---|
| 1.21.10 | `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482` | same | match |
| 1.21.11 | `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd` | same | match |

The manifest `currentMetadataSha256` values also match their adjacent `current-version-metadata.json` files. Both manifests explicitly have `historicalMetadataMatch: false` and describe current catalog metadata only as a download locator, not the historical identity. Therefore source identity here is established by the JAR pins; the current metadata hash is not treated as a historical pin.

Each present resource listed below matches its exact `files[].sha256` manifest pin. The 1.21.10 absence of `data/minecraft/tags/block/can_glide_through.json` is also reflected by no matching manifest entry. The built-in `data/minecraft/dimension_type/` directory contains the same four names on both sides: `overworld.json`, `overworld_caves.json`, `the_end.json`, and `the_nether.json`.

## Block tags

### `data/minecraft/tags/block/climbable.json`

Present on both sides with identical ordered membership:

1. `minecraft:ladder`
2. `minecraft:vine`
3. `minecraft:scaffolding`
4. `minecraft:weeping_vines`
5. `minecraft:weeping_vines_plant`
6. `minecraft:twisting_vines`
7. `minecraft:twisting_vines_plant`
8. `minecraft:cave_vines`
9. `minecraft:cave_vines_plant`

Hashes are identical on both sides: `d0e3e76d7457f3f3f3d7219fe218c7746e4b2e7626d5c388fcf193089069e365`. No package-level climbable membership difference is present.

### `data/minecraft/tags/block/can_glide_through.json`

Absent in 1.21.10 (no extracted file and no manifest entry); added in 1.21.11 with ordered values:

1. `minecraft:vine`
2. `minecraft:twisting_vines`
3. `minecraft:twisting_vines_plant`
4. `minecraft:weeping_vines`
5. `minecraft:weeping_vines_plant`
6. `#minecraft:cave_vines`

The final value is a nested tag reference, closed by the separately packaged `cave_vines` tag below. The tag membership is a package-level classification difference. Its runtime/player movement consumer and concrete consequence are not established by this resource-only audit.

### `data/minecraft/tags/block/cave_vines.json`

Present and byte-identical on both sides, ordered values `minecraft:cave_vines_plant`, then `minecraft:cave_vines`; SHA-256 `b936bbb57d972003dda38f1d3584e3749915f26220843b941fc2571ef901c75a`. The nested reference in the new `can_glide_through` tag therefore resolves to those two entries within the inspected vanilla tag tree.

## Built-in dimension types

The same four built-in dimension type paths are present on both sides. The 1.21.10 JSONs use top-level legacy fields including `bed_works`, `has_raids`, `natural`, `piglin_safe`, `respawn_anchor_works`, `ultrawarm`, plus dimension-specific `effects`, `fixed_time`, and `cloud_height`. The 1.21.11 JSONs instead include an `attributes` object, `timelines`, and other renamed/relocated presentation or gameplay settings; the Nether also has `cardinal_light`, and the End has `skybox`/`has_fixed_time`. Resource manifests pin all eight compared JSON files and the extracted bytes match those pins.

### FAST_LAVA classification

In 1.21.11 `data/minecraft/dimension_type/the_nether.json`, `attributes` contains the explicit entry `"minecraft:gameplay/fast_lava": true`. None of the other three 1.21.11 built-in dimension type JSONs contains that attribute. In 1.21.10, none of the four built-in JSONs has a `fast_lava` key or equivalent named attribute; `the_nether.json` instead has the legacy top-level `"ultrawarm": true` field.

Thus the packaged-resource evidence identifies `minecraft:gameplay/fast_lava` as a new explicit dimension-type configuration capability in the newer resource schema, with the built-in Nether configured true. It does **not** establish that `ultrawarm` is a historical semantic equivalent, nor how custom dimension data is interpreted by runtime code. Any claim that custom dimensions can use or override the setting is a schema-level inference from the placement of the key in dimension-type `attributes`; custom data loading and gameplay behavior remain outside this bounded resource-only audit. There is no historical counterpart in the inspected 1.21.10 resource fields by the same name.

## Bounded closure and gaps

- Examined and hash-verified: the three assigned tag paths (including the absent path), all four built-in dimension type JSON paths on each side, both client JAR pins, both metadata locator hashes, and all relevant manifest entries.
- Paired/closed package inventory: identical climbable membership; identical cave-vines nested-tag membership; new can-glide-through tag and its resolved cave-vines reference; same built-in dimension type filenames with a schema/field migration and the explicit Nether FAST_LAVA attribute in 1.21.11.
- Not examined: code consumers of tags/attributes, custom-dimension loading, runtime movement consequences, or any other packaged resources. These require source-code coverage outside this assignment and are not inferred here.
