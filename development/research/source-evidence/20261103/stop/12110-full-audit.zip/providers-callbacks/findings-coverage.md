# 1.21.10 → 1.21.11: providers and callbacks

## Inputs / identity

- Exact source roots: `decompiled_minecraft/1.21.10/mojmap` and `decompiled_minecraft/1.21.11/mojmap` in the supplied primary checkout (`D:\Javastuff\LegacyParkourCompat`). Pair manifest/client identities supplied by the coordinator: 1.21.10 manifest `4be26049350c1b314a0b198022cb1e7ab1e745e104047de7a5c7d099a9d7b7e1`, client `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482`; 1.21.11 manifest `0c4d83fef84c101d9db88f331acec7960f3c8346228c28995e6cf57bbfcae555`, client `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd`. Mojmap on both sides. Paired source members read directly; no regeneration.
- Owned inventory: collision traversal/provider (`CollisionGetter`, `BlockGetter`, `BlockCollisions`, `BlockBehaviour.BlockStateBase`, `Block`, `EntityCollisionContext`, voxel shape transforms); block/shape factories and registrations (`Blocks` and block subclasses overriding shape/collision/inside/step/fall/land callbacks); direct player callbacks in `Entity`/`LivingEntity`/`Player`; fluid provider and lava classification; block/fluid tags and data-gen membership; dimension/environment attribute registration and lookup. Followed inherited calls for surfaced behavior.
- Method inventory was built from both source roots before comparing. Compared paired bodies for 495 existing block-package methods matching shape providers, callbacks and movement/block predicates; inspected all paired results that differed after whitespace normalization. Also inspected the core collision traversal and state-shape cache/provider methods and exact FAST_LAVA/CAN_GLIDE_THROUGH call graphs.

## Findings

### Fast lava changes from `ultraWarm` to a dimension attribute

1.21.10 Mojmap: `net/minecraft/world/entity/Entity.java`, `updateInWaterStateAndDoFluidPushing`, line 1486, selects lava-push coefficient `0.007` vs `0.0023333333333333335` from `level().dimensionType().ultraWarm()`; `net/minecraft/world/level/material/LavaFluid.java`, `getSlopeFindDistance` line 152, `getDropOff` line 167, `getTickDelay` line 177 use the same predicate for `4/2`, `1/2`, `10/30`.

1.21.11 Mojmap: `Entity.java`, `updateInWaterStateAndDoFluidPushing`, line 1504, and `LavaFluid.java`, `getSlopeFindDistance` line 150, `getDropOff` line 165, `getTickDelay` line 175 call `isFastLava`; helper lines 234–235 reads `environmentAttributes().getDimensionValue(EnvironmentAttributes.FAST_LAVA)`.

Difference: all four consumers now share `FAST_LAVA`, rather than the dimension type's `ultraWarm` flag. A player in lava gets the higher fluid-push coefficient when this attribute is true; lava propagation also changes distance, level drop-off and delay and can change the fluid volume/position encountered by the player. This is reachable for dimension configurations where `FAST_LAVA` differs from `ultraWarm`.

Provider closure: `world/attribute/EnvironmentAttributes.java:126–128` registers `gameplay/fast_lava` as boolean, default false, non-positional and syncable. `world/level/dimension/DimensionType.java:39,49–50,95` carries `EnvironmentAttributeMap` in its dimension type and direct/network codecs; `world/attribute/EnvironmentAttributeMap.java:19–24` codecs those maps. `data/worldgen/DimensionTypes.java:57–86` explicitly sets Nether `FAST_LAVA=true`; default elsewhere is false. Search of the full 1.21.11 Mojmap Java root found only the declaration, this Nether classification, and the two consumers. Vanilla's built-in Nether retains fast lava; custom dimension data can classify independently of `ultraWarm` (custom runtime data not supplied).

### Fall-flying entities no longer count as climbing in tagged blocks

1.21.10 Mojmap: `net/minecraft/world/entity/LivingEntity.java`, `onClimbable`, line 1662 onward, checks spectator, then `BlockTags.CLIMBABLE`, then usable open trapdoor; no fall-flying exclusion.

1.21.11 Mojmap: `LivingEntity.java`, `onClimbable`, line 1669 onward, first returns false when `isFallFlying()` and current `getInBlockState()` is in `BlockTags.CAN_GLIDE_THROUGH`, before unchanged climbable and trapdoor checks. The method feeds living travel/collision decisions at lines 2400, 2442, 2539, 2562 and 3204; `Player.onClimbable` delegates unless creative-flying. `data/tags/VanillaBlockTagsProvider.java:320–324` places vines, twisting/weeping vines and cave vines (including plant variants through nested tags) in the new tag; `tags/BlockTags.java:125` declares it.

Difference: while fall-flying through a tagged climbable block, the player predicate now suppresses climbable handling. This changes climb response/branching for elytra contact with those blocks. Membership is data-driven; custom tag membership can expand reachability. Vanilla members are source-confirmed.

### Entity collision push now ignores non-finite vectors (conditional edge)

1.21.10 Mojmap: `net/minecraft/world/entity/Entity.java`, `push(Vec3)` line 1751 and `push(double,double,double)` line 1755 always add the supplied delta to velocity and set `hasImpulse=true`.

1.21.11 Mojmap: `Entity.java`, `push(Vec3)` lines 1769–1773 tests `Vec3.isFinite()`; scalar overload lines 1775–1781 tests all three components with `Double.isFinite`, then adds velocity and sets `needsSync=true`.

Difference: a non-finite push vector no longer contaminates player velocity. The in-source collision path `Entity.push(Entity)` (old around 1719; new around 1737) can derive NaN components if horizontal positions are non-finite: infinite separation passes its `>= 0.01F` gate, division by infinite square root produces NaN, then dispatches to `push(double,...)`. Normal finite entity positions produce finite vectors, so I did not establish a reachable ordinary parkour-map precondition; retain as a conditional direct-response delta for the integrator to classify. The finite-vector path keeps the same velocity addition and order.
## Checked slices / no source behavior change found

- `CollisionGetter.noCollision` was split into block/entity/border predicates in `world/level/CollisionGetter.java` (1.21.11 lines 49–77); old short-circuit order/results are preserved, including null-entity border handling. `BlockCollisions` traversal has nullable annotation changes only; iteration logic is unchanged.
- Across the 495 paired block-package methods, no further player movement delta was found. In the external Entity response slice, finite collision pushes are unchanged; the non-finite guard is recorded separately above. The changed callback bodies in `CropBlock`, `FarmBlock`, and `PowderSnowBlock` only migrate the mob-griefing rule API/name; `RedStoneWireBlock` and `BlockBehaviour` changes to indirect-neighbor signatures are annotations. `WetSpongeBlock.onPlace` changes its water evaporation gate from `ultraWarm` to `WATER_EVAPORATES` (world/environment behavior, no direct player movement response). A `PitcherCropBlock.entityInside` count mismatch in the automated roster is a decompiler/source shape discrepancy and its paired source block was checked manually; its body has no movement response change.
- `BlockBehaviour` shape/collision forwarding and cached `BlockStateBase` shape selection have no changed behavior. `Block.java` has no changed shape or player callback math. `EntityCollisionContext` differs only in nullable annotations.
- `Shapes` rotation API plumbing/helper changed. The inspected transforms retain the same per-axis mapping and transform math (old `offset + direction * (coord - origin)` vs new signed-coordinate-plus-offset expression). A full source-root search found the new `OctahedralGroup` horizontal-rotation overload only in `StairBlock` top shapes (three calls); each replaces the old `rotateHorizontal(rotate(shape, INVERT_Y))` composition with the equivalent composed rotation. Other shape rotations use the existing no-group or center-offset overloads.
- `Blocks` adds registrations for new 1.21.11 blocks and shifts static registration offsets. Existing paired block factories/callback bodies were covered by the method roster; the newly introduced blocks have no 1.21.10 counterpart and are outside the historical profile's feature set. `BlockTags` adds `CAN_GLIDE_THROUGH`; other declarations only rename `ResourceLocation` to `Identifier`.

## Remaining limits

- Checked and closed: paired existing block-package shape/callback/predicate method bodies (495); core collision iteration and state-shape forwarding/cache; both movement findings' callers and provider/classification graph.
- The paired Java code inventory is closed for the assigned methods and all newly introduced grouped rotation call sites. External data is not: generated tag resources and arbitrary datapack/mod-supplied custom tag or dimension contents were not present in supplied Mojmap Java roots.
- Java data-generation sources were checked for the new tag and dimension assignment. Generated resource/tag files and arbitrary datapack/mod-supplied custom tag or dimension data were not present in the supplied Java roots; runtime custom contents remain unknown.


