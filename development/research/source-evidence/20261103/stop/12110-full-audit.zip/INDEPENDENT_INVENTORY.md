# Independent source-audit inventory: 1.21.10 → 1.21.11

## Inputs and identity

- Exact releases: 1.21.10 → 1.21.11; Mojmap on both sides.
- Canonical read-only sources: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft\1.21.10\mojmap` and `...\1.21.11\mojmap`.
- 1.21.10 ready source manifest SHA-256: `4be26049350c1b314a0b198022cb1e7ab1e745e104047de7a5c7d099a9d7b7e1`; 6,386 source files. Client SHA-256: `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482`.
- 1.21.11 ready source manifest SHA-256: `0c4d83fef84c101d9db88f331acec7960f3c8346228c28995e6cf57bbfcae555`; 6,622 source files. Client SHA-256: `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd`.
- Mapping namespace, exact versions, manifest counts, and source roots verified against both `.ready.json` sidecars before comparison. Source trees remain read-only.

## Complete reachable player movement inventory and terminal dependencies

1. **Input and outer client tick**: key mappings/options and input sampling (`Input`, keyboard/controller input); client main tick scheduling; local player tick ordering, input application, sprint/sneak/jump/flight/swim/action gates; native/client/server ownership gates. Trace input writes through `LocalPlayer` and `Player`.
2. **Player pre-travel state and branches**: `Player`, `LivingEntity`, `Entity` inherited tick/aiStep; pose selection and dimension refresh; jump/sprint/swim/glide/fall-flying/slow-fall/levitation/climb/step/vehicle gates; attribute and effect reads; equipment and item-use reads.
3. **Travel and post-travel**: each `travel` branch and caller (`LocalPlayer`/`Player`/`LivingEntity`/`Entity`); acceleration, gravity, friction, drag, buoyancy, fluid currents, climbing, elytra/gliding and riptide; post-move velocity resets, fall-distance and movement-state updates.
4. **Position, velocity, box and collision writers/consumers**: all reachable setters/packet corrections/direct player responses; `Entity.move`, `moveRelative`, `setPos`/position setters, velocity setters, bounding-box/dimension writers; AABB/voxel math, stepping, clipping, block/entity collisions, suffocation and on-ground/horizontal/vertical collision flags. Follow every called terminal helper and write consumer.
5. **World/fluid and neighboring-block dependency graph**: block collision state lookup, `CollisionGetter`/`BlockGetter`/`LevelReader` and chunk access; fluid state/height/flow and water/lava tests; climbing, powder snow, bubble columns, slime/honey/ice/blue ice/soul sand/magma, scaffolding, trapdoors, fences/walls, doors/gates and other state-sensitive movement predicates.
6. **Shapes and providers**: vanilla blocks existing in the selected era, shape methods and state/property branches; block/item/fluid registries and factory/provider dispatch; entity-vs-block collision contexts; shape aggregation/voxel shapes/AABB terminals; resources/tags affecting runtime state classification. Include new or removed providers and check absences on both sides.
7. **Callbacks and external direct player movement responses**: block/entity inside/collision callbacks, piston pushes, explosions, projectiles/attacks that directly affect player motion, knockback, portals/teleport/respawn/server correction and event callbacks; inherited callbacks and callers. Exclude non-player physics, rendering, damage/health/food production and bed-entry eligibility while retaining any direct player movement response.
8. **Attributes/effects/equipment/items**: player-reachable attribute modifiers and recalculation, status effect application/removal and movement predicates, armor/equipment, food exclusions; item-use paths that directly modify player motion. Confirm modern-only introductions preserve native fallback.
9. **Resources/tags/configuration**: packaged vanilla resource/data assets that determine movement tags/provider membership/fluid IDs/block states; registries/bootstrap and dynamic dispatch connections. Static assets are terminal dependencies where a source predicate delegates to tags/data.
10. **No difference / exclusion accounting**: check relevant terminal slices for both changed and unchanged source bodies; additions/removals with replacement or checked absence; explicitly isolate excluded rendering/vehicle/non-player/health/damage behavior.

## Independent audit status

This inventory is the pre-closure roster. Domain workers were assigned only after writing it. Pair closure requires paired evidence for each terminal slice and an independent audit; this file alone is not closure evidence.
