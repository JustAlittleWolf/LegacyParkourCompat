# 1.21.8 → 1.21.10 tick/travel source comparison (bounded findings)

Scope examined: Mojmap `ClientLevel`, `LocalPlayer`, `KeyboardInput`, player `Input`, `Player`, `LivingEntity`, and `Entity` source files across 1.21.8, 1.21.9, 1.21.10. This records high-confidence deltas found in this pass; it is not a closure of the full movement inventory.

## Input and sprint decision

Primary paths (exact version roots):

- `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/1.21.8/mojmap/net/minecraft/client/player/LocalPlayer.java`
- Same path under `1.21.9` and `1.21.10`.
- Mojmap symbol names are `LocalPlayer.aiStep`, `canStartSprinting`, and `isSprintingPossible`.

| Release | Evidence | Result |
|---|---|---|
| 1.21.8 | `LocalPlayer.java:1065-1075` `canStartSprinting`: requires `(!isInWater() || isUnderWater())`; `aiStep` invokes this at `:722` before enabling sprint. | In-water sprint start is gated by `isUnderWater()` regardless of flight. Shallow water therefore blocks sprint start, including while ability-flying. |
| 1.21.9 | `LocalPlayer.java:1055-1069`: `isSprintingPossible(boolean flying)` returns `!isMobilityRestricted() && hasEnoughFoodToSprint() && passengerGate && (flying || !isInShallowWater())`; `canStartSprinting` passes `getAbilities().flying` at `:1062-1069`. `aiStep` calls it at `:726`. | Shallow-water block is bypassed when ability-flying is true. This is the opposite of the proposed claim “1.21.9 flying in shallow water prevents sprinting”: source logic allows starting sprint in that state, subject to the other gates. For non-flying players the helper rejects shallow water. |
| 1.21.10 | Same `LocalPlayer.java:1055-1069` logic as 1.21.9; full LocalPlayer file SHA-256 is identical between these releases. | No 1.21.9→1.21.10 change in this sprint decision. |

Additional release delta in 1.21.9: `LocalPlayer.aiStep` initializes `sprintTriggerTime` from `minecraft.options.sprintWindow().get()` (`:731`), versus constant `7` in 1.21.8 (`:727`). This affects double-tap sprint timing, not the flying/shallow-water predicate.

Direct state writer: within `aiStep`, the successful path calls `setSprinting(true)`; when already sprinting, the branch at `LocalPlayer.java:736-747` (1.21.8) / `:740-747` (1.21.10) may stop sprint through the swim/run stop predicates. The flying/shallow-water claim is specifically settled for *starting* sprint by `canStartSprinting`; stop-branch behavior is a separate path.

## Tick/travel call-path evidence and file-level comparison

Mojmap names/path mapping confirmed from source tree paths. The local-player tick/AI/move method locations are 1.21.8 `LocalPlayer.java:197,683,916` (`tick`, `aiStep`, `move`), and 1.21.9/1.21.10 `:195,687,906`. `Player`, `LivingEntity`, then `Entity` provide inherited tick/travel/movement operations; exact ordering and all inherited call edges have not been exhaustively line-traced in this bounded pass.

Full source SHA-256 (prefixes) show `KeyboardInput.java` and player `Input.java` identical across all three releases; `ClientLevel.java`, `LocalPlayer.java`, `Player.java`, and `LivingEntity.java` differ 1.21.8→1.21.9 but are byte-identical 1.21.9→1.21.10. `Entity.java` differs on both intervals, so no-difference is not established for its complete movement/callback graph.

A reviewed 1.21.8→1.21.9 `Entity.move` hunk changes no-physics path to clear horizontal/vertical collision flags; caps fall-damage-reset ray length at 8 blocks; and changes `addMovementThisTick`'s movement flag from constant `true` to requested movement `$$1`. These are candidate movement-state changes requiring lane-level dependency closure. The 1.21.9→1.21.10 `Entity.move` hunk changes stuck-speed application so it is skipped for `MoverType.PISTON`, while still clearing stuck-speed and delta movement. 1.21.10 also changes inside-block callback tracing and passes an extra boolean into `entityInside`; possible direct player movement effects depend on the block callback implementations and were not closed here.

## Provenance and limitations

`resource-inputs` provides client SHA-256 pins for 1.21.8 (`ea74e9c5e92d01f95f3d39196ddb734e19a077a58b4c433c34109487d600276f`) and 1.21.10 (`e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482`); both manifest identities state client bytes match historical source-publication SHA-256 pins. No `resource-inputs/1.21.9` exists in the permitted inputs, so intermediate artifact/resource identity is unresolved. The source tree is the authorized exact Mojmap input; source byte hashes were computed in place, not by decompiling or consulting online mappings.

Open dependencies for full acceptance: exact 1.21.9 provenance/resource identity; inherited tick and travel operation order; mobility restriction and shallow-water predicates' provider/state dependencies; full `Entity.move` consumers/callback effects; and the remaining inventory topics (collision/query, fluid/block providers, post-move callbacks, packets/effects/abilities/equipment). No acceptance claim is made for those topics.

