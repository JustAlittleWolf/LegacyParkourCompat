# noPhysics movement collision flags

1.21.8, Mojmap: `net/minecraft/world/entity/Entity.java`, `move` lines 663–666.
1.21.9 and 1.21.10, Mojmap: `net/minecraft/world/entity/Entity.java`, `move` lines 670–677.
1.21.8, Mojmap: `net/minecraft/world/entity/player/Player.java`, `tick` line 282 sets `noPhysics = isSpectator()`; 1.21.9 and 1.21.10: `Player.tick` lines 240–244 do the same. LocalPlayer inherits this path.

Difference: In 1.21.8, the `noPhysics` branch moves the entity with `setPos` and does not clear collision fields. Starting in 1.21.9, after moving it sets `horizontalCollision`, `verticalCollision`, `verticalCollisionBelow`, and `minorHorizontalCollision` to false. The remainder of normal collision handling is bypassed in both versions.

Movement meaning: A spectator local player reaches this branch through the inherited Entity movement path. On a no-physics movement step, 1.21.9 clears stale collision state while 1.21.8 leaves it. `LocalPlayer.sendPosition` reads `horizontalCollision` when constructing movement/status packets, so this also changes the reported local-player collision flag under the same gate. Ordinary colliding player movement does not enter the changed branch.
