# Fall-distance reset clip reach

1.21.8, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, fall-distance-reset clip around lines 685–692.
1.21.9 and 1.21.10, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, fall-distance-reset clip around lines 696–705 (1.21.9) and 699–708 (1.21.10).

Difference: Under the unchanged gate `fallDistance != 0.0 && actualMovement.lengthSqr() >= 1.0`, 1.21.8 clips from the entity’s starting position to `position + actualMovement`. Starting in 1.21.9 the clip distance is `min(actualMovement.length(), 8.0)` and the endpoint is `position + normalize(actualMovement) * distance`. The clip still uses `ClipContext.Block.FALLDAMAGE_RESETTING`, `ClipContext.Fluid.WATER`, and the entity as context; a hit still resets fall distance. The operation is unchanged in 1.21.10.

Movement meaning: A local player with existing fall distance and a resolved movement of length at least 1 reaches this collision query. For movement longer than 8 blocks, the 1.21.9 query cannot detect a reset block lying only beyond the 8-block clipped segment, while 1.21.8 queries along the full resolved movement. This directly changes the player’s fall-distance state and may affect subsequent fall handling; no damage calculation is included.
