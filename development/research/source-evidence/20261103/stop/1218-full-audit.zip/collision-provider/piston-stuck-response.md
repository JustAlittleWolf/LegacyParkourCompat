# Piston movement while carrying a block-stuck multiplier

1.21.8 and 1.21.9, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, stuck-speed handling around lines 676–680 (1.21.8) and 687–691 (1.21.9); no mover-type exception is present.
1.21.10, Mojmap: `net/minecraft/world/entity/Entity.java`, `move`, stuck-speed handling lines 687–694.
All three releases: `net/minecraft/world/level/block/piston/PistonMovingBlockEntity.java`, `moveEntityByPiston` line 188 calls `move(MoverType.PISTON, …)`; `moveCollidedEntities` and `tick` call the piston movement path. `net/minecraft/world/entity/player/Player.java`, `makeStuckInBlock` sets the inherited multiplier unless the player is flying (1.21.8 lines 1571–1577; 1.21.9 line 1428 and following; 1.21.10 corresponding method).

Difference: 1.21.8 and 1.21.9 multiply every nonzero movement request by `stuckSpeedMultiplier` when its squared length exceeds `1.0E-7`, then clear that multiplier and zero delta movement. In 1.21.10 this same block skips only the multiplication when `MoverType.PISTON`; it still clears the multiplier and zeroes delta movement. This is no change in 1.21.9; the boundary is between the supplied 1.21.9 and 1.21.10 sources.

Movement meaning: When a non-flying player has a pending block-stuck multiplier and a moving piston pushes it, 1.21.8/1.21.9 scale the piston displacement by the multiplier, while 1.21.10 applies the capped piston displacement unscaled. The player can acquire the multiplier through the normal block-effect path. This is a direct player displacement response to a piston, independent of the fact that piston motion is commonly also simulated by the server.
