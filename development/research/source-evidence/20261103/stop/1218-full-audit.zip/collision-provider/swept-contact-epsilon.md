# Swept-shape contact epsilon

1.21.8, Mojmap: `net/minecraft/world/phys/AABB.java`, `collidedAlongVector` lines 395–410; `net/minecraft/world/entity/Entity.java`, `collidedWithShapeMovingFrom` / `collidedWithFluid` lines 1186–1195 and block-effect callback lines 1138–1176.
1.21.9 and 1.21.10, Mojmap: `net/minecraft/world/phys/AABB.java`, `collidedAlongVector` lines 395–410; `net/minecraft/world/entity/Entity.java`, `collidedWithShapeMovingFrom` / `collidedWithFluid` lines 1237–1245 in 1.21.9 and 1242–1250 in 1.21.10.

Difference: In 1.21.8, `collidedAlongVector` inflates each contacted AABB by half the moving box size on each axis. In 1.21.9 and 1.21.10 it subtracts `1.0E-7` from each of those three inflation amounts before testing whether either endpoint lies inside the expanded AABB or whether `AABB.clip` finds an intersection. The release-to-release gate changes only the contact epsilon; the call chain is retained in 1.21.10.

Movement meaning: `Entity.collidedWithShapeMovingFrom` applies this test to the player box swept from the segment start to its end. `checkInsideBlocks` uses that result to decide whether a block’s entity-inside callback runs; `collidedWithFluid` uses it for fluid callbacks. Near-boundary contact can consequently start or suppress a movement-affecting block or fluid response. The exact outcome depends on the traversed shape and coordinates; no runtime trajectory is inferred here.
