# 1.21.8–1.21.10 player-movement resource closure

## Input and package verification

| Release | Client JAR SHA-256 | Additional identity check | Packaged resource snapshot |
|---|---|---|---|
| 1.21.8 | `ea74e9c5e92d01f95f3d39196ddb734e19a077a58b4c433c34109487d600276f` (matches local resource manifest) | SHA-1 `a19d9badbea944a4369fd0059e53bf7286597576` matches the supplied current metadata locator; that metadata is not the historical metadata identity (`historicalMetadataMatch=false`). | 593 manifest-listed JSON resources; selected entries verified in the client JAR and extracted files. |
| 1.21.9 | `40c0a32c46601f71f6a61dae9f126202ded5cc453cfb8da6e42ae73f2a3f5c1b`, matches `client.jar.pin.json` | `version.json` SHA-256 `3cca801f41f83059092c88f7de3ea74247da4c394f3e672b7a41451151c293d5` matches `version.json.pin.json`; pinned metadata identifies 1.21.9 and its client locator. | The canonical pinned client JAR was read directly; selected entries were present and hashed from ZIP bytes. |
| 1.21.10 | `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482` (matches local resource manifest) | SHA-1 `d3bdf582a7fa723ce199f3665588dcfe6bf9aca8` matches the supplied current metadata locator; that metadata is not the historical metadata identity (`historicalMetadataMatch=false`). | 616 manifest-listed JSON resources; selected entries verified in the client JAR and extracted files. |

Source references below are from the read-only `decompiled_minecraft/{1.21.8,1.21.9,1.21.10}/mojmap` trees. The inventory-relevant source tags resolve under `net/minecraft/tags/`; dimension fields resolve through `world/level/dimension/DimensionType.java`. Endpoint hashes below were checked against both the extracted resource snapshot and JAR entry; 1.21.9 hashes are from the pinned client JAR entry bytes. Equal SHA-256 values establish byte-identical JSON, including ordering and formatting.

## Movement-relevant packaged resources

`minecraft:<id>` is the resource key; the corresponding resource path is shown. All listed entries are present in each release's client JAR. “Same all” means the full SHA-256 shown applies to 1.21.8, 1.21.9, and 1.21.10.

| Resource key | Path | SHA-256 | Comparison and source dependency |
|---|---|---|---|
| `minecraft:climbable` (block tag) | `data/minecraft/tags/block/climbable.json` | `d0e3e76d7457f3f3f3d7219fe218c7746e4b2e7626d5c388fcf193089069e365` (same all) | No difference in either adjacent interval or endpoint. Read by `LivingEntity.onClimbable` and `Entity.isStateClimbable`; also a nested member of `fall_damage_resetting`. Membership unchanged: ladder, vine, scaffolding, weeping-vine and twisting-vine forms, cave-vine forms. |
| `minecraft:fall_damage_resetting` (block tag) | `data/minecraft/tags/block/fall_damage_resetting.json` | `3a765259768c8ecdfcb83e97e00dd808e709d51919d6d52436869bc93bc7b9e4` (same all) | No difference. Used by `ClipContext.Block.FALLDAMAGE_RESETTING`, a ray shape queried by the player fall path. Exact values are `#minecraft:climbable`, `minecraft:sweet_berry_bush`, `minecraft:cobweb`. |
| `minecraft:fences` (block tag) | `data/minecraft/tags/block/fences.json` | `214462701d11703b222317fb7d470caa40e017b5036b127db242986b92fb30cd` (same all) | No difference. Read by `Entity.getOnPos`; depends on `#minecraft:wooden_fences`. |
| `minecraft:wooden_fences` (block tag dependency) | `data/minecraft/tags/block/wooden_fences.json` | `b688d023f03758224cfd1bf8b50d018c287aab3bddd939a00abd699fea7ac11f` (same all) | No difference. Transitive membership for `minecraft:fences`; includes the vanilla wooden fence variants present in each JSON. |
| `minecraft:walls` (block tag) | `data/minecraft/tags/block/walls.json` | `7124e8b44110efc945df32e09bf88dae84413d38558c8073e84e98532391ef97` (same all) | No difference. Read with `minecraft:fences` by `Entity.getOnPos` for supporting-block position selection. |
| `minecraft:portals` (block tag) | `data/minecraft/tags/block/portals.json` | `fe9759678b07daacfebc3ce9e5aa616489cb432af36d14ce4cc1128cd3a410ef` (same all) | No difference. Read by `LivingEntity.dismountVehicle` when selecting a direct player dismount position; values remain Nether portal, End portal, End gateway. |
| `minecraft:water` (fluid tag) | `data/minecraft/tags/fluid/water.json` | `dcfa69a748d03dbf788d8f7b0e5eb6c8de6355a527fcaf74b9210fe4be2a3004` (same all) | No difference. Read by entity/player water detection and pushing; membership remains `minecraft:water`, `minecraft:flowing_water`. |
| `minecraft:lava` (fluid tag) | `data/minecraft/tags/fluid/lava.json` | `71f50fb9092d78260bc7434731fc5fd426a44e5284a6ad084ec71cb725630c6b` (same all) | No difference. Read by entity fluid pushing and living travel; membership remains `minecraft:lava`, `minecraft:flowing_lava`. |
| `minecraft:no_knockback` (damage-type tag) | `data/minecraft/tags/damage_type/no_knockback.json` | `f0db4376167bb46e78d37ce06ce3a489e682867388c2c374eef06aa308cdc1d8` (same all) | No difference. Included because `LivingEntity.hurt` gates the direct velocity/knockback mutation on `DamageTypeTags.NO_KNOCKBACK`; this is a movement mutation even though damage calculation itself is excluded. |
| `minecraft:overworld` (dimension type) | `data/minecraft/dimension_type/overworld.json` | `e55609ea78fa17ae6cac9456de8ad3cbb317b897c82c0b77c3458294d62eccdc` (same all) | No difference. `DimensionType` data; the dimension type’s `ultrawarm` value feeds `Entity.updateInWaterStateAndDoFluidPushing`. References `#minecraft:infiniburn_overworld`. |
| `minecraft:overworld_caves` (dimension type) | `data/minecraft/dimension_type/overworld_caves.json` | `9997280dff75576a4863d17207ac40f860405553de2f91b4c72555777bdfc239` (same all) | No difference. Same dimension-type codec and field closure; references `#minecraft:infiniburn_overworld`. |
| `minecraft:the_nether` (dimension type) | `data/minecraft/dimension_type/the_nether.json` | `26953e0426b058a44a4c1f2060a1a15823c03dd511f57dd7ef97dfa6327a3825` (same all) | No difference. Same dimension-type codec and field closure; references `#minecraft:infiniburn_nether`. Its `ultrawarm=true` field selects lava fluid-pushing constant. |
| `minecraft:the_end` (dimension type) | `data/minecraft/dimension_type/the_end.json` | 1.21.8: `6186e2dc90651fb3b9c3ad2df49416c655a7c6431b8cf83236ac0f7e8fe5dd2e`; 1.21.9 and 1.21.10: `cddd6141dd674f204d54e7bc5ca11c3a99293028bd3dd02d27ae9fbdbb75db27` | **Different 1.21.8→1.21.9; no difference 1.21.9→1.21.10.** Exact JSON changes: `ambient_light` 0.0→0.25, `has_skylight` false→true, `monster_spawn_light_level` `{ "type":"minecraft:uniform", "max_inclusive":7, "min_inclusive":0 }`→15. `ultrawarm` remains false; movement-relevant height, coordinate scale and other fields are unchanged. References `#minecraft:infiniburn_end`. |
| `minecraft:infiniburn_overworld` (block tag dependency) | `data/minecraft/tags/block/infiniburn_overworld.json` | `463640bbca53006d499273ffb36499d1f6f596a11d073ccd7ad7156335ba1a58` (same all) | No difference. Transitive decode dependency from Overworld and Overworld Caves dimension JSON. |
| `minecraft:infiniburn_nether` (block tag dependency) | `data/minecraft/tags/block/infiniburn_nether.json` | `c5256847f721908d61a51568598a141bc60bd2779aec34505b7b90381064592e` (same all) | No difference. Transitive decode dependency from Nether dimension JSON. |
| `minecraft:infiniburn_end` (block tag dependency) | `data/minecraft/tags/block/infiniburn_end.json` | `f498b235a368f9abe32ab4190fee70924da9af4624d0d2383260805f85882858` (same all) | No difference. Transitive decode dependency from End dimension JSON; itself references `#minecraft:infiniburn_overworld` and bedrock. |

## Movement-adjacent resource tags with no movement-state consequence

These three exact resources are read by the entity/player step-sound path. Their role is sound selection only; no player movement state, position, velocity, collision, or callback gate consumes the membership. Each hash is identical across all three releases.

| Resource key | Path | SHA-256 | Source use |
|---|---|---|---|
| `minecraft:inside_step_sound_blocks` | `data/minecraft/tags/block/inside_step_sound_blocks.json` | `2d97011bfe26d35e5895027ce80f3372b79ced9138bc567bf8cb031520f8a596` | `Entity` step sound selection. |
| `minecraft:combination_step_sound_blocks` | `data/minecraft/tags/block/combination_step_sound_blocks.json` | `0f0049644c911eb764bf3b8fdaa59428c4e2fbc7c3de2717af173b649e8f882e` | `Entity` and `Player` step sound selection. |
| `minecraft:crystal_sound_blocks` | `data/minecraft/tags/block/crystal_sound_blocks.json` | `6217bd619dea59a80a48ae687cb20ac977d50bd5cffca7c53f5692fc478c063f` | `Entity` step sound cooldown/sound selection. |

## Entity-tag candidates checked against the player path

Both resource keys are present in all three client JARs, with byte-identical JSON. The first is consulted by the Powder Snow block movement response but its exact members do not include `minecraft:player`; the second is consulted by `Entity.dismountsUnderwater` but lists only vehicle/entity types, not `minecraft:player`. They therefore create no player membership difference across these releases.

| Resource key | Path | SHA-256 (all three releases) | Exact membership and disposition |
|---|---|---|---|
| `minecraft:powder_snow_walkable_mobs` | `data/minecraft/tags/entity_type/powder_snow_walkable_mobs.json` | `b3b3e888f3c8590c9439b99bb4d7d8f8df610fdcc1a0b3e5c4418255ad8a000e` | `rabbit`, `endermite`, `silverfish`, `fox`; `PowderSnowBlock` checks it, but it excludes Player. |
| `minecraft:dismounts_underwater` | `data/minecraft/tags/entity_type/dismounts_underwater.json` | `eceb98cd9bba427be8f84d221cb56e207bf91b6db6ccdca32746e2b1eb680b5c` | `camel`, `chicken`, `donkey`, `happy_ghast`, `horse`, `llama`, `mule`, `pig`, `ravager`, `spider`, `strider`, `trader_llama`, `zombie_horse`; `Entity.dismountsUnderwater` checks it, but it excludes Player. |
## Checked exclusions

- No item-tag or mob-effect-tag JSON is read by the reachable movement logic in the assigned inventory. In these source versions, movement effects such as jump boost, slow falling, levitation and Dolphin’s Grace are referenced through built-in `MobEffects` registry constants, not packaged effect-tag membership.
- `BlockTags.SOUL_SPEED_BLOCKS` appears in the enchantment advancement predicates in `world/item/enchantment/Enchantments.java`; it does not appear in the reachable player movement implementation. It is excluded from the movement resource set.
- The `EntityTypeTags` references in the local-player/player/living/entity slices concern breathing, entity/damage immunity, projectile handling or passenger/dismount policy, except for no independent tag key affecting the player’s ordinary movement resource closure. Their consequences fall outside this assignment’s movement resource slice or the stated non-player/vehicle exclusions.
- Other `DamageTypeTags` references in the same source slices gate damage calculation, armor/effect immunity or hurt presentation. `NO_KNOCKBACK` alone is retained above because it directly gates a velocity mutation.
- No new block/fluid/item/entity/effect tag key or JSON membership difference was found in the checked movement closure. The only packaged JSON difference in that closure is the End dimension-type lighting/spawn-data change described above; it does not change the movement-consumed `ultrawarm` or geometry fields.

