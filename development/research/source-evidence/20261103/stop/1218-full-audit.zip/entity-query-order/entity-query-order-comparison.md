# Entity collision query and push candidate order — source comparison

## Coverage and result

Compared exact Mojmap source for 1.21.8→1.21.9 and 1.21.9→1.21.10. The checked slice is terminal for peer/entity collision broad-phase selection and candidate ordering, and for the client-player `LivingEntity.pushEntities` query. No behavioral delta in candidate inclusion, candidate order, or list consumption was found in either interval.

The player-reachable collision path is `Entity.collide` → `EntityGetter.getEntityCollisions` → `Level.getEntities` → `ClientLevel.getEntities`/`LevelEntityGetterAdapter` → `EntitySectionStorage` → `EntitySection`/`ClassInstanceMultiMap`. `Entity.collide` still queries the swept player box `currentBox.expandTowards(requestedMovement)`. `getEntityCollisions` still returns empty when query-box size is below `1.0E-7`; otherwise it inflates the query box by `1.0E-7`, selects `NO_SPECTATORS && source.canCollideWith(candidate)`, and builds collision shapes by iterating the returned entity list in order.

`Level.getEntities(source, box, predicate)` accumulates section-query results first, excluding the source by identity and applying the predicate; it then appends intersecting `EnderDragonPart` instances in `dragonParts()` iteration order, excluding the source and its parent. `ClientLevel.getEntities()` returns `entityStorage.getEntityGetter()` in all three releases. The adapter routes AABB queries to section storage. `forEachAccessibleNonEmptySection` uses the same X-ascending section scan and `sectionIds.subSet(...).iterator()` traversal for each X; it rejects sections outside the calculated Y/Z ranges, empty sections, and inaccessible sections. `EntitySection.getEntities(AABB, consumer)` tests each section entity's bounding box with `intersects` and visits the section storage iterator in sequence. That iterator is the `allInstances` list iterator in `ClassInstanceMultiMap`, preserving the section's insertion order (subject to ordinary removals/re-additions). Therefore collision-shape order is the section traversal order, then entity order within each section, followed by the dragon-part append order. All of these steps are unchanged across the pair.

## Peer push query

`LivingEntity.pushEntities()` obtains `level.getPushableEntities(this, this.getBoundingBox())`, then iterates that list in returned order and calls `doPush` for each candidate. `Level.getPushableEntities` delegates to the same `getEntities` query using `EntitySelector.pushableBy(source)`. The selector's team collision-rule branches, `NO_SPECTATORS` gate, target `isPushable()` gate, and candidate ordering are unchanged across all three releases. The only source-level expression change between 1.21.8 and 1.21.9 is `!source.level().isClientSide` becoming `!source.level().isClientSide()`; the getter returns the same stored `isClientSide` value in both versions and in 1.21.10.

On the logical client, `pushableBy` only admits a player target when it is the local player. The `Level.getEntities` call excludes the source player by identity, so the local player's client-side push query cannot return a peer player. Non-player client-side `LivingEntity` pushers are outside this movement slice; server-side entity cramming and server movement are excluded. Thus this query-order slice has no client-player peer-push candidate to process in these releases.

## Exact source references

All paths below are relative to `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/<version>/mojmap/`.

| Operation | 1.21.8 | 1.21.9 | 1.21.10 |
|---|---|---|---|
| Swept entity collision query | `net/minecraft/world/entity/Entity.java:1002-1010` | `Entity.java:1022-1030` | `Entity.java:1025-1033` |
| Collision candidates to shapes | `net/minecraft/world/level/EntityGetter.java:54-71` | same lines | same lines |
| Level candidate collection and dragon-part append | `net/minecraft/world/level/Level.java:658-674` | `Level.java:673-689` | same lines as 1.21.9 |
| Client entity getter | `net/minecraft/client/multiplayer/ClientLevel.java:834-836` | `ClientLevel.java:925-927` | same lines as 1.21.9 |
| Section bounds and traversal | `net/minecraft/world/level/entity/EntitySectionStorage.java:30-62,112-118` | same lines | same lines |
| Per-section AABB iteration | `net/minecraft/world/level/entity/EntitySection.java:30-38` | same lines | same lines |
| Per-section insertion-order iterator | `net/minecraft/util/ClassInstanceMultiMap.java:16-35,65-67` | same lines | same lines |
| Push query and candidate loop | `net/minecraft/world/entity/LivingEntity.java:2910-2934` | `LivingEntity.java:2940-2964` | same lines as 1.21.9 |
| Pushable query selector | `net/minecraft/world/level/Level.java:713-715`; `net/minecraft/world/entity/EntitySelector.java:27-54` | `Level.java:752-754`; `EntitySelector.java:27-54` | same lines as 1.21.9 |
| Client-side gate value | `net/minecraft/world/level/Level.java:116,154-157` | `Level.java:121,145-147` | same lines as 1.21.9 |

Source identity: 1.21.8 and 1.21.10 report exact version and Mojmap namespace in their `mojmap.provenance.json`; the selected Java source hashes were checked against the adjacent `mojmap.sources.sha256`. 1.21.9's `.decompile-provenance.json` source-hash map was used directly. All 11 selected source files for each release match their recorded SHA-256. The individual expected/actual values are in [`source-hash-check.tsv`](source-hash-check.tsv).

## Residual boundary

This closes only candidate selection/order and the peer-push query for the named intervals. It does not audit entity-specific `canBeCollidedWith` implementations, the downstream `Shapes.collide` narrow-phase math, or non-player entity movement. The broad-phase query itself is terminal for this assignment; no gameplay or runtime parity claim is made.
