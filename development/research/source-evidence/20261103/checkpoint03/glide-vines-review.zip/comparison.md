# Independent source review: 1.21.10 → 1.21.11 Elytra glide through vines

## Evidence identity

Both exact version directories identify the version and `mojmap` namespace in `mojmap.provenance.json` and `mojmap.ready.json`. Each provenance file names the same exact batch `1.21.8,1.21.10,1.21.11`, Mojang mappings, Vineflower 1.12.0, and the same toolchain. The ready markers report 6,386 files and client SHA-256 `e65ca028bc58da12bf8413066c90ecd4d48c94fb351d9bbd22ecdff5c87f9482` for 1.21.10, and 6,622 files and client SHA-256 `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd` for 1.21.11.

The `mojmap.sources.sha256` file hashes match the ready markers' source-manifest SHA-256 values (`4be26049350c1b314a0b198022cb1e7ab1e745e104047de7a5c7d099a9d7b7e1` and `0c4d83fef84c101d9db88f331acec7960f3c8346228c28995e6cf57bbfcae555`). Recomputed source hashes match manifest entries for every file used in this review:

| Source file | 1.21.10 SHA-256 | 1.21.11 SHA-256 |
| --- | --- | --- |
| `net/minecraft/world/entity/LivingEntity.java` | `b8b49d60769203f7bd5afe4a1bffcdcdbec30be28960324cdc43a2df85a6eb66` | `19ed2d565858c401c69a06750b054a633a20ea864cab3a753b5c767f0bdd60e8` |
| `net/minecraft/world/entity/Entity.java` | `8361dbb86fe6c975d21f69d008377b6f191669be751150c842517e9d0346fa18` | `32314478c6036fa9f3f3cc409c61c622eefc5a282d60e1011a1a33cc29cf18a3` |
| `net/minecraft/world/entity/player/Player.java` | `af857617b66a5776e63830771360b96f75e21d47d20db08f164a2dbeee801d82` | `8e97167350a91741d0aa10d3b0d92a33150ed6dccdc94cd5b37d9c7ca22bcc81` |
| `net/minecraft/data/tags/VanillaBlockTagsProvider.java` | `2393020635c9dbbe3cb2fa259870044d232ed215e45ed9acf048114b0904a980` | `8c17f2a6c6654721019e575377523edb0ac68c71b8325188a4e6412962c83474` |
| `net/minecraft/tags/BlockTags.java` | `da249a99c096ef294c6c00e04e94833b99168fe4099e7c33aa76103e650148f3` | `9db30d02bbb896538a35267b2f0e9c957a00ffdbf20bcc0ea025b5a7bbec38e3` |

## Independently traced behavior

- In both versions, `LivingEntity.travel` reaches `travelFallFlying` when the entity is fall-flying and is not on the fluid-travel branch. `Player.tryToStartFallFlying` sets the shared fall-flying flag after `canGlide()` succeeds and the player is not in water. The inherited `canGlide()` requires airborne, non-passenger, no levitation, and an equipped item accepted by `canGlideUsing`; `Player.canGlide()` additionally rejects creative flight. This supplies an ordinary player path with a usable Elytra/glider and the fall-flying flag set.
- `Entity.getInBlockState()` obtains the block state at `blockPosition()` (caching it until invalidation); `LivingEntity.onClimbable()` tests that state. In 1.21.10 the non-spectator path tests `CLIMBABLE`, then the ladder-compatible trapdoor case. In 1.21.11 it first returns false when `isFallFlying()` and the state is `CAN_GLIDE_THROUGH`, then applies those same existing climbable/trapdoor cases.
- In both versions, `travelFallFlying` calls `onClimbable()` first. True selects `travelInAir` and then `stopFallFlying`; false selects the unchanged gliding branch, which updates fall-flying velocity and moves. The new predicate gate therefore changes the player path for an active glider inside a block state in both tags.
- Vanilla tag defaults are published by `VanillaBlockTagsProvider`. `CLIMBABLE` contains vine, weeping vines and plant, twisting vines and plant, and both cave-vine blocks in 1.21.10 and 1.21.11. In 1.21.11, `CAN_GLIDE_THROUGH` contains vine, the weeping and twisting vine pairs, and `BlockTags.CAVE_VINES`; that subtag contains both cave-vine blocks. `BlockTags.CAN_GLIDE_THROUGH` is newly declared in 1.21.11 and absent from the 1.21.10 sources. This is an overlap of vanilla defaults, not a movement rule that applies to arbitrary blocks.

## Review verdict

**ACCEPT, with title and applicability narrowed.** The source difference and player path are real. The draft title could imply that those states cease being climbable in general; they remain climbable whenever the player is not fall-flying. The corrected finding scopes the exception to fall-flying and an overlap of the two vanilla tags. Runtime data packs can alter tag contents; the claim is about the published vanilla defaults.

This review is bounded to the Elytra/climbable-vine source claim and its direct dependencies. It is not a full-pair coverage audit.
