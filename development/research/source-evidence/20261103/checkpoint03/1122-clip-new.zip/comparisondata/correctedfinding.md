# Independent review: tiny collision offset witness

## Verdict

**Accept the source-level witness and the stated one-tick X-position consequence.** The gap is positive and below `1.0E-7`; 1.12.2 clips to that exact gap, while 1.13.2 clips to it on the aggregated stone shape and returns zero before consuming the following Shulker shape. This review did not run tests, launch a game, or generate decompiled sources.

The requested witness is compatible with the pre-travel writes checked here. In particular, the local player's four `pushAwayFrom` block-unembedding probes do not treat the positive gap as an intersection: `VoxelShapes.overlap(..., AND)` falls through to `SimpleIndexMerger`, which emits no shared occupied interval for these separated coordinate ranges. The `1.0E-7` bounds check only avoids the fast separated-shapes return; it does not make this pair overlap. Thus those probes do not overwrite velocity or position in this setup.

## Frozen witness reviewed

- Corrected position: `x = 1.0 - (0.6F / 2.0F) - 5.0E-8`, `y = 65.2`, `z = 0.8`; `onGround=false`; no liquids, sneak, flight, riding, or movement input.
- Stone at `(1,65,0)`; closed, alive Shulker collision box `[1.5,65,1]..[2.5,66,2]`.
- An absolute X position correction clears X velocity, then the explosion packet adds its float X impulse. The packet value `+0.8F` widens to a double in the handler and exceeds the `<0.003` velocity cutoff. Both server `Explosion.damageEntities` methods calculate the player impulse, and `ServerWorld.createExplosion` sends that vector in the packet; a non-destructive explosion keeps its damaged-block list empty, so this witness can retain the stone. The vector can have X component `0.8F` with its center and power chosen accordingly. The correction methods preserve position coordinates as doubles. Both releases use the same explosion packet source/hash.
- `LocalClientPlayerEntity.mobTick` calls `PlayerEntity.mobTick` after input/state handling; the latter performs its pre-super cooldown, inventory and bob updates, then calls `LivingEntity.mobTick`, which performs velocity cleanup and travel. In the chosen ordinary airborne, non-flying, non-riding, dry state, jump and flight branches do not write velocity; zero movement input adds no horizontal acceleration. The four `pushAwayFrom` calls are block-unembedding probes, and the initial box has no block intersection. `LivingEntity.mobTick` then keeps the `0.8F` X component through its small-velocity cleanup and enters the ordinary air movement path. That path calls `move(SELF, velocityX, velocityY, velocityZ)` before gravity and drag are applied. The airborne/zero-vertical-request state makes the step gate false.
- The stone occupies the swept broad phase, is not excluded by the starting-box overlap test, and is accumulated in the 1.13.2 `IntVoxelShape` because its collision shape is the canonical full-block shape. `getBlockCollisions` concatenates this aggregate after individual block shapes; `World.getCollisions` then concatenates eligible entity shapes. The Shulker is non-spectating, alive, not the player’s vehicle, and its box intersects the swept query. It therefore follows the stone aggregate in encounter order.
- On X clipping, 1.13.2's `VoxelShape.calculateMaxDistance` returns the positive stone face gap. The next `VoxelShapes.calculateMaxOffset` loop iteration checks `abs(maxDist) < 1.0E-7` before calling `iterator.next()` and returns zero. 1.12.2 folds `Box.intersectX` over its full collision list; the later Shulker box does not reduce the already clipped positive gap. Thus old X advances to contact and new X stays at the corrected coordinate for this move.

## Exact-source provenance and identity

Read-only canonical root: `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`.

Both `ornithe-feather.provenance.json` records identify `decompileMinecraft` runs and Feather build-2 mapping artifacts. Recomputed provenance-file SHA-256 values: 1.12.2 `747425a26da363d1abc8a2cecd83a74504aeb1f58be93aa53f48c690e35318ce`; 1.13.2 `e25950b7855fc4f2aee1a662f0be6b0af9f28788d9e27293075cfc5a3aa5d383`. Recomputed whole-manifest SHA-256 values:

- 1.12.2 `ornithe-feather.sources.sha256`: `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da`
- 1.13.2 `ornithe-feather.sources.sha256`: `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211`

Key direct file hashes (all matched their release manifest):

| Release | Relative source | SHA-256 |
|---|---|---|
| 1.12.2 | `net/minecraft/entity/Entity.java` | `80f091bf32166c88cf8bbd31caf72d84fa16224410733c7d2a0f00563f294a0a` |
| 1.12.2 | `net/minecraft/entity/living/LivingEntity.java` | `190e9ac551538e015d9e4d6c42856e5ba32b593131cf6d93895e7b29533f1ee6` |
| 1.12.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `01a58e94d8c6ff98a8e3794227cdc76a5fcbdbad795c70c9cf28854aff9823cc` |
| 1.12.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `e4e0fdbbe07a0d0ae4a70cbb6739a287c9d045a4a12b409895c220b5d91fe1e` |
| 1.12.2 | `net/minecraft/world/explosion/Explosion.java` | `f19842a09492536a3461f386ad3108b05aa7cb6b140c1eb3b97d7c3fe5d7a95e` |
| 1.12.2 | `net/minecraft/server/world/ServerWorld.java` | `e2c2270ec773560226fa89590e7334509889f44e49c610bf087c89ca79a357e9` |
| 1.12.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `fce21d9902e555fd46545fb04bdb6c4a912eef6398790776ad1a122e09960c7c` |
| 1.12.2 | `net/minecraft/world/World.java` | `e9fa9b8d6d31ad57a5b876f5f63a5e3c554a23437decf1845a493daf48233594` |
| 1.12.2 | `net/minecraft/util/math/Box.java` | `f788b8146b14f299ccb58ea0854609f845c298a963295d503de2e30e15d66f3a` |
| 1.12.2 | `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `b3951c88369647044465bb915e1e480702ccce11a224b49c3fc5a9db79bf8829` |
| 1.12.2 | `net/minecraft/network/packet/s2c/play/ExplosionS2CPacket.java` | `d3adb63f5cce384fbd3b8679893425910152dd3f06df6645ac692141114e0391` |
| 1.13.2 | `net/minecraft/entity/Entity.java` | `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269` |
| 1.13.2 | `net/minecraft/entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.13.2 | `net/minecraft/client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.13.2 | `net/minecraft/entity/living/player/PlayerEntity.java` | `4ed22f6c5a3c55d67eed782070ac722201df4d624adbc90779f1fd29c2876633` |
| 1.13.2 | `net/minecraft/world/explosion/Explosion.java` | `72d86b4acfdfc963ca9a912ad4a9e697f52bf770b91fa8bf88e89881b6e774e2` |
| 1.13.2 | `net/minecraft/server/world/ServerWorld.java` | `c19008dae507736dad4834d26e41ab4df8fab3bc2ed52fe87994ae4428c7e4dd` |
| 1.13.2 | `net/minecraft/client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| 1.13.2 | `net/minecraft/world/World.java` | `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |
| 1.13.2 | `net/minecraft/world/WorldView.java` | `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f` |
| 1.13.2 | `net/minecraft/world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShape.java` | `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.13.2 | `net/minecraft/block/shape/VoxelShapes.java` | `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95` |
| 1.13.2 | `net/minecraft/block/shape/SimpleIndexMerger.java` | `5557e978b8e817a53d965f3917267e25bda0d08055139d4df2cb086120d354d1` |
| 1.13.2 | `net/minecraft/block/shape/IntVoxelShape.java` | `e563f5530907a5cd0ecc07bd79473d378c8c1aeeaba1dba4ac6f703de7d7b3ca` |
| 1.13.2 | `net/minecraft/entity/living/mob/monster/ShulkerEntity.java` | `35d3f858f7e06c035ee66b74b08420b678665dcdff9e4cf0619d68570966afa5` |
| 1.13.2 | `net/minecraft/network/packet/s2c/play/ExplosionS2CPacket.java` | `d3adb63f5cce384fbd3b8679893425910152dd3f06df6645ac692141114e0391` |
| 1.13.2 | `net/minecraft/unmapped/C_70593968.java` | `6efb9fbc71bca9d0c49a8ed265721874a264fb51233c8ba5f547bb0e5e98d974` |

## Logical-side boundary

This is a client-local-player witness. In both releases `LocalClientPlayerEntity.isLocallyControlled()` returns true, and `LivingEntity.moveRelative` uses the `isLocallyControlled() || isLogicalSideForUpdatingMovement()` gate. Nothing here claims that the historical local-player movement route runs on a logical server.


