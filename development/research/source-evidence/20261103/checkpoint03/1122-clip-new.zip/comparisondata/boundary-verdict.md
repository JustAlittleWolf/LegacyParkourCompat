# Independent boundary renewal: tiny collision offset

## Verdict

**Accept the revised finding's first-new-release boundary at 1.13.1.** I independently rechecked the changed claim against exact 1.12, 1.12.1, 1.12.2, 1.13, 1.13.1 and 1.13.2 sources. The previously reviewed 1.13.2 endpoint does not bind this revised boundary claim; this verdict is fresh and bound to the inputs below.

The particular stone-then-Shulker offset witness does not get zeroed between shapes in 1.13.0: its block and entity collisions are unioned into one VoxelShape and clipped once. In 1.13.1 the block query yields a stream, with the full-cube aggregate before the entity stream; the Shulker candidate follows the stone-containing aggregate. `calculateMaxOffset` returns zero when it reaches the next stream iteration with the stone-clipped gap under `1.0E-7`. 1.13.2 retains those relevant methods and order. The old 1.12 through 1.12.2 list fold continues to keep the exact positive face gap.

## Exact release and mapping identity

All sources were read from the read-only canonical root `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`. SHA-256 values below were recomputed. The 1.12 and 1.12.1 current source files match their retained `.decompile-provenance.json` source entries; their mapping jar hashes also match the retained metadata. Releases 1.12.2 and 1.13 onward match their active source manifests.

| Release | Ornithe Feather mapping identity | Immutable source identity |
|---|---|---|
| 1.12 | `feather-gen2:1.12+build.2` | Previous provenance JSON SHA-256 `27515e5f4c71e7db2f035a81716507128d77466c75380ad1ef7d140c06401467`; mapping jar `73ce7d6d0a281db15fa030ae09e836387dae1172fdffcaf3e2d1a4840830b719` |
| 1.12.1 | `feather-gen2:1.12.1+build.2` | Previous provenance JSON SHA-256 `0ff5246e8d29c04554cc9ec93ae9b4abef539652325b6c0ac822851d7186a9c8`; mapping jar `f94febd2167d6091b4c157aef0a85c8791e6f8fb27b883e27a82a68c7b02b9c7` |
| 1.12.2 | `feather-gen2:1.12.2+build.2` | Source manifest SHA-256 `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da` |
| 1.13 | `feather-gen2:1.13+build.2` | Provenance JSON SHA-256 `34652aeef6914b5cbff6619ae60a855aa676b2ae1f607eccdaa623ad09dc5e8d`; source manifest SHA-256 `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a` |
| 1.13.1 | `feather-gen2:1.13.1+build.2` | Provenance JSON SHA-256 `c28ed59f2c507b6133f7677742d316d38e9993eaf1fbb6c2054bd68d1085e904`; source manifest SHA-256 `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba` |
| 1.13.2 | `feather-gen2:1.13.2+build.2` | Source manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` |

Relevant direct source hashes (all match the identities above):

- 1.12, 1.12.1 and 1.12.2: `entity/Entity.java` `80f091bf32166c88cf8bbd31caf72d84fa16224410733c7d2a0f00563f294a0a`; `util/math/Box.java` `f788b8146b14f299ccb58ea0854609f845c298a963295d503de2e30e15d66f3a`. `world/World.java`: 1.12 `f7ab7a34d456e720e7ee4f34fbd0eb10f7f96151596c8c615ab2edef05a884d8`; 1.12.1 `d182122a9b052f57803672c21b0941cb7e7d41ed756cd0a4ea8c0858684c8259`; 1.12.2 `e9fa9b8d6d31ad57a5b876f5f63a5e3c554a23437decf1845a493daf48233594`.
- 1.13: `entity/Entity.java` `09514488d9055449c47e2e4bcd23b5773203ca634b7ecba2323a99d0ae016642`; `world/WorldView.java` `b0d1406fb04eacbc644a78548f858d5ff6c14ad781927832cb374e985f32a543`; `block/shape/VoxelShapes.java` `6ae1a6fa0ab76098252208fad00a6d4f3d3f1cf2023d76f63d450855df00a330`.
- 1.13.1 and 1.13.2: `entity/Entity.java` `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`; `world/WorldView.java` `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f`; `block/shape/VoxelShapes.java` `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95`; `block/shape/VoxelShape.java` `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1`; `world/EntityView.java` `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de`; `block/shape/IntVoxelShape.java` `e563f5530907a5cd0ecc07bd79473d378c8c1aeeaba1dba4ac6f703de7d7b3ca`; `unmapped/C_70593968.java` `6efb9fbc71bca9d0c49a8ed265721874a264fb51233c8ba5f547bb0e5e98d974`. `world/World.java` differs as a whole file (`119ac6f61b93cf352b2026934e9f95877f55dc2f582b45d75c2bdae3652532b6` in 1.13.1; `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` in 1.13.2), so its collision adapter was compared by method body as well.

## Boundary evidence

Method-body digests below are SHA-256 over each exact source slice from the named method signature through its balanced closing brace.

**1.12 through 1.12.2:** `Entity.move` hashes to `33bf2dcc93a938f4910bfdf130ee2acdbbc2fa66bc8c0887a8f85e6d9995c272` in all three releases; `Box.intersectX` hashes to `8cc3f11b3b15807d8e8c31723a453727f9e29da993da0a02f4026b2bec322f7f`; `World.getCollisions(entity, box)` hashes to `227b1be34ca8602bdbf15283fdd5b212d004409e41524d5ae2c0a838d0b3b9a5`; and the private block collector hashes to `dfdec2ce08f74e710a1004a9edd4690965c092cc46a400655244417a4230917e`. Thus all three aliases preserve the same exact `Box` clip and block-first/entity-last collection order, despite their full `World.java` hashes differing.

**1.13 scalar-union route:** `Entity.move` makes one scalar clipping call per nonzero axis (method digest `80fc57cd07b79344d94af6dca5a4da897e280e76a7653e4bc93025937d09a2fd`). `WorldView.getCollisions` first gets the block union and then unions eligible entity collision shapes into it (method digest `faf16e6a512523abf57386183cd9711d9be4f69ff8d4b030d2f2a2659146ca80`). `VoxelShapes.m_84966497` clips that single union once (method digest `1401ec27e454db9b1bc974720ffbfdb20fec7bd05ccabb762cfac83f450660bb`). Its small-offset guard sees the original `+0.8F` request, not a stone-clipped remainder; scanning the union returns the stone's positive gap. There is no between-shape fold to zero it.

**1.13.1 and 1.13.2 stream route:** the following relevant method-body digests match exactly in both releases: `Entity.move` `04d5f2c89569d31feaa96da401a56c9731f4acbd4e6bad1a30c747431870c423`; `WorldView.getBlockCollisions` `0e5eba7a644bf30b2b0a2b8ea37ed5057b3a175def2f81d700734d83b602eb7e`; swept `WorldView.getCollisions` `2c0acfa61f2a780d47b618c4f581cf4f25f7eb462f14d7d1792d5cb90373468f`; `World.getCollisions` adapter `75a38204575b9d536fa140a372bc80bc67d28ec784b6e98799223275695bf013`; `EntityView.getEntityCollisions` `e6c59cb6cc7c6b33769b53c7bf9f96f94e7f1655c9046a40d5a32e4bc40f9fbd`; and `VoxelShapes.calculateMaxOffset` `9e35c325c8db036609b7292bc33a9a346d32a9fc71e7ddac5346815960e90bb2`.

The stream collector emits individual non-full-block shapes during block traversal, puts full-cube blocks into its `VoxelSet`, then concatenates one `IntVoxelShape` for that set. In the witness, that aggregate contains the stone and is the first non-empty block shape. `World.getCollisions` concatenates eligible entity collisions after the block stream; `EntityView.getEntityCollisions` queries the swept bounds expanded by `0.25`, excludes spectator candidates and same-vehicle entities, and emits the live Shulker's intersecting collision box. `calculateMaxOffset` checks `abs(maxDist) < 1.0E-7` before `iterator.next()` on a subsequent loop iteration. After the aggregate clips the large X request to the positive stone gap, the check returns zero before another shape is folded. This is the first-new-version stream behavior in 1.13.1 and is retained in 1.13.2.

## Scope of this verdict

The revised boundary and source-order claim are verified. This is not a full-pair coverage audit and does not establish other collision-query equivalences. Review was source-only; no product files, tests, gameplay/runtime launches or decompilation were used.

