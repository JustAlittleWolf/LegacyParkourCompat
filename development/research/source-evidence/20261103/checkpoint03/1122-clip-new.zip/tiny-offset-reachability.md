# Tiny move-clipping remainder reachability supplement

## Exact local-player route

The ordinary local-player tick calls `super.mobTick()` after input/state work (`LocalClientPlayerEntity.java:648-812` in 1.12.2; `:652-837` in 1.13.2). `LivingEntity.mobTick` zeros velocity components only when `abs(component) < 0.003` (`LivingEntity.java:1802-1812`; 1.13.2 `:1878-1888`) before its travel/movement dispatch (`:1842-1848`; 1.13.2 `:1920-1926`). The ordinary air route applies input acceleration and calls `move(MoverType.SELF, velocityX, velocityY, velocityZ)`; zero input adds no horizontal acceleration. Thus arbitrary tiny incoming X velocity would be cleared, but a normal-sized horizontal response is preserved to the move call.

The client accepts a server player-position correction and applies `updatePositionAndAngles` (`ClientPlayNetworkHandler.java:582-619` in 1.12.2; `:626-670` in 1.13.2). Absolute X correction clears the prior X velocity; a following explosion packet adds its float X impulse directly to the local player's velocity (`:928-937`; 1.13.2 `:968-977`). Both `ExplosionS2CPacket.java` files are byte-identical and store/read the player impulse as a float; both handlers add it without scaling. Therefore an identical received `+0.8F` impulse after the correction yields a movement delta above the `0.003` pre-travel cutoff in both releases. `LocalClientPlayerEntity.move` delegates directly to `super.move` and then tries auto-jump (`:846-851`; 1.13.2 `:871-876`); auto-jump is gated by `onGround`, so it does not run for this airborne witness.

## Ordered collision witness

Use a loaded flat region and identical old/new vanilla player state. The exact player X position is `1.0 - (0.6F / 2.0F) - 5.0E-8`, ensuring its maximum X face is `1.0 - 5.0E-8`; player Z center `0.8`, bottom Y `65.2`, `onGround=false`, no water/lava, no sneak, and zero movement input. Place stone at `(1,65,0)`. Place a closed, alive Shulker at `(2.0,65,1.5)`, with its bounds `[1.5,65,1]..[2.5,66,2]`. The player's bounds initially overlap neither collider, overlap the stone's Z interval by `0.5`, and overlap the Shulker's Z interval by `0.1`. The Shulker bounds touch the stone's Z face and do not intersect the stone. Supply an identical incoming explosion X impulse of `+0.8F`; no Y/Z impulse is needed.

In 1.12.2, `World.getCollisions(entity, expandedBox)` yields the stone's collision Box before nearby entity collision Boxes (`World.java:1017-1039`). Exact `Box.intersectX` clips the positive `0.8F` request to the stone gap `1.0 - playerBox.maxX`, approximately `5.0E-8` (`Box.java:185-203`). The Shulker's farther box leaves this positive remainder unchanged. Because the player is airborne and the vertical request is zero, `Entity.move`'s step gate is false (`Entity.java:603-604`). Final X advances by the gap to contact.

In 1.13.2, `WorldView.getBlockCollisions` emits the full stone collision through the aggregated `IntVoxelShape`; `World.getCollisions` appends the Shulker's collision shape afterward (`WorldView.java:112-152`, `World.java:1755-1758`, `EntityView.java:21-35`). `VoxelShape.calculateMaxDistance` returns the same approximately `5.0E-8` gap for the stone (`VoxelShape.java:188-235`). Before the next stream element, `VoxelShapes.calculateMaxOffset` sees `abs(maxDist) < 1.0E-7` and returns `0.0` (`VoxelShapes.java:194-205`), so the move makes no X progress. The same false step gate applies (`Entity.java:601-602`).

This closes an exact, ordinary local-player reachable witness for the threshold difference. It is a one-tick position difference of about `5.0E-8` blocks (advance to contact versus remain just short); no claim is made about a larger trajectory divergence. It requires a block collider followed by a second entity collider in the swept query, with a positive sub-`1e-7` face gap. A sub-`1e-7` raw move request is unnecessary. Intermediate-source comparison places this specific per-shape stream-fold effect first in 1.13.1; 1.13.0 merges block and entity candidates into one VoxelShape and does not reproduce this witness's zero result. See `applicability-first-version.md`.

## Boundary check

For a single constraining shape, a positive gap below `1.0E-7` is preserved by the first `VoxelShape.calculateMaxDistance` call and by old `Box.intersectX`; the `calculateMaxOffset` early-zero behavior occurs only if another stream shape follows. A negative gap means the player box already overlaps the block/entity shape; the new swept query excludes shapes overlapping the starting box, while old `Box.intersectX` does not clip a positive move from an already-overlapping X interval. I did not find a new negative-contact witness with an eligible old/new difference from that case. The accepted witness uses a positive gap and a later eligible entity shape.

## Additional source identities

Every direct hash below was recomputed and matches its release's `ornithe-feather.sources.sha256` entry.

| Source | SHA-256 |
|---|---|
| 1.12.2 `entity/living/LivingEntity.java` | `190e9ac551538e015d9e4d6c42856e5ba32b593131cf6d93895e7b29533f1ee6` |
| 1.13.2 `entity/living/LivingEntity.java` | `bb691358c9a43c9f46e85575bf4d0a4ad671d0eb912502acc3a6a3f625e42f1c` |
| 1.12.2 `client/entity/living/player/LocalClientPlayerEntity.java` | `01a58e94d8c6ff98a8e3794227cdc76a5fcbdbad795c70c9cf28854aff9823cc` |
| 1.13.2 `client/entity/living/player/LocalClientPlayerEntity.java` | `2583495f3a02b4791aa036e6a8d354d7596c4984761969a0f29b29d8d9bf42bf` |
| 1.12.2 `client/network/handler/ClientPlayNetworkHandler.java` | `fce21d9902e555fd46545fb04bdb6c4a912eef6398790776ad1a122e09960c7c` |
| 1.13.2 `client/network/handler/ClientPlayNetworkHandler.java` | `4f65502fbee6476cef0838563f03a66f07a1a9ed8c63e580f5338ba5fe274f11` |
| Both `network/packet/s2c/play/ExplosionS2CPacket.java` | `d3adb63f5cce384fbd3b8679893425910152dd3f06df6645ac692141114e0391` |
| 1.13.2 `world/EntityView.java` | `2b5b59eef6efa93bb51c1d838c7a1cf64725be96c55c47f76894fde11e13d6de` |
| 1.12.2 `entity/living/mob/monster/ShulkerEntity.java` | `b3951c88369647044465bb915e1e480702ccce11a224b49c3fc5a9db79bf8829` |
| 1.13.2 `entity/living/mob/monster/ShulkerEntity.java` | `35d3f858f7e06c035ee66b74b08420b678665dcdff9e4cf0619d68570966afa5` |
