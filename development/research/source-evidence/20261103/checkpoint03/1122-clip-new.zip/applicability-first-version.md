# Tiny-positive-gap witness: exact earlier and first-new version boundary

## Verdict

The finding is specifically a 1.13.1 behavior, not an effect of the 1.13.0 scalar VoxelShape clip. The chosen two-collider witness remains at its corrected X position in 1.13.0 because block and entity collisions are unioned into one VoxelShape and one scalar `calculateMaxDistance` call returns the first stone gap. In 1.13.1 the collision source changes to a stream of distinct VoxelShapes; the tiny-offset guard runs between elements, turning the already clipped positive gap into zero before the Shulker element. 1.13.2 retains the same relevant stream, guard and candidate order.

The examined 1.12 and 1.12.1 aliases have the same `Entity.move` and `Box.intersectX` bytes as 1.12.2. Their paired `World` block/entity candidate-gather bodies at lines 964-1039 are text-identical: block collision Boxes are accumulated first, then eligible entity Boxes appended. Thus the older side of the witness has no earlier patch within these exact releases.

## Pair identity and source hashes

All sources were read from `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`. The 1.12 alias trees no longer have active metadata sidecars, so their exact mapping and file identities were matched against the source hashes in the retained `.decompile-provenance.json` sidecars under each `.ornithe-feather.previous-*` directory. Those recorded hashes match the current canonical files listed here. 1.12.2 and 1.13+ have active Feather provenance and source manifests.

| Release | Feather mapping coordinate | Source identity | Key SHA-256s |
|---|---|---|---|
| 1.12 | `feather-gen2:1.12+build.2` | Previous `.decompile-provenance.json` SHA-256 `27515e5f4c71e7db2f035a81716507128d77466c75380ad1ef7d140c06401467`; its source hashes match current tree; mapping jar SHA-256 `73ce7d6d0a281db15fa030ae09e836387dae1172fdffcaf3e2d1a4840830b719` | `Entity.java` `80f091bf32166c88cf8bbd31caf72d84fa16224410733c7d2a0f00563f294a0a`; `Box.java` `f788b8146b14f299ccb58ea0854609f845c298a963295d503de2e30e15d66f3a`; `World.java` `f7ab7a34d456e720e7ee4f34fbd0eb10f7f96151596c8c615ab2edef05a884d8` |
| 1.12.1 | `feather-gen2:1.12.1+build.2` | Previous `.decompile-provenance.json` SHA-256 `0ff5246e8d29c04554cc9ec93ae9b4abef539652325b6c0ac822851d7186a9c8`; its source hashes match current tree; mapping jar SHA-256 `f94febd2167d6091b4c157aef0a85c8791e6f8fb27b883e27a82a68c7b02b9c7` | `Entity.java` and `Box.java` same bytes as 1.12; `World.java` `d182122a9b052f57803672c21b0941cb7e7d41ed756cd0a4ea8c0858684c8259` |
| 1.12.2 | `feather-gen2:1.12.2+build.2` | Source manifest SHA-256 `b8a37ccfccd2aac5f40f5e34fec85873dbdfa93a266043c103e592e4a8c949da` | `Entity.java` and `Box.java` same bytes as 1.12; `World.java` `e9fa9b8d6d31ad57a5b876f5f63a5e3c554a23437decf1845a493daf48233594` |
| 1.13 | `feather-gen2:1.13+build.2` | Source manifest SHA-256 `0509c2614b0bb0e616e2ebc6382f8eb5d031b5d86b834a4a6ed7fd96b6d68f1a` | `Entity.java` `09514488d9055449c47e2e4bcd23b5773203ca634b7ecba2323a99d0ae016642`; `WorldView.java` `b0d1406fb04eacbc644a78548f858d5ff6c14ad781927832cb374e985f32a543`; `VoxelShapes.java` `6ae1a6fa0ab76098252208fad00a6d4f3d3f1cf2023d76f63d450855df00a330` |
| 1.13.1 | `feather-gen2:1.13.1+build.2` | Source manifest SHA-256 `21770b01ff3bf443db2e9e1b6df7db25d2fd6b7a72a86228259269c932d3abba` | `Entity.java` `1d6ec8b80f74635401745c2c027bf36555c85348ca5693764f2668363b17d269`; `WorldView.java` `9577360b1a1bdde9280f0b72593e5e6dde45d9a54719cd7ff933f3ecd31b971f`; `VoxelShapes.java` `313968d4e5855b5ec380272b6ababcc5849d478ab771926355912a8cb6aa9c95`; `VoxelShape.java` `d95b0607647da11595e24e1e26e9615cb7da7705ea7885908544362df62275c1` |
| 1.13.2 | `feather-gen2:1.13.2+build.2` | Source manifest SHA-256 `2c8cfb646bf622fb26ac0ca0cb5e02a354fb512e29f8b1010f1aaacd509e1211` | `Entity.java`, `WorldView.java`, `VoxelShapes.java`, and `VoxelShape.java` are byte-identical to 1.13.1; `World.java` `0023de30da608db73c6c6188334d2bb19039d86fe4d6f5e4ad79d732a5d2cd1a` |

## Exact compared members

### 1.12 aliases and 1.12.2

- `entity/Entity.java:567-600`: `List<Box>` candidates, exact vertical/X/Z `Box.intersect*` clipping; all three versions have the same `Entity.java` hash.
- `util/math/Box.java:185-243`: strict two-axis overlap gates and exact face-gap comparisons, without a `1.0E-7` threshold; all three versions have the same `Box.java` hash.
- `world/World.java:964-1039`: nested block collision enumeration fills the candidate list; `getCollisions` then appends other-entity collision Boxes. This method text is identical in 1.12, 1.12.1 and 1.12.2 despite different whole-file `World.java` hashes.

### 1.13.0 scalar VoxelShape call

- `entity/Entity.java:578-599`: each nonzero axis calls the scalar `VoxelShapes.m_84966497(axis, box, voxelShape, distance)` once.
- `world/WorldView.java:191-218`: `getCollisions` creates the swept voxel region, collects block collisions into one VoxelShape, unions entity collision shapes into it with `BooleanOp.OR`, and returns the union.
- `block/shape/VoxelShapes.java:207-243`: `m_84966497` calls `m_14725303` once for that union shape. The `abs(distance)<1.0E-7` gate is before grid inspection and sees the original `0.8F` request in this witness. It returns the tiny stone gap when it encounters the first occupied cell; there is no subsequent shape-fold iteration to reset the clipped result.

### 1.13.1 first stream-fold behavior; retained by 1.13.2

- `entity/Entity.java:578-599`: the swept query now produces a `Stream<VoxelShape>` and the X axis passes that stream to `VoxelShapes.calculateMaxOffset`.
- `world/WorldView.java:112-152`: per-block collision shapes are emitted, then a full-block `IntVoxelShape` is concatenated at stream tail. For the witness's stone-only block slice, that aggregate is the first non-empty block shape.
- `world/World.java:1755-1758` and `world/EntityView.java:21-35`: non-null-player entity collision shapes are concatenated after the block stream. The Shulker `VoxelShapes.block(box)` is therefore the next eligible shape after stone.
- `block/shape/VoxelShapes.java:194-205`: the fold checks `abs(maxDist)<1.0E-7` before each iterator consumption and returns `0.0` if the previous shape clipped a large request to the tiny positive stone gap.
- `block/shape/VoxelShape.java:184-235`: the stone shape returns the gap `stone.minX - playerBox.maxX` (about `5.0E-8`) from the large requested `+0.8F` move.

This source check narrows the first newer release for this particular ordered-fold finding to 1.13.1. It does not revise the broader pair coverage or declare any other movement operation's version boundary.
