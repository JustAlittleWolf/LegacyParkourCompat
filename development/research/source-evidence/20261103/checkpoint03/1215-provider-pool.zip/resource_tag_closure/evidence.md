# Resource/tag closure audit: 1.21.5–1.21.8

## Exact source identities and archive checks

The canonical source/client identities were verified against local cache pins, version metadata, and decompile provenance:

| Version | Client JAR SHA-256 | Mojang client object | Version metadata SHA-256 |
| --- | --- | --- | --- |
| 1.21.5 | `522672ad20b460c02c2e39b6c5035ef6a849af28eb11ab2ac7eb293d395a8c11` | recovered endpoint manifest + canonical `mojmap.ready.json` | endpoint metadata locator only |
| 1.21.6 | `9592df8587d6d3ec0334c873ad432dc76006d6129afdce9a7eac52638339a24a` | `740a125b83dd3447feaa3c5e891ead7fbb21ae28` | `ea1c91ccb9760c9f7e697c29ed679427dd20cdac9ce35937125e5690973df6dd` |
| 1.21.7 | `6d0aa64c6a0aee3270253317f51e9e816f94cd3b16b44f5d605615c39fc62fb9` | `a2db1ea98c37b2d00c83f6867fb8bb581a593e07` | `b7ebf2fb9a9cc655f874386a55731e87fa20d35fcbae43bb92ddb4df081fc51a` |
| 1.21.8 | `ea74e9c5e92d01f95f3d39196ddb734e19a077a58b4c433c34109487d600276f` | recovered endpoint manifest + canonical `mojmap.ready.json` | endpoint metadata locator only |

For .6 and .7, each client JAR hash matched its `client.jar.pin.json`, the matching client URL hash in `.decompile-provenance.json`, and Mojang version metadata's client SHA-1. Each `version.json` also matched its `version.json.pin.json` SHA-256. For .5 and .8, client JAR hashes matched both the recovered resource manifest and canonical `mojmap.ready.json`. Their recovered manifests mark current metadata as a locator (`historicalMetadataMatch: false`), not as the historical identity.

The .5 and .8 resource manifests each matched their complete extracted file sets, every extracted file hash, and every exact JAR entry. Counts: .5 = 579 tag JSON + 4 dimension types (583 total); .8 = 589 tag JSON + 4 dimension types (593 total). The .6 and .7 archives were read directly from the canonical cache; each contains 589 tag JSON + 4 dimension types (593 total).

## Direct adjacent comparisons

### 1.21.5 → 1.21.6

Exact differences are two dimension files and 17 tag files (11 added, 1 removed, 5 changed):

- `dimension_type/overworld.json` and `dimension_type/overworld_caves.json`: only `cloud_height` is added, with value `192` (rendering data; no movement field changes).
- Added block tags: `happy_ghast_avoids`, `triggers_ambient_desert_dry_vegetation_block_sounds`, `triggers_ambient_desert_sand_block_sounds`, `triggers_ambient_dried_ghast_block_sounds`.
- Removed block tag: `plays_ambient_desert_block_sounds`.
- `block/sand.json` and `item/sand.json` each remove a duplicate `minecraft:suspicious_sand` entry; effective membership is unchanged.
- Added empty dialog tags `pause_screen_additions`, `quick_actions`; entity tags `can_equip_harness`, `followable_friendly_mobs`; and item tags `happy_ghast_food`, `happy_ghast_tempt_items`, `harnesses`.
- `entity_type/dismounts_underwater` and `entity_type/fall_damage_immune` each gain `minecraft:happy_ghast`; `item/horse_food` gains `minecraft:carrot`.

No movement predicate block/fluid tag membership changes. The other changed tags concern sounds, happy-ghast/entity behavior, dialogs, or item content; the entity tags do not add the player entity.

### 1.21.7 → 1.21.8

No differences: all 589 `data/minecraft/tags/**/*.json` entries and all four `data/minecraft/dimension_type/*.json` entries have identical SHA-256 hashes across the exact client archives.

### Cross-check: 1.21.6 → 1.21.7

Direct archive comparison confirms 593 scoped entries on each side and one changed entry: `data/minecraft/tags/painting_variant/placeable.json`. No dimension-type entry changes.

## Disposition

Direct resource evidence closes both requested outer boundaries. No effective movement-related block/fluid tag membership changes across 1.21.5→1.21.6 or 1.21.7→1.21.8. Movement-relevant dimension defaults are unchanged; the only .5→.6 dimension delta is visual cloud height. Exact non-movement and duplicate-entry deltas are preserved above.
