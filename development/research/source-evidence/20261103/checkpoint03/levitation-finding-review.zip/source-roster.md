# Independent source roster: Levitation arrival fall-distance timing

Review scope: exact Mojmap source path from local player tick through ordinary living travel, entity movement, player edge backoff, and client effect update for 1.19.4 versus 1.20–1.20.4. No product code or Git history consulted before freezing this roster.

## Source identity checked

- Canonical read-only source root: `D:/Javastuff/LegacyParkourCompat/decompiled_minecraft/`.
- 1.19.4 Mojmap source manifest SHA-256: `6286e325371e085dfee1ab7987e66d4b6d1a984a49b6ec8ea730045cd24cecb3`; ready marker SHA-256: `59f59ab516d41eb97e09d63256ee26a68c15102052bf7acafdbd5440b72547d0`.
- 1.20.4 Mojmap source manifest SHA-256: `fd3c8668483e5ff208c847474f6cbd3952a909c4aa602ed98b24e3d11a9602a1`; ready marker SHA-256: `6225b97979420cc743c8b7156a0ce512ef27d0dbf48bfffbc40d3e1c8cb044d1`.
- Relevant endpoint source file SHA-256s independently recomputed: 1.19.4 `LivingEntity.java` `c8d91af61f87aaa1666de79696d7cd9d4a8212d05f873bdaf28d7bb2926bf165`, `Player.java` `5e4436afccb361156f8184e7a5cfd91d5b12dcfe8f5937b4ac23dd3edda737a2`, `Entity.java` `3667fee610cbc5f58012e3a8fb8d6c4849f649fb7fe5300595158112d8b4b58b`, `LocalPlayer.java` `8e7da18f42d09fbb994f522c2b0e65fcb2bb83cabb21024360299d44d9674c58`; 1.20.4 `LivingEntity.java` `f7bc53db24c1798f19f9bd6f6356c86d5e560e9c8e8aac60decaf15cc785e07d`, `Player.java` `218da60bc4f8c9279f56eb87e2cf2c0af79562fbe3d818a408429c656efb95dd`, `Entity.java` `07383522bff169938136638ef8c3244ca511b56ca4266913524f99f9821331b9`, `LocalPlayer.java` `bb5cbfb03656a1866bb77c00431618befe792081223b35db4bd121ecbb151fd5`.

## Independently derived call graph and gates

- `LocalPlayer.aiStep` delegates to superclass `aiStep` (1.19.4 line 795; 1.20.4 line 800). `LivingEntity.aiStep` reaches travel after its pre-travel state work (1.19.4 lines 2540–2551; 1.20.4 lines 2590–2604).
- 1.19.4 ordinary `LivingEntity.travel` invokes `handleRelativeFrictionAndCalculateMovement` at 2092; helper calls `move(MoverType.SELF, getDeltaMovement())` before return (2152–2162); Levitation adjusts the returned Y and resets fall distance after this call (2093–2096). The 1.20.4 helper still calls SELF move (2202–2213), but `LivingEntity.aiStep` resets fall distance for Slow Falling or Levitation before travel (2596–2604); the Levitation branch in travel has no reset (2143–2147).
- Across exact inspected 1.20, 1.20.1, 1.20.2, 1.20.3, 1.20.4 sources, `LivingEntity.aiStep` resets fall distance for Levitation before ordinary travel; `travel` dispatches to the same movement helper before its post-move Levitation velocity adjustment. Older 1.19.4 ordinary Levitation reset remains after helper/SELF move.
- `Entity.move` invokes virtual `maybeBackOffFromEdge` before collision resolution (1.19.4 lines 568–570; 1.20+ lines 612–616). `Player.maybeBackOffFromEdge` requires not flying, requested Y `<=0`, SELF/PLAYER mover, `isStayingOnGroundSurface()` (shift held, Player.java 308–310 in 1.19.4, 310–312 in 1.20.4), and `isAboveGround()`. `isAboveGround` is on-ground or `fallDistance < maxUpStep && !noCollision(box moved vertically by fallDistance - maxUpStep)` (1.19.4 lines 1095–1099; 1.20.4 lines 1102–1106). It trims horizontal deltas by 0.05 while the box moved down by `maxUpStep` has no collision.
- Client `handleUpdateMobEffect` ensures client-thread execution and adds the effect instance to the target LivingEntity (1.19.4 lines 1483–1500; 1.20.4 lines 1501–1518), allowing the effect to be present before the next local player tick.

## Frozen review conclusion

For a tick-start state with airborne `fallDistance >= maxUpStep`, `maxUpStep > 0`, not flying, crouch/shift held, nonpositive requested Y, nonzero horizontal SELF movement, and static support such that the current box is clear but the box shifted down by `maxUpStep` intersects support, old edge-backoff sees `isAboveGround == false`; after the 1.20+ pre-travel reset, it sees true. If horizontal request clears the shifted support box and a 0.05 reduction restores the support collision, 1.20+ reduces the requested horizontal move and tick position differs. Keep the witness constrained to Levitation arriving before this tick; continuously active Levitation is not the asserted old-version witness. Slow Falling is excluded.
