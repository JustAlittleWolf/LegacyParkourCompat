# Powder Snow inside-contact independent review

## Verdict

**Supported with a corrected witness.** The source difference is real and can affect local-player movement. A straight downward crossing of the upper 0.1 while `fallDistance > 2.5` is not a safe witness: the same fall-distance gate selects Powder Snow's 0.9-high collision shape, which can clip the descent before the player enters that interval. A reachable witness uses horizontal entry into that upper interval while falling beside the block.

## Exact source identity

The read-only canonical root was `D:\Javastuff\LegacyParkourCompat\decompiled_minecraft`. Both versions are ready exact Mojmap/Vineflower outputs from the recorded `1.21.1,1.21.3,1.21.4,1.21.5` batch, with `versionId` matching the directory and Mojmap mapping. The ready markers bind the source manifests and exact client jars:

| Version | Client SHA-256 | Source-manifest SHA-256 |
| --- | --- | --- |
| 1.21.4 Mojmap | `c17c450c6e72cc51297daa57ce38f800aa01cf022b743daa21a0512d326d894e` | `f90b61197928632e061ea877955a19055c92ae6f357c2daf1bc646172c6f51f0` |
| 1.21.5 Mojmap | `522672ad20b460c02c2e39b6c5035ef6a849af28eb11ab2ac7eb293d395a8c11` | `365cc2d22446ceba0e36f46aa1c95ce4cc31514dbd657505680fb660f3adefd9` |

The ready markers, provenance, manifests and every listed source-file digest were checked. Relevant Java source SHA-256 values (also present in the corresponding source manifest):

| Source | 1.21.4 | 1.21.5 |
| --- | --- | --- |
| `world/entity/Entity.java` | `05f18ef2ec0413fc010230407c812a11553eb5123b68d21b5d7b2c0c175698ad` | `fc177733e9cc4b2d5cf2562e5529d0f4e0b9c3690f081fbd58aa9119eb173dc4` |
| `world/entity/LivingEntity.java` | `e62ce650af0a5ac97e4d0a2ba7cad4ba68a8d098525609f8b5b6976a8ab0ae30` | `a8aed863d4fdc515c751dd2878a8bb9c13179228cb8dbb50edf1d19cd5404271` |
| `world/level/block/PowderSnowBlock.java` | `a018411167f5d8b60b131c3f6387dcdd256b736ef64126bdcf33fd4457151654` | `de72fb6e70616d7727bf324b0da4a98250cabd97ad39ecbe1062732d47f39770` |
| `world/level/block/state/BlockBehaviour.java` | `a549c5dcf7768f89f18519bdd2f985ef498d1bd4f6b329a30e0088e437819ddf` | `15418b0026919ef5ab97780a6ce8844677dc82d36cc4433a58f379b837d5cc50` |
| `world/level/BlockGetter.java` | `8bd936e3ecac5720a36b675f4910801e9d201e899b34c316c6d0be9a12d4da20` | `8494b6a560adcd84dec9340cae99a937fa98a5153fa02cf8764348c94c266d76` |
| `world/phys/AABB.java` | `1990e0e1058e9ac5201c32e51c6a5f9b671e7ed00ba863aacf2c5b7b0adff217` | `6cc796ada9d1c3880f3a96fd8323f71ccec2c195fcf05b32f22c1be0b375c372` |
| `client/player/LocalPlayer.java` | `145686ebdc7f0d12a64070309073665eb8695b7e09911a723e86113a77d04611` | `f1fcfed4a938732361e7ad951f93e9b73b02320ee56f0b219e2b3c7acdbfa2ef` |
| `world/entity/InsideBlockEffectType.java` | — | `2b3d7b27bc5242bc1394843a8c9ae227deb550c730d2a4c24dd3fb2b59df2d68` |

Reviewed input hashes:

| Input | SHA-256 |
| --- | --- |
| Candidate `powder-snow-inside-contact-shape.md` | `0e3bf4d330fb91365a9d7b5d37225504c9f116d84a000af6cea72a7b85b520d7` |
| State/block `provider-coverage.md` | `a72c29140cd2fae2cfcf800e4338b1408b2ae01c5a0ad9fd49eeee22d88a5418` |
| Tick `comparison.md` | `cf58e82cb6c9cfa39e7d261144edbc5ae42501a5f61593b78393fe5a3e575a05` |

## Independent trace and witness

* In 1.21.4, `BlockBehaviour.getEntityInsideCollisionShape` defaults to `Shapes.block()` and Powder Snow inherits that full block. `Entity.checkInsideBlocks` visits the Powder Snow cell along the moved player's box and invokes `entityInside` for that full-block shape. `PowderSnowBlock.entityInside` calls `makeStuckInBlock` for a `LivingEntity` whenever `getInBlockState()` is Powder Snow.
* In 1.21.5, `PowderSnowBlock.getEntityInsideCollisionShape` obtains the mover's `getCollisionShape` with `CollisionContext.of(entity)` and substitutes `Shapes.block()` only if that result is empty. When the entity's fall distance is above 2.5, `getCollisionShape` is `FALLING_COLLISION_SHAPE`, y=0..0.9. `checkInsideBlocks` then calls `entityInside` only if the previous box intersects that inside shape along its movement segment.
* Valid upper-slice witness: a normal standing local player is falling next to a Powder Snow block, with feet at `blockY + 0.95`, `fallDistance > 2.5`, and lateral input moving the player into the cell. The collision shape ends at `blockY + 0.9`, so the player's box has a 0.05 vertical gap and this horizontal move is not provider-clipped. The player's floored block position after entry is the Powder Snow cell. In 1.21.4 the full-block inside gate therefore calls `entityInside`; in 1.21.5 the collision-shape sweep cannot intersect: its shape expanded by half the player-box height ends at centerY `blockY + 0.9 + halfHeight`, while the player's center is `blockY + 0.95 + halfHeight`, above that bound throughout the horizontal segment.
* On the 1.21.4 callback, `makeStuckInBlock` resets fall distance and stores `(0.9F, 1.5, 0.9)`. `Entity.move` consumes a nonzero stuck multiplier on the next movement call by scaling the attempted movement, clearing the multiplier, and zeroing delta movement. This consumer is later than the callback and is reachable on the next local-player movement. The 1.21.5 callback is not sampled in this witness, so it stores no corresponding multiplier.
* The related friction-helper gate also has a concrete ordered difference in the same witness when the local player wears leather boots and keeps jump pressed. `LocalPlayer` copies that input to `jumping` before travel on both sides. The movement has no horizontal collision, so the branch's `(horizontalCollision || jumping)` gate is satisfied by `jumping`. After the move, 1.21.4 reads the current `getInBlockState()` and recognizes Powder Snow; 1.21.5 reads `wasInPowderSnow`, latched from the previous tick and false because the player had not occupied Powder Snow then. The old helper consequently takes the Powder Snow walkable-mob vertical response (`y = 0.2`); the new helper does not. Block effects are applied after travel in both `LivingEntity.aiStep` bodies, so a newly sampled Powder Snow callback cannot retroactively satisfy that tick's `wasInPowderSnow` check.

This witness does not rely on downward motion entering the 0.9 collision shape. A continued descent may later be clipped by that shape; that does not undo the already sampled old callback and its next-move stuck multiplier.

## Corrected candidate wording

Use the replacement in `corrected-finding.md` for reconciliation. It narrows the trajectory statement to the witnessed lateral entry and explicitly keeps provider clipping in view.

## Dependency gates and limits

The operation-level difference is source-supported and locally reachable with the stated player position, fall-distance gate, side movement and prior Powder-Snow state. The climb-response interaction additionally requires leather boots (or another `canEntityWalkOnPowderSnow` entity tag) and jump input held while airborne. It is independent of the collision-shape finding and should remain a separate resolved operation if implemented.

No runtime or tick-parity validation was performed. The precise patch introduction within the 1.21.4–1.21.5 interval is not established by this endpoint pair. Pair-wide coverage and unrelated provider/neighbor dependencies remain open; this review accepts only this bounded source finding and the stated witness.
